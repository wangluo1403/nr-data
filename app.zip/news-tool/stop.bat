@echo off
chcp 65001 >nul
title Stop Offline News Daemon
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop.ps1"
echo.
pause
