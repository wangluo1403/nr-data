# -*- coding: utf-8 -*-
"""B 站热门视频抓取。

热门榜接口和播放地址接口都不用登录、不用签名，直接就能拿到 mp4 直链，
所以「离线刷视频」这条路是通的。（抖音那边要 a_bogus 签名，直接 403，做不了。）

整个模块只用标准库，跟 newsd.py 一样零依赖。
"""

import json
import os
import ssl
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

API_POPULAR = "https://api.bilibili.com/x/web-interface/popular"
API_PAGELIST = "https://api.bilibili.com/x/player/pagelist"
API_PLAYURL = "https://api.bilibili.com/x/player/playurl"
API_REPLY = "https://api.bilibili.com/x/v2/reply/main"

REFERER = "https://www.bilibili.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

QN = 32                     # 16=360P 32=480P 64=720P
TIMEOUT = 15
DL_TIMEOUT = 90
CHUNK = 262144
WORKERS = 4

# 视频直链所在的 CDN 有时候证书链不全，准备一个宽松的兜底
_PLAIN = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_LAX = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))

_BV_RE = __import__("re").compile(r"^BV[0-9A-Za-z]{8,14}$")


def _open(url, timeout=TIMEOUT, referer=REFERER, extra=None):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", UA)
    req.add_header("Referer", referer)
    for k, v in (extra or {}).items():
        req.add_header(k, v)
    try:
        return _PLAIN.open(req, timeout=timeout)
    except Exception:
        return _LAX.open(req, timeout=timeout)


def _json(url, timeout=TIMEOUT):
    with _open(url, timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def fetch_popular(count=50):
    """热门榜，翻页凑够 count 条。接口坏掉就返回拿到的那部分。"""
    out, pn = [], 1
    while len(out) < count and pn <= 4:
        try:
            d = _json("%s?ps=50&pn=%d" % (API_POPULAR, pn))
        except Exception:
            break
        if d.get("code") != 0:
            break
        lst = (d.get("data") or {}).get("list") or []
        if not lst:
            break
        out.extend(lst)
        pn += 1

    seen, uniq = set(), []
    for v in out:
        bv = v.get("bvid") or ""
        if not bv or bv in seen:
            continue
        seen.add(bv)
        uniq.append(v)
    return uniq[:count]


def get_cid(bvid, fallback=0):
    try:
        d = _json("%s?bvid=%s" % (API_PAGELIST, bvid))
    except Exception:
        return fallback
    if d.get("code") != 0:
        return fallback
    lst = d.get("data") or []
    return int((lst[0] or {}).get("cid") or fallback) if lst else fallback


def get_playurl(bvid, cid, qn=QN):
    """拿 mp4 直链，返回 (url, 字节数, 实际清晰度)。拿不到就三个 0/空。"""
    u = ("%s?bvid=%s&cid=%s&qn=%d&fnval=1&fnver=0&fourk=1"
         % (API_PLAYURL, bvid, cid, qn))
    try:
        d = _json(u)
    except Exception:
        return "", 0, 0
    if d.get("code") != 0:
        return "", 0, 0
    dd = d.get("data") or {}
    for x in (dd.get("durl") or []):
        if x.get("url"):
            return x["url"], int(x.get("size") or 0), int(dd.get("quality") or 0)
    return "", 0, 0


def get_comments(aid, limit=6):
    """抓几条热门评论。抓不到就返回空表，别给视频本体添麻烦。"""
    if not aid:
        return []
    u = "%s?type=1&oid=%s&mode=3&ps=%d" % (API_REPLY, aid, max(limit, 10))
    try:
        d = _json(u)
    except Exception:
        return []
    if d.get("code") != 0:
        return []
    out = []
    for r in ((d.get("data") or {}).get("replies") or []):
        msg = ((r.get("content") or {}).get("message") or "").strip()
        if not msg:
            continue
        out.append({
            "user": ((r.get("member") or {}).get("uname") or "").strip(),
            "text": msg[:200],
            "like": int(r.get("like") or 0),
        })
        if len(out) >= limit:
            break
    return out


def _download(url, path, max_bytes=0, timeout=DL_TIMEOUT, referer=REFERER,
              throttle=None):
    """先写 .part 再改名，中途出错不会留半个文件。

    throttle 是外部传进来的限速钩子（收字节数），别把热点占满。
    """
    tmp = path + ".part"
    total = 0
    try:
        with _open(url, timeout, referer) as r:
            with open(tmp, "wb") as f:
                while True:
                    chunk = r.read(CHUNK)
                    if not chunk:
                        break
                    total += len(chunk)
                    if max_bytes and total > max_bytes:
                        raise ValueError("超过体积上限")
                    f.write(chunk)
                    if throttle:
                        throttle(len(chunk))
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    if total <= 0:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise ValueError("下到 0 字节")
    os.replace(tmp, path)
    return total


def _vpic(pic):
    if not pic:
        return ""
    if pic.startswith("//"):
        return "https:" + pic
    return pic.replace("http://", "https://", 1)


def fetch_all(video_dir, count=50, keep=150, max_duration=600, qn=QN,
              max_bytes=80 * 1024 * 1024, comments=6, log=print, throttle=None):
    """抓 B 站热门视频存到 video_dir，返回（新的在前）视频索引列表。

    已经下过的不重复下。最后按 keep 裁一刀，多出来的 mp4 和封面一起删掉。
    throttle 是外部传进来的限速钩子，透传给 _download。
    """
    os.makedirs(video_dir, exist_ok=True)

    log("去 B 站热门榜挑视频…")
    raw = fetch_popular(max(count * 2, 40))
    if not raw:
        log("热门榜没拿到东西，这轮跳过")
        return []

    cands, too_long = [], 0
    for v in raw:
        dur = int(v.get("duration") or 0)
        if dur <= 0:
            continue
        if max_duration and dur > max_duration:
            too_long += 1
            continue
        cands.append(v)
        if len(cands) >= count:
            break
    log("热门榜 %d 条，%d 条超过 %d 分钟不要，挑中 %d 条"
        % (len(raw), too_long, max_duration // 60, len(cands)))

    fails = []

    def one(v):
        bv = v.get("bvid") or ""
        if not _BV_RE.match(bv):
            return None
        mp4 = os.path.join(video_dir, bv + ".mp4")
        jpg = os.path.join(video_dir, bv + ".jpg")
        size, quality = 0, 0

        if os.path.exists(mp4) and os.path.getsize(mp4) > 0:
            size = os.path.getsize(mp4)
        else:
            cid = int(v.get("cid") or 0) or get_cid(bv)
            if not cid:
                fails.append((bv, "拿不到 cid"))
                return None
            url, size_hint, quality = get_playurl(bv, cid, qn)
            if not url:
                fails.append((bv, "拿不到播放地址"))
                return None
            try:
                size = _download(url, mp4, max_bytes, throttle=throttle)
            except Exception as e:
                fails.append((bv, "%s: %s" % (type(e).__name__, str(e)[:60])))
                return None

        pic_local = ""
        if not (os.path.exists(jpg) and os.path.getsize(jpg) > 0):
            src = _vpic(v.get("pic"))
            if src:
                try:
                    _download(src, jpg, 4 * 1024 * 1024, 20,
                              referer="https://www.bilibili.com/", throttle=throttle)
                except Exception:
                    pic_local = ""
        if os.path.exists(jpg):
            pic_local = "videos/" + bv + ".jpg"

        st = v.get("stat") or {}
        owner = v.get("owner") or {}
        aid = int(v.get("aid") or 0)
        return {
            "id": bv,
            "aid": aid,
            "title": (v.get("title") or "").strip(),
            "up": (owner.get("name") or "").strip(),
            "up_mid": owner.get("mid") or 0,
            "duration": int(v.get("duration") or 0),
            "desc": (v.get("desc") or "").strip()[:300],
            "pic": pic_local,
            "file": "videos/" + bv + ".mp4",
            "size": size,
            "quality": quality,
            "comments": get_comments(aid, comments) if comments else [],
            "view": int(st.get("view") or 0),
            "like": int(st.get("like") or 0),
            "danmaku": int(st.get("danmaku") or 0),
            "pub_ts": int(v.get("pubdate") or 0),
            "added_ts": time.time(),
            "url": "https://www.bilibili.com/video/" + bv,
        }

    items, done = [], 0
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        for r in ex.map(one, cands):
            done += 1
            if r:
                items.append(r)
            if done % 10 == 0:
                log("视频下到 %d/%d" % (done, len(cands)))

    items.sort(key=lambda x: x.get("added_ts") or 0, reverse=True)
    total_mb = sum(i["size"] for i in items) / 1048576.0
    log("视频抓到 %d/%d 个，共 %.0f MB" % (len(items), len(cands), total_mb))
    if fails:
        log("有 %d 个没下来：%s"
            % (len(fails), "；".join("%s %s" % f for f in fails[:5])))

    if keep and len(items) > keep:
        drop = items[keep:]
        items = items[:keep]
        freed = 0
        for it in drop:
            for p in (os.path.join(video_dir, it["id"] + ".mp4"),
                      os.path.join(video_dir, it["id"] + ".jpg")):
                try:
                    freed += os.path.getsize(p)
                    os.remove(p)
                except OSError:
                    pass
        log("视频留最近 %d 个，删掉 %d 个，腾出 %.0f MB"
            % (keep, len(drop), freed / 1048576.0))

    return items


def prune(video_dir, items, keep=150, log=print):
    """按索引把不在名单里的 mp4 / 封面删掉（比如手工删过索引）。"""
    if not os.path.isdir(video_dir):
        return
    alive = set()
    for it in items[:keep] if keep else items:
        for key in ("file", "pic"):
            v = it.get(key) or ""
            if v.startswith("videos/"):
                alive.add(os.path.basename(v))
    freed = 0
    for fn in os.listdir(video_dir):
        if fn in alive or fn.endswith(".part"):
            continue
        p = os.path.join(video_dir, fn)
        if not os.path.isfile(p):
            continue
        try:
            freed += os.path.getsize(p)
            os.remove(p)
        except OSError:
            pass
    if freed:
        log("清掉 %d 个没人引用的视频文件，腾出 %.0f MB" % (0, freed / 1048576.0))
