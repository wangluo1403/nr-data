# -*- coding: utf-8 -*-
"""
music.py — 本地点歌台

跟 videos.py / search.py 不一样的定位：这里**不下载任何东西**。
你自己往 data/music/ 里丢歌，这个模块只负责扫出来、读标签、抽封面，
前端做成播放器的样子给你听。

为什么不去网易云抓：
  1. 那些歌有版权，未登录拿不到完整音质，绕过去就是侵权
  2. 这个工具是离线用的，抓到本地等于永久保存，性质更重

支持 mp3 / flac / m4a / ogg / wav / aac / wma / ape。
标签优先读 ID3v2（mp3 最常见），读不到就退回文件名「歌手 - 歌名」。

依赖：纯标准库。
"""

import os
import re
import hashlib

AUDIO_EXT = (".mp3", ".flac", ".m4a", ".ogg", ".wav", ".aac", ".wma", ".ape",
             ".opus", ".aiff")

# 「01. 歌手 - 歌名」「歌手-歌名」这类文件名，实在没标签时拿来兜底
_NAME_RE = re.compile(r"^\s*(?:\d{1,3}[.\-_、\s]+)?(.+?)\s*[-–—]\s*(.+?)\s*$")

_COVER_EXT = {b"image/jpeg": ".jpg", b"image/jpg": ".jpg",
              b"image/png": ".png", b"image/webp": ".webp"}

# ID3v2 里我们要的帧
_WANT_FRAMES = {b"TIT2": "title", b"TPE1": "artist", b"TALB": "album",
                b"APIC": "cover"}
# 歌词帧（USLT）结构跟文本帧不一样：编码(1) + 语言(3) + 描述 + 正文，
# 所以单独处理，不塞进 _WANT_FRAMES。


def _decode_text(raw: bytes, enc: int) -> str:
    """ID3v2 文本帧的编码字节：0=latin1 1=utf16(带BOM) 2=utf16be 3=utf8。"""
    try:
        if enc == 0:
            return raw.rstrip(b"\x00").decode("latin-1", "replace")
        if enc == 1:
            return raw.decode("utf-16", "replace").strip("\x00").strip()
        if enc == 2:
            return raw.decode("utf-16-be", "replace").strip("\x00").strip()
        return raw.decode("utf-8", "replace").strip("\x00").strip()
    except Exception:  # noqa: BLE001
        return ""


def _syncsafe(n: bytes) -> int:
    """ID3v2 的长度字段是「每字节只用低 7 位」的 syncsafe 整数。"""
    return ((n[0] & 0x7F) << 21) | ((n[1] & 0x7F) << 14) | \
           ((n[2] & 0x7F) << 7) | (n[3] & 0x7F)


def read_id3v2(path: str) -> dict:
    """读 ID3v2.2/2.3/2.4 的头，返回 {title, artist, album, cover: bytes}。

    只认少数几个帧，别的一律跳过 —— 我们要的就是歌名、歌手、专辑、封面。
    """
    out = {}
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(10)
            if len(head) < 10 or head[:3] != b"ID3":
                return out
            ver = head[3]
            tag_size = _syncsafe(head[6:10])
            body = f.read(min(tag_size, 8 * 1024 * 1024))
    except OSError:
        return out

    pos = 0
    id_len = 3 if ver == 2 else 4
    hdr_len = 6 if ver == 2 else 10
    while pos + hdr_len <= len(body):
        fid = body[pos:pos + id_len]
        if not fid.strip(b"\x00"):
            break
        if ver == 2:
            fsize = int.from_bytes(body[pos + 3:pos + 6], "big")
        elif ver == 4:
            fsize = _syncsafe(body[pos + 4:pos + 8])
        else:
            fsize = int.from_bytes(body[pos + 4:pos + 8], "big")
        if fsize <= 0 or pos + hdr_len + fsize > len(body):
            break
        data = body[pos + hdr_len:pos + hdr_len + fsize]

        # v2.2 用三位 ID，映射到常见的四个
        name = {b"TT2": b"TIT2", b"TP1": b"TPE1", b"TAL": b"TALB",
                b"PIC": b"APIC"}.get(fid, fid)
        key = _WANT_FRAMES.get(name)

        if fid == b"USLT" and data and len(data) > 4:
            enc = data[0]
            rest = data[4:]          # 跳过语言码
            if enc in (1, 2):
                # utf-16：描述也是两个字节一个字符，找 00 00
                for i in range(0, min(len(rest) - 1, 400), 2):
                    if rest[i] == 0 and rest[i + 1] == 0:
                        rest = rest[i + 2:]
                        break
            else:
                z = rest.find(b"\x00")
                if 0 <= z < 400:
                    rest = rest[z + 1:]
            txt = _decode_text(rest, enc)
            if txt:
                out["lyrics"] = txt
        elif key and key != "cover" and data:
            out[key] = _decode_text(data[1:], data[0])
        elif key == "cover" and data:
            enc = data[0]
            rest = data[1:]
            # 图片格式：v2.3 是 image/xxx\0，v2.2 是 3 字节
            if ver == 2:
                mime = rest[:3]
                rest = rest[3:]
                ext = b"image/" + (b"jpeg" if b"JPG" in mime.upper() else mime.lower())
            else:
                z = rest.find(b"\x00")
                if z < 0:
                    pos += hdr_len + fsize
                    continue
                ext = rest[:z].lower()
                rest = rest[z + 1:]
            # 一张描述文字（同样用 enc 编码），之后才是图片数据
            if enc == 1 or enc == 2:
                if len(rest) >= 2:
                    for i in range(0, min(len(rest) - 1, 400), 2):
                        if rest[i] == 0 and rest[i + 1] == 0:
                            rest = rest[i + 2:]
                            break
            else:
                z = rest.find(b"\x00")
                if 0 <= z < 400:
                    rest = rest[z + 1:]
            if rest:
                out["cover"] = rest
                out["cover_ext"] = _COVER_EXT.get(ext, b".jpg")
        pos += hdr_len + fsize
    return out


def read_id3v1(path: str) -> dict:
    """最老的 ID3v1：文件最后 128 字节，只在没有 v2 时兜底用。"""
    out = {}
    try:
        with open(path, "rb") as f:
            f.seek(-128, os.SEEK_END)
            tail = f.read(128)
    except OSError:
        return out
    if len(tail) < 128 or tail[:3] != b"TAG":
        return out
    for key, a, b in (("title", 3, 33), ("artist", 33, 63), ("album", 63, 93)):
        v = tail[a:b].split(b"\x00")[0]
        try:
            out[key] = v.decode("gbk", "replace").strip()
        except Exception:  # noqa: BLE001
            out[key] = v.decode("latin-1", "replace").strip()
    return out


def _from_filename(path: str) -> dict:
    stem = os.path.splitext(os.path.basename(path))[0]
    m = _NAME_RE.match(stem)
    if m:
        return {"artist": m.group(1).strip(), "title": m.group(2).strip()}
    return {"title": stem.strip()}


_SIDECAR_EXT = (".jpg", ".jpeg", ".png", ".webp", ".gif")


def read_sidecar_cover(audio_path: str) -> str:
    """读同目录、同名的封面图（下歌时存下来的那张）。找不到返回空串。"""
    base = os.path.splitext(audio_path)[0]
    for ext in _SIDECAR_EXT:
        path = base + ext
        if os.path.isfile(path):
            return path
    return ""


def read_sidecar_text(audio_path: str, suffix: str) -> str:
    """读同名后缀的文本文件（.tlrc 这种）。编码先 utf-8 再 gbk。"""
    path = os.path.splitext(audio_path)[0] + suffix
    if not os.path.isfile(path):
        return ""
    try:
        with open(path, "rb") as f:
            raw = f.read(256 * 1024)
    except OSError:
        return ""
    for enc in ("utf-8-sig", "gbk", "utf-16"):
        try:
            return raw.decode(enc).strip()
        except (UnicodeDecodeError, UnicodeError):
            continue
    return raw.decode("utf-8", "replace").strip()


def read_lrc(audio_path: str) -> str:
    """读同名 .lrc。编码先试 utf-8（网易云给的就是这个），不行再 gbk。

    返回空串表示没歌词，这很正常 —— 没歌词不该当成错误。
    """
    base = os.path.splitext(audio_path)[0]
    for ext in (".lrc", ".LRC"):
        path = base + ext
        if not os.path.isfile(path):
            continue
        try:
            with open(path, "rb") as f:
                raw = f.read(256 * 1024)
        except OSError:
            continue
        for enc in ("utf-8-sig", "gbk", "utf-16"):
            try:
                return raw.decode(enc).strip()
            except (UnicodeDecodeError, UnicodeError):
                continue
        return raw.decode("utf-8", "replace").strip()
    return ""


def scan(music_dir: str, cover_dir: str) -> list[dict]:
    """扫 data/music/，返回曲目列表。封面抽出来单独存，别塞进 JSON。"""
    if not os.path.isdir(music_dir):
        return []

    out = []
    for name in sorted(os.listdir(music_dir)):
        full = os.path.join(music_dir, name)
        if not os.path.isfile(full):
            continue
        if os.path.splitext(name)[1].lower() not in AUDIO_EXT:
            continue

        try:
            size = os.path.getsize(full)
        except OSError:
            continue
        if size < 1024:
            continue

        tags = {}
        if name.lower().endswith(".mp3"):
            tags = read_id3v2(full) or read_id3v1(full)
        elif name.lower().endswith(".flac"):
            # FLAC 的 Vorbis comment 结构复杂，先用文件名顶上
            tags = {}

        meta = _from_filename(full)
        meta.update({k: v for k, v in tags.items() if v and k != "cover"})

        # 歌词：优先同名 .lrc（带时间轴，能滚动），其次内嵌 USLT（纯文本）
        lrc = read_lrc(full) or tags.get("lyrics") or ""
        # 翻译单独一份（.tlrc），播放器会把每行中文挂到原句下面
        tlrc = read_sidecar_text(full, ".tlrc")

        item = {
            "id": hashlib.sha1(name.encode("utf-8")).hexdigest()[:12],
            "file": "music/" + name,
            "name": name,
            "title": meta.get("title") or os.path.splitext(name)[0],
            "artist": meta.get("artist") or "",
            "album": meta.get("album") or "",
            "size": size,
            "cover": "",
            "lrc": lrc[:40000] if isinstance(lrc, str) else "",
            "tlrc": tlrc[:40000] if isinstance(tlrc, str) else "",
        }

        blob = tags.get("cover")
        if not blob:
            # 没有内嵌封面 —— 看看下歌时存的同名图片在不在
            side = read_sidecar_cover(full)
            if side:
                try:
                    with open(side, "rb") as f:
                        blob = f.read()
                    ext_map = {".jpg": b".jpg", ".jpeg": b".jpg", ".png": b".png",
                               ".webp": b".webp", ".gif": b".gif"}
                    tags = dict(tags)
                    tags["cover_ext"] = ext_map.get(
                        os.path.splitext(side)[1].lower(), b".jpg")
                except OSError:
                    blob = None
        if blob and len(blob) > 512:
            ext = (tags.get("cover_ext") or b".jpg").decode("ascii", "ignore")
            if not ext.startswith("."):
                ext = ".jpg"
            cname = item["id"] + ext
            cpath = os.path.join(cover_dir, cname)
            if not os.path.exists(cpath):
                try:
                    os.makedirs(cover_dir, exist_ok=True)
                    with open(cpath, "wb") as f:
                        f.write(blob)
                except OSError:
                    cname = ""
            if cname:
                item["cover"] = "music_cover/" + cname

        out.append(item)

    # 按「歌手 + 歌名」排，同专辑的挨在一起
    out.sort(key=lambda x: ((x["artist"] or "zzz").lower(), x["title"].lower()))
    return out


def prune_covers(cover_dir: str, items: list[dict]) -> int:
    """删掉已经没人引用的封面文件，返回删了几个。"""
    if not os.path.isdir(cover_dir):
        return 0
    keep = {os.path.basename(it["cover"]) for it in items if it.get("cover")}
    removed = 0
    for name in os.listdir(cover_dir):
        if name in keep:
            continue
        try:
            os.remove(os.path.join(cover_dir, name))
            removed += 1
        except OSError:
            pass
    return removed
