# uninstall-autostart.ps1 - remove the Startup shortcut created by install-autostart.ps1

$ErrorActionPreference = "SilentlyContinue"

$startup = [Environment]::GetFolderPath('Startup')
$lnkPath = Join-Path $startup "OfflineNews.lnk"

if (Test-Path $lnkPath) {
    Remove-Item $lnkPath -Force
    Write-Host "[OK] autostart removed."
} else {
    Write-Host "[i] no autostart shortcut found."
}
