#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
newsd.py — 离线新闻抓取守护进程（纯标准库，零依赖）

干两件事：
  1. 盯网络：距上次抓满 3 小时就切进「每秒探测」模式，一连上网立刻抓新闻，
     存成 Markdown 文档 + JSON 数据 + 本地封面图（图下不下来的就只存文字）。
  2. 起本地小站：把抓好的东西给浏览器看，断网照样翻。

常用命令：
    python newsd.py              # 守护 + 网页服务（正常用法）
    python newsd.py --fetch      # 立刻抓一次就退出
    python newsd.py --check      # 只测一下网络通不通
    python newsd.py --no-serve   # 只守护抓取，不起网页
    python newsd.py --port 8765  # 指定端口
"""

from __future__ import annotations

import argparse
import hashlib
import html as html_mod
import json
import os
import re
import shutil
import socket
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# 便携版 Python（python\ 子目录里的 embeddable 包）默认找不到脚本所在目录，
# 这里手动补一下，免得换台电脑就 import 不到 sources。
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from sources import CATEGORIES, DEFAULT_LIMIT, SOURCES

try:
    import videos as vmod
except Exception as _e:  # noqa: BLE001
    vmod = None
    print("videos 模块没加载上，视频功能关掉：%s" % _e)

try:
    import music as musicmod
except Exception as _e:  # noqa: BLE001
    musicmod = None
    print("music 模块没加载上，点歌台关掉：%s" % _e)

try:
    import config as cfgr
except Exception as _e:  # noqa: BLE001
    cfgr = None
    print("config 模块没加载上，设置面板关掉：%s" % _e)

try:
    import search as searchmod
except Exception as _e:  # noqa: BLE001
    searchmod = None
    print("search 模块没加载上，必应搜索关掉：%s" % _e)

try:
    import mirror as mirrormod
except Exception as _e:  # noqa: BLE001
    mirrormod = None
    print("mirror 模块没加载上，网页镜像关掉：%s" % _e)

try:
    import sched as schedmod
except Exception as _e:  # noqa: BLE001
    schedmod = None
    print("sched 模块没加载上，任务队列关掉：%s" % _e)

try:
    import library as libmod
except Exception as _e:  # noqa: BLE001
    libmod = None
    print("library 模块没加载上，收藏归档关掉：%s" % _e)

try:
    import netmusic
except Exception as _e:  # noqa: BLE001
    netmusic = None
    print("netmusic 模块没加载上，联网抓歌关掉：%s" % _e)

try:
    import anime_site as sitesmod
except Exception as _e:  # noqa: BLE001
    sitesmod = None
    print("anime_site 模块没加载上，小站追番关掉：%s" % _e)

try:
    import bili as bilimod
except Exception as _e:  # noqa: BLE001
    bilimod = None
    print("bili 模块没加载上，B 站下载关掉：%s" % _e)

try:
    import bilipage as bpmod
except Exception as _e:  # noqa: BLE001
    bpmod = None
    print("bilipage 模块没加载上，B 站页面状态关掉：%s" % _e)

try:
    import anime as animemod
except Exception as _e:  # noqa: BLE001
    animemod = None
    print("anime 模块没加载上，追番追漫关掉：%s" % _e)

try:
    import license as licmod
except Exception as _e:  # noqa: BLE001
    licmod = None
    print("license 模块没加载上，激活码关掉：%s" % _e)

try:
    import usbkey as usbmod
except Exception as _e:  # noqa: BLE001
    usbmod = None
    print("usbkey 模块没加载上，U 盘钥匙关掉：%s" % _e)

# ══════════════════════════════════════════════════════════════════════
#  配置
# ══════════════════════════════════════════════════════════════════════

# v0.3 改了节奏：不再「等满 3 小时才去探网」。
# 现在是一直探（IDLE_POLL 秒一次），一发现能上网就干活；
# 用 ONLINE_DEDUPE 这个窗口防止「热点断一下又连上」把同一批东西重下一遍。
# 断网之后先安静等这么久，再开始试探联网。
# 注意：抓取完成之后**不计时**；计时是在「发现断网」那一刻才开始。
ONLINE_DEDUPE = 20 * 60
ROUND_BUDGET = 15 * 60         # 一次联网最多干多久（秒），到点停手留给下次
DISK_MIN_BYTES = 800 * 1024 * 1024   # 剩余空间低于这个数就不再下载
IDLE_POLL = 20.0               # 多久探一次网（秒）
DEFAULT_PORT = 8765

NET_TIMEOUT = 8                # 普通请求超时
IMG_TIMEOUT = 12               # 图片请求超时
IMG_MAX_BYTES = 3 * 1024 * 1024
IMG_MIN_BYTES = 1024           # 小于这个基本是占位图，扔掉
SUMMARY_LEN = 220

WORKERS_FEED = 6               # 抓源的并发（别太猛，留点带宽给别的任务）
WORKERS_IMG = 6                # 下图并发
MAX_IMAGES_PER_SOURCE = 6      # 每个源最多下几张封面（控磁盘，一张约 300KB）
ENRICH_IMAGES = True           # RSS 里没图时，去原文页抠 og:image
MAX_ENRICH_PER_SOURCE = 4      # 每个源最多补几篇（补多了抓取会变慢）

KEEP_SNAPSHOTS = 6             # 最多留多少份历史快照（3 小时一份 ≈ 18 小时）
                               # 正文功能开了之后一份快照 ~50MB，别留太多
MAX_AGE_DAYS = 14              # 超过这个天数的旧闻直接扔掉（0 = 不过滤）
                               # 更新慢的源可以在 sources.py 里用 max_age_days 单独放宽

# ── 正文（点开卡片看的本地全文） ──
FETCH_ARTICLE = True           # 抓正文存本地。关掉就只剩摘要，能省不少时间和磁盘
MAX_ARTICLES_PER_SOURCE = 5    # 每个源最多给几篇配正文
MIN_RSS_CHARS = 700            # RSS 自带的正文够长就不去抓页面了
MAX_ARTICLE_CHARS = 10000      # 一篇正文最多存多少字
MAX_ARTICLE_IMAGES = 4         # 一篇正文最多留几张图
MIN_PARA_CHARS = 15            # 短于这个长度不算一个段落
ARTICLE_TIMEOUT = 12
ARTICLE_MAX_BYTES = 1200 * 1024

# ── 本地短视频（B 站热门榜） ──
FETCH_VIDEO = True             # 抓 B 站热门视频存本地，跟新闻一起下
VIDEO_COUNT = 50               # 一轮抓几个
VIDEO_KEEP = 150               # 最多留几个，超了从最旧的开始删
VIDEO_MAX_DURATION = 600       # 超过这个秒数的视频不要（10 分钟）
VIDEO_QN = 32                  # 16=360P 32=480P 64=720P
VIDEO_MAX_BYTES = 80 * 1024 * 1024   # 单个视频最大多少字节

# ── 必应搜索（结果单独放「搜索」标签页，不混进新闻流） ──
SEARCH_KEYWORDS = []           # 想搜的关键词，一行一个
SEARCH_NEWS = True             # 除了网页，再多搜一路必应新闻
SEARCH_FETCH_ARTICLE = True    # 搜索结果也抓正文，抓了才能断网读全文
SEARCH_PER_KEYWORD = 10        # 每个关键词留几条

# ── 点歌台（网易云公开榜单，见 netmusic.py） ──
MUSIC_ENABLED = True           # 联网时顺手抓几首歌
MUSIC_PER_RUN = 4              # 一次抓几首
MUSIC_CHARTS = ["热歌榜", "新歌榜"]   # 从哪些榜里挑
MUSIC_KEEP = 200               # 本地最多留几首
MUSIC_MAX_BYTES = 20 * 1024 * 1024   # 单首歌最大多少（防止下到奇怪的巨物）

# ── B 站首页推荐 + 关键词搜索（只存条目，不下视频） ──
BILI_REC_ENABLED = True
BILI_REC_COUNT = 12
BILI_KEYWORDS = []             # 每次联网轮流搜一个词
BILI_SEARCH_COUNT = 8
BILI_REC_DL = 3                # 每次联网从"新推荐"里自动挑几个下（0 = 不下）

# ── 追番 / 追漫 ──
ANIME_ENABLED = True
ANIME_AUTO_FOLLOW = True       # 追更列表空着时，自动按关键词追几部
ANIME_KEYWORDS = ["凡人修仙传", "鬼灭之刃", "间谍过家家",
                  "葬送的芙莉莲", "咒术回战", "进击的巨人"]
# 小站（OmoFun）追番：分段下载，一集分几百片，断了下次接着下
ANIME_SITE_MAX_SEG = 60       # 一次联网最多下几片（控制窗口内时长）

# ── 权限与菜单（v0.5） ──
BOOT_MODE = "password"         # password=开屏要口令 / direct=直接进新闻
ADMIN_PASSWORD_ON = True       # 管理员口令（只能禁用，不能改）
L1_SEARCH = True               # 一级菜单给不给搜索
L1_LIBRARY = True              # 一级菜单给不给收藏/归档
WEEKDAY_OPEN = [1, 2, 3, 4, 5, 6, 7]
USB_BYPASS_TIME = True
EXAM_LOCK = False
HIDE_LOG = False
HIDE_BUTTONS = False
LOCK_SETTINGS = False
FEAT_VIDEO = True
FEAT_MUSIC = True
FEAT_BILI = True
FEAT_ANIME = True
FEAT_MIRROR = True
FEAT_SEARCH = True
UPDATE_AUTO = False
UPDATE_INTERVAL_H = 24
PROXY = ""                     # 形如 http://127.0.0.1:7890，空 = 直连
PASSWORD_ON = True             # 老的机器码密码（保留兼容，默认不用了）
UPDATE_REPO = ""               # GitHub 用户名/仓库名，U 盘插上时去拉新版
CLOUD_URL = ""                 # 云端禁用名单（一个 JSON 地址）

# ── 离线网页镜像 ──
MIRROR_JS = False              # 连 JavaScript 一起扒（文件大，有些站脚本会外连）
MIRROR_MAX_BYTES = 20 * 1024 * 1024
MIRROR_KEEP = 30               # 最多留几个镜像，超了删最旧的
MIRROR_AUTO = False            # 每轮顺手把搜索到的前几个页面也扒了
MIRROR_AUTO_COUNT = 3
# 搜索结果要不要顺手扒整页（「正文 / 原网页」那个切换得有东西可切）
SEARCH_MIRROR = True
SEARCH_MIRROR_COUNT = 6        # 每次搜索最多扒几篇整页
SEARCH_MIRROR_MB = 8           # 单篇上限

# ── 自定义抓取地址（RSS 和普通网页都行，自动判断） ──
CUSTOM_SOURCES = []

# ── 全局限速（别把热点占满，老师那边网页打不开就该来抓人了） ──
# 所有下载（源 + 正文页 + 封面图 + 正文配图 + 视频）加起来的带宽上限，字节/秒。
# 0 = 不限速。1536*1024 ≈ 1.5 MB/s ≈ 12 Mbps。
# 算一笔账：一轮下来新闻带图约 110MB，视频约 600MB，合计 ~750MB。
#   1.5MB/s → 8.5 分钟    1MB/s → 12.5 分钟    0.5MB/s → 25 分钟
# 一节课 40 分钟，就算按 0.5MB/s 也来得及，所以放心慢慢下。
MAX_RATE_BYTES = 1536 * 1024

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
SNAP_DIR = os.path.join(DATA_DIR, "snapshots")
DOCS_DIR = os.path.join(DATA_DIR, "docs")
IMG_DIR = os.path.join(DATA_DIR, "images")
VIDEO_DIR = os.path.join(DATA_DIR, "videos")
VIDEO_INDEX = os.path.join(DATA_DIR, "videos.json")
WEB_DIR = os.path.join(BASE_DIR, "web")
STATE_FILE = os.path.join(DATA_DIR, "state.json")
LATEST_FILE = os.path.join(DATA_DIR, "latest.json")
INDEX_FILE = os.path.join(DATA_DIR, "index.json")
LOG_FILE = os.path.join(DATA_DIR, "newsd.log")
LOCK_FILE = os.path.join(DATA_DIR, "newsd.lock")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
SEARCH_FILE = os.path.join(DATA_DIR, "search.json")
MIRROR_DIR = os.path.join(DATA_DIR, "mirror")
MIRROR_INDEX = os.path.join(DATA_DIR, "mirror.json")
MUSIC_DIR = os.path.join(DATA_DIR, "music")
MUSIC_COVER_DIR = os.path.join(DATA_DIR, "music_cover")
MUSIC_INDEX = os.path.join(DATA_DIR, "music.json")
QUEUE_FILE = os.path.join(DATA_DIR, "queue.json")
LIB_FILE = os.path.join(DATA_DIR, "library.json")
ANIME_FILE = os.path.join(DATA_DIR, "anime.json")
FOLLOWS_FILE = os.path.join(DATA_DIR, "follows.json")
LICENSE_FILE = os.path.join(DATA_DIR, "license.json")

for _d in (DATA_DIR, SNAP_DIR, DOCS_DIR, IMG_DIR, VIDEO_DIR, MIRROR_DIR,
           MUSIC_DIR, MUSIC_COVER_DIR):
    os.makedirs(_d, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

# ══════════════════════════════════════════════════════════════════════
#  HTTP 客户端（显式禁用代理：目标都是国内站，直连最稳）
# ══════════════════════════════════════════════════════════════════════

_CTX_VERIFY = ssl.create_default_context()
_CTX_LAX = ssl.create_default_context()
_CTX_LAX.check_hostname = False
_CTX_LAX.verify_mode = ssl.CERT_NONE

def _build_openers(proxy: str = ""):
    """按代理设置建两个 opener。proxy 形如 http://127.0.0.1:7890，空 = 直连。"""
    proxy = (proxy or "").strip()

    def mk(ctx):
        h = (urllib.request.ProxyHandler({"http": proxy, "https": proxy})
             if proxy else urllib.request.ProxyHandler({}))
        return urllib.request.build_opener(h, urllib.request.HTTPSHandler(context=ctx))

    return mk(_CTX_VERIFY), mk(_CTX_LAX)


OPENER_VERIFY, OPENER_LAX = _build_openers()


def _base_headers(referer: str = "") -> dict:
    h = {
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        # 故意不要 gzip：urllib 不会自动解压，直接要明文
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        h["Referer"] = referer
    return h


# ══════════════════════════════════════════════════════════════════════
#  全局限速
# ══════════════════════════════════════════════════════════════════════

class _RateLimiter:
    """所有线程加起来不超过 rate 字节/秒。

    记账方式：从 _t0 起到现在一共放行了 _total 字节，那么此刻的时间至少得是
    _t0 + _total/rate，不够就睡到那时候。这样「网络本身读得慢」花掉的时间也
    算在预算里，总速率才会真的贴着 rate 走 —— 要是按「每块固定睡 n/rate」，
    读的时间会额外叠上去，实测只有设定值的 2/3。
    空闲太久（距上次放行超过 5 秒）就重新起算，免得不小心攒出一大笔额度。
    """

    def __init__(self, rate: float):
        self.rate = float(rate)
        self._lock = threading.Lock()
        self._t0 = time.monotonic()
        self._total = 0
        self._last = self._t0

    def take(self, n: int) -> None:
        if self.rate <= 0 or n <= 0:
            return
        now = time.monotonic()
        with self._lock:
            if now - self._last > 5.0:
                self._t0, self._total = now, 0
            self._total += n
            due = self._t0 + self._total / self.rate
        while True:
            wait = due - time.monotonic()
            if wait <= 0.01:
                break
            time.sleep(min(wait, 0.5))
        with self._lock:
            self._last = time.monotonic()


_LIMITER = _RateLimiter(MAX_RATE_BYTES)


# ══════════════════════════════════════════════════════════════════════
#  设置（config.json）
# ══════════════════════════════════════════════════════════════════════
#
#  网页上的设置面板改完就存 config.json，然后调 apply_config() 当场盖到下面
#  这些模块常量上 —— 所以大部分改动不用重启进程。改的是 dict，线程读到的
#  要么旧值要么新值，不会读半个，够用了。

CFG: dict = {}


def _parse_weekdays(raw) -> list:
    """'1,2,3,4,5' → [1,2,3,4,5]。乱七八糟的一律当全开。"""
    out = []
    for part in str(raw or "").replace("，", ",").split(","):
        part = part.strip()
        if not part.isdigit():
            continue
        n = int(part)
        if 1 <= n <= 7 and n not in out:
            out.append(n)
    return out or [1, 2, 3, 4, 5, 6, 7]


def apply_config(cfg: dict) -> dict:
    """把一份设置盖到模块常量上，返回规范化之后的结果。"""
    if cfgr is None:
        return cfg if isinstance(cfg, dict) else {}
    cfg = cfgr.normalize(cfg)
    g = globals()

    def put(name, value):
        g[name] = value

    # 联网节奏
    put("ONLINE_DEDUPE", float(cfg["online_dedupe_min"]) * 60)
    put("ROUND_BUDGET", float(cfg["round_budget_min"]) * 60)
    put("DISK_MIN_BYTES", int(cfg["disk_min_mb"]) * 1024 * 1024)
    put("IDLE_POLL", float(cfg["idle_poll_s"]))
    # 抓取
    put("MAX_AGE_DAYS", cfg["max_age_days"])
    put("KEEP_SNAPSHOTS", cfg["keep_snapshots"])
    # 正文
    put("FETCH_ARTICLE", cfg["fetch_article"])
    put("MAX_ARTICLES_PER_SOURCE", cfg["max_articles_per_source"])
    put("MAX_ARTICLE_CHARS", cfg["max_article_chars"])
    # 封面图
    put("ENRICH_IMAGES", cfg["enrich_images"])
    put("MAX_IMAGES_PER_SOURCE", cfg["max_images_per_source"])
    put("IMG_MAX_BYTES", int(cfg["img_max_kb"]) * 1024)
    # 视频
    put("FETCH_VIDEO", cfg["fetch_video"])
    put("VIDEO_COUNT", cfg["video_count"])
    put("VIDEO_KEEP", cfg["video_keep"])
    put("VIDEO_MAX_DURATION", cfg["video_max_min"] * 60)
    put("VIDEO_QN", cfg["video_qn"])
    # 限速
    put("MAX_RATE_BYTES", int(float(cfg["max_rate_mb"]) * 1048576))
    _LIMITER.rate = float(MAX_RATE_BYTES)
    # 搜索
    put("SEARCH_KEYWORDS", list(cfg["search_keywords"]))
    put("SEARCH_NEWS", cfg["search_news"])
    put("SEARCH_FETCH_ARTICLE", cfg["search_fetch_article"])
    put("SEARCH_PER_KEYWORD", cfg["search_per_keyword"])
    # 镜像
    put("MIRROR_JS", cfg["mirror_js"])
    put("MIRROR_MAX_BYTES", int(cfg["mirror_max_mb"]) * 1024 * 1024)
    put("MIRROR_AUTO", cfg["mirror_auto"])
    put("MIRROR_AUTO_COUNT", cfg["mirror_auto_count"])
    put("MIRROR_KEEP", cfg["mirror_keep"])
    # 点歌台
    put("MUSIC_ENABLED", cfg["music_enabled"])
    put("MUSIC_PER_RUN", cfg["music_per_run"])
    put("MUSIC_CHARTS", list(cfg["music_charts"]))
    put("MUSIC_KEEP", cfg["music_keep"])
    # B 站
    put("BILI_REC_ENABLED", cfg["bili_rec_enabled"])
    put("BILI_REC_COUNT", cfg["bili_rec_count"])
    put("BILI_KEYWORDS", list(cfg["bili_keywords"]))
    put("BILI_SEARCH_COUNT", cfg["bili_search_count"])
    # 追番
    put("ANIME_ENABLED", cfg["anime_enabled"])
    put("ANIME_AUTO_FOLLOW", cfg["anime_auto_follow"])
    put("ANIME_KEYWORDS", list(cfg["anime_keywords"]))
    # 权限与菜单
    put("BOOT_MODE", cfg["boot_mode"])
    put("ADMIN_PASSWORD_ON", cfg["admin_password_on"])
    put("L1_SEARCH", cfg["l1_search"])
    put("L1_LIBRARY", cfg["l1_library"])
    put("WEEKDAY_OPEN", _parse_weekdays(cfg["weekday_open"]))
    put("USB_BYPASS_TIME", cfg["usb_bypass_time"])
    put("EXAM_LOCK", cfg["exam_lock"])
    put("HIDE_LOG", cfg["hide_log"])
    put("HIDE_BUTTONS", cfg["hide_buttons"])
    put("LOCK_SETTINGS", cfg["lock_settings"])
    put("FEAT_VIDEO", cfg["feat_video"])
    put("FEAT_MUSIC", cfg["feat_music"])
    put("FEAT_BILI", cfg["feat_bili"])
    put("FEAT_ANIME", cfg["feat_anime"])
    put("FEAT_MIRROR", cfg["feat_mirror"])
    put("FEAT_SEARCH", cfg["feat_search"])
    put("UPDATE_AUTO", cfg["update_auto"])
    put("UPDATE_INTERVAL_H", cfg["update_interval_h"])
    # 权限与更新
    put("PASSWORD_ON", cfg["password_on"])
    put("UPDATE_REPO", cfg["update_repo"])
    put("CLOUD_URL", cfg["cloud_url"])
    put("PROXY", str(cfg.get("proxy") or "").strip())
    # 代理变了就重建 opener（只影响后面发的请求）
    _op = globals().get("OPENER_VERIFY")
    if _op is not None:
        global OPENER_VERIFY, OPENER_LAX
        OPENER_VERIFY, OPENER_LAX = _build_openers(PROXY)
    if schedmod is not None:
        # 注意：模块导入阶段 load_config() 就跑在这行之前，那时 _QUEUE 还没建，
        # 所以用 globals() 查一下，没建就跳过（导入完会不会再补一次？不需要）。
        _q = globals().get("_QUEUE")
        if _q is not None:
            if not MUSIC_ENABLED:
                _q.drop("music")
            if not BILI_REC_ENABLED:
                _q.drop("bili_rec")
            if not ANIME_ENABLED:
                _q.drop("anime")
    # 自定义源
    put("CUSTOM_SOURCES", list(cfg["custom_sources"]))

    CFG.clear()
    CFG.update(cfg)
    return cfg


def load_config() -> dict:
    """读一遍 config.json 并应用。读不动就用默认值，不影响主流程。"""
    if cfgr is None:
        return {}
    try:
        return apply_config(cfgr.load(BASE_DIR))
    except Exception as e:  # noqa: BLE001
        print("config.json 读不动，用默认设置：%s: %s" % (type(e).__name__, e))
        return {}


def save_config(raw: dict) -> dict:
    """存一份设置并当场生效。

    只传了部分键的（比如别人用 curl 扔个 ``{"max_rate_mb": 0.5}``）先合到当前
    配置上再存 —— 不然没提到的键会掉回默认值，自定义源那种列表就没了。
    """
    if cfgr is None:
        raise RuntimeError("config 模块没加载上")
    merged = dict(CFG)
    merged.update(raw or {})
    saved = cfgr.save(BASE_DIR, merged)
    return apply_config(saved)


load_config()


def _read_slow(resp, max_bytes: int) -> bytes:
    """按块读响应，顺便过一遍限速器。"""
    buf = bytearray()
    while len(buf) < max_bytes:
        chunk = resp.read(min(262144, max_bytes - len(buf)))
        if not chunk:
            break
        buf += chunk
        _LIMITER.take(len(chunk))
    return bytes(buf)


def http_get(url: str, timeout: int = NET_TIMEOUT, referer: str = "",
             max_bytes: int = 8 * 1024 * 1024,
             retries: int = 1) -> tuple[bytes, str]:
    """返回 (body, content_type)。证书有问题会放宽重试，网络抖动会再试一次。"""
    req = urllib.request.Request(url, headers=_base_headers(referer))
    attempt = 0
    while True:
        attempt += 1
        try:
            with OPENER_VERIFY.open(req, timeout=timeout) as r:
                return _read_slow(r, max_bytes), r.headers.get("Content-Type", "")
        except (ssl.SSLError, urllib.error.URLError) as e:
            reason = getattr(e, "reason", None)
            if isinstance(e, ssl.SSLError) or isinstance(reason, ssl.SSLError):
                log("  证书有点怪，放宽重试：%s" % url)
                with OPENER_LAX.open(req, timeout=timeout) as r:
                    return _read_slow(r, max_bytes), r.headers.get("Content-Type", "")
            if attempt > retries:
                raise
            time.sleep(0.6)


# ══════════════════════════════════════════════════════════════════════
#  日志
# ══════════════════════════════════════════════════════════════════════

_log_lock = threading.Lock()


def log(msg: str) -> None:
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    with _log_lock:
        try:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 2 * 1024 * 1024:
                shutil.move(LOG_FILE, LOG_FILE + ".old")
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass
        try:
            print(line, flush=True)
        except (OSError, ValueError, AttributeError):
            pass  # pythonw 下没有 stdout，正常


# ══════════════════════════════════════════════════════════════════════
#  联网检测
# ══════════════════════════════════════════════════════════════════════

# 先用 TCP 摸一下（便宜、快），通了再发 HTTP 确认（防校园网认证门户假联网）
TCP_TARGETS = [
    ("223.5.5.5", 443),      # 阿里 DNS
    ("119.29.29.29", 443),   # 腾讯 DNS
    ("180.76.76.76", 443),   # 百度 DNS
    ("114.114.114.114", 53),
]

# HTTP 确认：内容里必须出现这些字样，否则说明被劫持到了登录页
HTTP_PROBES = [
    ("http://www.baidu.com/", b"baidu"),
    ("http://www.qq.com/", b"qq"),
    ("http://www.people.com.cn/", b"people"),
]


def _tcp_ok(timeout: float = 0.9) -> bool:
    for host, port in TCP_TARGETS:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False


def _http_ok(timeout: int = 5) -> bool:
    for url, needle in HTTP_PROBES:
        try:
            req = urllib.request.Request(url, headers=_base_headers())
            with OPENER_VERIFY.open(req, timeout=timeout) as r:
                if r.status not in (200, 204):
                    continue
                body = r.read(65536)
            if needle in body.lower() or r.status == 204:
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


_http_ok_cache = {"ts": 0.0}


def probe_online(force_http: bool = False) -> bool:
    """一次联网探测。TCP 不通 → 直接 False；TCP 通 → 再过一遍 HTTP 确认。"""
    with STATUS_LOCK:
        STATUS["probe_count"] += 1
        STATUS["last_probe_ts"] = time.time()

    if not _tcp_ok():
        _http_ok_cache["ts"] = 0.0
        _set_online(False)
        return False

    # HTTP 确认成功后有 60 秒豁免，避免每秒都发请求
    if not force_http and (time.time() - _http_ok_cache["ts"]) < 60:
        _set_online(True)
        return True

    if _http_ok():
        _http_ok_cache["ts"] = time.time()
        _set_online(True)
        return True

    _set_online(False)
    return False


def _set_online(v: bool) -> None:
    with STATUS_LOCK:
        STATUS["online"] = v


# ══════════════════════════════════════════════════════════════════════
#  RSS / Atom 解析
# ══════════════════════════════════════════════════════════════════════

IMG_TAG_RE = re.compile(
    r"""<img[^>]*?\b(?:data-src|data-original|data-lazy-src|src)\s*=\s*["']([^"']+)["']""",
    re.I,
)
TAG_RE = re.compile(r"<(script|style)\b.*?</\1>", re.I | re.S)
ANYTAG_RE = re.compile(r"<[^>]+>")
WS_RE = re.compile(r"[ \t\u00a0]+")
BAD_IMG_HINT = re.compile(
    r"(?:^|/)(?:logo|icon|avatar|emoji|spacer|blank|pixel|qrcode|qr_|weixin|weibo|ad_|ads?)"
    r"|\.svg(?:\?|$)|1x1|transparent",
    re.I,
)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _text(el) -> str:
    return "".join(el.itertext()).strip() if el is not None else ""


def _strip_html(s: str) -> str:
    if not s:
        return ""
    s = TAG_RE.sub(" ", s)
    s = ANYTAG_RE.sub(" ", s)
    s = html_mod.unescape(s)
    s = WS_RE.sub(" ", s)
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()


def _clip(s: str, n: int = SUMMARY_LEN) -> str:
    s = _strip_html(s)
    if len(s) <= n:
        return s
    cut = s[:n]
    for sep in ("。", "！", "？", ".", "；", ";"):
        i = cut.rfind(sep)
        if i > n * 0.6:
            return cut[: i + 1]
    return cut.rstrip() + "…"


# 有的源 description 只写一句废话，别拿它当摘要
JUNK_SUMMARY_RE = re.compile(
    r"^[（(【\[]?\s*(?:点击?|单击)?\s*(?:查看|阅读|浏览)?\s*"
    r"(?:原文|全文|详情|更多|正文|内容)\s*[）)】\]]?\s*[»>…\.]*$")


def _clean_summary(s: str) -> str:
    s = _clip(s)
    if len(s) < 8 or JUNK_SUMMARY_RE.match(s):
        return ""
    return s


def _parse_date(raw: str) -> float:
    raw = (raw or "").strip()
    if not raw:
        return 0.0
    try:
        from email.utils import parsedate_to_datetime
        dt = parsedate_to_datetime(raw)
        if dt is not None:
            return dt.timestamp()
    except Exception:  # noqa: BLE001
        pass
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
                "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d"):
        try:
            return time.mktime(time.strptime(raw[: len(fmt) + 6], fmt))
        except Exception:  # noqa: BLE001
            continue
    m = re.search(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", raw)
    if m:
        try:
            return time.mktime((int(m.group(1)), int(m.group(2)), int(m.group(3)),
                                0, 0, 0, 0, 0, -1))
        except Exception:  # noqa: BLE001
            pass
    return 0.0


def _clean_url(u: str) -> str:
    """修一些源写歪的图片地址，例如 https:https://img.x/a.jpg 或 https:/img.x/a.jpg"""
    u = (u or "").strip()
    for _ in range(3):
        m = re.match(r"^(https?):(https?://.*)$", u, re.I)
        if m:
            u = m.group(2)
            continue
        break
    return re.sub(r"^(https?):/(?!/)", r"\1://", u, flags=re.I)


def _pick_image(entry, entry_html: str, base_url: str) -> str:
    """按 优先级 找封面图：media/enclosure > 正文第一张 <img>。"""
    cands = []
    for child in entry:
        tag = child.tag
        name = _local(tag)
        if name == "enclosure":
            u = child.get("url") or ""
            t = (child.get("type") or "").lower()
            if u and (t.startswith("image") or not t):
                cands.append(u)
        elif name in ("content", "thumbnail") and "search.yahoo.com/mrss" in tag:
            u = child.get("url") or ""
            if u:
                cands.append(u)
        elif name == "image":
            u = child.get("href") or child.get("url") or _text(child)
            if u:
                cands.append(u)

    for m in IMG_TAG_RE.finditer(entry_html or ""):
        cands.append(m.group(1))

    for raw in cands:
        u = html_mod.unescape((raw or "").strip())
        if not u or u.startswith("data:"):
            continue
        if u.startswith("//"):
            u = "http:" + u
        u = _clean_url(u)
        u = urllib.parse.urljoin(base_url, u)
        if not u.lower().startswith("http"):
            continue
        if BAD_IMG_HINT.search(u):
            continue
        return u
    return ""


META_TAG_RE = re.compile(r"<meta\b[^>]*>", re.I)
OG_NAME_RE = re.compile(
    r"""(?:property|name)\s*=\s*["'](?:og:image(?::url)?|twitter:image(?::src)?)["']""",
    re.I,
)
CONTENT_RE = re.compile(r"""content\s*=\s*["']([^"']+)["']""", re.I)
LINK_IMG_RE = re.compile(
    r"""<link\b[^>]*rel\s*=\s*["']image_src["'][^>]*href\s*=\s*["']([^"']+)["']""", re.I)

# 正文图兜底用的过滤：比 RSS 那套更狠，宁可没图也别把箭头图标当封面
BODY_BAD_RE = re.compile(
    r"logo|icon|arrow|toparr|blink|btn|button|banner|header|nav|share|weixin|weibo|"
    r"qrcode|avatar|blank|spacer|pixel|loading|placeholder|default|homepage|"
    r"bg\.|background|border|underline|advert|/ad[s_/]",
    re.I,
)
BODY_IMG_EXT_RE = re.compile(r"\.(jpe?g|png|webp)(\?|$)", re.I)
IMG_TAG_ONLY_RE = re.compile(r"<img\b[^>]*>", re.I)
IMG_SRC_ATTR_RE = re.compile(
    r"""\b(?:data-src|data-original|data-lazy-src|src)\s*=\s*["']([^"']+)["']""", re.I)
BODY_CLASS_RE = re.compile(
    r"""class\s*=\s*["']([^"']*)["']""", re.I)
BODY_CONTENT_CLASS_RE = re.compile(
    r"picture|illustrat|article|content|photo|poster|cover|detail|txt|zw", re.I)
WIDTH_ATTR_RE = re.compile(r"""\bwidth\s*=\s*["']?(\d+)""", re.I)
HEIGHT_ATTR_RE = re.compile(r"""\bheight\s*=\s*["']?(\d+)""", re.I)
LONG_ID_RE = re.compile(r"\d{8,}")
# 有些图床把尺寸写在路径里，比如新浪的 /w49h49l50t50q80.jpg
URL_SIZE_RE = re.compile(r"[/?&#]w(\d{1,4})h(\d{1,4})", re.I)


def _pick_body_image(text: str, page_url: str) -> str:
    """最后一招：在页面里挑一张最像正文配图的 <img>。挑不到就认了。"""
    for m in IMG_TAG_ONLY_RE.finditer(text[:400000]):
        tag = m.group(0)
        a = IMG_SRC_ATTR_RE.search(tag)
        if not a:
            continue
        u = _clean_url(html_mod.unescape(a.group(1)))
        if not u or u.startswith("data:"):
            continue
        if u.startswith("//"):
            u = "http:" + u
        u = urllib.parse.urljoin(page_url, u)
        if not u.lower().startswith("http"):
            continue
        if BODY_BAD_RE.search(u) or BODY_IMG_EXT_RE.search(u) is None:
            continue

        w = WIDTH_ATTR_RE.search(tag)
        h = HEIGHT_ATTR_RE.search(tag)
        if w and int(w.group(1)) < 150:
            continue
        if h and int(h.group(1)) < 100:
            continue
        us = URL_SIZE_RE.search(u)
        if us and (int(us.group(1)) < 200 or int(us.group(2)) < 150):
            continue

        cls = BODY_CLASS_RE.search(tag)
        cls_txt = cls.group(1) if cls else ""
        big = (w and int(w.group(1)) >= 300) or (h and int(h.group(1)) >= 200)
        # 得有一个说得过去的理由，才认为它是正文图
        if BODY_CONTENT_CLASS_RE.search(cls_txt) or big or LONG_ID_RE.search(u):
            return u
    return ""


def fetch_og_image(page_url: str) -> str:
    """RSS 里没图时，去原文页抠封面。先 og:image，再退一步找正文图。"""
    try:
        raw, _ctype = http_get(page_url, timeout=8, max_bytes=400 * 1024)
    except Exception:  # noqa: BLE001
        return ""
    text = raw.decode("utf-8", "replace")

    for m in META_TAG_RE.finditer(text[:200000]):
        tag = m.group(0)
        if OG_NAME_RE.search(tag):
            c = CONTENT_RE.search(tag)
            if c:
                u = _clean_url(html_mod.unescape(c.group(1)))
                if u.lower().startswith("http") and not BAD_IMG_HINT.search(u):
                    return u

    m = LINK_IMG_RE.search(text[:200000])
    if m:
        u = _clean_url(html_mod.unescape(m.group(1)))
        if u.lower().startswith("http") and not BAD_IMG_HINT.search(u):
            return u

    return _pick_body_image(text, page_url)


def parse_feed(xml_bytes: bytes, base_url: str) -> list[dict]:
    # 中关村在线这类源还是 GBK 的 XML，按声明解码，别硬上 utf-8
    text = _decode_html(xml_bytes)
    text = re.sub(r"^\s*<\?xml[^>]*\?>", "", text, count=1).strip()
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
    # 有的源 XML 不合法：正文里裸 & 没转义。补一下，别让整个源白抓。
    text = re.sub(
        r"&(?!(?:[a-zA-Z][a-zA-Z0-9]{0,10}|#\d{1,6}|#x[0-9a-fA-F]{1,6});)",
        "&amp;", text)
    root = ET.fromstring(text)

    entries = [el for el in root.iter() if _local(el.tag) in ("item", "entry")]
    out = []
    for el in entries:
        title = ""
        link = ""
        html_blob = ""
        date_raw = ""
        for child in el:
            name = _local(child.tag)
            if name == "title" and not title:
                title = _strip_html(_text(child))
            elif name == "link":
                href = child.get("href") or _text(child)
                rel = (child.get("rel") or "alternate").lower()
                if href and (not link or rel == "alternate"):
                    link = href.strip()
            elif name in ("description", "summary", "encoded"):
                html_blob += _text(child)
            elif name == "content" and "search.yahoo.com" not in child.tag:
                html_blob += _text(child)
            elif name in ("pubdate", "published", "updated", "date", "created"):
                if not date_raw:
                    date_raw = _text(child)
            elif name == "guid" and not link:
                g = _text(child)
                if g.startswith("http"):
                    link = g

        if not title:
            continue
        title = re.sub(r"\s+", " ", title).strip()

        if not link:
            for child in el.iter():
                if _local(child.tag) == "link":
                    href = child.get("href") or _text(child)
                    if href.startswith("http"):
                        link = href
                        break

        published_ts = _parse_date(date_raw)
        summary = _clean_summary(html_blob)
        image = _pick_image(el, html_blob, link or base_url)

        out.append({
            "title": title,
            "url": link.strip(),
            "summary": summary,
            "published_ts": published_ts,
            "image_src": image,
            "_blob": html_blob,      # 正文抽取用，落盘前会删掉
        })
    return out


# ══════════════════════════════════════════════════════════════════════
#  图片落地
# ══════════════════════════════════════════════════════════════════════

_MAGIC = [
    (b"\xff\xd8\xff", ".jpg"),
    (b"\x89PNG\r\n\x1a\n", ".png"),
    (b"GIF87a", ".gif"),
    (b"GIF89a", ".gif"),
    (b"BM", ".bmp"),
]


def _guess_ext(raw: bytes, url: str) -> str:
    for magic, ext in _MAGIC:
        if raw.startswith(magic):
            return ext
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return ".webp"
    m = re.search(r"\.(jpe?g|png|gif|webp|bmp)(?:\?|$)", url, re.I)
    if m:
        return "." + m.group(1).lower().replace("jpeg", "jpg")
    return ".jpg"


def download_image(url: str, referer: str = "") -> str:
    """下载封面图，返回相对路径 images/xxx.jpg；失败返回空串。"""
    try:
        raw, ctype = http_get(url, timeout=IMG_TIMEOUT, referer=referer,
                              max_bytes=IMG_MAX_BYTES)
    except Exception:  # noqa: BLE001
        return ""
    if len(raw) < IMG_MIN_BYTES:
        return ""
    ext = _guess_ext(raw, url)
    if not ctype.lower().startswith("image/") and ext == ".jpg" and raw[:2] != b"\xff\xd8":
        return ""
    name = hashlib.sha1(url.encode("utf-8")).hexdigest()[:20] + ext
    path = os.path.join(IMG_DIR, name)
    if not os.path.exists(path):
        tmp = path + ".part"
        try:
            with open(tmp, "wb") as f:
                f.write(raw)
            os.replace(tmp, path)
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            return ""
    return "images/" + name


# ══════════════════════════════════════════════════════════════════════
#  正文抽取
#  精简版 readability：建 DOM → 砍掉垃圾块 → 挑出正文容器 → 按顺序收段落和配图。
#  全程纯标准库，不装任何东西。
# ══════════════════════════════════════════════════════════════════════

_VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input",
              "link", "meta", "param", "source", "track", "wbr"}

_DROP_TAGS = {"script", "style", "noscript", "iframe", "svg", "canvas", "form",
              "input", "button", "select", "textarea", "nav", "header", "footer",
              "aside", "object", "embed", "template", "video", "audio", "map",
              "dialog", "menu"}

# 这些标签里的文字当成「一段」来处理
_TEXT_TAGS = {"p", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "li",
              "pre", "figcaption", "dd", "dt"}

# class / id 命中这些词，基本是导航、评论、推荐之类的垃圾块
_JUNK_ATTR_RE = re.compile(
    r"comment|pingback|sidebar|side-?bar|"
    r"(^|[-_])nav($|[-_])|navbar|menu|breadcrumb|crumb|"
    r"share|social|weixin|weibo|qrcode|"
    r"advert|adsbygoogle|(^|[-_])ads?($|[-_])|banner|promo|sponsor|"
    r"related|recommend|tuijian|(^|[-_])hot($|[-_])|(^|[-_])rank($|[-_])|"
    r"copyright|copyinfo|beian|icp|subscribe|newsletter|widget|popup|modal|toolbar|"
    r"statement|disclaimer|app-?down|download-?app|"
    r"(^|[-_])prev($|[-_])|(^|[-_])next($|[-_])|pagination|pager|"
    r"(^|[-_])tags?($|[-_])|catalog|(^|[-_])search($|[-_])|login|register|"
    # 各种「精选 / 热榜 / 猜你喜欢」的侧栏，光靠 recommend 抓不到
    r"selected_news|news_?list|newslist|hot_?news|top_?news|tuijian|"
    r"(^|[-_])jxxw($|[-_])|(^|[-_])tj($|[-_])|(^|[-_])xgw($|[-_])|"
    r"news_?recommend|recommend_?news|guess_?like|you_?may_?like",
    re.I)

# 正文配图的过滤，比封面那套松一点（正文里的图本来就该留着）
ART_BAD_RE = re.compile(
    r"logo|icon|arrow|btn|button|banner|share|qrcode|avatar|blank|spacer|"
    r"pixel|loading|placeholder|sprite|underline|advert|/ad[s_/]|"
    r"bg\.|background|weixin|weibo|emoticon|smiley?/",
    re.I)

WS_RE = re.compile(r"[ \t\u00a0\u3000]+")
NL_RE = re.compile(r"\s*\n\s*")


class _Node:
    __slots__ = ("tag", "attrs", "kids", "parent", "buf")

    def __init__(self, tag, attrs, parent):
        self.tag = tag
        self.attrs = attrs
        self.kids = []
        self.parent = parent
        self.buf = []

    def text(self) -> str:
        out = []
        stack = [self]
        while stack:
            n = stack.pop()
            if n.buf:
                out.append("".join(n.buf))
            # 保持文档顺序
            for k in reversed(n.kids):
                stack.append(k)
        return "".join(out)


class _DomBuilder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _Node("#root", {}, None)
        self.cur = self.root

    def handle_starttag(self, tag, attrs):
        a = {}
        for k, v in attrs:
            a[k.lower()] = v if v is not None else ""
        n = _Node(tag, a, self.cur)
        self.cur.kids.append(n)
        if tag not in _VOID_TAGS:
            self.cur = n

    def handle_endtag(self, tag):
        n = self.cur
        while n is not None and n.tag != tag:
            n = n.parent
        if n is not None and n.parent is not None:
            self.cur = n.parent

    def handle_data(self, data):
        if data and data.strip():
            self.cur.buf.append(data)


def _build_dom(html_text: str):
    b = _DomBuilder()
    try:
        b.feed(html_text)
        b.close()
    except Exception:  # noqa: BLE001
        pass
    return b.root


def _is_junk(n: _Node) -> bool:
    a = n.attrs
    style = a.get("style", "").replace(" ", "").lower()
    if "display:none" in style or "visibility:hidden" in style:
        return True
    if a.get("hidden") is not None or a.get("aria-hidden") == "true":
        return True
    hay = "%s %s %s" % (a.get("class", ""), a.get("id", ""), a.get("role", ""))
    if not hay.strip():
        return False
    return bool(_JUNK_ATTR_RE.search(hay))


def _prune_dom(node: _Node) -> None:
    keep = []
    for k in node.kids:
        if k.tag in _DROP_TAGS or _is_junk(k):
            continue
        _prune_dom(k)
        keep.append(k)
    node.kids = keep


def _stats(root: _Node) -> dict:
    """自底向上算一遍：每块里有多少 <p> 文本、多少链接文本、几个段落几张图。"""
    order, stack = [], [root]
    while stack:
        n = stack.pop()
        order.append(n)
        stack.extend(n.kids)

    st = {}
    for n in reversed(order):
        own = len("".join(n.buf).strip())
        p_len = a_len = 0
        p_cnt = img_cnt = 0
        sub = 0
        for k in n.kids:
            s = st[k]
            p_len += s["p_len"]
            a_len += s["a_len"]
            p_cnt += s["p_cnt"]
            img_cnt += s["img_cnt"]
            sub += s["own"] + s["sub"]
        if n.tag == "p":
            t = own + sub
            if t >= MIN_PARA_CHARS:
                p_len += t
                p_cnt += 1
        if n.tag == "a":
            a_len += own + sub
        if n.tag == "img":
            img_cnt += 1
        st[n] = {"own": own, "sub": sub, "p_len": p_len, "a_len": a_len,
                 "p_cnt": p_cnt, "img_cnt": img_cnt}
    return st


_CANDIDATE_TAGS = {"div", "article", "section", "main", "td", "body", "#root"}


def _pick_main(root: _Node, st: dict):
    best, best_score = None, float("-inf")
    stack = [root]
    while stack:
        n = stack.pop()
        stack.extend(n.kids)
        if n.tag not in _CANDIDATE_TAGS:
            continue
        s = st[n]
        if s["p_cnt"] < 1:
            continue
        if s["a_len"] >= s["p_len"] * 0.85 and s["img_cnt"] == 0:
            continue  # 整块基本都是链接，是导航 / 相关阅读，不是正文
        score = s["p_len"] - 2.0 * s["a_len"]
        if score > best_score:
            best, best_score = n, score

    # 父节点的分数天然 ≥ 子节点（把子节点的段落也算进去了），
    # 所以从最高分那个往下走，只要子节点还兜着 ≥90% 的段落就继续钻
    node = best
    for _ in range(60):
        if node is None:
            break
        need = st[node]["p_len"] * 0.9
        nxt = None
        for k in node.kids:
            if k.tag in _TEXT_TAGS or k.tag in _DROP_TAGS:
                continue
            s = st.get(k)
            if s and s["p_len"] >= need and s["p_len"] > 0:
                if nxt is None or s["p_len"] > st[nxt]["p_len"]:
                    nxt = k
        if nxt is None:
            break
        node = nxt
    return node


def _norm_ws(s: str) -> str:
    s = WS_RE.sub(" ", s.replace("\r", "\n"))
    s = NL_RE.sub(" ", s)
    return s.strip()


def _img_url_of(node: _Node, page_url: str) -> str:
    a = node.attrs
    u = (a.get("data-src") or a.get("data-original") or a.get("data-lazy-src")
         or a.get("data-actualsrc") or a.get("src") or "").strip()
    if not u or u.startswith("data:"):
        return ""
    if "," in u and " " in u:              # srcset，取第一个
        u = u.split(",")[0].strip().split(" ")[0]
    if u.startswith("//"):
        u = "https:" + u
    u = _clean_url(html_mod.unescape(u))
    u = urllib.parse.urljoin(page_url, u)
    if not u.lower().startswith("http"):
        return ""
    if ART_BAD_RE.search(u):
        return ""
    if BODY_IMG_EXT_RE.search(u) is None and "image" not in u.lower():
        return ""
    for attr, floor in (("width", 120), ("height", 90)):
        raw = re.sub(r"[^\d]", "", a.get(attr, "") or "")
        try:
            if raw and int(raw) < floor:
                return ""
        except ValueError:
            pass
    us = URL_SIZE_RE.search(u)
    if us and (int(us.group(1)) < 150 or int(us.group(2)) < 100):
        return ""
    return u


def _link_text_len(node: _Node) -> int:
    """节点里所有链接文字的长度，用来判断这整段是不是导航/相关阅读。"""
    total, stack = 0, list(node.kids)
    while stack:
        n = stack.pop()
        if n.tag == "a":
            total += len(_norm_ws(n.text()))
            continue
        stack.extend(n.kids)
    return total


def _collect(node: _Node, page_url: str, blocks: list) -> None:
    for k in node.kids:
        tag = k.tag
        if tag in _DROP_TAGS:
            continue
        if tag == "img":
            u = _img_url_of(k, page_url)
            if u:
                blocks.append({"t": "img", "u": u, "v": ""})
            continue
        if tag in _TEXT_TAGS:
            txt = _norm_ws(k.text())
            # 整段都在链接里的，基本是「相关阅读 / 更多新闻」那种列表，不是正文
            if txt and _link_text_len(k) >= len(txt) * 0.9:
                continue
            if tag.startswith("h"):
                if 2 <= len(txt) <= 140:
                    blocks.append({"t": "h", "v": txt})
            elif len(txt) >= MIN_PARA_CHARS:
                blocks.append({"t": "p", "v": txt})
            # 段落里嵌的图也捞出来
            for sub in k.kids:
                if sub.tag == "img":
                    u = _img_url_of(sub, page_url)
                    if u:
                        blocks.append({"t": "img", "u": u, "v": ""})
                else:
                    for s2 in sub.kids:
                        if s2.tag == "img":
                            u = _img_url_of(s2, page_url)
                            if u:
                                blocks.append({"t": "img", "u": u, "v": ""})
            continue
        _collect(k, page_url, blocks)


def _fallback_blocks(root: _Node) -> list:
    """DOM 挑不出东西时的兜底：把清过垃圾的树按块级标签撸成纯文本。"""
    _BLOCK = {"p", "div", "li", "tr", "td", "section", "article", "h1", "h2",
              "h3", "h4", "h5", "h6", "blockquote", "pre", "figure",
              "figcaption", "dd", "dt", "ul", "ol", "table", "br"}
    parts = []

    def walk(n: _Node) -> None:
        for k in n.kids:
            if k.tag in _DROP_TAGS:
                continue
            pad = k.tag in _BLOCK or k.tag in _TEXT_TAGS
            if pad:
                parts.append("\n")
            if k.buf:
                parts.append("".join(k.buf))
            walk(k)
            if pad:
                parts.append("\n")

    walk(root)
    out = []
    for line in "".join(parts).split("\n"):
        line = _norm_ws(line)
        if len(line) >= 25:
            out.append({"t": "p", "v": line})
    return out


def _dedup_blocks(blocks: list) -> list:
    out, seen_img, seen_txt = [], set(), set()
    for b in blocks:
        if b["t"] == "img":
            u = b.get("u", "")
            if not u or u in seen_img:
                continue
            seen_img.add(u)
        else:
            if b["v"] in seen_txt:
                continue
            seen_txt.add(b["v"])
        out.append(b)
    return out


def _trim_blocks(blocks: list) -> list:
    """控一下长度：正文最多 MAX_ARTICLE_CHARS 字，图最多 MAX_ARTICLE_IMAGES 张。"""
    out, chars, imgs = [], 0, 0
    for b in blocks:
        if b["t"] == "img":
            if imgs >= MAX_ARTICLE_IMAGES:
                continue
            imgs += 1
            out.append(b)
            continue
        v = b["v"]
        if chars >= MAX_ARTICLE_CHARS:
            continue
        if chars + len(v) > MAX_ARTICLE_CHARS:
            v = v[:max(0, MAX_ARTICLE_CHARS - chars)] + "…"
        chars += len(v)
        out.append({"t": b["t"], "v": v})
    return out


def html_to_blocks(html_text: str, base_url: str) -> list:
    """把一段 HTML 片段（RSS 里的 content:encoded 之类）拆成段落 + 图。"""
    if not html_text or not html_text.strip():
        return []
    root = _build_dom(html_text)
    _prune_dom(root)
    blocks = []
    _collect(root, base_url, blocks)
    if sum(1 for b in blocks if b["t"] != "img") < 2:
        fb = _fallback_blocks(root)
        if len(fb) > sum(1 for b in blocks if b["t"] != "img"):
            blocks = fb
    return _trim_blocks(_dedup_blocks(blocks))


def extract_article(html_text: str, page_url: str) -> list:
    """从一整张原文页里抽出正文。"""
    if "_waf_" in html_text[:8000] or "waf_verify" in html_text[:8000]:
        return []  # 撞上 WAF 拦截页，宁可没有也别把 JSON 当正文
    root = _build_dom(html_text)
    _prune_dom(root)
    st = _stats(root)
    main = _pick_main(root, st) or root

    blocks = []
    _collect(main, page_url, blocks)
    if sum(1 for b in blocks if b["t"] != "img") < 2 and main is not root:
        blocks = []
        _collect(root, page_url, blocks)
    if sum(1 for b in blocks if b["t"] != "img") < 2:
        fb = _fallback_blocks(html_text)
        if len(fb) > sum(1 for b in blocks if b["t"] != "img"):
            blocks = fb
    out = _trim_blocks(_dedup_blocks(blocks))
    txt = "".join(b["v"] for b in out if b["t"] != "img")
    if txt and (txt.count("{") + txt.count('"')) > len(txt) * 0.08:
        return []  # 抽出来是 JSON/脚本，不是正文
    return out


def _decode_html(raw: bytes, ctype: str = "") -> str:
    """国内不少站还是 GBK，先按声明来，再退到 gb18030。"""
    charset = ""
    m = re.search(r"charset\s*=\s*[\"']?([\w-]+)", ctype or "", re.I)
    if m:
        charset = m.group(1)
    if not charset:
        m = re.search(rb"""<\?xml[^>]+encoding\s*=\s*["']([\w-]+)""", raw[:512], re.I)
        if m:
            charset = m.group(1).decode("ascii", "ignore")
    if not charset:
        m = re.search(rb"""<meta[^>]+charset\s*=\s*["']?([\w-]+)""", raw[:4096], re.I)
        if m:
            charset = m.group(1).decode("ascii", "ignore")
    for enc in (charset, "utf-8", "gb18030"):
        if not enc:
            continue
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


def fetch_article_blocks(page_url: str) -> list:
    try:
        raw, ctype = http_get(page_url, timeout=ARTICLE_TIMEOUT,
                              max_bytes=ARTICLE_MAX_BYTES)
    except Exception:  # noqa: BLE001
        return []
    try:
        return extract_article(_decode_html(raw, ctype), page_url)
    except Exception:  # noqa: BLE001
        return []


def _attach_articles(items: list, per_source: int | None = None) -> None:
    """给靠前的新闻配本地正文：RSS 里够全就直接用，不够就去原文页抓。

    per_source 是每个 source_id 最多配几篇正文，默认用 MAX_ARTICLES_PER_SOURCE。
    搜索结果不走内置源那套，自己传个数进来。
    """
    cap = MAX_ARTICLES_PER_SOURCE if per_source is None else per_source
    per_src: dict[str, int] = {}
    todo = []
    for it in items:
        sid = it.get("source_id") or ""
        if per_src.get(sid, 0) >= cap:
            continue
        per_src[sid] = per_src.get(sid, 0) + 1
        todo.append(it)

    need_page = []
    for it in todo:
        blob = it.pop("_blob", "") or ""
        url = it.get("url") or ""
        blocks = html_to_blocks(blob, url) if blob else []
        txt = sum(len(b["v"]) for b in blocks if b["t"] != "img")
        if txt >= MIN_RSS_CHARS:
            it["content"] = blocks
        else:
            it["content"] = blocks
            if url:
                need_page.append(it)

    # 不在 todo 里的也要清掉，免得跟着快照写进 JSON
    for it in items:
        it.pop("_blob", None)

    if need_page:
        log("RSS 里正文不够全，去原文页抓：%d 篇" % len(need_page))
        with STATUS_LOCK:
            STATUS["article_total"] = len(need_page)
            STATUS["article_done"] = 0
        try:
            with ThreadPoolExecutor(max_workers=WORKERS_IMG) as ex:
                futs = {ex.submit(fetch_article_blocks, it["url"]): it
                        for it in need_page}
                for fut in futs:
                    it = futs[fut]
                    try:
                        blocks = fut.result()
                    except Exception:  # noqa: BLE001
                        blocks = []
                    if blocks:
                        new_txt = sum(len(b["v"]) for b in blocks if b["t"] != "img")
                        old_txt = sum(len(b["v"]) for b in it.get("content") or []
                                      if b["t"] != "img")
                        if new_txt > old_txt:
                            it["content"] = blocks
                    with STATUS_LOCK:
                        STATUS["article_done"] += 1
        finally:
            with STATUS_LOCK:
                STATUS["article_total"] = 0
                STATUS["article_done"] = 0

    _localize_article_images(todo)


def _localize_article_images(items: list) -> None:
    """正文里的图也存到本地，不然断网就只剩文字了。"""
    # 同一张图被好几篇不相干的文章引用，那是站点模板图（默认分享图之类），扔掉
    users = {}
    for it in items:
        for b in it.get("content") or []:
            u = b.get("u") or ""
            if u:
                users.setdefault(u, set()).add(it.get("url") or "")
    tmpl = {u for u, s in users.items() if len(s) >= 3}
    if tmpl:
        log("正文里 %d 张图是站点模板图，扔掉" % len(tmpl))

    pairs, ref = [], {}
    for it in items:
        cnt = 0
        for b in it.get("content") or []:
            if b["t"] != "img":
                continue
            u = b.get("u") or ""
            if not u or u in tmpl or cnt >= MAX_ARTICLE_IMAGES:
                b["u"] = ""
                continue
            cnt += 1
            pairs.append(b)
            ref.setdefault(u, it.get("url") or "")
    if not pairs:
        for it in items:
            for b in it.get("content") or []:
                b.pop("u", None)
        return

    log("下正文配图，%d 处（去重后 %d 张）" % (len(pairs), len(ref)))
    got = {}
    try:
        with ThreadPoolExecutor(max_workers=WORKERS_IMG) as ex:
            futs = {ex.submit(download_image, u, ref.get(u, "")): u for u in ref}
            for fut in futs:
                u = futs[fut]
                try:
                    got[u] = fut.result()
                except Exception:  # noqa: BLE001
                    got[u] = ""
    except Exception:  # noqa: BLE001
        pass

    for it in items:
        kept = []
        for b in it.get("content") or []:
            if b["t"] == "img":
                local = got.get(b.get("u") or "", "")
                b.pop("u", None)
                if not local:
                    continue
                b["v"] = local
            kept.append(b)
        it["content"] = kept


# ══════════════════════════════════════════════════════════════════════
#  抓取主流程
# ══════════════════════════════════════════════════════════════════════

STATUS_LOCK = threading.Lock()
STATUS = {
    "state": "starting",       # starting / idle / hunting / fetching / blocked
    "online": None,
    "last_fetch_ts": 0.0,
    "last_fetch_at": "",
    "snapshot_id": "",
    "total_items": 0,
    "category_counts": {},
    "fetching": False,
    "progress_done": 0,
    "progress_total": 0,
    "article_done": 0,
    "article_total": 0,
    "video_total": 0,
    "video_bytes": 0,
    "search_total": 0,
    "search_at": "",
    "search_keywords": [],
    "mirror_total": 0,
    "mirror_bytes": 0,
    "rate_bytes": MAX_RATE_BYTES,
    "probe_count": 0,
    "last_probe_ts": 0.0,
    "last_error": "",
    "started_ts": time.time(),
    "port": 0,
    "next_check_ts": 0.0,
    "interval_hours": 0.0,
    # ── v0.3 ──
    "last_round_ts": 0.0,      # 上一轮「联网抓取」什么时候结束的
    "round_started_ts": 0.0,   # 这一轮什么时候开始的（算预算用）
    "budget_left": 0.0,
    "task": "",                # 当前在干的是哪条任务
    "task_label": "",
    "music_total": 0,
    "music_bytes": 0,
    "bili_total": 0,
    "anime_total": 0,
    "queue": {},               # 队列快照（build_status 里补）
    "blocked": "",             # 云端禁用之类，非空就停服务
    "auth_required": False,
    "license": {},             # 激活状态
    "usb": False,              # U 盘钥匙在不在
    "edition": "试用",
    "last_update_check": "",
    "update_available": "",
}

_manual_fetch = threading.Event()
# 用户刚点了「离线点歌 / 加歌单」时用它把守护循环从打盹里捅醒，
# 不用等下一个 20 秒的探测周期。
_queue_kick = threading.Event()


def nap(stop_evt, seconds: float) -> None:
    """等一会儿，但队列来新活了就立刻醒。"""
    end = time.time() + max(0.0, seconds)
    while not stop_evt.is_set():
        left = end - time.time()
        if left <= 0:
            return
        if _queue_kick.is_set():
            _queue_kick.clear()
            return
        stop_evt.wait(min(1.0, left))

# ── v0.3 新加的三个长期对象 ──
# 队列：联网窗口里干活的清单，存 data/queue.json，断网不丢
# 收藏：点开/收藏/看完的记录，存 data/library.json
# 会话：给 netmusic / anime 那些模块用的下载会话，统一走限速器
_QUEUE = schedmod.Queue(QUEUE_FILE, log) if schedmod is not None else None
_LIB = libmod.Library(LIB_FILE, log) if libmod is not None else None


class Session:
    """给功能模块用的下载会话。

    netmusic / anime 这些模块不该自己 import newsd（会绕死），
    也不该绕过全局限速 —— 所以把它们要用的三个动作包成对象传进去。
    """

    def get_bytes(self, url: str, referer: str = "", timeout: int = 15) -> bytes:
        data, _ctype = http_get(url, timeout=timeout, referer=referer)
        return data

    def get_json(self, url: str, referer: str = "", timeout: int = 15) -> dict:
        raw = self.get_bytes(url, referer=referer, timeout=timeout)
        try:
            return json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            # 有些接口返回 BOM 或者前后带空白
            txt = raw.decode("utf-8-sig", "replace").strip()
            return json.loads(txt)

    def save_stream(self, url: str, dest_path: str, referer: str = "",
                    timeout: int = 30, max_bytes: int = 300 * 1024 * 1024) -> int:
        """下载到文件，边下边过限速器。返回写入了多少字节。"""
        req = urllib.request.Request(url, headers=_base_headers(referer))
        written = 0
        tmp = dest_path + ".part"
        os.makedirs(os.path.dirname(dest_path) or ".", exist_ok=True)
        try:
            with OPENER_VERIFY.open(req, timeout=timeout) as resp:
                with open(tmp, "wb") as f:
                    while written < max_bytes:
                        chunk = resp.read(min(262144, max_bytes - written))
                        if not chunk:
                            break
                        _LIMITER.take(len(chunk))
                        f.write(chunk)
                        written += len(chunk)
            os.replace(tmp, dest_path)
        except Exception:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        return written

    def exists(self, path: str) -> bool:
        return os.path.isfile(path)


_SESSION = Session()
_BP = bpmod.Store(DATA_DIR, log) if bpmod is not None else None


def free_bytes() -> int:
    """磁盘还剩多少。读不出来就当够用（别因为读不到空间就不干活）。"""
    try:
        st = os.statvfs(DATA_DIR)          # 只有类 Unix 有
        return st.f_bavail * st.f_frsize
    except (AttributeError, OSError):
        pass
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        free = ctypes.c_ulonglong(0)
        total = ctypes.c_ulonglong(0)
        root = os.path.splitdrive(DATA_DIR)[0] + "\\"
        ok = k32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(root), ctypes.byref(free),
                                     ctypes.byref(total), None)
        if ok:
            return int(free.value)
    except Exception:  # noqa: BLE001
        pass
    return 1 << 40


def disk_ok() -> bool:
    return free_bytes() >= DISK_MIN_BYTES


def load_state() -> dict:
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_state() -> None:
    with STATUS_LOCK:
        data = {
            "last_fetch_ts": STATUS["last_fetch_ts"],
            "last_fetch_at": STATUS["last_fetch_at"],
            "snapshot_id": STATUS["snapshot_id"],
            "total_items": STATUS["total_items"],
            "category_counts": STATUS["category_counts"],
            "last_round_ts": STATUS.get("last_round_ts") or 0.0,
        }
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as e:
        log("状态写不进去：%s" % e)


def _pid_alive(pid: int) -> bool:
    """这个 PID 还在跑吗。查不出来就当它没了，宁可放行也别把人卡死。"""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            STILL_ACTIVE = 259
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        except Exception:  # noqa: BLE001
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_lock() -> bool:
    """同一时刻只准跑一个 newsd。

    两个实例一起抓会互相覆盖 latest.json 和快照 —— 实测撞过一回，
    227 条那份被另一份 207 条的盖掉了，还少了三个源。
    锁文件里就存个 PID，进程没了自然作废，不用清理。
    """
    os.makedirs(DATA_DIR, exist_ok=True)
    try:
        with open(LOCK_FILE, "r", encoding="utf-8") as f:
            old = int((f.read() or "0").strip())
    except (OSError, ValueError):
        old = 0

    me = os.getpid()
    if old and old != me and _pid_alive(old):
        return False
    try:
        with open(LOCK_FILE, "w", encoding="utf-8") as f:
            f.write(str(me))
    except OSError:
        pass
    return True


def _iter_nodes(root):
    """深度优先遍历整棵树。"""
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        for k in reversed(n.kids):
            stack.append(k)


# 「关于我们」「登录」这种长得像链接但不是新闻的，靠最后一招：只认正文味的路径
_LIST_NAV_RE = re.compile(
    r"^(?:首页|主页|home|登录|注册|登陆|退出|关于|联系|更多|下载|客户端|上一页|下一页|"
    r"尾页|首页上一页|评论|分享|返回|广告|合作|招聘|版权|隐私|条款|english|中文|"
    r"rss|sitemap|订阅|搜索|导航|菜单|全部|查看|详情|阅读全文)$", re.I)

_ARTICLE_PATH_RE = re.compile(
    r"(?:/\d{4}[-/]?\d{2}[-/]?\d{2}/)"
    r"|(?:/\d{4}/\d{1,2}/)"
    r"|(?:\.s?html?$)"
    r"|(?:/(?:article|news|post|blog|story|detail|content|p|a)/)"
    r"|(?:/\d{5,})", re.I)


def scrape_listing(html_text: str, base_url: str, limit: int) -> list[dict]:
    """把自定义源当普通网页处理：从首页的链接里挑出像文章的那些。

    没有通用的办法 —— 各家列表页结构千差万别。所以走的是「按链接长相过滤」：
    正文路径基本都带日期、长数字 ID 或者 .html，导航链接一般很短或者就几个字。
    挑出来的未必完美，但比让用户手写选择器靠谱得多。
    """
    try:
        root = _build_dom(html_text)
    except Exception:  # noqa: BLE001
        return []
    try:
        _prune_dom(root)
    except Exception:  # noqa: BLE001
        pass

    host = urllib.parse.urlparse(base_url).netloc.lower()
    out, seen_url, seen_title = [], set(), set()

    for n in _iter_nodes(root):
        if n.tag != "a":
            continue
        href = _clean_url((n.attrs.get("href") or "").strip())
        if not href or href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue
        url = urllib.parse.urljoin(base_url, href)
        url = url.split("#")[0]
        if not url.startswith(("http://", "https://")):
            continue
        if urllib.parse.urlparse(url).netloc.lower() != host:
            continue          # 列表页往外链的，多半是广告或者转载，不要
        if url.rstrip("/") == base_url.rstrip("/"):
            continue

        title = _norm_ws(n.text())
        if not title:
            title = _norm_ws(n.attrs.get("title") or "")
        if not title:
            for k in n.kids:
                if k.tag == "img":
                    title = _norm_ws(k.attrs.get("alt") or "")
                    break
        # 列表里常带「· 」「• 」「>>」这类装饰前缀，剪掉
        title = title.lstrip("·•∙●○■□▪-—–_|｜>》»·、,，.。 ")
        if len(title) < 8 or len(title) > 140:
            continue
        if _LIST_NAV_RE.match(title):
            continue

        path = urllib.parse.urlparse(url).path
        looks = bool(_ARTICLE_PATH_RE.search(path))
        # 路径不像文章就得靠标题够长来补（有些站用 /xxxxxx 这种纯 ID 路径）
        if not looks and len(title) < 16:
            continue
        if not looks and len(path.strip("/").split("/")) < 1:
            continue

        if url in seen_url or title in seen_title:
            continue
        seen_url.add(url)
        seen_title.add(title)

        # 图片：链接里嵌的 <img>，当个粗封面用
        img = ""
        for k in _iter_nodes(n):
            if k.tag == "img":
                src = _clean_url(k.attrs.get("src") or k.attrs.get("data-src") or "")
                if src.startswith("//"):
                    src = "https:" + src
                elif src.startswith("/"):
                    src = urllib.parse.urljoin(base_url, src)
                if src.startswith(("http://", "https://")):
                    img = src
                    break

        # 列表页本身没有时间，但不少站的日期就写在链接里：
        #   /202610/t20261016_1454374.html   /cont/80/2026/10/16/23253.shtml
        pub = 0
        for _pat in (r"[/_t-](20\d{2})(\d{2})(\d{2})[/_.-]",
                     r"/(20\d{2})/(\d{1,2})/(\d{1,2})/"):
            m = re.search(_pat, url + "/")
            if not m:
                continue
            try:
                y, mo, dd = (int(x) for x in m.groups())
                pub = time.mktime(time.strptime("%04d-%02d-%02d" % (y, mo, dd), "%Y-%m-%d"))
            except ValueError:
                pub = 0
            break

        out.append({
            "title": title,
            "url": url,
            "summary": "",
            "image_src": img,
            "published_ts": pub,
        })
        if len(out) >= limit:
            break

    return out


def _load_sources() -> list[dict]:
    """每次抓取都重新 import 一次 sources.py，改完源不用重启。"""
    try:
        import importlib
        import sources as smod
        importlib.reload(smod)
        base = list(smod.SOURCES)
    except Exception as e:  # noqa: BLE001
        log("源清单读不了，用内存里的旧版：%s" % e)
        base = list(SOURCES)
    # 自定义源接在后面。挂了不影响内置的那批
    for s in CUSTOM_SOURCES:
        if not s.get("enabled", True):
            continue
        base.append({
            "id": s["id"], "name": s["name"], "cat": s.get("cat") or "科技",
            "url": s["url"], "limit": int(s.get("limit") or DEFAULT_LIMIT),
            "custom": True,
        })
    return base


def fetch_one_source(src: dict) -> tuple[dict, list[dict]]:
    """抓单个源，返回 (统计, 条目列表)。任何异常都吞掉，不让它拖垮全局。"""
    stat = {"id": src["id"], "name": src["name"], "cat": src["cat"],
            "ok": False, "count": 0, "error": ""}
    try:
        raw, _ctype = http_get(src["url"],
                               timeout=int(src.get("timeout", NET_TIMEOUT)),
                               retries=int(src.get("retries", 1)))
        items = []
        _is_web = bool(src.get("custom") or src.get("web"))
        try:
            items = parse_feed(raw, src["url"])
        except Exception:  # noqa: BLE001
            if not _is_web:
                raise
            # 网页型的源（自定义源，或者 sources.py 里标了 "web": True 的）
            # 喂进来的是 HTML，ParseError 很正常，往下走当网页扒
        if not items and _is_web:
            # 解析不出 feed，那就当普通网页，从链接里挑文章。
            # 「RSS 和网页自动判断」就是靠这个分支 —— 先试 feed，不成再扒网页。
            html_text = _decode_html(raw)
            items = scrape_listing(html_text, src["url"],
                                   int(src.get("limit", DEFAULT_LIMIT)))
        limit = int(src.get("limit", DEFAULT_LIMIT))
        items = items[:limit]
        if not items:
            stat["error"] = "解析出来 0 条"
            return stat, []
        stat["ok"] = True
        stat["count"] = len(items)
        log("  [OK ] %-10s %-4s %d 条" % (src["name"], src["cat"], len(items)))
        return stat, items
    except Exception as e:  # noqa: BLE001
        stat["error"] = "%s: %s" % (type(e).__name__, str(e)[:120])
        log("  [FAIL] %-10s %s" % (src["name"], stat["error"]))
        return stat, []


def fetch_all(with_extras: bool = True) -> dict:
    """跑一轮完整抓取，落盘，返回快照 dict。

    with_extras=False 时只抓新闻本身，视频/搜索/镜像交给任务队列一条条做 ——
    v0.3 之后队列才是老大，一次性全干完太容易在短窗口里被打断。
    """
    started = time.time()
    sources = _load_sources()
    log("═" * 60)
    log("开始抓新闻，%d 个源（限速 %.1f MB/s）"
        % (len(sources), MAX_RATE_BYTES / 1048576.0 if MAX_RATE_BYTES else 0))

    with STATUS_LOCK:
        STATUS["fetching"] = True
        STATUS["state"] = "fetching"
        STATUS["progress_done"] = 0
        STATUS["progress_total"] = len(sources)

    stats, collected = [], []
    try:
        with ThreadPoolExecutor(max_workers=WORKERS_FEED) as ex:
            futures = {ex.submit(fetch_one_source, s): s for s in sources}
            for fut in futures:
                stat, items = fut.result()
                stats.append(stat)
                for it in items:
                    it["source"] = stat["name"]
                    it["source_id"] = stat["id"]
                    it["category"] = stat["cat"]
                    collected.append(it)
                with STATUS_LOCK:
                    STATUS["progress_done"] += 1
    except KeyboardInterrupt:
        raise

    dead = [s for s in sources
            if not any(st["id"] == s["id"] and st["ok"] for st in stats)]
    if dead:
        # 偶发抽风（SSL 握手、超时）会让整个分类凭空消失，歇一会儿再试一次
        log("有 %d 个源没抓到，隔 4 秒再试一次：%s"
            % (len(dead), "、".join(s["name"] for s in dead)))
        time.sleep(4)
        with ThreadPoolExecutor(max_workers=min(WORKERS_FEED, len(dead))) as ex:
            futures = {ex.submit(fetch_one_source, s): s for s in dead}
            for fut in futures:
                stat, items = fut.result()
                for i, st in enumerate(stats):
                    if st["id"] == stat["id"]:
                        stats[i] = stat
                        break
                if not stat["ok"]:
                    continue
                for it in items:
                    it["source"] = stat["name"]
                    it["source_id"] = stat["id"]
                    it["category"] = stat["cat"]
                    collected.append(it)

    # 跨源去重 + 按时间倒序
    seen, uniq = set(), []
    for it in collected:
        key = it["url"] or it["title"]
        h = hashlib.sha1(key.encode("utf-8", "replace")).hexdigest()[:16]
        if h in seen:
            continue
        seen.add(h)
        it["id"] = h
        uniq.append(it)
    uniq.sort(key=lambda x: (x.get("published_ts") or 0), reverse=True)

    # 个别源时区标错，时间会跑到未来，按「刚刚」处理，免得霸在列表最前
    _now = time.time()
    for it in uniq:
        if it.get("published_ts") and it["published_ts"] > _now:
            it["published_ts"] = _now

    # 有的源会混进几年前的存货，按时间切一刀（解析不出时间的留着，不冤枉它）。
    # 更新慢的源（科学类那种一个月才发几篇的）可以在 sources.py 里用 max_age_days 放宽。
    limits = {s["id"]: s.get("max_age_days", MAX_AGE_DAYS) for s in sources}
    if any(v and v > 0 for v in limits.values()):
        _cut = time.time()
        kept, dropped = [], 0
        for it in uniq:
            lim = limits.get(it.get("source_id"), MAX_AGE_DAYS)
            ts = it.get("published_ts")
            if lim and lim > 0 and ts and ts < _cut - lim * 86400:
                dropped += 1
                continue
            kept.append(it)
        if dropped:
            log("扔掉 %d 条过期旧闻" % dropped)
        uniq = kept

    # RSS 是纯文字的源，去原文页抠 og:image（每个源限量，免得抓取拖太久）
    if ENRICH_IMAGES:
        need, per_enrich = [], {}
        for it in uniq:
            if it.get("image_src") or not it.get("url"):
                continue
            sid = it["source_id"]
            if per_enrich.get(sid, 0) >= MAX_ENRICH_PER_SOURCE:
                continue
            per_enrich[sid] = per_enrich.get(sid, 0) + 1
            need.append(it)
        if need:
            log("RSS 里没图的，去原文页抠封面：%d 篇" % len(need))
            with STATUS_LOCK:
                STATUS["progress_total"] = len(sources) + len(need)
            with ThreadPoolExecutor(max_workers=WORKERS_IMG) as ex:
                futs = {ex.submit(fetch_og_image, it["url"]): it for it in need}
                for fut in futs:
                    it = futs[fut]
                    try:
                        it["image_src"] = fut.result()
                    except Exception:  # noqa: BLE001
                        it["image_src"] = ""
                    with STATUS_LOCK:
                        STATUS["progress_done"] += 1

    # 有的站拿同一张模板图糊弄所有新闻（背景图、栏目图那种），
    # 同一张图被 3 条以上不同新闻引用，基本可以断定不是正文配图，扔掉。
    _freq: dict[str, int] = {}
    for it in uniq:
        u = it.get("image_src")
        if u:
            _freq[u] = _freq.get(u, 0) + 1
    for it in uniq:
        u = it.get("image_src")
        if u and _freq.get(u, 0) >= 3:
            it["image_src"] = ""

    # 封面图：每个源限量下载
    per_src_count: dict[str, int] = {}
    to_get = []
    for it in uniq:
        sid = it["source_id"]
        if it.get("image_src") and per_src_count.get(sid, 0) < MAX_IMAGES_PER_SOURCE:
            per_src_count[sid] = per_src_count.get(sid, 0) + 1
            to_get.append(it)
    if to_get:
        log("下封面图，%d 张" % len(to_get))
        with ThreadPoolExecutor(max_workers=WORKERS_IMG) as ex:
            fut_map = {ex.submit(download_image, it["image_src"], it["url"]): it
                       for it in to_get}
            for fut in fut_map:
                it = fut_map[fut]
                try:
                    it["image"] = fut.result()
                except Exception:  # noqa: BLE001
                    it["image"] = ""

    # 正文：点开卡片看本地全文，不用跳去外网
    if FETCH_ARTICLE:
        _attach_articles(uniq)
    else:
        for it in uniq:
            it.pop("_blob", None)
            it["content"] = []

    # 之前抓过的标个 new=False，这次新出现的标 True
    prev_ids = set()
    try:
        with open(LATEST_FILE, "r", encoding="utf-8") as f:
            prev = json.load(f)
        prev_ids = {i["id"] for i in prev.get("items", [])}
    except (OSError, ValueError, KeyError):
        pass
    for it in uniq:
        it["is_new"] = it["id"] not in prev_ids
        it["image"] = it.get("image") or ""
        if it.get("published_ts"):
            it["published"] = time.strftime("%m-%d %H:%M",
                                            time.localtime(it["published_ts"]))
        else:
            it["published"] = ""

    snap_id = time.strftime("%Y-%m-%d_%H%M")
    generated_ts = time.time()
    cat_counts = {}
    for it in uniq:
        cat_counts[it["category"]] = cat_counts.get(it["category"], 0) + 1

    snapshot = {
        "id": snap_id,
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(generated_ts)),
        "generated_ts": generated_ts,
        "duration_sec": round(time.time() - started, 1),
        "total": len(uniq),
        "category_counts": cat_counts,
        "categories": [c for c in CATEGORIES if c in cat_counts],
        "source_stats": stats,
        "items": uniq,
    }

    _write_snapshot(snapshot)
    _write_doc(snapshot)
    _prune()

    if with_extras:
        _fetch_videos()          # 视频单独一段，它挂了不影响上面已经存好的新闻
        _fetch_search()          # 必应搜索同理，结果另外存一份

        # 顺手把搜索到的页面扒成离线镜像（设置里开了才做）
        if MIRROR_AUTO and SEARCH_KEYWORDS:
            try:
                s_idx = _read_json(SEARCH_FILE, {})
                _mirror_search_hits(list((s_idx or {}).get("items") or []))
            except Exception as e:  # noqa: BLE001
                log("顺手扒镜像出错，不影响别的：%s: %s" % (type(e).__name__, e))

    with STATUS_LOCK:
        STATUS["last_fetch_ts"] = generated_ts
        STATUS["last_fetch_at"] = snapshot["generated_at"]
        STATUS["snapshot_id"] = snap_id
        STATUS["total_items"] = len(uniq)
        STATUS["category_counts"] = cat_counts
        STATUS["fetching"] = False
        STATUS["state"] = "idle"
        STATUS["last_error"] = "" if uniq else "一个源都没抓下来"
    save_state()
    log("抓完了：%d 条，耗时 %.1f 秒" % (len(uniq), snapshot["duration_sec"]))
    return snapshot


def _atomic_write(path: str, text: str) -> None:
    """先写临时文件再改名，这样网页那边永远读不到写了一半的 JSON。"""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def _write_snapshot(snap: dict) -> None:
    body = json.dumps(snap, ensure_ascii=False, separators=(",", ":"))
    _atomic_write(os.path.join(SNAP_DIR, snap["id"] + ".json"), body)
    _atomic_write(LATEST_FILE, body)
    _rebuild_index()


def _rebuild_index() -> None:
    rows = []
    for fn in sorted(os.listdir(SNAP_DIR), reverse=True):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(SNAP_DIR, fn), "r", encoding="utf-8") as f:
                s = json.load(f)
            rows.append({"id": s["id"], "generated_at": s["generated_at"],
                         "total": s["total"], "category_counts": s.get("category_counts", {})})
        except (OSError, ValueError, KeyError):
            continue
    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump({"snapshots": rows}, f, ensure_ascii=False, separators=(",", ":"))


def _write_doc(snap: dict) -> None:
    """生成人能直接读的 Markdown 文档。"""
    lines = []
    lines.append("# 离线新闻速览 · %s\n" % snap["generated_at"])
    lines.append("> 共 **%d** 条 ｜ 有效源 %d/%d ｜ 抓取耗时 %.1f 秒\n"
                 % (snap["total"],
                    sum(1 for s in snap["source_stats"] if s["ok"]),
                    len(snap["source_stats"]),
                    snap["duration_sec"]))
    lines.append("| 分类 | 条数 |\n| --- | --- |")
    for c in snap["categories"]:
        lines.append("| %s | %d |" % (c, snap["category_counts"][c]))
    lines.append("")

    by_cat: dict[str, list] = {}
    for it in snap["items"]:
        by_cat.setdefault(it["category"], []).append(it)

    for cat in CATEGORIES:
        items = by_cat.get(cat)
        if not items:
            continue
        lines.append("\n---\n\n## %s（%d 条）\n" % (cat, len(items)))
        for it in items:
            title = it["title"].replace("[", "【").replace("]", "】")
            if it["url"]:
                lines.append("### [%s](%s)" % (title, it["url"]))
            else:
                lines.append("### %s" % title)
            if it.get("image"):
                lines.append("")
                lines.append("![封面](%s)" % it["image"].replace("images/", "../images/"))
            meta = it["source"]
            if it.get("published"):
                meta += " · " + it["published"]
            if it.get("is_new"):
                meta += " · 新"
            lines.append("")
            lines.append("`%s`" % meta)
            blocks = it.get("content") or []
            if blocks:
                lines.append("")
                for b in blocks:
                    t = b.get("t")
                    if t == "img":
                        if b.get("v"):
                            lines.append("![配图](%s)"
                                         % b["v"].replace("images/", "../images/"))
                            lines.append("")
                    elif t == "h":
                        lines.append("**%s**" % b["v"])
                        lines.append("")
                    else:
                        lines.append(b["v"])
                        lines.append("")
            elif it.get("summary"):
                lines.append("")
                lines.append(it["summary"])
            lines.append("")

    lines.append("\n---\n\n*由 newsd.py 自动生成*\n")
    with open(os.path.join(DOCS_DIR, snap["id"] + ".md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def _prune() -> None:
    """只留最近 N 份快照 + 被它们引用的图片（快照、文档、图片）。

    注意别把这个和 DOM 那边收拾垃圾节点的 _prune_dom 搞混了 ——
    以前这俩都叫 _prune，后者把前者盖掉，一调就 TypeError。
    """
    try:
        snaps = sorted([f for f in os.listdir(SNAP_DIR) if f.endswith(".json")],
                       reverse=True)
        for fn in snaps[KEEP_SNAPSHOTS:]:
            try:
                os.remove(os.path.join(SNAP_DIR, fn))
                doc = os.path.join(DOCS_DIR, fn[:-5] + ".md")
                if os.path.exists(doc):
                    os.remove(doc)
            except OSError:
                pass

        keep = set()
        for fn in snaps[:KEEP_SNAPSHOTS]:
            try:
                with open(os.path.join(SNAP_DIR, fn), "r", encoding="utf-8") as f:
                    body = f.read()
            except OSError:
                continue
            # 封面和正文配图都得算上，只认 it["image"] 会把正文图全删掉
            keep.update(re.findall(r"images/([A-Za-z0-9_.-]+)", body))
        for img in os.listdir(IMG_DIR):
            if img not in keep:
                try:
                    os.remove(os.path.join(IMG_DIR, img))
                except OSError:
                    pass
    except OSError:
        pass


# ══════════════════════════════════════════════════════════════════════
#  本地短视频（B 站热门榜）
# ══════════════════════════════════════════════════════════════════════

def _fetch_videos() -> None:
    """抓一轮热门短视频，写 data/videos.json。

    独立成一个函数，整个包在 try 里 —— B 站接口抽风的时候，
    新闻该存还是存，别被它连累。
    """
    if not FETCH_VIDEO:
        return
    if vmod is None:
        log("videos 模块没加载上，这轮不抓视频")
        return

    t0 = time.time()
    try:
        items = vmod.fetch_all(VIDEO_DIR, count=VIDEO_COUNT, keep=VIDEO_KEEP,
                               max_duration=VIDEO_MAX_DURATION, qn=VIDEO_QN,
                               max_bytes=VIDEO_MAX_BYTES, log=log,
                               throttle=_LIMITER.take)
    except Exception as e:  # noqa: BLE001
        log("视频抓取出错：%s: %s" % (type(e).__name__, e))
        return

    if not items:
        log("这轮没抓到视频")
        return

    total = sum(int(i.get("size") or 0) for i in items)
    body = json.dumps({
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "generated_ts": time.time(),
        "total": len(items),
        "total_bytes": total,
        "items": items,
    }, ensure_ascii=False, separators=(",", ":"))
    _atomic_write(VIDEO_INDEX, body)

    with STATUS_LOCK:
        STATUS["video_total"] = len(items)
        STATUS["video_bytes"] = total
    log("视频入库：%d 个，共 %.0f MB，耗时 %.1f 秒"
        % (len(items), total / 1048576.0, time.time() - t0))


# ══════════════════════════════════════════════════════════════════════
#  必应搜索
# ══════════════════════════════════════════════════════════════════════

def _read_json(path: str, default):
    """读个小 JSON，读不动就给默认值。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _fetch_search() -> None:
    """按设置里的关键词去必应搜一遍，结果单独存 data/search.json。

    搜索结果不混进新闻流 —— 那边是「今天发生了什么」，这边是「我想找什么」，
    混在一起两边都不好用。网页上单独一个「搜索」标签页。
    """
    if searchmod is None:
        return
    keywords = [k for k in SEARCH_KEYWORDS if (k or "").strip()]
    if not keywords:
        return

    t0 = time.time()
    log("开始搜索 %d 个关键词：%s" % (len(keywords), "、".join(keywords)))
    try:
        items = searchmod.run(keywords, per_keyword=SEARCH_PER_KEYWORD,
                              news=SEARCH_NEWS, timeout=15, log=log)
    except Exception as e:  # noqa: BLE001
        log("搜索出错：%s: %s" % (type(e).__name__, e))
        return
    if not items:
        log("这轮搜索没搜到东西")
        return

    # source_id 按关键词分，这样「每源几篇正文」的配额是按关键词各算各的
    for it in items:
        it["source"] = "必应"
        it["source_id"] = "bing:" + (it.get("keyword") or "")
        it["category"] = "搜索"

    if SEARCH_FETCH_ARTICLE and FETCH_ARTICLE:
        try:
            _attach_articles(items, per_source=SEARCH_PER_KEYWORD)
        except Exception as e:  # noqa: BLE001
            log("搜索结果的正文没抓好，先存下来：%s: %s" % (type(e).__name__, e))

    for it in items:
        it.pop("_blob", None)     # 别跟着写进 JSON

    # 搜索结果的整页镜像：这样「原网页」那个开关才有东西可切。
    # 只给搜索结果做，新闻那种一次几百条全扒会把盘吃光。
    if SEARCH_MIRROR and mirrormod is not None:
        done = 0
        for it in items:
            if done >= SEARCH_MIRROR_COUNT:
                break
            if not disk_ok():
                log("磁盘不够了，剩下的整页不扒了")
                break
            url = (it.get("url") or "").strip()
            if not url.startswith(("http://", "https://")):
                continue
            try:
                entry = mirrormod.mirror_page(
                    url, MIRROR_DIR,
                    max_bytes=SEARCH_MIRROR_MB * 1024 * 1024,
                    want_js=MIRROR_JS, log=lambda *a: None)
                it["mirror"] = entry.get("id") or ""
                done += 1
            except Exception:  # noqa: BLE001
                continue
        if done:
            log("搜索结果扒了 %d 篇整页，切「原网页」能看" % done)

    body = json.dumps({
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "generated_ts": time.time(),
        "keywords": keywords,
        "total": len(items),
        "items": items,
    }, ensure_ascii=False, separators=(",", ":"))
    _atomic_write(SEARCH_FILE, body)

    with STATUS_LOCK:
        STATUS["search_total"] = len(items)
        STATUS["search_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        STATUS["search_keywords"] = keywords
    log("搜索入库：%d 条，耗时 %.1f 秒" % (len(items), time.time() - t0))


# ══════════════════════════════════════════════════════════════════════
#  离线网页镜像
# ══════════════════════════════════════════════════════════════════════

def _mirror_index() -> dict:
    idx = _read_json(MIRROR_INDEX, None)
    if not isinstance(idx, dict):
        idx = {"total": 0, "items": []}
    if not isinstance(idx.get("items"), list):
        idx["items"] = []
    return idx


def _save_mirror_index(items: list) -> None:
    body = json.dumps({
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "generated_ts": time.time(),
        "total": len(items),
        "items": items,
    }, ensure_ascii=False, separators=(",", ":"))
    _atomic_write(MIRROR_INDEX, body)
    with STATUS_LOCK:
        STATUS["mirror_total"] = len(items)


def mirror_one(url: str) -> dict:
    """扒一个网页存下来，挂进索引。失败往上抛，让调用方告诉用户。"""
    if mirrormod is None:
        raise RuntimeError("mirror 模块没加载上")
    url = (url or "").strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError("网址得是 http:// 或 https:// 开头的")
    entry = mirrormod.mirror_page(url, MIRROR_DIR, max_bytes=MIRROR_MAX_BYTES,
                                  want_js=MIRROR_JS, log=log)
    idx = _mirror_index()
    items = [i for i in idx["items"] if i.get("id") != entry["id"]]
    items.insert(0, entry)
    keep, drop = items[:MIRROR_KEEP], items[MIRROR_KEEP:]
    for d in drop:
        shutil.rmtree(os.path.join(MIRROR_DIR, str(d.get("id") or "")),
                      ignore_errors=True)
    if drop:
        log("镜像超量，删掉最旧的 %d 个，只留 %d 个" % (len(drop), MIRROR_KEEP))
    _save_mirror_index(keep)
    return entry


def delete_mirror(mid: str) -> bool:
    """删一个镜像（目录 + 索引条目）。"""
    mid = (mid or "").strip()
    if not mid or "/" in mid or "\\" in mid or ".." in mid:
        return False
    idx = _mirror_index()
    keep = [i for i in idx["items"] if i.get("id") != mid]
    found = len(keep) != len(idx["items"])
    shutil.rmtree(os.path.join(MIRROR_DIR, mid), ignore_errors=True)
    if found:
        _save_mirror_index(keep)
    return found


def _mirror_search_hits(items: list) -> None:
    """顺手把搜索到的前几个页面也扒成镜像。"""
    if not MIRROR_AUTO or mirrormod is None:
        return
    urls = [it.get("url") for it in items[:max(1, MIRROR_AUTO_COUNT)]]
    urls = [u for u in urls if u]
    if not urls:
        return
    log("顺手扒 %d 个搜索结果的镜像…" % len(urls))
    ok = 0
    for u in urls:
        try:
            mirror_one(u)
            ok += 1
        except Exception as e:  # noqa: BLE001
            log("  这个扒不动 %s（%s: %s）" % (u[:60], type(e).__name__, str(e)[:60]))
    log("镜像完成 %d/%d 个" % (ok, len(urls)))


def _restore_index_status() -> None:
    """重启后把视频/搜索/镜像的数量读回来，不然状态栏全是 0。"""
    v = _read_json(VIDEO_INDEX, None)
    if isinstance(v, dict):
        with STATUS_LOCK:
            STATUS["video_total"] = int(v.get("total") or 0)
            STATUS["video_bytes"] = int(v.get("total_bytes") or 0)
    s = _read_json(SEARCH_FILE, None)
    if isinstance(s, dict):
        with STATUS_LOCK:
            STATUS["search_total"] = int(s.get("total") or 0)
            STATUS["search_at"] = s.get("generated_at") or ""
            STATUS["search_keywords"] = s.get("keywords") or []
    m = _mirror_index()
    with STATUS_LOCK:
        STATUS["mirror_total"] = len(m["items"])
        STATUS["mirror_bytes"] = sum(int(i.get("bytes") or 0) for i in m["items"])
    mu = _read_json(MUSIC_INDEX, None)
    if isinstance(mu, dict):
        with STATUS_LOCK:
            STATUS["music_total"] = int(mu.get("total") or 0)
            STATUS["music_bytes"] = int(mu.get("total_bytes") or 0)
    bi = _read_json(BILI_FILE, None)
    if isinstance(bi, dict):
        with STATUS_LOCK:
            STATUS["bili_total"] = int(bi.get("total") or 0)
    an = _read_json(ANIME_FILE, None)
    if isinstance(an, dict):
        with STATUS_LOCK:
            STATUS["anime_total"] = len(an.get("items") or [])


def config_payload() -> dict:
    """设置面板要的东西：当前值 + 怎么画 + 默认值。"""
    if cfgr is None:
        return {"config": {}, "schema": [], "defaults": {},
                "error": "config 模块没加载上"}
    return {
        "config": dict(CFG),
        "schema": cfgr.SCHEMA,
        "defaults": dict(cfgr.DEFAULTS),
        "path": CONFIG_FILE,
    }


def start_mirror_job(url: str) -> None:
    """后台扒一个网页。扒一个要几秒到几十秒，不能让浏览器在那儿干等。"""
    with STATUS_LOCK:
        if (STATUS.get("mirror_job") or {}).get("state") == "running":
            return              # 已经在扒了，别叠着来
        STATUS["mirror_job"] = {"url": url, "state": "running",
                                "started_ts": time.time(), "error": ""}

    def work():
        try:
            entry = mirror_one(url)
            with STATUS_LOCK:
                STATUS["mirror_job"] = {
                    "url": url, "state": "done", "error": "",
                    "id": entry["id"], "title": entry["title"],
                    "bytes": entry["bytes"], "assets": entry["assets"],
                    "finished_ts": time.time(),
                }
        except Exception as e:  # noqa: BLE001
            log("镜像失败 %s：%s: %s" % (url[:60], type(e).__name__, str(e)[:120]))
            with STATUS_LOCK:
                STATUS["mirror_job"] = {
                    "url": url, "state": "error",
                    "error": "%s: %s" % (type(e).__name__, str(e)[:160]),
                    "finished_ts": time.time(),
                }

    threading.Thread(target=work, daemon=True, name="mirror-one").start()


def start_search_job() -> None:
    """手动搜一次。跟镜像一样丢后台，前端轮询状态。"""
    with STATUS_LOCK:
        if (STATUS.get("search_job") or {}).get("state") == "running":
            return
        STATUS["search_job"] = {"state": "running", "started_ts": time.time(),
                                "error": "", "total": 0}

    def work():
        try:
            _fetch_search()
            with STATUS_LOCK:
                STATUS["search_job"] = {
                    "state": "done", "error": "",
                    "total": len(_read_json(SEARCH_FILE, {}).get("items") or []),
                    "finished_ts": time.time(),
                }
        except Exception as e:  # noqa: BLE001
            log("搜索失败：%s: %s" % (type(e).__name__, str(e)[:120]))
            with STATUS_LOCK:
                STATUS["search_job"] = {
                    "state": "error",
                    "error": "%s: %s" % (type(e).__name__, str(e)[:160]),
                    "finished_ts": time.time(),
                }

    threading.Thread(target=work, daemon=True, name="search-once").start()


# ══════════════════════════════════════════════════════════════════════
#  任务执行层（队列里的每一种任务对应下面一个函数）
# ══════════════════════════════════════════════════════════════════════
#
# 每个 handler 返回 (状态, 备注)：状态是 "done" 或 "skipped"，
# 真出错就往外抛异常，由 run_queue 统一标 failed 和处理重试。

BILI_FILE = os.path.join(DATA_DIR, "bili.json")
MUSIC_META = os.path.join(DATA_DIR, "music_meta.json")
PLAYLIST_FILE = os.path.join(DATA_DIR, "playlists.json")
ANIME_DL_FILE = os.path.join(DATA_DIR, "anime_dl.json")
NM_TRACKS_FILE = os.path.join(DATA_DIR, "netease_tracks.json")
NM_CACHE_FILE = os.path.join(DATA_DIR, "netmusic_cache.json")
WISH_FILE = os.path.join(DATA_DIR, "wishes.json")


def _write_json(path: str, obj) -> None:
    _atomic_write(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))


def _now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


# ── 新闻 ──

def _task_news(task) -> tuple[str, str]:
    snap = fetch_all(with_extras=False)
    return "done", "抓到 %d 条" % snap.get("total", 0)


# ── 必应搜索 ──

def _task_search(task) -> tuple[str, str]:
    if not SEARCH_KEYWORDS:
        return "skipped", "没设关键词"
    before = len(_read_json(SEARCH_FILE, {}).get("items") or [])
    _fetch_search()
    after = len(_read_json(SEARCH_FILE, {}).get("items") or [])
    return "done", "%d 条（+%d）" % (after, max(0, after - before))


# ── B 站热门视频（真下文件） ──

def _task_videos(task) -> tuple[str, str]:
    if not FETCH_VIDEO:
        return "skipped", "设置里关了"
    if vmod is None:
        return "skipped", "videos 模块没加载"
    _fetch_videos()
    with STATUS_LOCK:
        n = STATUS.get("video_total", 0)
    return ("done", "本地共 %d 个" % n) if n else ("skipped", "这轮没抓到")


# ── 点歌台：从网易云公开榜单挑几首下下来 ──

def _rebuild_music() -> None:
    """扫描 data/music/ 重建 music.json，并把榜单信息合进去。"""
    if musicmod is None:
        return
    try:
        items = musicmod.scan(MUSIC_DIR, MUSIC_COVER_DIR)
    except Exception as e:  # noqa: BLE001
        log("点歌台索引重建失败：%s: %s" % (type(e).__name__, e))
        return
    meta = _read_json(MUSIC_META, {}) or {}
    for it in items:
        m = meta.get(it.get("name")) or {}
        it["chart"] = m.get("chart") or ""
        it["added_at"] = m.get("added_at") or ""
        it["song_id"] = m.get("id") or ""
        # 时长以接口给的为准（本地解析 VBR 的时长很麻烦，有现成的就用）
        if m.get("duration_s"):
            it["duration_s"] = int(m["duration_s"])
    total = sum(int(i.get("size") or 0) for i in items)
    _write_json(MUSIC_INDEX, {
        "generated_at": _now_str(), "generated_ts": time.time(),
        "total": len(items), "total_bytes": total, "items": items,
    })
    with STATUS_LOCK:
        STATUS["music_total"] = len(items)
        STATUS["music_bytes"] = total


def _music_prune() -> int:
    """超出 MUSIC_KEEP 就从最老的下手删。收藏的一首都不动。"""
    try:
        items = (musicmod.scan(MUSIC_DIR, MUSIC_COVER_DIR) if musicmod else [])
    except Exception:  # noqa: BLE001
        return 0
    if len(items) <= MUSIC_KEEP:
        return 0
    meta = _read_json(MUSIC_META, {}) or {}
    fav_ids = set()
    if _LIB is not None:
        for rec in _LIB.listing(kind="music", fav=True, limit=10000):
            fav_ids.add(rec.get("rid") or "")
    def _age(it):
        return float((meta.get(it.get("name")) or {}).get("added_ts") or 0)
    items.sort(key=_age)          # 先删 added_ts 小的（老）
    removed = 0
    for it in items:
        if len(items) - removed <= MUSIC_KEEP:
            break
        if it.get("id") in fav_ids:
            continue
        try:
            os.remove(os.path.join(MUSIC_DIR, it["name"]))
            meta.pop(it["name"], None)
            removed += 1
        except OSError:
            pass
    if removed:
        _write_json(MUSIC_META, meta)
    return removed


def _task_music(task) -> tuple[str, str]:
    if not MUSIC_ENABLED:
        return "skipped", "设置里关了"
    if netmusic is None or musicmod is None:
        return "skipped", "模块没加载上"
    count = int(task["payload"].get("count") or MUSIC_PER_RUN or 0)
    if count <= 0:
        return "skipped", "一次抓 0 首"
    charts = tuple(MUSIC_CHARTS) or ("热歌榜",)
    picks = netmusic.pick(_SESSION, charts=charts, count=count, log=log)
    if not picks:
        return "skipped", "榜单里没挑到能下的歌"

    meta = _read_json(MUSIC_META, {}) or {}
    got = 0
    for it in picks:
        if not disk_ok():
            log("磁盘快到警戒线了，剩下的歌不下了")
            break
        try:
            r = netmusic.download(_SESSION, it, MUSIC_DIR, log=log)
        except Exception as e:  # noqa: BLE001
            log("下歌失败（继续下一首）：%s: %s" % (type(e).__name__, str(e)[:100]))
            continue
        if not r.get("ok"):
            if r.get("error"):
                log("跳过一首：%s" % r["error"])
            continue
        if not r.get("skipped"):
            got += 1
        fn = os.path.basename(r.get("file") or "")
        if fn:
            meta[fn] = {"id": it.get("id"), "chart": it.get("chart") or "",
                        "added_at": _now_str(), "added_ts": time.time()}
    _write_json(MUSIC_META, meta)
    _music_prune()
    _rebuild_music()
    with STATUS_LOCK:
        n = STATUS.get("music_total", 0)
    return ("done", "新下 %d 首，本地共 %d 首" % (got, n)) if got else \
           ("skipped", "没有新歌可下（本地共 %d 首）" % n)


# ── B 站推荐 / 关键词搜索（只存条目和封面） ──

def _bili_load() -> list:
    data = _read_json(BILI_FILE, {}) or {}
    items = data.get("items") if isinstance(data, dict) else None
    return items if isinstance(items, list) else []


def _bili_save(items: list, keep: int = 300) -> None:
    items = items[:keep]
    _write_json(BILI_FILE, {"generated_at": _now_str(),
                            "generated_ts": time.time(),
                            "total": len(items), "items": items})
    with STATUS_LOCK:
        STATUS["bili_total"] = len(items)


def _bili_merge(new_items: list, kind: str) -> int:
    """按 bvid 合并进索引，新的排前面，旧的原样留着。"""
    old = _bili_load()
    seen = {i.get("bvid") for i in new_items if i.get("bvid")}
    merged = [dict(i, kind=kind, added_ts=time.time(), added_at=_now_str())
              for i in new_items if i.get("bvid")]
    for it in old:
        if it.get("bvid") in seen:
            continue
        merged.append(it)
    _bili_save(merged)
    return len(new_items)


def _save_covers(items: list, sub: str = "bili") -> None:
    """条目封面存本地（没网也能显示）。失败就当没有。"""
    for it in items:
        url = it.get("pic_url") or it.get("cover_url") or ""
        if not url or it.get("pic"):
            continue
        try:
            ext = ".jpg"
            name = hashlib.sha1(url.encode("utf-8")).hexdigest()[:16] + ext
            dest = os.path.join(IMG_DIR, name)
            if not os.path.isfile(dest):
                _SESSION.save_stream(url, dest, referer="https://www.bilibili.com/",
                                     timeout=15, max_bytes=2 * 1024 * 1024)
            it["pic"] = "images/" + name
        except Exception:  # noqa: BLE001
            it["pic"] = ""


def _task_bili_rec(task) -> tuple[str, str]:
    if not BILI_REC_ENABLED:
        return "skipped", "设置里关了"
    if animemod is None:
        return "skipped", "anime 模块没加载"
    items = animemod.home_rec(_SESSION, count=BILI_REC_COUNT, log=log)
    if not items:
        return "skipped", "推荐接口没给东西"
    _save_covers(items)
    n = _bili_merge(items, "rec")

    # 顺手把几条新推荐排进下载队列 —— 以前这一步是前端页面做的，
    # 结果"工具开着但网页没打开"就不下，逻辑挪到后端才说得通。
    queued = 0
    if BILI_REC_DL > 0 and _BP is not None and _QUEUE is not None:
        for it in items:
            if queued >= BILI_REC_DL:
                break
            dur = int(it.get("duration_s") or 0)
            if dur and dur > VIDEO_MAX_DURATION:
                continue
            bvid = it.get("bvid") or ""
            if not bvid:
                continue
            rec = _BP.dl_add(bvid, it.get("title") or "")
            if rec.get("state") in ("pending", "downloading", "done"):
                continue
            _QUEUE.add("bili_dl", "bv:" + bvid,
                       {"bvid": bvid, "title": it.get("title") or "",
                        "duration_s": dur})
            queued += 1
    if queued:
        log("从新推荐里排了 %d 个下载" % queued)
    return "done", "推荐 +%d 条%s" % (n, "，排了 %d 个下载" % queued if queued else "")


def _task_bili_search(task) -> tuple[str, str]:
    if not BILI_KEYWORDS:
        return "skipped", "没设关键词"
    if animemod is None:
        return "skipped", "anime 模块没加载"
    # 每次换一个词，别老搜同一个
    idx = int(time.time() // 3600) % max(1, len(BILI_KEYWORDS))
    kw = BILI_KEYWORDS[idx]
    items = animemod.search(_SESSION, kw, count=BILI_SEARCH_COUNT, log=log)
    if not items:
        return "skipped", "「%s」没搜到" % kw
    for it in items:
        it["keyword"] = kw
    _save_covers(items)
    n = _bili_merge(items, "search")
    return "done", "「%s」+%d 条" % (kw, n)


# ── 追番 / 追漫 ──

def _follows() -> list:
    data = _read_json(FOLLOWS_FILE, {}) or {}
    items = data.get("items") if isinstance(data, dict) else data
    return items if isinstance(items, list) else []


def _save_follows(items: list) -> None:
    _write_json(FOLLOWS_FILE, {"saved_at": _now_str(), "total": len(items),
                               "items": items})


def _anime_load() -> list:
    data = _read_json(ANIME_FILE, {}) or {}
    items = data.get("items") if isinstance(data, dict) else None
    return items if isinstance(items, list) else []


def _seed_follows() -> list:
    """按配置里的名字各搜一部番剧，加进追更。联网才跑，离线直接返回空。"""
    kws = [k for k in (ANIME_KEYWORDS or []) if (k or "").strip()]
    if not kws:
        return []
    items = _follows()
    have = {str(x.get("sid")) for x in items}
    added = 0
    for kw in kws:
        if added >= 8:
            break
        try:
            cands = animemod.bangumi_candidates(_SESSION, kw, log=lambda *a: None)
        except Exception:  # noqa: BLE001
            continue
        if not cands:
            continue
        hit = cands[0]
        sid = str(hit.get("sid") or "")
        if not sid or sid in have:
            continue
        items.append({
            "sid": sid,
            "type": str(hit.get("type") or "番剧"),
            "title": hit.get("title") or kw,
            "cover_url": hit.get("cover_url") or "",
            "url": hit.get("url") or "",
            "added_at": _now_str(),
            "last_ep_id": "",
            "auto": True,
        })
        have.add(sid)
        added += 1
    if added:
        _save_follows(items)
        log("自动追了 %d 部：%s" % (added, "、".join(
            x.get("title") or "" for x in items if x.get("auto"))))
    return items


def _task_anime(task) -> tuple[str, str]:
    if not ANIME_ENABLED:
        return "skipped", "设置里关了"
    if animemod is None:
        return "skipped", "anime 模块没加载"
    follows = _follows()
    if not follows and ANIME_AUTO_FOLLOW:
        # 追更列表空着就先按关键词各搜一部加进去 —— 省得刚装好什么都看不到
        follows = _seed_follows()
    if not follows:
        return "skipped", "还没追任何番"

    ups = animemod.check_bangumi(_SESSION, follows, log=log)
    if not ups:
        _write_json(ANIME_FILE, {"checked_at": _now_str(), "items": _anime_load()})
        return "skipped", "追的 %d 部都没更新" % len(follows)

    old = _anime_load()
    seen = {(u.get("sid"), str(u.get("new_ep"))) for u in ups}
    merged = [dict(u, found_ts=time.time(), found_at=_now_str()) for u in ups]
    for it in old:
        if (it.get("sid"), str(it.get("new_ep"))) in seen:
            continue
        merged.append(it)
    _write_json(ANIME_FILE, {"checked_at": _now_str(),
                             "total": len(merged), "items": merged[:300]})

    # 把"追到第几集"记回去，下次才知道什么是新的
    by_sid = {u.get("sid"): u for u in ups}
    changed = False
    for f in follows:
        u = by_sid.get(f.get("sid"))
        if u and u.get("ep_id") and f.get("last_ep_id") != u.get("ep_id"):
            f["last_ep_id"] = u.get("ep_id")
            f["last_ep"] = u.get("new_ep")
            f["last_checked"] = _now_str()
            changed = True
    if changed:
        _save_follows(follows)
    with STATUS_LOCK:
        STATUS["anime_total"] = len(_anime_load())
    return "done", "%d 部有更新" % len(ups)


# ── 手动排的镜像任务（队列里真正用到的唯一带 url 的任务） ──

def _task_mirror(task) -> tuple[str, str]:
    url = (task["payload"].get("url") or "").strip()
    if not url:
        return "skipped", "没有地址"
    rec = mirror_one(url)
    return "done", "扒好了：%s" % (rec.get("title") or url)[:40]


# ── 自定义歌单：搜用户名 → 看他/她的歌单 → 整个扒下来，边扒边显示进度 ──

def _playlists_load() -> list:
    data = _read_json(PLAYLIST_FILE, {}) or {}
    items = data.get("items") if isinstance(data, dict) else None
    return items if isinstance(items, list) else []


def _playlists_save(items: list) -> None:
    _write_json(PLAYLIST_FILE, {"saved_at": _now_str(),
                                "total": len(items), "items": items})


def _playlist_update(pid: str, **fields) -> dict | None:
    """改一条歌单的进度。前端 1.5 秒拉一次，所以进度只从这儿出。"""
    items = _playlists_load()
    for it in items:
        if str(it.get("pid")) == str(pid):
            for k, v in fields.items():
                if v is not None:
                    it[k] = v
            _playlists_save(items)
            return dict(it)
    return None


def _playlist_get(pid: str) -> dict | None:
    for it in _playlists_load():
        if str(it.get("pid")) == str(pid):
            return dict(it)
    return None


def _nm_cache_load() -> dict:
    d = _read_json(NM_CACHE_FILE, {}) or {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("users", {})
    d.setdefault("playlists", {})
    d.setdefault("plsearch", {})
    return d


def _nm_cache_put(kind: str, key: str, items: list) -> None:
    d = _nm_cache_load()
    d[kind][key] = {"ts": time.time(), "at": _now_str(), "items": items}
    # 别让它无限长：每类只留最近 60 条
    for k in ("users", "playlists", "plsearch"):
        bucket = d[k]
        if len(bucket) > 60:
            keep = sorted(bucket.items(), key=lambda kv: kv[1].get("ts") or 0,
                          reverse=True)[:60]
            d[k] = dict(keep)
    _write_json(NM_CACHE_FILE, d)


def _nm_cache_get(kind: str, key: str) -> dict | None:
    return (_nm_cache_load().get(kind) or {}).get(key)


def search_playlist_cached(keyword: str, timeout: int = 15) -> dict:
    """按歌单名搜，断网就翻缓存。跟搜用户那套一个路子。"""
    keyword = (keyword or "").strip()
    if not keyword:
        return {"q": "", "total": 0, "items": [], "offline": False, "error": "没给关键词"}
    if netmusic is None or not hasattr(netmusic, "search_playlist"):
        return {"q": keyword, "total": 0, "items": [], "offline": False,
                "error": "netmusic 模块没这个功能"}
    err = ""
    try:
        items = netmusic.search_playlist(_SESSION, keyword, log=log)
        if items:
            _nm_cache_put("plsearch", keyword, items)
            return {"q": keyword, "total": len(items), "items": items,
                    "offline": False, "cached_at": "", "error": ""}
        err = "没搜到这样的歌单"
    except Exception as e:  # noqa: BLE001
        err = "%s: %s" % (type(e).__name__, str(e)[:120])
    hit = _nm_cache_get("plsearch", keyword)
    if hit:
        return {"q": keyword, "total": len(hit.get("items") or []),
                "items": hit.get("items") or [], "offline": True,
                "cached_at": hit.get("at") or "", "error": err}
    return {"q": keyword, "total": 0, "items": [], "offline": False,
            "cached_at": "", "error": err}


def search_user_cached(keyword: str, timeout: int = 15) -> dict:
    """搜用户，断网就翻上次的缓存。

    学校电脑大部分时间是没网的，总不能一断网点开歌单广场就白屏。
    所以：先试网络，成功就顺手存一份；失败就把上次的拿出来，
    并且告诉前端这是"离线缓存"和什么时候存的。
    """
    keyword = (keyword or "").strip()
    if not keyword:
        return {"q": "", "total": 0, "items": [], "offline": False, "error": "没给关键词"}
    if netmusic is None or not hasattr(netmusic, "search_user"):
        return {"q": keyword, "total": 0, "items": [], "offline": False,
                "error": "netmusic 模块没这个功能"}
    err = ""
    try:
        items = netmusic.search_user(_SESSION, keyword, log=log)
        if items:
            _nm_cache_put("users", keyword, items)
            return {"q": keyword, "total": len(items), "items": items,
                    "offline": False, "cached_at": "", "error": ""}
        err = "没搜到这个人"
    except Exception as e:  # noqa: BLE001
        err = "%s: %s" % (type(e).__name__, str(e)[:120])
    hit = _nm_cache_get("users", keyword)
    if hit:
        return {"q": keyword, "total": len(hit.get("items") or []),
                "items": hit.get("items") or [], "offline": True,
                "cached_at": hit.get("at") or "", "error": err}
    return {"q": keyword, "total": 0, "items": [], "offline": False,
            "cached_at": "", "error": err}


def user_playlists_cached(uid: str, timeout: int = 15) -> dict:
    uid = (uid or "").strip()
    if not uid:
        return {"uid": "", "playlists": [], "offline": False, "error": "缺 uid"}
    if netmusic is None or not hasattr(netmusic, "user_playlists"):
        return {"uid": uid, "playlists": [], "offline": False,
                "error": "netmusic 模块没这个功能"}
    err = ""
    try:
        pls = netmusic.user_playlists(_SESSION, uid, log=log)
        if pls:
            _nm_cache_put("playlists", uid, pls)
            return {"uid": uid, "total": len(pls), "playlists": pls,
                    "offline": False, "cached_at": "", "error": ""}
        err = "这个人没有公开歌单"
    except Exception as e:  # noqa: BLE001
        err = "%s: %s" % (type(e).__name__, str(e)[:120])
    hit = _nm_cache_get("playlists", uid)
    if hit:
        return {"uid": uid, "total": len(hit.get("items") or []),
                "playlists": hit.get("items") or [], "offline": True,
                "cached_at": hit.get("at") or "", "error": err}
    return {"uid": uid, "total": 0, "playlists": [], "offline": False,
            "cached_at": "", "error": err}


# ── 离线点歌：离线时先记个名字，联网了自己去搜去下 ──

def _wishes_load() -> list:
    d = _read_json(WISH_FILE, {}) or {}
    items = d.get("items") if isinstance(d, dict) else d
    return items if isinstance(items, list) else []


def _wishes_save(items: list) -> None:
    _write_json(WISH_FILE, {"saved_at": _now_str(), "total": len(items),
                            "items": items})


def _wish_update(wid: str, **fields) -> dict | None:
    items = _wishes_load()
    for it in items:
        if str(it.get("id")) == str(wid):
            for k, v in fields.items():
                if v is not None:
                    it[k] = v
            _wishes_save(items)
            return dict(it)
    return None


def _task_wish(task) -> tuple[str, str]:
    wid = str(task["payload"].get("id") or "")
    text = str(task["payload"].get("text") or "")
    if not wid or not text:
        return "skipped", "缺名字"
    if netmusic is None or not hasattr(netmusic, "search_song"):
        return "skipped", "netmusic 没有搜歌功能"
    rec = next((x for x in _wishes_load() if str(x.get("id")) == wid), None)
    if rec is None:
        return "skipped", "这条点歌已经删了"

    _wish_update(wid, state="searching", error="")
    try:
        songs = netmusic.search_song(_SESSION, text, limit=10, log=log)
    except Exception as e:  # noqa: BLE001
        _wish_update(wid, state="error",
                     error="%s: %s" % (type(e).__name__, str(e)[:100]))
        raise
    if not songs:
        _wish_update(wid, state="error", error="没搜到「%s」" % text)
        return "skipped", "「%s」没搜到" % text

    # 优先挑能下的（fee 0/8），挑不到就把第一首拿来试
    usable = [x for x in songs if x.get("fee") in (0, 8)] or songs[:1]
    meta = _read_json(MUSIC_META, {}) or {}
    err = ""
    for song in usable[:3]:
        if not disk_ok():
            err = "磁盘快满了，先不下了"
            break
        _wish_update(wid, state="downloading",
                     song="%s - %s" % (song.get("artist"), song.get("name")))
        try:
            r = netmusic.download(_SESSION, song, MUSIC_DIR, log=log)
        except Exception as e:  # noqa: BLE001
            err = "%s: %s" % (type(e).__name__, str(e)[:80])
            continue
        if r.get("ok"):
            fn = os.path.basename(r.get("file") or "")
            if fn:
                meta[fn] = {"id": song.get("id"), "chart": "点歌",
                            "duration_s": song.get("duration_s") or 0,
                            "added_at": _now_str(), "added_ts": time.time()}
                _write_json(MUSIC_META, meta)
                _music_prune()
                _rebuild_music()
            _wish_update(wid, state="done", song="%s - %s" % (song.get("artist"),
                                                            song.get("name")),
                         file=fn, error="", done_at=_now_str())
            return "done", "下好了：%s" % song.get("name")
        err = r.get("error") or "下不下来"

    _wish_update(wid, state="error", error=err or "下不下来")
    return "skipped", "「%s」没下成" % text


def _task_playlist(task) -> tuple[str, str]:
    pid = str(task["payload"].get("pid") or "")
    name = str(task["payload"].get("name") or "歌单")
    if not pid:
        return "skipped", "缺歌单 id"
    if netmusic is None or not hasattr(netmusic, "crawl_playlist"):
        return "skipped", "netmusic 模块没这个功能"
    rec = _playlist_get(pid)
    if rec is None:
        return "skipped", "这个歌单已经不在列表里了"

    _playlist_update(pid, state="running", error="", current="")

    def on_progress(p):
        # 每下完一首写一次盘。文件很小，换来的是前端进度条能平滑地动
        _playlist_update(pid, state="running",
                         total=int(p.get("total") or 0),
                         done=int(p.get("done") or 0),
                         ok=int(p.get("ok") or 0),
                         failed=int(p.get("failed") or 0),
                         skipped=int(p.get("skipped") or 0),
                         current=str(p.get("current") or ""))

    try:
        res = netmusic.crawl_playlist(
            _SESSION, pid, MUSIC_DIR,
            limit=int(task["payload"].get("limit") or 50),
            on_progress=on_progress, log=log)
    except Exception as e:  # noqa: BLE001
        _playlist_update(pid, state="error",
                         error="%s: %s" % (type(e).__name__, str(e)[:120]))
        raise

    # 把这些歌归到这个歌单名下，点歌台里能按歌单分组显示
    meta = _read_json(MUSIC_META, {}) or {}
    now = _now_str()
    for fn in res.get("files") or []:
        base = os.path.basename(fn)
        if not base:
            continue
        meta[base] = {"id": "", "chart": name, "playlist": pid,
                      "added_at": now, "added_ts": time.time()}
    _write_json(MUSIC_META, meta)
    _music_prune()
    _rebuild_music()

    done_all = int(res.get("total") or 0)
    _playlist_update(pid, state="done",
                     total=done_all,
                     done=int(res.get("ok", 0)) + int(res.get("failed", 0))
                     + int(res.get("skipped", 0)),
                     ok=int(res.get("ok") or 0),
                     failed=int(res.get("failed") or 0),
                     skipped=int(res.get("skipped") or 0),
                     current="", error=str(res.get("error") or ""))
    if done_all == 0:
        # 整张歌单一首能下的都没有（多半全是 VIP/无版权）——
        # 别显示成「已下好 0 首」让人以为成功了，明确标红说清楚
        _playlist_update(pid, state="error",
                         error="这一整个歌单都是 VIP 或无版权的歌，下不了")
        return "skipped", "%s：整张都是 VIP，下不了" % name
    return "done", "%s：下好 %d 首（共 %d）" % (name, res.get("ok", 0), done_all)


# ── B 站整页：搜索、关键词、单个下载 ──

def bili_search_cached(q: str, count: int = 20) -> dict:
    """搜 B 站视频，断网就翻上次的结果。"""
    q = (q or "").strip()
    if not q:
        return {"q": "", "total": 0, "items": [], "offline": False, "error": "没给关键词"}
    if bilimod is None or _BP is None:
        return {"q": q, "total": 0, "items": [], "offline": False,
                "error": "bili 模块没加载"}
    err = ""
    try:
        items = bilimod.search(_SESSION, q, count=count, log=log)
        if items:
            _BP.search_save(q, items)
            with STATUS_LOCK:
                STATUS["bili_total"] = len(items)
            return {"q": q, "total": len(items), "items": items,
                    "offline": False, "cached_at": "", "error": ""}
        err = "没搜到"
    except Exception as e:  # noqa: BLE001
        err = "%s: %s" % (type(e).__name__, str(e)[:120])
    old = _BP.search_load()
    if old.get("items"):
        return {"q": q, "total": len(old["items"]), "items": old["items"],
                "offline": True, "cached_at": old.get("at") or "", "error": err}
    return {"q": q, "total": 0, "items": [], "offline": False,
            "cached_at": "", "error": err}


def _task_bili_dl(task) -> tuple[str, str]:
    bvid = str(task["payload"].get("bvid") or "")
    title = str(task["payload"].get("title") or "")
    if not bvid:
        return "skipped", "缺 bvid"
    if bilimod is None or _BP is None:
        return "skipped", "bili 模块没加载"
    _BP.dl_update(bvid, state="downloading", progress=0, error="")
    try:
        rec = bilimod.download_one(
            _SESSION, {"bvid": bvid, "title": title,
                       "duration_s": task["payload"].get("duration_s") or 0},
            VIDEO_DIR, qn=VIDEO_QN, max_duration=VIDEO_MAX_DURATION,
            max_bytes=VIDEO_MAX_BYTES, log=log)
    except Exception as e:  # noqa: BLE001
        _BP.dl_update(bvid, state="error",
                      error="%s: %s" % (type(e).__name__, str(e)[:120]))
        raise
    if not rec.get("ok"):
        _BP.dl_update(bvid, state="error", error=rec.get("error") or "下不下来")
        return "skipped", rec.get("error") or "下不下来"
    rel = ""
    try:
        rel = os.path.relpath(rec.get("file") or "", DATA_DIR).replace("\\", "/")
    except ValueError:
        rel = ""
    _BP.dl_update(bvid, state="done", progress=100, error="", file=rel,
                  size=int(rec.get("size") or 0))
    return "done", "下好了：%s" % title[:30]


def _task_bili_kw(task) -> tuple[str, str]:
    wid = str(task["payload"].get("id") or "")
    kw = str(task["payload"].get("keyword") or "")
    if not kw or _BP is None:
        return "skipped", "缺关键词"
    _BP.want_update(wid, state="running", note="正在搜…")
    res = bili_search_cached(kw, count=20)
    if not res.get("items"):
        _BP.want_update(wid, state="failed",
                        note=res.get("error") or "没搜到")
        return "skipped", "「%s」没搜到" % kw
    # 前两条不太长的排进下载队列
    picked = [x for x in res["items"]
              if 0 < int(x.get("duration_s") or 0) <= 1800][:2]
    for x in picked:
        _BP.dl_add(x["bvid"], x.get("title") or "")
        if _QUEUE is not None:
            _QUEUE.add("bili_dl", "bv:" + x["bvid"],
                       {"bvid": x["bvid"], "title": x.get("title") or "",
                        "duration_s": x.get("duration_s") or 0})
    _BP.want_update(wid, state="done",
                    note="搜到 %d 条，排了 %d 个下载"
                         % (len(res["items"]), len(picked)))
    return "done", "「%s」搜到 %d 条，排了 %d 个" % (kw, len(res["items"]), len(picked))


# ── 小站追番：分段下载 + 断点续传 ──

def _adl_load() -> list:
    d = _read_json(ANIME_DL_FILE, {}) or {}
    items = d.get("items") if isinstance(d, dict) else d
    return items if isinstance(items, list) else []


def _adl_save(items: list) -> None:
    _write_json(ANIME_DL_FILE, {"saved_at": _now_str(),
                                "total": len(items), "items": items[:200]})


def _adl_update(key: str, **fields) -> dict | None:
    items = _adl_load()
    for it in items:
        if it.get("key") == key:
            for k, v in fields.items():
                if v is not None:
                    it[k] = v
            _adl_save(items)
            return dict(it)
    return None


def _adl_add(key: str, title: str, aid: str, ep: str) -> dict:
    items = _adl_load()
    for it in items:
        if it.get("key") == key:
            return it
    item = {"key": key, "title": title, "aid": aid, "ep": ep,
            "state": "pending", "done": 0, "total": 0, "error": "",
            "created_at": _now_str(), "file": ""}
    items.insert(0, item)
    _adl_save(items)
    return item


def _task_anime_dl(task) -> tuple[str, str]:
    key = str(task["payload"].get("key") or "")
    title = str(task["payload"].get("title") or "")
    aid = str(task["payload"].get("aid") or "")
    ep = str(task["payload"].get("ep") or "")
    if not aid or not ep:
        return "skipped", "缺番剧 id 或集数"
    if sitesmod is None:
        return "skipped", "anime_site 模块没加载"

    rec = next((x for x in _adl_load() if x.get("key") == key), None)
    if rec is None:
        return "skipped", "这条下载记录没了"

    _adl_update(key, state="running", error="")
    try:
        if not rec.get("m3u8"):
            src = sitesmod.resolve(aid, ep, log=log)
            if not src:
                _adl_update(key, state="error", error="没拿到播放地址")
                return "skipped", "没拿到播放地址"
            _adl_update(key, m3u8=src[0]["url"], url_site=src[0].get("site") or "")
            rec["m3u8"] = src[0]["url"]

        def on_progress(p):
            _adl_update(key, done=int(p.get("done") or 0),
                        total=int(p.get("total") or 0))

        r = sitesmod.download_episode_resume(
            rec["m3u8"], VIDEO_DIR, key,
            max_segments=ANIME_SITE_MAX_SEG, on_progress=on_progress, log=log)
    except Exception as e:  # noqa: BLE001
        _adl_update(key, state="error",
                    error="%s: %s" % (type(e).__name__, str(e)[:120]))
        raise

    if r.get("finished"):
        rel = ""
        try:
            rel = os.path.relpath(r.get("file") or "", DATA_DIR).replace("\\", "/")
        except ValueError:
            rel = ""
        _adl_update(key, state="done", done=r.get("total") or 0,
                    total=r.get("total") or 0, file=rel, error="",
                    bytes=int(r.get("bytes") or 0))
        return "done", "%s %s 下完了（%.0f MB）" % (
            title, ep, (r.get("bytes") or 0) / 1048576.0)

    _adl_update(key, state="paused",
                done=int(r.get("done") or 0), total=int(r.get("total") or 0),
                error=str(r.get("error") or ""))
    # 没下完：把任务放回队列，下次联网从缺的那一片接着下（这才是断点续传）
    return "pending", "已下 %d/%d 片，等下次联网接着下" % (
        int(r.get("done") or 0), int(r.get("total") or 0))


# ── 单曲下载（按 song_id 精确下，不靠名字搜） ──

def _ntracks_load() -> dict:
    d = _read_json(NM_TRACKS_FILE, {}) or {}
    return d if isinstance(d, dict) else {}


def _ntracks_put(pid: str, items: list) -> None:
    d = _ntracks_load()
    d[pid] = {"at": _now_str(), "ts": time.time(), "items": items}
    if len(d) > 80:
        keep = sorted(d.items(), key=lambda kv: (kv[1] or {}).get("ts") or 0,
                      reverse=True)[:80]
        d = dict(keep)
    _write_json(NM_TRACKS_FILE, d)


def playlist_tracks_view(pid: str) -> dict:
    """歌单曲目列表（不下载）。断网时回退上次抓的。"""
    pid = (pid or "").strip()
    if not pid:
        return {"pid": "", "total": 0, "items": [], "error": "缺 pid"}
    if netmusic is None:
        return {"pid": pid, "total": 0, "items": [], "error": "netmusic 没加载"}

    err = ""
    items = []
    try:
        raw = netmusic.playlist_tracks(_SESSION, pid, log=log)
        items = [{
            "id": str(x.get("id") or ""),
            "name": x.get("name") or "",
            "artist": x.get("artist") or "",
            "album": x.get("album") or "",
            "duration_s": int(x.get("duration_s") or 0),
            "fee": x.get("fee"),
            "cover_url": x.get("cover_url") or "",
        } for x in raw]
        if items:
            _ntracks_put(pid, items)
    except Exception as e:  # noqa: BLE001
        err = "%s: %s" % (type(e).__name__, str(e)[:100])

    offline = False
    cached_at = ""
    if not items:
        hit = _ntracks_load().get(pid)
        if hit and hit.get("items"):
            items = hit["items"]
            offline = True
            cached_at = hit.get("at") or ""

    # 标 VIP、标已下
    have = {}
    try:
        for it in (musicmod.scan(MUSIC_DIR, MUSIC_COVER_DIR) if musicmod else []):
            sid = str(it.get("song_id") or "")
            if sid:
                have[sid] = 1
    except Exception:  # noqa: BLE001
        pass
    for it in items:
        it["vip"] = (it.get("fee") == 1)
        it["downloaded"] = str(it.get("id")) in have

    return {"pid": pid, "total": len(items), "items": items,
            "offline": offline, "cached_at": cached_at, "error": err}


def _task_song_dl(task) -> tuple[str, str]:
    p = task["payload"] or {}
    sid = str(p.get("song_id") or "")
    if not sid:
        return "skipped", "缺 song_id"
    if netmusic is None:
        return "skipped", "netmusic 没加载"

    item = {
        "id": sid,
        "name": p.get("name") or "",
        "artist": p.get("artist") or "",
        "album": p.get("album") or "",
        "duration_s": int(p.get("duration_s") or 0),
        "mp3_url": "https://music.163.com/song/media/outer/url?id=%s.mp3" % sid,
        "cover_url": "",
        "chart": p.get("playlist_name") or "歌单",
    }
    try:
        item["cover_url"] = netmusic.cover_url_of(_SESSION, item)
    except Exception:  # noqa: BLE001
        pass

    r = netmusic.download(_SESSION, item, MUSIC_DIR, log=log)
    if not r.get("ok"):
        return "skipped", r.get("error") or "下不动"

    fn = os.path.basename(r.get("file") or "")
    if fn:
        meta = _read_json(MUSIC_META, {}) or {}
        meta[fn] = {"id": sid, "chart": item["chart"],
                    "playlist": str(p.get("playlist_pid") or ""),
                    "duration_s": item["duration_s"],
                    "added_at": _now_str(), "added_ts": time.time()}
        _write_json(MUSIC_META, meta)
    _music_prune()
    _rebuild_music()
    return "done", "下好了：%s" % (item["name"] or sid)


def relrc_one(sid: str) -> dict:
    """给一首已经下好的歌重新补歌词（去掉 feat. 尾巴再匹配）。"""
    sid = str(sid or "").strip()
    if not sid or netmusic is None:
        return {"ok": False, "error": "缺 id"}
    items = musicmod.scan(MUSIC_DIR, MUSIC_COVER_DIR) if musicmod else []
    target = None
    for it in items:
        if str(it.get("song_id") or "") == sid:
            target = it
            break
    if target is None:
        meta = _read_json(MUSIC_META, {}) or {}
        for fn, m in meta.items():
            if str((m or {}).get("id") or "") == sid:
                for it in items:
                    if it.get("name") == fn:
                        target = it
                        break
                break
    if target is None:
        return {"ok": False, "error": "本地没这首歌"}
    full = netmusic.get_lyric_full(_SESSION, sid)
    body = full.get("klyric") or full.get("lrc") or ""
    if not body.strip():
        return {"ok": False, "error": "网易云这首歌没有歌词"}
    base = os.path.splitext(os.path.join(MUSIC_DIR, target["name"]))[0]
    try:
        with open(base + ".lrc", "w", encoding="utf-8", newline="\n") as f:
            f.write(body)
        tl = full.get("tlrc") or ""
        if tl.strip():
            with open(base + ".tlrc", "w", encoding="utf-8", newline="\n") as f:
                f.write(tl)
    except OSError as e:
        return {"ok": False, "error": "写不进去：%s" % e}
    meta = _read_json(MUSIC_META, {}) or {}
    if meta.get(target["name"]):
        pass
    _rebuild_music()
    return {"ok": True, "msg": "补好了"}


# ── 检查更新（联网时自动跑，U 盘插着也会跑） ──

UPDATE_STATE = os.path.join(DATA_DIR, "update_state.json")


def _update_read() -> dict:
    d = _read_json(UPDATE_STATE, {}) or {}
    return d if isinstance(d, dict) else {}


def _task_update(task) -> tuple[str, str]:
    if not UPDATE_REPO:
        return "skipped", "没配版本仓库"
    try:
        import updater as updater_mod
    except Exception as e:  # noqa: BLE001
        return "skipped", "updater 没加载：%s" % e

    st = _update_read()
    st["last_check"] = _now_str()
    st["last_ts"] = time.time()
    res = updater_mod.check_update(_SESSION, UPDATE_REPO, log=log)
    st["latest"] = res.get("latest") or ""
    st["error"] = res.get("error") or ""
    st["has_update"] = bool(res.get("has_update"))
    _write_json(UPDATE_STATE, st)

    if not res.get("has_update"):
        return "skipped", res.get("error") or "已经是最新的"

    log("发现新版本 %s，开始下" % res.get("latest"))
    dl = updater_mod.download_zip(_SESSION, res.get("zip_url") or "", DATA_DIR, log=log)
    if not dl.get("ok"):
        return "skipped", "更新包没下来：%s" % (dl.get("error") or "")
    ap = updater_mod.apply_zip(dl.get("path") or "", BASE_DIR, log=log)
    st["applied"] = _now_str()
    st["applied_files"] = ap.get("files") or []
    st["need_restart"] = bool(ap.get("ok"))
    _write_json(UPDATE_STATE, st)
    if not ap.get("ok"):
        return "skipped", "装了但出问题：%s" % (ap.get("error") or "")
    with STATUS_LOCK:
        STATUS["update_available"] = ""
        STATUS["last_update_check"] = _now_str()
    return "done", "更新到 %s，重启后生效（备份在 data/backup）" % res.get("latest")


TASKS = {
    "news": _task_news,
    "search": _task_search,
    "videos": _task_videos,
    "music": _task_music,
    "playlist": _task_playlist,
    "wish": _task_wish,
    "song_dl": _task_song_dl,
    "anime_dl": _task_anime_dl,
    "bili_dl": _task_bili_dl,
    "bili_kw": _task_bili_kw,
    "bili_rec": _task_bili_rec,
    "bili_search": _task_bili_search,
    "anime": _task_anime,
    "update": _task_update,
    "mirror": _task_mirror,
}


def enqueue_round(force: bool = False) -> int:
    """按当前设置排一轮任务。已经在队里的不重复排（force=True 除外）。"""
    if _QUEUE is None:
        return 0
    before = _QUEUE.snapshot()["total"]

    def add(kind, key, payload=None):
        try:
            _QUEUE.add(kind, key, payload, dedupe=not force)
        except Exception as e:  # noqa: BLE001
            log("排任务失败 %s：%s" % (kind, e))

    add("news", "all")
    if SEARCH_KEYWORDS:
        add("search", "all")
    if FETCH_VIDEO:
        add("videos", "all")
    if MUSIC_ENABLED and netmusic is not None and MUSIC_PER_RUN > 0:
        add("music", "chart:%d" % MUSIC_PER_RUN, {"count": MUSIC_PER_RUN})
    if BILI_REC_ENABLED and animemod is not None:
        add("bili_rec", "all")
    if BILI_KEYWORDS and animemod is not None:
        add("bili_search", "kw")
    if ANIME_ENABLED and animemod is not None and _follows():
        add("anime", "all")
    if UPDATE_REPO and UPDATE_AUTO:
        last = float(_update_read().get("last_ts") or 0)
        if time.time() - last >= max(1, UPDATE_INTERVAL_H) * 3600:
            add("update", "all")
    if MIRROR_AUTO and SEARCH_KEYWORDS:
        try:
            hits = list((_read_json(SEARCH_FILE, {}) or {}).get("items") or [])
        except Exception:  # noqa: BLE001
            hits = []
        for it in hits[:max(0, MIRROR_AUTO_COUNT)]:
            url = it.get("url") or ""
            if url.startswith(("http://", "https://")):
                add("mirror", "auto:" + hashlib.sha1(url.encode()).hexdigest()[:12],
                    {"url": url})
    return _QUEUE.snapshot()["total"] - before


def run_queue(stop_evt: threading.Event | None = None,
              deadline: float = 0.0) -> int:
    """把能干的活一条条干完。网断了 / 到点了 / 磁盘满了就收工，剩下的留着。"""
    if _QUEUE is None:
        return 0
    done = 0
    while True:
        if stop_evt is not None and stop_evt.is_set():
            break
        if deadline and time.time() >= deadline:
            if _QUEUE.has_pending():
                log("这次窗口到点了，剩下的下次继续（还有 %d 条）"
                    % _QUEUE.snapshot()["pending"])
            break
        if not disk_ok():
            log("磁盘剩余不到 %.0f MB，先不下载了" % (DISK_MIN_BYTES / 1048576.0))
            break
        task = _QUEUE.pop_next()
        if task is None:
            break

        kind = task["kind"]
        label = schedmod.label_of(kind) if schedmod else kind
        fn = TASKS.get(kind)
        log("── 开工：%s%s" % (label, ("（" + task["key"] + "）")
                              if task["key"] not in ("all", "") else ""))
        with STATUS_LOCK:
            STATUS["state"] = "fetching"
            STATUS["fetching"] = True
            STATUS["task"] = kind
            STATUS["task_label"] = label
        t0 = time.time()
        try:
            state, note = fn(task) if fn else ("skipped", "没有这个任务")
        except Exception as e:  # noqa: BLE001
            msg = "%s: %s" % (type(e).__name__, str(e)[:160])
            log("── 失败：%s %s" % (label, msg))
            _QUEUE.set_state(task["id"], "failed", msg)
            with STATUS_LOCK:
                STATUS["last_error"] = msg
            # 失败了极可能是网断了，立刻确认一下
            if not probe_online():
                break
            continue
        _QUEUE.set_state(task["id"], state, note=note)
        log("── 收工：%s %s（%.1f 秒）" % (label, note, time.time() - t0))
        done += 1
        # 每干完一条都看一眼网还在不在，别硬撑
        if not probe_online():
            log("网没了，剩下的任务留在队列里")
            break

    with STATUS_LOCK:
        STATUS["fetching"] = False
        STATUS["task"] = ""
        STATUS["task_label"] = ""
        if STATUS["state"] == "fetching":
            STATUS["state"] = "idle"
    return done


# ══════════════════════════════════════════════════════════════════════
#  云端禁用名单（GitHub 上的一个 JSON）
# ══════════════════════════════════════════════════════════════════════

_CLOUD = {"ts": 0.0, "blocked": "", "scopes": [], "note": ""}
CLOUD_TTL = 10 * 60
CLOUD_STATE = os.path.join(DATA_DIR, "cloud_state.json")


def _cloud_load() -> dict:
    d = _read_json(CLOUD_STATE, {})
    if not isinstance(d, dict):
        d = {}
    return {
        "blocked": str(d.get("blocked") or ""),
        "scopes": list(d.get("scopes") or []),
        "note": str(d.get("note") or ""),
        "since": str(d.get("since") or ""),
    }


def _cloud_save(state: dict) -> None:
    try:
        _atomic_write(CLOUD_STATE, json.dumps(state, ensure_ascii=False, indent=1))
    except OSError as e:
        log("云端禁用状态写不进去：%s" % e)


def check_cloud_block(force: bool = False) -> str:
    """拉一次云端名单，返回禁用原因（空字符串 = 没被禁）。

    规矩（用户定的）：**一旦云端说这台机器停了，就一直停着**，
    哪怕以后一直断网也不解除；只有重新拉到云端、并且它明确说"没禁"，
    才恢复。这样断网不能当后门用。

    反过来，从来没拉到过（第一次就断网）按"没被禁"处理，
    不然学校那种常态性断网会把所有人挡在门外。
    """
    if not CLOUD_URL or licmod is None:
        return ""

    now = time.time()
    # 内存里的快照还新鲜，直接用
    if not force and now - _CLOUD["ts"] < CLOUD_TTL:
        return _CLOUD["blocked"]

    saved = _cloud_load()
    _CLOUD["ts"] = now

    try:
        updater = globals().get("updatermod")
        if updater is None:
            import updater as updater_mod   # 延迟导入，没有这个模块也不影响别的
            updater = updater_mod
        res = updater.cloud_block(_SESSION, CLOUD_URL, licmod.machine_code(), log=log)
    except Exception as e:  # noqa: BLE001
        # 没拉到：有历史禁用记录就继续禁着，别让断网变成解封手段
        log("云端名单没拉到：%s: %s" % (type(e).__name__, str(e)[:100]))
        res = None

    if res is None:
        if saved["blocked"]:
            _CLOUD["blocked"] = saved["blocked"]
            _CLOUD["scopes"] = saved["scopes"]
            return _CLOUD["blocked"]
        _CLOUD["blocked"] = ""
        _CLOUD["scopes"] = []
        return ""

    if not res.get("ok"):
        # 拉到了但内容读不懂（404/格式不对）：同上，保持原状
        log("云端名单读不出来（%s），保持当前状态" % (res.get("error") or "未知"))
        _CLOUD["blocked"] = saved["blocked"]
        _CLOUD["scopes"] = saved["scopes"]
        return _CLOUD["blocked"]

    if res.get("blocked"):
        note = res.get("note") or "这台机器被云端停用了"
        state = {
            "blocked": note,
            "scopes": list(res.get("scopes") or []),
            "note": note,
            "since": saved["since"] or _now_str(),
        }
        if state != saved:
            _cloud_save(state)
            log("云端禁用生效并记下来了：%s" % note)
        _CLOUD["blocked"] = note
        _CLOUD["scopes"] = state["scopes"]
        return note

    # 云端明确说没禁（拉取成功且没命中）：这才解除，并把记录清掉
    if saved["blocked"]:
        log("云端解封了，恢复下载")
        _cloud_save({"blocked": "", "scopes": [], "note": "", "since": ""})
    _CLOUD["blocked"] = ""
    _CLOUD["scopes"] = []
    return ""


# ══════════════════════════════════════════════════════════════════════
#  守护循环
# ══════════════════════════════════════════════════════════════════════

def monitor_loop(stop_evt: threading.Event) -> None:
    st = load_state()
    with STATUS_LOCK:
        STATUS["last_fetch_ts"] = float(st.get("last_fetch_ts") or 0)
        STATUS["last_fetch_at"] = st.get("last_fetch_at") or ""
        STATUS["snapshot_id"] = st.get("snapshot_id") or ""
        STATUS["total_items"] = int(st.get("total_items") or 0)
        STATUS["category_counts"] = st.get("category_counts") or {}
        STATUS["last_round_ts"] = float(st.get("last_round_ts") or 0)

    # 各种索引都是独立文件，重启后把已有数量读回来
    _restore_index_status()
    _rebuild_music()

    if _QUEUE is not None:
        q = _QUEUE.snapshot()
        if q["pending"]:
            log("队列里还有 %d 条上次没干完的，联网接着做" % q["pending"])

    if not os.path.exists(LATEST_FILE):
        log("本地还没有新闻，联网就抓")
        _manual_fetch.set()

    offline_since = 0.0     # 从什么时候开始断网的（0 = 没断）
    round_done = True       # 上一轮是不是刚干完（干完就别连着再抓）

    while not stop_evt.is_set():
        # 云端禁用：停一切下载，但联网检测照旧（主人说了，被禁也要能看见网通没通）
        blocked = check_cloud_block()
        if blocked:
            with STATUS_LOCK:
                STATUS["blocked"] = blocked
                STATUS["state"] = "blocked"
                STATUS["online"] = probe_online()
                STATUS["next_check_ts"] = time.time() + IDLE_POLL
            stop_evt.wait(IDLE_POLL)
            continue
        with STATUS_LOCK:
            STATUS["blocked"] = ""

        now = time.time()
        manual = _manual_fetch.is_set()

        # 断网之后先等一会儿再开始找网：这段窗口里连探测都不做，
        # 免得热点刚断就一秒一次地敲。手动抓取不受这条限制。
        if offline_since and not manual:
            waited = now - offline_since
            if waited < ONLINE_DEDUPE:
                left = int(ONLINE_DEDUPE - waited)
                with STATUS_LOCK:
                    STATUS["state"] = "hunting"
                    STATUS["offline_for"] = int(waited)
                    STATUS["next_check_ts"] = offline_since + ONLINE_DEDUPE
                nap(stop_evt, min(30, max(5, left)))
                continue

        online = probe_online(force_http=True)
        if not online:
            if not offline_since:
                offline_since = now
                log("断网了，开始计时（%d 分钟后才找网）" % int(ONLINE_DEDUPE / 60))
            with STATUS_LOCK:
                STATUS["state"] = "hunting"
                STATUS["offline_for"] = int(now - offline_since)
                STATUS["next_check_ts"] = offline_since + ONLINE_DEDUPE
            stop_evt.wait(IDLE_POLL)
            continue

        # 网回来了
        if offline_since:
            log("网回来了（断了 %d 秒）" % int(now - offline_since))
        offline_since = 0
        with STATUS_LOCK:
            STATUS["offline_for"] = 0

        # 有网了。看看要不要干活
        with STATUS_LOCK:
            last_round = STATUS["last_round_ts"]
        pending = bool(_QUEUE and _QUEUE.has_pending())
        # 点歌台 / 手动加的东西不受「等网」规则限制，有网就办
        quick_kinds = {"wish", "song_dl", "playlist"}
        quick = bool(_QUEUE and _QUEUE.has_pending(quick_kinds))

        if not manual and not quick and round_done and not pending and os.path.exists(LATEST_FILE):
            # 上一轮抓完、网还在：不重复抓，安静等着断网
            with STATUS_LOCK:
                STATUS["state"] = "idle"
                STATUS["next_check_ts"] = now + IDLE_POLL
            nap(stop_evt, IDLE_POLL)
            continue

        if manual:
            _manual_fetch.clear()
            log("手动触发：马上排一轮任务")

        if manual:
            n_new = enqueue_round(force=True)
        elif pending and _QUEUE is not None:
            # 只有用户手动加的歌单在排队时，别顺手把一整轮也排进来 ——
            # 人家只想下一张歌单，让人先等新闻视频跑完太不讲道理了。
            # 用户自己点的（歌单、离线点歌）不算"该抓一轮了"
            user_kinds = {"playlist", "wish"}
            others = set(TASKS) - user_kinds
            if _QUEUE.has_pending(user_kinds) and not _QUEUE.has_pending(others):
                n_new = 0
            else:
                n_new = enqueue_round()
        else:
            n_new = enqueue_round()
        if n_new:
            log("排了 %d 条任务" % n_new)
        if _QUEUE is None:
            continue

        round_done = False
        deadline = now + ROUND_BUDGET
        with STATUS_LOCK:
            STATUS["round_started_ts"] = now
            STATUS["budget_left"] = ROUND_BUDGET
        done = run_queue(stop_evt, deadline)
        round_done = True

        with STATUS_LOCK:
            STATUS["budget_left"] = 0.0
            STATUS["state"] = "idle"
            # 只有真干了活才算"这一轮结束"，不然窗口去重会把空转也当成抓过
            if done:
                STATUS["last_round_ts"] = time.time()
            STATUS["next_check_ts"] = time.time() + IDLE_POLL
        save_state()
        if done:
            log("这一轮干了 %d 条任务" % done)
        nap(stop_evt, max(2.0, IDLE_POLL))



# ══════════════════════════════════════════════════════════════════════
#  启动密码 / 激活 / U 盘钥匙
# ══════════════════════════════════════════════════════════════════════
#
# 三套权限，从高到低：
#   1. U 盘钥匙（插上 E: 那类可移动盘，根目录有隐藏的 .whale-key）
#      —— 免密码、解锁全部选项、还会顺手检查更新
#   2. 激活码（绑定机器、带起始日期和到期日、可以只开部分功能）
#   3. 试用（没激活）—— 能看，不能下

import secrets as _secrets

_AUTH_LOCK = threading.Lock()
_AUTH = {
    "token": _secrets.token_hex(16),   # 登录成功后发给前端，之后每个请求带上
    "unlocked": False,                 # 这个进程里有没有人输对过密码
    "tries": 0,
    "last_try_ts": 0.0,
}
_USB_PRESENT = False
_USB_INFO = None


def usb_present() -> bool:
    with _AUTH_LOCK:
        return _USB_PRESENT


def set_usb(info) -> None:
    global _USB_PRESENT, _USB_INFO
    with _AUTH_LOCK:
        _USB_PRESENT = bool(info)
        _USB_INFO = info
    if info:
        log("U 盘钥匙插上了：%s（%s）" % (info.get("name") or "", info.get("root") or ""))
        STATUS["usb"] = True
        STATUS["edition"] = "U 盘版"
    else:
        log("U 盘钥匙拔了")
        STATUS["usb"] = False


_LIC_CACHE = {"ts": 0.0, "val": None}


def license_status() -> dict:
    """激活 + U 盘的合并状态，前端拿去画那一小块。

    前端每秒都会问一次状态，这里缓存 5 秒 —— 激活状态不会一秒变一次，
    但每次去扫盘符 + 重算机器码就太浪费了。
    """
    now = time.time()
    if _LIC_CACHE["val"] is not None and now - _LIC_CACHE["ts"] < 5:
        return dict(_LIC_CACHE["val"])
    if licmod is None:
        return {"ok": False, "error": "license 模块没加载", "usb": usb_present()}
    try:
        st = licmod.status(BASE_DIR)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
    st["usb"] = usb_present()
    st["usb_name"] = (_USB_INFO or {}).get("name") or ""
    st["password_on"] = bool(PASSWORD_ON)
    if usb_present():
        st["edition"] = "U 盘版"
        st["features"] = list(getattr(licmod, "FEATURES", []) or [])
    _LIC_CACHE["ts"] = now
    _LIC_CACHE["val"] = dict(st)
    return st


_SCREEN = {"digits": "", "answer": "", "ts": 0.0, "solved": False}
_ADMIN = {"ok": False, "tries": 0, "ts": 0.0}
SCREEN_TTL = 10 * 60          # 一条挑战最多管 10 分钟


def screen_required() -> bool:
    """要不要先过开屏那一关。U 盘插着永远不用。"""
    if usb_present():
        return False
    return BOOT_MODE == "password"


def screen_state() -> dict:
    """给前端看的开屏状态。要口令但还没过，就把那行数字给它。"""
    if not screen_required():
        return {"required": False, "solved": True, "digits": ""}
    if _SCREEN["solved"]:
        return {"required": True, "solved": True, "digits": ""}
    now = time.time()
    if not _SCREEN["digits"] or now - _SCREEN["ts"] > SCREEN_TTL:
        try:
            ch = licmod.new_challenge()
        except Exception:  # noqa: BLE001
            ch = {"digits": "13579", "answer": "0000"}
        _SCREEN.update(digits=ch["digits"], answer=ch["answer"], ts=now)
    return {"required": True, "solved": False, "digits": _SCREEN["digits"]}


def try_screen(answer: str) -> dict:
    if not screen_required():
        return {"ok": True, "token": _AUTH["token"]}
    if _SCREEN["solved"]:
        return {"ok": True, "token": _AUTH["token"]}
    now = time.time()
    with _AUTH_LOCK:
        if _AUTH["tries"] >= 10 and now - _AUTH["last_try_ts"] < 60:
            return {"ok": False, "error": "错太多次了，等一分钟"}
    good = False
    try:
        good = licmod.check_screen(answer, _SCREEN.get("answer") or "")
    except Exception:  # noqa: BLE001
        good = False
    with _AUTH_LOCK:
        _AUTH["last_try_ts"] = now
        if good:
            _SCREEN["solved"] = True
            _AUTH["unlocked"] = True
            _AUTH["tries"] = 0
            log("开屏口令通过")
            return {"ok": True, "token": _AUTH["token"]}
        _AUTH["tries"] += 1
        # 错了换一条，免得一直盯着同一行数字试
        _SCREEN["digits"] = ""
    return {"ok": False, "error": "不对", "state": screen_state()}


def admin_ok() -> bool:
    """管理员身份：U 盘插着或者输过管理员口令。"""
    if usb_present():
        return True
    if not ADMIN_PASSWORD_ON or licmod is None:
        return False
    return bool(_ADMIN["ok"])


def try_admin(pw: str) -> dict:
    if usb_present():
        return {"ok": True, "via": "usb"}
    if not ADMIN_PASSWORD_ON:
        return {"ok": False, "error": "管理员口令已经禁用了，只能插 U 盘"}
    now = time.time()
    with _AUTH_LOCK:
        if _ADMIN["tries"] >= 6 and now - _ADMIN["ts"] < 120:
            return {"ok": False, "error": "错太多次了，歇两分钟"}
    good = False
    try:
        good = licmod.check_admin(pw)
    except Exception:  # noqa: BLE001
        good = False
    with _AUTH_LOCK:
        _ADMIN["ts"] = now
        if good:
            _ADMIN["ok"] = True
            _ADMIN["tries"] = 0
            log("管理员口令通过")
            return {"ok": True, "via": "password"}
        _ADMIN["tries"] += 1
    log("有人输错管理员口令（第 %d 次）" % _ADMIN["tries"])
    return {"ok": False, "error": "口令不对"}


def today_open() -> bool:
    """今天（周几）允不允许开二级菜单。"""
    wd = time.localtime().tm_wday + 1        # 1=周一
    return wd in WEEKDAY_OPEN


def level2_state() -> dict:
    """二级菜单现在能不能进，不能的话为什么。"""
    if usb_present():
        return {"open": True, "reason": "usb"}
    if not admin_ok():
        return {"open": False, "reason": "need_admin"}
    if EXAM_LOCK:
        return {"open": False, "reason": "exam_lock"}
    if not today_open() and not (USB_BYPASS_TIME and usb_present()):
        return {"open": False, "reason": "not_today"}
    return {"open": True, "reason": "ok"}


def feature_on(name: str) -> bool:
    return {
        "video": FEAT_VIDEO, "music": FEAT_MUSIC, "bili": FEAT_BILI,
        "anime": FEAT_ANIME, "mirror": FEAT_MIRROR, "search": FEAT_SEARCH,
    }.get(name, True)


def need_auth() -> bool:
    """要不要先过开屏。"""
    return screen_required() and not _SCREEN["solved"]


def auth_ok(token: str) -> bool:
    if not need_auth():
        return True
    with _AUTH_LOCK:
        if _AUTH["unlocked"] and token and token == _AUTH["token"]:
            return True
    return False


def try_login(password: str) -> dict:
    """验密码。连续错太多次会歇一会儿，别让人拿穷举硬试（虽然拦不住改代码）。"""
    if licmod is None:
        return {"ok": False, "error": "license 模块没加载，没法验密码"}
    now = time.time()
    with _AUTH_LOCK:
        if _AUTH["tries"] >= 8 and now - _AUTH["last_try_ts"] < 30:
            return {"ok": False, "error": "错太多次了，歇 30 秒再试"}
    try:
        good = licmod.check_password(password or "")
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}
    with _AUTH_LOCK:
        _AUTH["last_try_ts"] = now
        if good:
            _AUTH["unlocked"] = True
            _AUTH["tries"] = 0
            return {"ok": True, "token": _AUTH["token"]}
        _AUTH["tries"] += 1
    log("有人输错了启动密码（第 %d 次）" % _AUTH["tries"])
    return {"ok": False, "error": "密码不对"}


def _usb_watch(stop_evt: threading.Event) -> None:
    """后台盯着 U 盘钥匙。插上 = 最高权限 + 顺便看更新。"""
    if usbmod is None:
        return

    def on_plug(key):
        set_usb(key)
        check_update(quiet=True)

    def on_unplug(old):
        set_usb(None)

    try:
        set_usb(usbmod.find_key())
        usbmod.watch(stop_evt, interval_s=3.0, on_plug=on_plug,
                     on_unplug=on_unplug, log=log)
    except Exception as e:  # noqa: BLE001
        log("U 盘监视出问题了：%s: %s" % (type(e).__name__, e))


def check_update(quiet: bool = False) -> dict:
    """去 GitHub 看看有没有新版。只有 U 盘插着才自动检查。"""
    if not UPDATE_REPO:
        return {"ok": False, "error": "没配版本仓库"}
    try:
        import updater as updater_mod
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": "updater 模块没加载：%s" % e}
    res = updater_mod.check_update(_SESSION, UPDATE_REPO, log=log)
    with STATUS_LOCK:
        STATUS["last_update_check"] = _now_str()
        STATUS["update_available"] = res.get("latest") if res.get("has_update") else ""
    if res.get("has_update"):
        log("有新版本：%s → %s" % (res.get("current"), res.get("latest")))
    elif not quiet:
        log("版本检查：%s" % (res.get("error") or "已经是最新的"))
    return res


# ══════════════════════════════════════════════════════════════════════
#  全局搜索（一个框搜遍新闻 / 视频 / 音乐 / 搜索 / 追番 / 镜像 / 归档）
# ══════════════════════════════════════════════════════════════════════

GROUP_LABELS = {
    "news": "新闻", "video": "视频", "music": "音乐", "search": "搜索",
    "bili": "B 站", "anime": "追更", "mirror": "离线页", "archive": "归档",
}


def _hit(kind, rid, title, sub="", image="", url="", extra=None) -> dict:
    h = {"kind": kind, "rid": rid, "title": title, "sub": sub,
         "image": image, "url": url}
    if extra:
        h.update(extra)
    return h


def global_search(q: str, limit: int = 300) -> dict:
    """一个关键词把本地所有东西翻一遍。纯本地，不联网。"""
    q = (q or "").strip()
    ql = q.lower()
    if not ql:
        return {"q": "", "total": 0, "groups": []}

    def hit(text: str) -> bool:
        return ql in (text or "").lower()

    buckets: dict[str, list] = {}

    # 新闻（当前快照）
    try:
        snap = _read_json(LATEST_FILE, {}) or {}
        for it in snap.get("items") or []:
            if hit(it.get("title")) or hit(it.get("summary")) or hit(it.get("source")):
                buckets.setdefault("news", []).append(_hit(
                    "news", it.get("id"), it.get("title"),
                    " ・ ".join([x for x in [it.get("source"), it.get("published")] if x]),
                    it.get("image") or "", it.get("url") or "",
                    {"category": it.get("category")}))
    except Exception:  # noqa: BLE001
        pass

    # 必应搜索结果
    try:
        sd = _read_json(SEARCH_FILE, {}) or {}
        for it in sd.get("items") or []:
            if hit(it.get("title")) or hit(it.get("summary")) or hit(it.get("keyword")):
                buckets.setdefault("search", []).append(_hit(
                    "search", it.get("id"), it.get("title"),
                    it.get("host") or "", it.get("image") or "", it.get("url") or ""))
    except Exception:  # noqa: BLE001
        pass

    # B 站热门视频
    try:
        vd = _read_json(VIDEO_INDEX, {}) or {}
        for it in vd.get("items") or []:
            if hit(it.get("title")) or hit(it.get("up")) or hit(it.get("desc")):
                buckets.setdefault("video", []).append(_hit(
                    "video", it.get("bvid") or it.get("id"), it.get("title"),
                    it.get("up") or "", it.get("pic") or "", it.get("url") or "",
                    {"file": it.get("file") or "", "duration": it.get("duration")}))
    except Exception:  # noqa: BLE001
        pass

    # 点歌台
    try:
        md = _read_json(MUSIC_INDEX, {}) or {}
        for it in md.get("items") or []:
            if hit(it.get("title")) or hit(it.get("artist")) or hit(it.get("album")):
                buckets.setdefault("music", []).append(_hit(
                    "music", it.get("id"), it.get("title"),
                    it.get("artist") or "", it.get("cover") or "", "",
                    {"file": it.get("file") or ""}))
    except Exception:  # noqa: BLE001
        pass

    # B 站推荐 / 关键词搜索攒下来的条目
    try:
        for it in _bili_load():
            if hit(it.get("title")) or hit(it.get("up")) or hit(it.get("keyword")):
                buckets.setdefault("bili", []).append(_hit(
                    "bili", it.get("bvid"), it.get("title"),
                    it.get("up") or "", it.get("pic") or it.get("pic_url") or "",
                    it.get("url") or ""))
    except Exception:  # noqa: BLE001
        pass

    # 追更
    try:
        for it in _anime_load():
            if hit(it.get("title")) or hit(it.get("new_ep_title")):
                buckets.setdefault("anime", []).append(_hit(
                    "anime", it.get("sid"), it.get("title"),
                    "第 %s 集 ・ %s" % (it.get("new_ep"), it.get("new_ep_title") or ""),
                    it.get("cover_url") or "", it.get("url") or ""))
    except Exception:  # noqa: BLE001
        pass

    # 离线镜像
    try:
        for it in _mirror_index().get("items") or []:
            if hit(it.get("title")) or hit(it.get("url")):
                buckets.setdefault("mirror", []).append(_hit(
                    "mirror", it.get("id"), it.get("title"),
                    it.get("host") or "", it.get("image") or "", ""))
    except Exception:  # noqa: BLE001
        pass

    # 归档（看完收起来的东西，在这也能搜到）
    if _LIB is not None:
        try:
            for rec in _LIB.listing(archived=True, q=q, limit=limit):
                buckets.setdefault("archive", []).append(_hit(
                    "archive", rec.get("key"), rec.get("title") or rec.get("key"),
                    "%s ・ %s" % (GROUP_LABELS.get(rec.get("kind"), rec.get("kind")),
                                  rec.get("sub") or ""),
                    rec.get("image") or "", rec.get("url") or ""))
        except Exception:  # noqa: BLE001
            # 归档搜不到不影响别的
            pass

    groups = []
    total = 0
    for kind in ("news", "video", "music", "bili", "search", "anime", "mirror", "archive"):
        items = buckets.get(kind) or []
        if not items:
            continue
        total += len(items)
        groups.append({"kind": kind, "label": GROUP_LABELS.get(kind, kind),
                       "count": len(items), "items": items[:60]})
    return {"q": q, "total": total, "groups": groups}


def library_view(kind: str = "", q: str = "", archived=None,
                 fav=None, limit: int = 500) -> dict:
    if _LIB is None:
        return {"error": "library 模块没加载", "items": []}
    items = _LIB.listing(kind=kind, q=q, archived=archived, fav=fav, limit=limit)
    return {"total": len(items), "items": items, "counts": _LIB.status()}


# ══════════════════════════════════════════════════════════════════════
#  本地网页服务
# ══════════════════════════════════════════════════════════════════════

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
    ".ico": "image/x-icon", ".svg": "image/svg+xml",
    ".mp4": "video/mp4", ".webm": "video/webm", ".m4v": "video/mp4",
}


class NewsHandler(BaseHTTPRequestHandler):
    _head_only = False
    server_version = "NewsD/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # 静音访问日志
        pass

    # ---------- 工具 ----------
    def _send(self, code: int, body: bytes, ctype: str, cache: str = "no-store"):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.end_headers()
            if not self._head_only:
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _file(self, path: str, cache: str = "no-store"):
        if not os.path.isfile(path):
            self._send(404, b"404 not found", "text/plain; charset=utf-8")
            return
        ext = os.path.splitext(path)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        try:
            size = os.path.getsize(path)
        except OSError:
            self._send(500, b"read error", "text/plain; charset=utf-8")
            return

        # 视频必须支持 Range，不然 <video> 拖不动进度条，有的浏览器干脆不播。
        # 图片走同一套也没坏处。
        start, end, partial = 0, max(0, size - 1), False
        rng = self.headers.get("Range") or ""
        if rng.startswith("bytes=") and size > 0:
            m = re.match(r"(\d*)-(\d*)$", rng[6:].strip())
            if m and (m.group(1) or m.group(2)):
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(int(m.group(2)), size - 1)
                else:                       # bytes=-500 表示最后 500 字节
                    start = max(0, size - int(m.group(2)))
                if start >= size or start > end:
                    try:
                        self.send_response(416)
                        self.send_header("Content-Range", "bytes */%d" % size)
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    return
                partial = True

        length = end - start + 1
        try:
            if partial:
                self.send_response(206)
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            else:
                self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", cache)
            self.end_headers()
            if self._head_only:
                return
            with open(path, "rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(262144, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError,
                OSError):
            pass

    def _safe_join(self, root: str, rel: str) -> str:
        rel = urllib.parse.unquote(rel).replace("\\", "/").lstrip("/")
        target = os.path.normpath(os.path.join(root, rel))
        if not target.startswith(os.path.normpath(root)):
            return ""
        return target

    # ---------- 路由 ----------
    def do_HEAD(self):  # noqa: N802
        """下载工具 / 浏览器有时先发 HEAD 探一下，别回 501。"""
        self._head_only = True
        try:
            self.do_GET()
        finally:
            self._head_only = False

    def do_GET(self):  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        # 上锁的时候只放行：首页、静态资源、登录接口、状态、激活状态。
        # 别的接口一律 401，前端看到 auth 字段就弹密码框。
        public = (path in ("/", "/index.html", "/api/login", "/api/status",
                           "/api/license", "/api/screen", "/api/admin",
                           "/api/policy")
                  or path.startswith("/static/"))
        if not public and not auth_ok(self.headers.get("X-Whale-Token") or ""):
            self._json({"ok": False, "error": "需要开屏口令", "auth": True,
                        "screen": screen_state()}, 401)
            return

        # 二级菜单里的东西：没管理员身份 / 今天不开 / 考试周 就一律挡掉
        lv2_pref = ("/api/music", "/api/bili", "/api/anime", "/api/mirror",
                    "/api/videos", "/api/playlist", "/api/netease", "/api/wish",
                    "/api/library", "/api/fav", "/api/finished", "/api/archive",
                    "/api/open", "/api/refetch", "/api/search-all", "/api/search",
                    "/api/queue")
        # 收藏/归档、全局搜索 这两样可以放给一级菜单，看设置
        l1_ok = ((L1_LIBRARY and path.startswith(("/api/library", "/api/fav",
                                                   "/api/finished", "/api/archive")))
                 or (L1_SEARCH and path in ("/api/search-all",)))
        if path.startswith(lv2_pref) and not l1_ok:
            st2 = level2_state()
            if not st2["open"]:
                self._json({"ok": False, "error": "这一块要管理员才能看",
                            "level2": True, "reason": st2["reason"]}, 403)
                return

        if path in ("/", "/index.html"):
            self._file(os.path.join(WEB_DIR, "index.html"))
        elif path.startswith("/static/"):
            self._file(self._safe_join(WEB_DIR, path[len("/static/"):]))
        elif path.startswith("/music/"):
            self._file(self._safe_join(MUSIC_DIR, path[len("/music/"):]),
                       cache="max-age=604800")
        elif path.startswith("/music_cover/"):
            self._file(self._safe_join(MUSIC_COVER_DIR, path[len("/music_cover/"):]),
                       cache="max-age=604800")
        elif path == "/api/music":
            if os.path.isfile(MUSIC_INDEX):
                self._file(MUSIC_INDEX)
            else:
                self._json({"generated_at": "", "generated_ts": 0,
                            "total": 0, "total_bytes": 0, "items": []})
        elif path.startswith("/images/"):
            self._file(self._safe_join(IMG_DIR, path[len("/images/"):]), cache="max-age=604800")
        elif path.startswith("/videos/"):
            self._file(self._safe_join(VIDEO_DIR, path[len("/videos/"):]),
                       cache="max-age=604800")
        elif path == "/api/videos":
            if os.path.isfile(VIDEO_INDEX):
                self._file(VIDEO_INDEX)
            else:
                self._json({"generated_at": "", "generated_ts": 0,
                            "total": 0, "total_bytes": 0, "items": []})
        elif path == "/api/status":
            self._json(build_status())
        elif path == "/api/news":
            self._api_news(qs)
        elif path == "/api/snapshots":
            self._file(INDEX_FILE)
        elif path == "/api/snapshot":
            sid = (qs.get("id") or [""])[0]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4}", sid):
                self._json({"error": "bad id"}, 400)
                return
            self._file(os.path.join(SNAP_DIR, sid + ".json"))
        elif path == "/api/doc":
            sid = (qs.get("id") or [""])[0]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4}", sid):
                self._json({"error": "bad id"}, 400)
                return
            md = os.path.join(DOCS_DIR, sid + ".md")
            if os.path.isfile(md):
                with open(md, "r", encoding="utf-8") as f:
                    self._send(200, f.read().encode("utf-8"),
                               "text/markdown; charset=utf-8")
            else:
                self._json({"error": "not found"}, 404)
        elif path == "/api/log":
            n = int((qs.get("n") or ["120"])[0])
            self._send(200, tail_log(n).encode("utf-8"), "text/plain; charset=utf-8")
        elif path.startswith("/mirror/"):
            self._file(self._safe_join(MIRROR_DIR, path[len("/mirror/"):]),
                       cache="max-age=604800")
        elif path == "/api/config":
            self._json(config_payload())
        elif path == "/api/search":
            job = (build_status().get("search_job") or {})
            if os.path.isfile(SEARCH_FILE):
                data = _read_json(SEARCH_FILE, {})
                data["job"] = job
                self._json(data)
            else:
                self._json({"generated_at": "", "generated_ts": 0,
                            "keywords": [], "total": 0, "items": [], "job": job})
        elif path == "/api/mirror":
            idx = _mirror_index()
            idx["job"] = (build_status().get("mirror_job") or {})
            self._json(idx)
        elif path == "/api/bili":
            data = _read_json(BILI_FILE, {}) or {}
            if not isinstance(data, dict):
                data = {}
            data.setdefault("items", [])
            self._json(data)
        elif path == "/api/anime":
            data = _read_json(ANIME_FILE, {}) or {}
            if not isinstance(data, dict):
                data = {}
            data.setdefault("items", [])
            data["follows"] = _follows()
            self._json(data)
        elif path == "/api/follows":
            self._json({"items": _follows(), "total": len(_follows())})
        elif path == "/api/anime/search":
            q = (qs.get("q") or [""])[0].strip()
            if not q or animemod is None:
                self._json({"items": [], "error": "没关键词或者 anime 模块没加载"})
                return
            try:
                items = animemod.bangumi_candidates(_SESSION, q, log=log)
            except Exception as e:  # noqa: BLE001
                self._json({"items": [], "error": "%s: %s" % (type(e).__name__, str(e)[:120])})
                return
            self._json({"q": q, "total": len(items), "items": items})
        elif path == "/api/library":
            kind = (qs.get("kind") or [""])[0]
            q = (qs.get("q") or [""])[0]
            arch = (qs.get("archived") or [""])[0]
            fav = (qs.get("fav") or [""])[0]
            archived = None if arch == "" else (arch == "1")
            favv = None if fav == "" else (fav == "1")
            self._json(library_view(kind, q, archived, favv))
        elif path == "/api/search-all":
            q = (qs.get("q") or [""])[0]
            self._json(global_search(q))
        elif path == "/api/queue":
            self._json(_QUEUE.snapshot() if _QUEUE else {"items": [], "total": 0})
        elif path == "/api/playlist":
            items = _playlists_load()
            self._json({"total": len(items), "items": items})
        elif path == "/api/netease/user":
            q = (qs.get("q") or [""])[0].strip()
            self._json(search_user_cached(q))
        elif path == "/api/anime/site/search":
            q = (qs.get("q") or [""])[0].strip()
            if not q or sitesmod is None:
                self._json({"q": q, "total": 0, "items": [],
                            "error": "没关键词或模块没加载"})
                return
            try:
                items = sitesmod.search(q, log=log)
            except Exception as e:  # noqa: BLE001
                self._json({"q": q, "total": 0, "items": [],
                            "error": "%s: %s" % (type(e).__name__, str(e)[:100])})
                return
            self._json({"q": q, "total": len(items), "items": items})
        elif path == "/api/anime/site/episodes":
            aid = (qs.get("aid") or [""])[0].strip()
            if not aid or sitesmod is None:
                self._json({"aid": aid, "items": []})
                return
            try:
                eps = sitesmod.episodes(aid, log=log)
            except Exception as e:  # noqa: BLE001
                self._json({"aid": aid, "items": [],
                            "error": "%s: %s" % (type(e).__name__, str(e)[:100])})
                return
            self._json({"aid": aid, "total": len(eps), "items": eps})
        elif path == "/api/anime/site/resolve":
            aid = (qs.get("aid") or [""])[0].strip()
            ep = (qs.get("ep") or [""])[0].strip()
            if not aid or not ep or sitesmod is None:
                self._json({"items": [], "error": "缺参数"})
                return
            try:
                src = sitesmod.resolve(aid, ep, log=log)
            except Exception as e:  # noqa: BLE001
                self._json({"items": [],
                            "error": "%s: %s" % (type(e).__name__, str(e)[:100])})
                return
            self._json({"aid": aid, "ep": ep, "total": len(src), "items": src})
        elif path == "/api/anime/site/list":
            self._json({"items": _adl_load()})
        elif path == "/api/screen":
            self._json(screen_state())
        elif path == "/api/admin":
            self._json({"admin": admin_ok(), "usb": usb_present(),
                        "password_on": bool(ADMIN_PASSWORD_ON),
                        "level2": level2_state(),
                        "today_open": today_open(),
                        "weekday": time.localtime().tm_wday + 1,
                        "weekdays": list(WEEKDAY_OPEN),
                        "exam_lock": bool(EXAM_LOCK)})
        elif path == "/api/policy":
            lv2 = level2_state()
            feats = {}
            for name in ("video", "music", "bili", "anime", "mirror", "search"):
                feats[name] = bool(feature_on(name)) and lv2["open"]
            self._json({
                "boot_mode": BOOT_MODE,
                "hide_log": bool(HIDE_LOG),
                "hide_buttons": bool(HIDE_BUTTONS),
                "lock_settings": bool(LOCK_SETTINGS),
                "admin": admin_ok(),
                "usb": usb_present(),
                "level2": lv2,
                "features": feats,
                "l1_search": bool(L1_SEARCH),
                "l1_library": bool(L1_LIBRARY),
                "screen": screen_state(),
                "license": license_status(),
                "weekday": time.localtime().tm_wday + 1,
                "weekdays": list(WEEKDAY_OPEN),
                "exam_lock": bool(EXAM_LOCK),
            })
        elif path == "/api/bili/page":
            if _BP is None:
                self._json({"query": "", "items": [], "wants": [],
                            "downloads": [], "error": "状态模块没加载"})
            else:
                d = _BP.page()
                d["online"] = STATUS.get("online")
                self._json(d)
        elif path == "/api/bili/search":
            q = (qs.get("q") or [""])[0].strip()
            self._json(bili_search_cached(q))
        elif path == "/api/wish":
            items = _wishes_load()
            self._json({"total": len(items), "items": items,
                        "online": STATUS.get("online")})
        elif path == "/api/netease/playlist/tracks":
            pid = (qs.get("pid") or [""])[0].strip()
            self._json(playlist_tracks_view(pid))
        elif path == "/api/netease/plsearch":
            q = (qs.get("q") or [""])[0].strip()
            self._json(search_playlist_cached(q))
        elif path == "/api/netease/recent":
            d = _nm_cache_load()
            kws = [{"q": k, "at": (v.get("at") or ""),
                    "total": len(v.get("items") or [])}
                   for k, v in d["users"].items()]
            kws.sort(key=lambda x: x["at"], reverse=True)
            uids = [{"uid": k, "at": (v.get("at") or ""),
                     "total": len(v.get("items") or []),
                     "name": ((v.get("items") or [{}])[0].get("name") or "")
                     if (v.get("items") or []) else ""}
                    for k, v in d["playlists"].items()]
            uids.sort(key=lambda x: x["at"], reverse=True)
            pls = [{"q": k, "at": (v.get("at") or ""),
                    "total": len(v.get("items") or [])}
                   for k, v in d.get("plsearch", {}).items()]
            pls.sort(key=lambda x: x["at"], reverse=True)
            self._json({"keywords": kws[:20], "users": uids[:20],
                        "playlists": pls[:20],
                        "online": STATUS.get("online")})
        elif path == "/api/netease/playlists":
            uid = (qs.get("uid") or [""])[0].strip()
            self._json(user_playlists_cached(uid))
        elif path == "/api/license":
            self._json(license_status())
        else:
            self._send(404, b"404", "text/plain; charset=utf-8")

    def _body_json(self) -> dict:
        """读 POST 的 JSON 体。读不了就给空 dict，让上层报错去。"""
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            n = 0
        if n <= 0 or n > 4 * 1024 * 1024:
            return {}
        try:
            body = self.rfile.read(n).decode("utf-8")
            data = json.loads(body)
            return data if isinstance(data, dict) else {}
        except (ValueError, UnicodeDecodeError, OSError):
            return {}

    def do_POST(self):  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path not in ("/api/login", "/api/screen", "/api/admin") and \
                not auth_ok(self.headers.get("X-Whale-Token") or ""):
            self._json({"ok": False, "error": "需要启动密码", "auth": True}, 401)
            return

        if parsed.path == "/api/screen":
            data = self._body_json()
            self._json(try_screen(str(data.get("answer") or "")))
        elif parsed.path == "/api/login":
            data = self._body_json()
            res = try_login(str(data.get("password") or ""))
            if res.get("ok"):
                log("密码对了，解锁")
            self._json(res)
        elif parsed.path == "/api/admin":
            data = self._body_json()
            self._json(try_admin(str(data.get("password") or "")))
        elif parsed.path == "/api/fetch":
            _manual_fetch.set()
            log("前端点了「立刻抓取」")
            self._json({"ok": True, "msg": "已排队，联网就开工"})
        elif parsed.path == "/api/open":
            data = self._body_json()
            kind = str(data.get("kind") or "")
            rid = str(data.get("rid") or "")
            if _LIB is None or not kind or not rid:
                self._json({"ok": False, "error": "缺 kind/rid"}, 400)
                return
            rec = _LIB.mark_opened(kind, rid, {
                "title": data.get("title") or "",
                "sub": data.get("sub") or "",
                "cat": data.get("cat") or "",
                "url": data.get("url") or "",
                "image": data.get("image") or "",
                "ts": float(data.get("ts") or 0),
            })
            self._json({"ok": True, "record": rec})
        elif parsed.path == "/api/fav":
            data = self._body_json()
            if _LIB is None:
                self._json({"ok": False, "error": "library 没加载"}, 500)
                return
            key = str(data.get("key") or "")
            rec = _LIB.set_fav(key, bool(data.get("on", True)))
            self._json({"ok": bool(rec), "record": rec})
        elif parsed.path == "/api/finished":
            data = self._body_json()
            if _LIB is None:
                self._json({"ok": False, "error": "library 没加载"}, 500)
                return
            rec = _LIB.mark_finished(str(data.get("key") or ""))
            self._json({"ok": bool(rec), "record": rec})
        elif parsed.path == "/api/archive":
            data = self._body_json()
            if _LIB is None:
                self._json({"ok": False, "error": "library 没加载"}, 500)
                return
            rec = _LIB.set_archived(str(data.get("key") or ""),
                                    bool(data.get("on", True)))
            self._json({"ok": bool(rec), "record": rec})
        elif parsed.path == "/api/follows":
            data = self._body_json()
            items = _follows()
            act = str(data.get("action") or "add")
            it = data.get("item") or {}
            sid = str(it.get("sid") or "").strip()
            if not sid:
                self._json({"ok": False, "error": "缺 sid"}, 400)
                return
            if act == "del":
                items = [x for x in items if str(x.get("sid")) != sid]
            elif act == "bind":
                # 给这部番绑一个"小站番剧 id"，有了它才能下载
                aid = str(it.get("site_aid") or "").strip()
                for x in items:
                    if str(x.get("sid")) == sid:
                        x["site_aid"] = aid
                        break
            else:
                if not any(str(x.get("sid")) == sid for x in items):
                    items.append({
                        "sid": sid,
                        "type": str(it.get("type") or "番剧"),
                        "title": str(it.get("title") or ""),
                        "cover_url": str(it.get("cover_url") or ""),
                        "url": str(it.get("url") or ""),
                        "added_at": _now_str(),
                        "last_ep_id": "",
                    })
            _save_follows(items)
            if _QUEUE is not None and act != "del":
                _QUEUE.add("anime", "all")
            self._json({"ok": True, "items": items})
        elif parsed.path == "/api/activate":
            data = self._body_json()
            if licmod is None:
                self._json({"ok": False, "error": "license 没加载"}, 500)
                return
            code = str(data.get("code") or "").strip()
            res = licmod.verify(code, licmod.machine_code())
            if res.get("ok"):
                st = licmod.load_state(BASE_DIR)
                st["code"] = code
                st["activated_at"] = _now_str()
                licmod.save_state(BASE_DIR, st)
                STATUS["license"] = res
                STATUS["edition"] = "激活版"
                log("激活成功，到期 %s" % res.get("expires"))
            self._json(res)
        elif parsed.path == "/api/update":
            data = self._body_json()
            act = str(data.get("action") or "check")
            if act == "check":
                self._json(check_update())
            else:
                self._json({"ok": False, "error": "自动更新还没接上"})
        elif parsed.path == "/api/queue":
            data = self._body_json()
            act = str(data.get("action") or "")
            if _QUEUE is None:
                self._json({"ok": False, "error": "队列没加载"}, 500)
                return
            if act == "clear":
                n = _QUEUE.clear_finished()
            elif act == "retry":
                # 把死掉的重新激活（用户手动点的）
                n = 0
            else:
                n = 0
            self._json({"ok": True, "cleared": n, "queue": _QUEUE.snapshot()})
        elif parsed.path == "/api/refetch":
            data = self._body_json()
            url = str(data.get("url") or "").strip()
            if not url.startswith(("http://", "https://")):
                self._json({"ok": False, "error": "没有原文地址，或者不是 http(s) 的"}, 400)
                return
            if _QUEUE is None:
                self._json({"ok": False, "error": "队列没加载"}, 500)
                return
            key = "re:" + hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
            _QUEUE.add("mirror", key, {"url": url})
            self._json({"ok": True, "msg": "排进队列了，联网就重新扒一份"})
        elif parsed.path == "/api/music/download":
            data = self._body_json()
            sid = str(data.get("song_id") or "").strip()
            if not sid:
                self._json({"ok": False, "error": "缺 song_id"}, 400)
                return
            if netmusic is None or _QUEUE is None:
                self._json({"ok": False, "error": "模块没加载"}, 500)
                return
            _QUEUE.add("song_dl", "sg:" + sid, {
                "song_id": sid,
                "name": str(data.get("name") or ""),
                "artist": str(data.get("artist") or ""),
                "album": str(data.get("album") or ""),
                "duration_s": data.get("duration_s") or 0,
                "playlist_name": str(data.get("playlist_name") or ""),
                "playlist_pid": str(data.get("playlist_pid") or ""),
            })
            _queue_kick.set()
            online = bool(STATUS.get("online"))
            self._json({"ok": True, "queued": True, "online": online,
                        "msg": ("排队中，马上开始" if online
                                else "排上了，联网后自动下")})
        elif parsed.path == "/api/music/relrc":
            data = self._body_json()
            res = relrc_one(str(data.get("song_id") or ""))
            self._json(res)
        elif parsed.path == "/api/anime/site/download":
            data = self._body_json()
            aid = str(data.get("aid") or "").strip()
            ep = str(data.get("ep") or "").strip()
            title = str(data.get("title") or "").strip() or aid
            if not aid or not ep:
                self._json({"ok": False, "error": "缺番剧 id 或集数"}, 400)
                return
            key = "an_%s_%s" % (aid, ep)
            _adl_add(key, title, aid, ep)
            if _QUEUE is not None:
                _QUEUE.add("anime_dl", key,
                           {"key": key, "title": title, "aid": aid, "ep": ep})
                _queue_kick.set()
            self._json({"ok": True, "key": key,
                        "msg": "已排队，分段下，断了下次接着下"})
        elif parsed.path == "/api/bili/want":
            data = self._body_json()
            kw = str(data.get("keyword") or "").strip()
            if not kw:
                self._json({"ok": False, "error": "给个关键词"}, 400)
                return
            if _BP is None:
                self._json({"ok": False, "error": "状态模块没加载"}, 500)
                return
            wid = hashlib.sha1(("%s|%.3f" % (kw, time.time())).encode("utf-8")
                               ).hexdigest()[:12]
            item = _BP.want_add(kw, wid)
            if _QUEUE is not None:
                _QUEUE.add("bili_kw", "kw:" + wid, {"id": wid, "keyword": kw})
                _queue_kick.set()
            online = bool(STATUS.get("online"))
            log("记了个 B 站关键词：「%s」（%s）" % (kw, "联网就搜" if online else "等联网"))
            self._json({"ok": True, "item": item, "online": online,
                        "msg": ("已排队，马上搜" if online
                                else "记下了，联网时自动搜并下前几个")})
        elif parsed.path == "/api/bili/download":
            data = self._body_json()
            bvid = str(data.get("bvid") or "").strip()
            if not bvid:
                self._json({"ok": False, "error": "缺 bvid"}, 400)
                return
            if _BP is None:
                self._json({"ok": False, "error": "状态模块没加载"}, 500)
                return
            _BP.dl_add(bvid, str(data.get("title") or ""),
                       {"duration_s": data.get("duration_s") or 0})
            if _QUEUE is not None:
                _QUEUE.add("bili_dl", "bv:" + bvid,
                           {"bvid": bvid, "title": str(data.get("title") or ""),
                            "duration_s": data.get("duration_s") or 0})
                _queue_kick.set()
            online = bool(STATUS.get("online"))
            self._json({"ok": True, "online": online,
                        "msg": ("排队中，马上开始" if online
                                else "排队了，联网后自动下")})
        elif parsed.path == "/api/wish":
            data = self._body_json()
            text = str(data.get("text") or "").strip()
            if not text:
                self._json({"ok": False, "error": "给个歌名或者歌手名"}, 400)
                return
            items = _wishes_load()
            # 同名字还没下完的，别重复记
            for x in items:
                if x.get("text") == text and x.get("state") in (
                        "pending", "searching", "downloading"):
                    self._json({"ok": True, "exist": True, "item": x,
                                "msg": "这个名字已经在排队了"})
                    return
            wid = hashlib.sha1(("%s|%.3f" % (text, time.time())).encode("utf-8")
                               ).hexdigest()[:12]
            item = {"id": wid, "text": text, "state": "pending",
                    "song": "", "file": "", "error": "",
                    "created_at": _now_str()}
            items.insert(0, item)
            _wishes_save(items)
            if _QUEUE is not None:
                _QUEUE.add("wish", "w:" + wid, {"id": wid, "text": text})
            _queue_kick.set()
            online = bool(STATUS.get("online"))
            log("记了个待下载：「%s」（%s）" % (text,
                                        "联网就下" if online else "等联网"))
            self._json({"ok": True, "item": item, "queued": True,
                        "online": online,
                        "msg": ("已排队，马上开始" if online
                                else "先记下了，联网后自动搜来下")})
        elif parsed.path == "/api/playlist/add":
            data = self._body_json()
            pid = str(data.get("pid") or "").strip()
            if not pid:
                self._json({"ok": False, "error": "缺歌单 id"}, 400)
                return
            items = _playlists_load()
            if any(str(x.get("pid")) == pid for x in items):
                self._json({"ok": True, "exist": True, "item": _playlist_get(pid),
                            "msg": "这个歌单已经在列表里了"})
                return
            # 只收藏目录：不再整单排队下载（那样一加就是几百首）。
            # 真正下歌在「点开歌单 → 逐首下载」里，一首一首来。
            item = {
                "pid": pid,
                "name": str(data.get("name") or "歌单"),
                "cover": str(data.get("cover") or ""),
                "uid": str(data.get("uid") or ""),
                "creator": str(data.get("creator") or ""),
                "state": "saved",
                "total": int(data.get("total") or 0),
                "done": 0, "ok": 0, "failed": 0, "skipped": 0,
                "current": "", "error": "",
                "added_at": _now_str(),
            }
            items.insert(0, item)
            _playlists_save(items)
            log("收藏了歌单「%s」（只存目录，不下歌）" % item["name"])
            self._json({"ok": True, "item": item, "queued": False,
                        "online": bool(STATUS.get("online")),
                        "msg": "收藏好了，点开可以逐首下载"})
        elif parsed.path == "/api/search-all":
            data = self._body_json()
            self._json(global_search(str(data.get("q") or "")))
        elif parsed.path == "/api/config":
            if LOCK_SETTINGS and not admin_ok():
                self._json({"ok": False, "error": "设置被锁了，要管理员才能改",
                            "locked": True}, 403)
                return
            data = self._body_json()
            try:
                saved = save_config(data)
            except Exception as e:  # noqa: BLE001
                self._json({"ok": False, "error": "%s: %s" % (type(e).__name__, e)}, 500)
                return
            log("设置改了：去重窗口 %.0f 分、限速 %.1fMB/s、关键词 %d 个、"
                "点歌 %d 首、自定义源 %d 个"
                % (saved["online_dedupe_min"], saved["max_rate_mb"],
                   len(saved["search_keywords"]), saved["music_per_run"],
                   len(saved["custom_sources"])))
            self._json({"ok": True, "config": saved, "msg": "已保存，大部分设置立刻生效"})
        elif parsed.path == "/api/search":
            if not SEARCH_KEYWORDS:
                self._json({"ok": False, "error": "先去设置里填几个关键词"}, 400)
                return
            start_search_job()
            self._json({"ok": True, "msg": "开始搜了，几秒就好"})
        elif parsed.path == "/api/mirror":
            data = self._body_json()
            url = (data.get("url") or "").strip()
            if not url.startswith(("http://", "https://")):
                self._json({"ok": False, "error": "网址得是 http:// 或 https:// 开头的"}, 400)
                return
            start_mirror_job(url)
            self._json({"ok": True, "msg": "开始扒了，几秒到几十秒不等，好了会自动出现"})
        else:
            self._json({"error": "not found"}, 404)

    def do_DELETE(self):  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/api/mirror":
            mid = (qs.get("id") or [""])[0]
            ok = delete_mirror(mid)
            self._json({"ok": ok, "msg": "删了" if ok else "没找到这个镜像"})
        elif parsed.path == "/api/anime/site/list":
            if not auth_ok(self.headers.get("X-Whale-Token") or ""):
                self._json({"ok": False, "error": "需要启动密码", "auth": True}, 401)
                return
            key = (qs.get("key") or [""])[0]
            items = [x for x in _adl_load() if x.get("key") != key]
            _adl_save(items)
            if _QUEUE is not None:
                _QUEUE.drop("anime_dl", key)
            self._json({"ok": True, "msg": "删了"})
        elif parsed.path == "/api/bili/want":
            if not auth_ok(self.headers.get("X-Whale-Token") or ""):
                self._json({"ok": False, "error": "需要启动密码", "auth": True}, 401)
                return
            wid = (qs.get("id") or [""])[0]
            ok = _BP.want_remove(wid) if _BP is not None else False
            if _QUEUE is not None:
                _QUEUE.drop("bili_kw", "kw:" + wid)
            self._json({"ok": ok, "msg": "删了" if ok else "没找到"})
        elif parsed.path == "/api/wish":
            if not auth_ok(self.headers.get("X-Whale-Token") or ""):
                self._json({"ok": False, "error": "需要启动密码", "auth": True}, 401)
                return
            wid = (qs.get("id") or [""])[0]
            items = [x for x in _wishes_load() if str(x.get("id")) != str(wid)]
            _wishes_save(items)
            if _QUEUE is not None:
                _QUEUE.drop("wish", "w:" + wid)
            self._json({"ok": True, "msg": "删了"})
        elif parsed.path == "/api/playlist":
            if not auth_ok(self.headers.get("X-Whale-Token") or ""):
                self._json({"ok": False, "error": "需要启动密码", "auth": True}, 401)
                return
            pid = (qs.get("pid") or [""])[0]
            items = [x for x in _playlists_load() if str(x.get("pid")) != str(pid)]
            _playlists_save(items)
            if _QUEUE is not None:
                _QUEUE.drop("playlist", "pl:" + pid)
            self._json({"ok": True, "msg": "删了"})
        else:
            self._json({"error": "not found"}, 404)

    def _api_news(self, qs):
        want_id = (qs.get("id") or [""])[0]
        cat = (qs.get("category") or [""])[0]
        only_new = (qs.get("only_new") or ["0"])[0] == "1"

        src = LATEST_FILE
        if want_id and re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{4}", want_id):
            cand = os.path.join(SNAP_DIR, want_id + ".json")
            if os.path.isfile(cand):
                src = cand
        try:
            with open(src, "r", encoding="utf-8") as f:
                snap = json.load(f)
        except (OSError, ValueError):
            self._json({"error": "还没有数据", "items": [], "total": 0}, 200)
            return

        items = snap.get("items", [])
        if cat:
            items = [i for i in items if i.get("category") == cat]
        if only_new:
            items = [i for i in items if i.get("is_new")]
        snap = dict(snap, items=items, shown=len(items))
        self._json(snap)


def tail_log(n: int = 120) -> str:
    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-n:])
    except OSError:
        return "(还没有日志)"


def build_status() -> dict:
    with STATUS_LOCK:
        s = dict(STATUS)
    now = time.time()
    s["now"] = now
    # 这几个是能现改的，别读快照里那份旧值
    s["rate_bytes"] = MAX_RATE_BYTES
    last = s.get("last_fetch_ts") or 0
    if last:
        s["hours_since_fetch"] = round((now - last) / 3600.0, 3)
        s["last_fetch_ts"] = last
    else:
        s["hours_since_fetch"] = None
    # v0.3：没有"下次抓取时间"了，只有"下一轮什么时候肯再抓"
    round_ts = s.get("last_round_ts") or 0
    s["dedupe_seconds"] = int(ONLINE_DEDUPE)
    if round_ts:
        left = max(0, int(round_ts + ONLINE_DEDUPE - now))
        s["seconds_to_next_round"] = left
        s["next_round_ts"] = round_ts + ONLINE_DEDUPE
    else:
        s["seconds_to_next_round"] = 0
        s["next_round_ts"] = 0
    s["seconds_to_due"] = s["seconds_to_next_round"]   # 老前端还认这个字段
    s["interval_hours"] = ONLINE_DEDUPE / 3600.0
    s["budget_total"] = int(ROUND_BUDGET)
    s["disk_free_mb"] = round(free_bytes() / 1048576.0, 1)
    s["disk_min_mb"] = int(DISK_MIN_BYTES / 1048576.0)
    if _QUEUE is not None:
        s["queue"] = _QUEUE.snapshot()
    if _LIB is not None:
        s["library"] = _LIB.status()
    s["has_data"] = os.path.exists(LATEST_FILE)
    s["usb"] = usb_present()
    if s.get("blocked"):
        s["blocked_since"] = _cloud_load().get("since") or ""
    s["auth_required"] = bool(need_auth())
    s["unlocked"] = not need_auth() or auth_ok("")
    try:
        s["license"] = license_status()
    except Exception:  # noqa: BLE001
        s["license"] = {}
    return s


# ══════════════════════════════════════════════════════════════════════
#  启动
# ══════════════════════════════════════════════════════════════════════

def find_port(preferred: int) -> int:
    for p in [preferred] + list(range(preferred + 1, preferred + 20)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return 0


def serve(port: int, stop_evt: threading.Event, open_browser: bool = False) -> None:
    httpd = ThreadingHTTPServer(("127.0.0.1", port), NewsHandler)
    httpd.daemon_threads = True
    with STATUS_LOCK:
        STATUS["port"] = port
    log("网页服务起来了： http://127.0.0.1:%d" % port)
    if open_browser:
        try:
            import webbrowser
            webbrowser.open("http://127.0.0.1:%d" % port)
        except Exception:  # noqa: BLE001
            pass
    thread = threading.Thread(target=httpd.serve_forever, kwargs={"poll_interval": 0.5},
                              daemon=True)
    thread.start()
    try:
        while not stop_evt.is_set():
            stop_evt.wait(0.5)
    finally:
        httpd.shutdown()
        httpd.server_close()


def main() -> int:
    ap = argparse.ArgumentParser(description="离线新闻抓取守护进程")
    ap.add_argument("--fetch", action="store_true", help="立刻抓一次就退出")
    ap.add_argument("--check", action="store_true", help="只测网络")
    ap.add_argument("--no-serve", action="store_true", help="不起网页服务")
    ap.add_argument("--open", action="store_true", dest="open_ui",
                    help="服务起来后自动打开浏览器")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    args = ap.parse_args()

    if args.check:
        print("TCP 能连吗：", "能" if _tcp_ok() else "不能")
        print("能真上网吗：", "能" if _http_ok() else "不能")
        return 0

    if not acquire_lock():
        try:
            with open(LOCK_FILE, "r", encoding="utf-8") as f:
                other = (f.read() or "?").strip()
        except OSError:
            other = "?"
        msg = ("已经有一个 newsd 在跑了（PID %s），两个一起抓会把快照互相盖掉。\n"
               "想让它立刻抓，用浏览器打开页面上点「立刻抓取」，"
               "或者在命令行跑 stop.bat 把它关掉再重来。" % other)
        log(msg.replace("\n", " "))
        print(msg)
        return 1

    if args.fetch:
        if not probe_online(force_http=True):
            log("没网，抓不了")
            print("没网，抓不了")
            return 1
        snap = fetch_all(with_extras=True)
        print("抓完：%d 条" % snap["total"])
        print("文档：%s" % os.path.join(DOCS_DIR, snap["id"] + ".md"))
        return 0

    log("=" * 60)
    log("newsd 启动")
    if licmod is not None:
        try:
            _st = licmod.status(BASE_DIR)
            log("机器码 %s ・ 版本 %s" % (_st.get("machine_code"), _st.get("edition")))
        except Exception as e:  # noqa: BLE001
            log("激活状态读不出来：%s" % e)

    stop_evt = threading.Event()
    port = DEFAULT_PORT if args.no_serve else find_port(args.port)

    # U 盘监视：插上就是最高权限，顺手看看有没有新版
    threading.Thread(target=_usb_watch, args=(stop_evt,), daemon=True,
                     name="usb-watch").start()

    if args.no_serve:
        try:
            monitor_loop(stop_evt)
        except KeyboardInterrupt:
            pass
        return 0

    mon = threading.Thread(target=monitor_loop, args=(stop_evt,), daemon=True)
    mon.start()
    try:
        serve(port, stop_evt, args.open_ui)
    except KeyboardInterrupt:
        log("收到 Ctrl+C，收工")
    finally:
        stop_evt.set()
    return 0


if __name__ == "__main__":
    sys.exit(main())
