# -*- coding: utf-8 -*-
"""
netmusic.py — 网易云榜单「顺手薅几首」

定位跟 music.py 相反：music.py 只扫本地，这个模块负责在老师开热点那几分钟里
从网易云公开榜单挑几首歌下到 data/music/，之后断网也能听。

为什么不走官方 weapi / 加密接口：
  那些接口要 AES 加密请求体、模拟 cookie，纯标准库写起来又臭又长。
  `api/playlist/detail` 这个老接口不用登录、不用签名，直接 GET 就返回歌单。

实测结论（2026-10-31，本机直连，urllib 显式禁用系统代理）：
  * `https://music.163.com/api/playlist/detail?id=<榜单id>` —— 可用。
    带 Referer + 浏览器 UA，code=200；热歌榜 200 首，新歌/飙升/原创各 100 首。
    字段是老版结构：`artists`（不是 `ar`）、`duration` 是毫秒、封面在 `album.picUrl`。
    这个老接口**没有 `privilege` 字段**，只能拿 `fee` 预筛。
  * `https://music.163.com/api/v6/playlist/detail?id=<id>&n=1000&offset=0` —— 请求能过，
    code=200，但 `result.tracks` 是空数组（新接口把歌单挪进 trackIds/privilege 了），
    所以只当老接口挂掉时的备用。
  * `https://music.163.com/song/media/outer/url?id=<songid>.mp3` —— 可用，
    302 到 m701/m801.music.126.net，必须带 Referer 和 UA。
  * fee 才是关键：`fee=8`（免费）和 `fee=0`（完全免费）能下到完整 mp3；
    `fee=1`（VIP）会 302 到 `https://music.163.com/404`，
    返回一份 107KB 的 **HTML 404 页面**（Content-Type: text/html）。
    所以光靠「小于 60KB 算失败」拦不住 —— 它比阈值还大，
    必须再看文件头是不是文本，见下面的 _looks_html()。
  实测抽样 15 首 fee∈{0,8} 全都拿到 200KB+ 的真音频。

依赖：纯标准库，跟项目其它模块一样零 pip。
"""

import json
import os
import random
import re
import urllib.error
import urllib.request

CHARTS = {
    "热歌榜": 3778678,
    "新歌榜": 3779629,
    "飙升榜": 19723756,
    "原创榜": 2884035,
}

API_DETAIL = "https://music.163.com/api/playlist/detail?id={pid}"
API_DETAIL_V6 = "https://music.163.com/api/v6/playlist/detail?id={pid}&n=1000&offset=0"
API_SONG = "https://music.163.com/song/media/outer/url?id={sid}.mp3"

REFERER = "https://music.163.com/"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

# 每个榜单只在前 POOL_SIZE 首里挑，越靠后的歌越旧，也越容易撞版权墙
POOL_SIZE = 100
# 能下的 fee 值：8=免费 0=完全免费；1=VIP、4=买专辑，都会拿到 404 页面
PLAYABLE_FEE = (0, 8)

# 小于这个就当没下到
MIN_AUDIO = 60 * 1024
# 已存在且大于这个大小就不重下（上一轮下完的）
SKIP_ALREADY = 100 * 1024

# Windows 文件名非法字符 + 控制字符
_BAD_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f\x7f]')
# 全角符号看着没事，其实也容易在各处出幺蛾子，一并换掉
_FULLWIDTH = {"／": "_", "＼": "_", "：": "_", "＊": "_", "？": "_",
              "＂": "_", "＜": "_", "＞": "_", "｜": "_"}

_HTML_HEAD = (b"<!doctype", b"<html", b"<?xml", b"<head", b"<body")


def _s(v) -> str:
    """接口里的字段可能是 None / 数字，统一成干净的字符串。"""
    if v is None:
        return ""
    return str(v).strip()


def _safe_name(text: str, limit: int = 90) -> str:
    """转成 Windows 能落盘的文件名。
    除了非法字符，还得去掉结尾的点和空格 —— Windows 上「歌名. 」这种
    创建会直接失败，或者变成一个没后缀的怪文件。
    """
    for k, v in _FULLWIDTH.items():
        text = text.replace(k, v)
    text = _BAD_CHARS.sub("_", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = text.rstrip(". ")
    if len(text) > limit:
        text = text[:limit].rstrip(". ")
    return text


def _looks_html(head: bytes) -> bool:
    """靠文件头判断这到底是不是音频。
    mp3 一般以 ID3 开头，或者直接是 0xFF 0xFx 帧同步字节；HTML 则是 '<'。
    这一步必须做：VIP 歌返回的 404 页面有 107KB，光看大小会被当成成功。
    """
    s = head.lstrip()[:16].lower()
    if not s:
        return True
    if s[:1] == b"<":
        return True
    return any(s.startswith(h) for h in _HTML_HEAD)


def _norm(raw: dict, chart: str) -> dict:
    """把原始 track 压成主控要的结构。
    老接口用 artists / duration(ms) / album.picUrl，新接口用 ar / dt / al.picUrl，
    两边都认，省得哪天接口悄悄换版直接崩。
    """
    arts = raw.get("artists") or raw.get("ar") or []
    names = []
    for a in arts:
        if isinstance(a, dict):
            n = _s(a.get("name"))
            if n:
                names.append(n)
    album = raw.get("album") or raw.get("al") or {}
    if not isinstance(album, dict):
        album = {}
    dur = raw.get("duration") or raw.get("dt") or 0
    try:
        dur_s = int(dur) // 1000
    except (TypeError, ValueError):
        dur_s = 0
    cover = _s(album.get("picUrl"))
    # 接口给的封面是 http，换 https 少一次跳转
    if cover.startswith("http://"):
        cover = "https://" + cover[7:]
    sid = _s(raw.get("id"))
    return {
        "id": sid,
        "name": _s(raw.get("name")),
        "artist": " / ".join(names),
        "album": _s(album.get("name")),
        "duration_s": dur_s,
        "cover_url": cover,
        "mp3_url": API_SONG.format(sid=sid) if sid else "",
        "chart": chart,
    }


def _usable(raw: dict) -> bool:
    """预筛，先把明显下不到的歌剔掉，省得下载时白等。
    fee 不在白名单、status 非 0（下架）、带 noCopyrightRcmd（无版权）都跳过。
    privilege.st < 0 只有新接口才有，有就顺手看一眼。
    """
    if not raw.get("id") or not _s(raw.get("name")):
        return False
    try:
        fee = int(raw.get("fee") or 0)
    except (TypeError, ValueError):
        fee = -1
    if fee not in PLAYABLE_FEE:
        return False
    if raw.get("status") not in (None, 0):
        return False
    if raw.get("noCopyrightRcmd"):
        return False
    pr = raw.get("privilege")
    if isinstance(pr, dict):
        try:
            if int(pr.get("st") or 0) < 0:
                return False
        except (TypeError, ValueError):
            pass
    return True


def _fetch_chart(sess, chart: str, pid: int, timeout: int, log) -> list[dict]:
    """抓一个榜单的前 POOL_SIZE 首。
    老接口挂了再试新接口；两个都挂就返回空，让 pick 继续跑别的榜。
    """
    for url in (API_DETAIL.format(pid=pid), API_DETAIL_V6.format(pid=pid)):
        try:
            data = sess.get_json(url, referer=REFERER, timeout=timeout)
            tracks = ((data or {}).get("result") or {}).get("tracks") or []
            if tracks:
                hit = sum(1 for t in tracks if _usable(t))
                log("[netmusic] %s：拿到 %d 首，可下 %d 首"
                    % (chart, len(tracks), hit))
                return [t for t in tracks[:POOL_SIZE] if _usable(t)]
            log("[netmusic] %s：接口没给 tracks，换备用接口" % chart)
        except Exception as exc:
            log("[netmusic] %s：%s 失败（%s）"
                % (chart, url.split("?")[0], type(exc).__name__))
    return []


def pick(sess, charts=("热歌榜",), count=5, timeout=15, log=print) -> list[dict]:
    """从网易云公开榜单里挑歌。

    sess 是主控注入的会话对象，提供 get_bytes / get_json / save_stream。
    count 是这一轮总共挑几首（跨榜单合计）。
    挑不到就返回 []，绝不抛异常 —— 断网是常态，不能把整轮抓取带崩。
    """
    try:
        count = max(0, int(count))
    except (TypeError, ValueError):
        return []
    if count <= 0:
        return []

    names = []
    for c in charts or ():
        if c in CHARTS:
            names.append(c)
        else:
            log("[netmusic] 不认识的榜单：%r，跳过" % (c,))
    if not names:
        return []

    # 每个榜单独攒池子，之后轮着抽，免得全被第一个榜霸占
    pools = []
    for chart in names:
        try:
            songs = _fetch_chart(sess, chart, CHARTS[chart], timeout, log)
        except Exception as exc:      # _fetch_chart 里已经 catch 过，这是双保险
            log("[netmusic] %s 抓取异常：%s" % (chart, type(exc).__name__))
            songs = []
        if songs:
            random.shuffle(songs)     # 每次挑的不一样，别老下同一批
            pools.append((chart, songs))

    picked = []
    seen = set()
    # 轮盘式：第 1 首从第一个榜、第 2 首从第二个榜……轮流把 count 填满
    while len(picked) < count and pools:
        alive = 0
        for chart, pool in pools:
            if len(picked) >= count:
                break
            if not pool:
                continue
            alive += 1
            raw = pool.pop(0)
            item = _norm(raw, chart)
            if item["id"] in seen:
                continue
            seen.add(item["id"])
            picked.append(item)
        if alive == 0:
            break

    return picked[:count]


def _file_base(item: dict) -> str:
    """`歌手 - 歌名`，没有歌手就只写歌名。"""
    artist = _safe_name(_s(item.get("artist")))
    name = _safe_name(_s(item.get("name"))) or _safe_name(_s(item.get("id"))) or "unknown"
    return ("%s - %s" % (artist, name)) if artist else name


def _is_complete(path: str) -> bool:
    """已存在且大于 100KB 就算下完了；残包留给 download 重下。"""
    try:
        return os.path.getsize(path) > SKIP_ALREADY
    except OSError:
        return False


def _try_remove(path: str) -> None:
    """删半成品。文件不存在、被占用都当没事。"""
    try:
        os.remove(path)
    except OSError:
        pass


def download(sess, item, out_dir, log=print) -> dict:
    """把一首歌下载到 out_dir（绝对路径目录，调用方已建好）。
    返回 {"ok", "file", "bytes", "error", "skipped"}，同样绝不抛异常。
    """
    res = {"ok": False, "file": "", "bytes": 0, "error": "", "skipped": False}
    try:
        mp3 = _s(item.get("mp3_url"))
        if not mp3:
            sid = _s(item.get("id"))
            if not sid:
                res["error"] = "没有歌曲 id"
                return res
            mp3 = API_SONG.format(sid=sid)

        base = _file_base(item)
        path = os.path.join(out_dir, base + ".mp3")
        # 重名往后加 (2)(3)……：同名不同版本挺常见，别互相覆盖
        n = 2
        while os.path.exists(path) and not _is_complete(path):
            path = os.path.join(out_dir, "%s (%d).mp3" % (base, n))
            n += 1

        if _is_complete(path):
            res.update(ok=True, file=path, bytes=os.path.getsize(path),
                       skipped=True)
            log("[netmusic] %s 已经有了，跳过" % os.path.basename(path))
            return res

        try:
            got = sess.save_stream(mp3, path, referer=REFERER, timeout=30,
                                   max_bytes=300 * 1024 * 1024)
        except Exception as exc:
            _try_remove(path)
            res["error"] = "下载失败：%s" % (type(exc).__name__,)
            return res

        try:
            got = int(got)
        except (TypeError, ValueError):
            try:
                got = os.path.getsize(path)
            except OSError:
                got = 0

        # 双保险：小文件 和 HTML 404 页面都算失败
        bad = got < MIN_AUDIO
        if not bad and os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    head = f.read(256)
                bad = _looks_html(head)
            except OSError:
                bad = False
        if bad:
            _try_remove(path)
            res["bytes"] = got
            res["error"] = "获取不到完整音频，多半是 VIP 或无版权"
            return res

        res.update(ok=True, file=path, bytes=got)

        # 顺手把封面存成同名图片，点歌台和全屏歌词页要用它
        try:
            save_cover(sess, cover_url_of(sess, item), os.path.splitext(path)[0])
        except Exception:  # noqa: BLE001
            pass

        # 顺手把歌词存成同名 .lrc，播放器的全屏歌词页就近读它。
        # 拿不到就算了，没歌词又不影响听歌。
        try:
            sid = _s(item.get("id"))
            base_lrc = os.path.splitext(path)[0]
            if sid:
                full = get_lyric_full(sess, sid)
                # 逐字那份优先落到 .lrc 里 —— 播放器认得 YRC，比整行强
                body = full.get("klyric") or full.get("lrc") or ""
                if body.strip() and not os.path.exists(base_lrc + ".lrc"):
                    with open(base_lrc + ".lrc", "w", encoding="utf-8",
                              newline="\n") as f:
                        f.write(body)
                tl = full.get("tlrc") or ""
                if tl.strip() and not os.path.exists(base_lrc + ".tlrc"):
                    with open(base_lrc + ".tlrc", "w", encoding="utf-8",
                              newline="\n") as f:
                        f.write(tl)
        except Exception:  # noqa: BLE001
            pass
        return res
    except Exception as exc:        # 路径/权限之类，别让调用方跟着崩
        res["error"] = "异常：%s" % (type(exc).__name__,)
        return res


# ============================================================================
# 用户 / 歌单（搜人 → 看歌单 → 整个歌单边下边报进度）
#
# 实测结论（2026-10-31，本机直连，urllib 显式禁用系统代理，Referer + 浏览器 UA）：
#   * 搜用户 `api/search/get/web?type=1002&s=<urlencode>`
#     —— 可用，code=200，`result.userprofiles` 是那 10 条（搜「陈奕迅」实测 10 条）。
#     字段是 `userId / nickname / avatarUrl / signature / playlistCount`，
#     没有 `id / name / playlist_count`，两套名字都得兜。
#   * 用户歌单 `api/user/playlist?uid=&offset=&limit=`
#     —— 可用，code=200，`playlist` 数组；`playlist[0]` 通常是「XX喜欢的音乐」
#     （specialType=0，但 name 带「喜欢的音乐」），照常返回。
#     实测 uid=14180774028 拿到 9 个歌单，`trackCount` 是歌单真实总曲数。
#   * 歌单详情 `api/playlist/detail?id=&n=1000`（老接口）
#     —— **只给 10 首**，n/offset 都不管用（offset=10 还是那 10 首）。
#     而且「我喜欢的音乐」这类歌单直接返回 code=20001。
#   * `api/v6/playlist/detail?id=&n=1000&offset=0`
#     —— 返回结构是**顶层 `playlist`**，不是 `result`！
#     `playlist.tracks` 默认也只有 10 首，但 **`playlist.trackIds` 是全的**
#     （339 首的歌单给 339 个 id）。想让它直接吐全量 tracks 得加
#     `Cookie: os=pc` —— 可惜 sess 只有 url/referer/timeout，塞不进 header，
#     所以这里走「先拿 trackIds，再批量换歌」。
#   * `api/song/detail?ids=[a,b,c]`
#     —— 可用，不用登录，单次实测可到 200 个 id（要 250 个只回 201 个，会丢），
#     所以按 200 一批切；返回老结构 `songs`，带 `fee / status / duration / artists`。
#     靠这个就能凑齐整个歌单，且字段跟老接口一致，_norm 直接能吃。
#   * `music.163.com/playlist?id=<pid>` 这个 HTML 页里有个
#     `<textarea id="song-list-pre-data">` 塞了整份 JSON，当最后一道备用。
# ============================================================================

API_SEARCH_USER = ("https://music.163.com/api/search/get/web"
                   "?type=1002&s={kw}&limit={limit}&offset={offset}")
API_USER_PLAYLIST = ("https://music.163.com/api/user/playlist"
                     "?uid={uid}&offset={offset}&limit={limit}")
API_PLAYLIST_V6 = "https://music.163.com/api/v6/playlist/detail?id={pid}&n=1000&offset=0"
API_PLAYLIST_OLD = "https://music.163.com/api/playlist/detail?id={pid}&n=1000"
API_SONG_DETAIL = "https://music.163.com/api/song/detail?ids=[{ids}]"
API_USER_DETAIL = "https://music.163.com/api/v1/user/detail/{uid}"
API_PLAYLIST_PAGE = "https://music.163.com/playlist?id={pid}"

# song/detail 一次最多认 200 个 id（250 个会悄悄少 49 首），别贪
SONG_BATCH = 200
# 磁盘低于这个就收手，别把 D 盘最后一点空间也吃干净
MIN_FREE_BYTES = 8 * 1024 * 1024


def _https(url: str) -> str:
    """接口给的封面是 http，统一换 https，少一次跳转。"""
    u = _s(url)
    if u.startswith("http://"):
        return "https://" + u[7:]
    return u


def _int(v, default: int = 0) -> int:
    """接口里数字可能是字符串、也可能整个字段没有。"""
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def _free_bytes(path: str):
    """目录所在盘还剩多少字节；读不出来返回 None（当够用，别因为读不到就罢工）。"""
    try:
        import shutil
        return shutil.disk_usage(path).free
    except Exception:
        return None


def _norm_user(raw: dict) -> dict:
    """把接口里的用户压成主控要的四个字段 + uid。
    两套命名都认：userId/`id`、nickname/`name`、playlistCount/`playlist_count`。
    """
    uid = raw.get("userId")
    if uid is None:
        uid = raw.get("id")
    name = raw.get("nickname")
    if name is None:
        name = raw.get("name")
    avatar = raw.get("avatarUrl")
    if not avatar:
        avatar = raw.get("avatar")
    pc = raw.get("playlistCount")
    if pc is None:
        pc = raw.get("playlist_count")
    return {
        "uid": _s(uid),
        "name": _s(name),
        "avatar": _https(avatar),
        "signature": _s(raw.get("signature")),
        "playlist_count": _int(pc),
    }


def _norm_playlist(raw: dict) -> dict:
    """歌单列表项。creator 是个嵌套对象，只取昵称。"""
    creator = raw.get("creator")
    if isinstance(creator, dict):
        cname = _s(creator.get("nickname")) or _s(creator.get("userName"))
    else:
        cname = _s(creator)
    return {
        "pid": _s(raw.get("id")),
        "name": _s(raw.get("name")),
        "track_count": _int(raw.get("trackCount")),
        "cover_url": _https(raw.get("coverImgUrl")),
        "creator": cname,
        "play_count": _int(raw.get("playCount")),
    }


def _songs_by_ids(sess, ids: list, timeout: int, log) -> list:
    """拿 trackIds 批量换完整歌曲对象。
    song/detail 一次只认 200 个 id，多了会悄悄丢，所以切开查；
    结果按传入的 ids 顺序摆好 —— 歌单顺序就是人家的排序，不能乱。
    """
    if not ids:
        return []
    got = {}
    for i in range(0, len(ids), SONG_BATCH):
        chunk = ids[i:i + SONG_BATCH]
        url = API_SONG_DETAIL.format(ids=",".join(chunk))
        try:
            data = sess.get_json(url, referer=REFERER, timeout=timeout)
        except Exception as exc:
            log("[netmusic] 批量取歌失败（第 %d 批）：%s" % (i // SONG_BATCH + 1,
                                                       type(exc).__name__))
            continue
        for s in (data or {}).get("songs") or []:
            if isinstance(s, dict) and s.get("id") is not None:
                got[_s(s.get("id"))] = s
    if not got:
        return []
    return [got[i] for i in ids if i in got]


def _playlist_raw_from_page(sess, pid, timeout: int, log) -> list:
    """最后一道备用：歌单 HTML 页里 <textarea id="song-list-pre-data"> 的整份 JSON。"""
    try:
        import html as _html
        raw = sess.get_bytes(API_PLAYLIST_PAGE.format(pid=pid),
                             referer=REFERER, timeout=timeout)
        text = raw.decode("utf-8", "replace")
        m = re.search(r'id="song-list-pre-data"[^>]*>(.*?)</textarea>',
                      text, re.S)
        if not m:
            log("[netmusic] 歌单页里没找到 song-list-pre-data")
            return []
        arr = json.loads(_html.unescape(m.group(1)))
        if isinstance(arr, list):
            log("[netmusic] 从歌单页兜到 %d 首" % len(arr))
            return [x for x in arr if isinstance(x, dict)]
    except Exception as exc:
        log("[netmusic] 抓歌单页失败：%s" % (type(exc).__name__,))
    return []


def _playlist_tracks_raw(sess, pid, timeout: int, log):
    """拿一个歌单的原始 track 列表，顺带把歌单名带出来 -> (name, tracks)。
    顺序：v6 的 trackIds + song/detail（唯一能拿全量的）
        → 老接口 tracks（只有 10 首，凑合）
        → v6 的 tracks（同样 10 首）
        → 歌单 HTML 页
    """
    pid = _s(pid)
    if not pid:
        return "", []
    name = ""

    # A. v6 拿全量 id，再批量换歌
    try:
        data = sess.get_json(API_PLAYLIST_V6.format(pid=pid),
                            referer=REFERER, timeout=timeout)
        pl = (data or {}).get("playlist") or {}
        if isinstance(pl, dict):
            name = _s(pl.get("name"))
            tids = []
            for t in pl.get("trackIds") or []:
                if isinstance(t, dict) and t.get("id") is not None:
                    tids.append(_s(t.get("id")))
            if tids:
                songs = _songs_by_ids(sess, tids, timeout, log)
                if songs:
                    log("[netmusic] 歌单《%s》：trackIds %d 个，换到 %d 首"
                        % (name, len(tids), len(songs)))
                    if len(songs) < len(tids):
                        log("[netmusic] 有 %d 首已经没了（下架/删除），跳过"
                            % (len(tids) - len(songs)))
                    return name, songs
            if pl.get("tracks"):
                return name, [t for t in pl["tracks"] if isinstance(t, dict)]
    except Exception as exc:
        log("[netmusic] 歌单 v6 接口失败：%s" % (type(exc).__name__,))

    # B. 老接口：只有前 10 首，聊胜于无
    try:
        data = sess.get_json(API_PLAYLIST_OLD.format(pid=pid),
                            referer=REFERER, timeout=timeout)
        res = (data or {}).get("result") or {}
        if isinstance(res, dict):
            name = name or _s(res.get("name"))
            tracks = [t for t in (res.get("tracks") or []) if isinstance(t, dict)]
            if tracks:
                total = _int(res.get("trackCount"))
                log("[netmusic] 老接口只给了 %d 首%s"
                    % (len(tracks),
                       ("（共 %d 首，被截断了）" % total) if total > len(tracks) else ""))
                return name, tracks
        elif data and data.get("code") not in (200, None):
            log("[netmusic] 老接口 code=%s" % (data.get("code"),))
    except Exception as exc:
        log("[netmusic] 歌单老接口失败：%s" % (type(exc).__name__,))

    # C. HTML 页兜底
    return name, _playlist_raw_from_page(sess, pid, timeout, log)


def search_user(sess, keyword, limit=10, timeout=15, log=print) -> list[dict]:
    """按用户名搜网易云用户。

    返回 [{"uid","name","avatar","signature","playlist_count"}]，
    搜不到返回 []，绝不抛异常（断网是常态）。

    实测：`api/search/get/web?type=1002` 不用登录就能用，code=200，
    数据在 `result.userprofiles`（老文档写 `result.users`，两种都兜一下）。
    """
    kw = _s(keyword)
    if not kw:
        return []
    try:
        limit = max(1, min(50, int(limit)))
    except (TypeError, ValueError):
        limit = 10

    from urllib.parse import quote
    url = API_SEARCH_USER.format(kw=quote(kw), limit=limit, offset=0)
    try:
        data = sess.get_json(url, referer=REFERER, timeout=timeout)
    except Exception as exc:
        log("[netmusic] 搜用户「%s」失败：%s" % (kw, type(exc).__name__))
        return []
    if not isinstance(data, dict):
        return []
    code = data.get("code")
    res = data.get("result") or {}
    if not isinstance(res, dict):
        res = {}
    if code not in (200, None):
        # 405（操作频繁）之类：别直接认输，下面还有 cloudsearch 兜底
        log("[netmusic] 搜用户「%s」返回 code=%s（%s），换兜底接口"
            % (kw, code, _s(data.get("message")) or _s(data.get("msg"))))
        raw = []
    else:
        raw = res.get("userprofiles") or res.get("users") or []
    if not raw:
        alt = search_fallback(sess, kw, 1002, limit, timeout=timeout, log=log)
        raw = alt.get("userprofiles") or alt.get("users") or []
    out = []
    seen = set()
    for u in raw:
        if not isinstance(u, dict):
            continue
        item = _norm_user(u)
        if not item["uid"] or item["uid"] in seen:
            continue
        seen.add(item["uid"])
        out.append(item)
    log("[netmusic] 搜用户「%s」：%d 条" % (kw, len(out)))
    return out[:limit]


def user_playlists(sess, uid, limit=50, timeout=15, log=print) -> list[dict]:
    """某个用户创建/收藏的歌单。

    返回 [{"pid","name","track_count","cover_url","creator","play_count"}]。
    `api/user/playlist` 一页最多给 100 个，要更多就翻页；翻页失败就返回已拿到的。
    """
    uid = _s(uid)
    if not uid:
        return []
    try:
        limit = max(1, int(limit))
    except (TypeError, ValueError):
        limit = 50

    out = []
    seen = set()
    offset = 0
    while len(out) < limit:
        want = min(100, limit - len(out))
        url = API_USER_PLAYLIST.format(uid=uid, offset=offset, limit=want)
        try:
            data = sess.get_json(url, referer=REFERER, timeout=timeout)
        except Exception as exc:
            log("[netmusic] 取用户 %s 的歌单失败：%s" % (uid, type(exc).__name__))
            break
        if not isinstance(data, dict):
            break
        code = data.get("code")
        if code not in (200, None):
            log("[netmusic] 用户 %s 歌单接口 code=%s" % (uid, code))
            break
        pls = data.get("playlist") or []
        if not isinstance(pls, list) or not pls:
            break
        before = len(out)
        for p in pls:
            if not isinstance(p, dict):
                continue
            item = _norm_playlist(p)
            if not item["pid"] or item["pid"] in seen:
                continue
            seen.add(item["pid"])
            out.append(item)
            if len(out) >= limit:
                break
        # 这一页没添新东西（全是重复）就停，免得死循环
        if len(out) == before:
            break
        if len(pls) < want:
            break
        offset += len(pls)

    log("[netmusic] 用户 %s：拿到 %d 个歌单" % (uid, len(out)))
    return out[:limit]


def playlist_tracks(sess, pid, limit=100, timeout=15, log=print) -> list[dict]:
    """歌单里的歌，字段跟 pick() 返回的一致，chart 填歌单名。

    注意：这里**不按 fee 过滤**，VIP / 无版权的也照原样返回，
    能不能下由 crawl_playlist 用 _usable() 自己筛（前端可能想展示全列表）。
    """
    pid = _s(pid)
    if not pid:
        return []
    try:
        limit = max(0, int(limit))
    except (TypeError, ValueError):
        limit = 100
    if limit == 0:
        return []

    name, raw = _playlist_tracks_raw(sess, pid, timeout, log)
    out = []
    for t in raw:
        try:
            out.append(_norm(t, name))
        except Exception:
            continue
        if len(out) >= limit:
            break
    log("[netmusic] 歌单 %s《%s》：%d 首" % (pid, name or "?", len(out)))
    return out


def crawl_playlist(sess, pid, out_dir, limit=50, on_progress=None,
                   timeout=15, log=print) -> dict:
    """整个歌单边下边报进度，给前端做进度条。

    on_progress 每处理完一首调一次，参数：
        {"total","done","ok","failed","skipped","current","file"}
      total 是**按可下过滤后**、且不超过 limit 的曲数（进度条要能用 done/total 收尾）；
      current 是 "歌手 - 歌名" 而不是文件路径。
    已经下过的（download 判 skipped）算 skipped，不重复下。
    磁盘写满（ENOSPC）或剩余空间低于 MIN_FREE_BYTES 就停手，
    返回已经下好的部分，error 里写清楚原因 —— 绝不抛异常。
    """
    res = {"total": 0, "ok": 0, "failed": 0, "skipped": 0,
           "files": [], "error": ""}
    pid = _s(pid)
    if not pid:
        res["error"] = "没有歌单 id"
        return res
    try:
        limit = max(0, int(limit))
    except (TypeError, ValueError):
        limit = 50
    if limit == 0:
        return res

    out_dir = _s(out_dir)
    if not out_dir:
        res["error"] = "没有输出目录"
        return res
    try:
        os.makedirs(out_dir, exist_ok=True)
    except OSError as exc:
        res["error"] = "建目录失败：%s" % (exc,)
        return res

    name, raw = _playlist_tracks_raw(sess, pid, timeout, log)
    # 只留能下的，进度条的总数才对得上
    usable = []
    for t in raw:
        if _usable(t):
            usable.append(t)
    playable = len(usable)
    cut = playable > limit
    usable = usable[:limit]
    res["total"] = len(usable)
    log("[netmusic] 歌单《%s》：%d 首里可下 %d 首%s"
        % (name or "?", len(raw), playable,
           ("，本轮只跑前 %d 首" % limit) if cut else ""))
    if not usable:
        res["error"] = "这个歌单里没有能下的歌"
        return res

    enospc = False
    for idx, t in enumerate(usable, 1):
        item = _norm(t, name)
        title = item["name"] or item["id"]
        current = ("%s - %s" % (item["artist"], title)) if item["artist"] else title

        # 下一首之前先看眼空间，别等下到一半把盘写死
        free = _free_bytes(out_dir)
        if free is not None and free < MIN_FREE_BYTES:
            res["error"] = ("磁盘空间不足（剩 %.1f MB），停在 %d/%d 首"
                            % (free / 1024.0 / 1024.0,
                               res["ok"] + res["failed"] + res["skipped"],
                               res["total"]))
            log("[netmusic] " + res["error"])
            enospc = True
            break

        r = download(sess, item, out_dir, log=log)
        file_path = _s(r.get("file"))
        if r.get("skipped"):
            res["skipped"] += 1
        elif r.get("ok"):
            res["ok"] += 1
            # 只有真下了新文件才放进 files，跳过的老文件不算
            if file_path:
                res["files"].append(file_path)
        else:
            res["failed"] += 1

        done = res["ok"] + res["failed"] + res["skipped"]
        if on_progress:
            try:
                on_progress({
                    "total": res["total"],
                    "done": done,
                    "ok": res["ok"],
                    "failed": res["failed"],
                    "skipped": res["skipped"],
                    "current": current,
                    # 刚下好的文件名；跳过/失败都留空
                    "file": file_path if (r.get("ok") and not r.get("skipped")) else "",
                })
            except Exception as exc:      # 前端回调崩了不能带走整轮下载
                log("[netmusic] on_progress 回调出错：%s" % (type(exc).__name__,))

        # 下载失败后再看眼空间：ENOSPC 时 download 只回了句 OSError，
        # 靠剩余空间骤降判断是不是写满了
        if not r.get("ok"):
            free_now = _free_bytes(out_dir)
            if free_now is not None and free_now < MIN_FREE_BYTES:
                res["error"] = ("磁盘写满（剩 %.1f MB），停在 %d/%d 首"
                                % (free_now / 1024.0 / 1024.0, done, res["total"]))
                log("[netmusic] " + res["error"])
                enospc = True
                break

    if not enospc and res["failed"] and not res["error"]:
        res["error"] = "有 %d 首没下下来（VIP/无版权/网络）" % res["failed"]
    log("[netmusic] 歌单《%s》跑完：成功 %d，跳过 %d，失败 %d"
        % (name or "?", res["ok"], res["skipped"], res["failed"]))
    return res


def playlist_index(sess, uid, timeout=15, log=print) -> dict:
    """一次给前端拿全：{"user": {...}, "playlists": [...]}，省一次往返。

    user 用 `api/v1/user/detail/<uid>`（实测 code=200，数据在 `profile`）；
    这个接口要是挂了，就拿歌单里自带的 creator 昵称凑一个，反正前端主要要名字。
    """
    uid = _s(uid)
    user = {"uid": uid, "name": "", "avatar": "", "signature": "",
            "playlist_count": 0}
    if uid:
        try:
            data = sess.get_json(API_USER_DETAIL.format(uid=uid),
                                referer=REFERER, timeout=timeout)
            prof = (data or {}).get("profile") if isinstance(data, dict) else None
            if isinstance(prof, dict) and prof:
                # 这个接口的字段名跟搜索结果不完全一样，复用同一个归一化
                item = _norm_user({
                    "userId": prof.get("userId") or uid,
                    "nickname": prof.get("nickname"),
                    "avatarUrl": prof.get("avatarUrl"),
                    "signature": prof.get("signature"),
                    "playlistCount": prof.get("playlistCount"),
                })
                item["uid"] = uid
                user = item
        except Exception as exc:
            log("[netmusic] 取用户资料失败：%s" % (type(exc).__name__,))

    playlists = []
    try:
        playlists = user_playlists(sess, uid, timeout=timeout, log=log)
    except Exception as exc:          # user_playlists 自己不抛，双保险
        log("[netmusic] 取歌单失败：%s" % (type(exc).__name__,))

    if not user["name"] and playlists:
        # 兜个名字，总比空着强
        user["name"] = _s(playlists[0].get("creator"))
    if not user["playlist_count"]:
        user["playlist_count"] = len(playlists)
    return {"user": user, "playlists": playlists}


if __name__ == "__main__":
    # 自测：造一个最朴素的 sess，模拟主控注入的那个对象。
    # 必须显式禁用系统代理 —— 这台机器的系统代理/TLS 是坏的。
    import sys
    import time

    _opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def _req(url, referer=""):
        r = urllib.request.Request(url)
        r.add_header("User-Agent", UA)
        if referer:
            r.add_header("Referer", referer)
        return r

    class FakeSess:
        def get_bytes(self, url, referer="", timeout=15):
            with _opener.open(_req(url, referer), timeout=timeout) as r:
                return r.read()

        def get_json(self, url, referer="", timeout=15):
            return json.loads(self.get_bytes(url, referer, timeout)
                              .decode("utf-8", "replace"))

        def save_stream(self, url, dest_path, referer="", timeout=30,
                        max_bytes=300 * 1024 * 1024):
            got = 0
            os.makedirs(os.path.dirname(dest_path) or ".", exist_ok=True)
            with _opener.open(_req(url, referer), timeout=timeout) as r:
                with open(dest_path, "wb") as f:
                    while True:
                        chunk = r.read(65536)
                        if not chunk:
                            break
                        if got + len(chunk) > max_bytes:
                            chunk = chunk[:max_bytes - got]
                        f.write(chunk)
                        got += len(chunk)
                        if got >= max_bytes:
                            break
            return got

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    sess = FakeSess()
    print("=== pick ===")
    t0 = time.time()
    songs = pick(sess, charts=tuple(CHARTS), count=5)
    print("挑到 %d 首，用时 %.1fs" % (len(songs), time.time() - t0))
    for s in songs:
        print("  [%s] %s - %s (%ds) id=%s" %
              (s["chart"], s["artist"], s["name"], s["duration_s"], s["id"]))
        print("     mp3: %s" % s["mp3_url"])
        print("     cover: %s" % s["cover_url"])

    print("=== download ===")
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "music")
    os.makedirs(out, exist_ok=True)
    print("目标目录：", out)
    done = 0
    for s in songs:
        if done >= 1:
            break
        r = download(sess, s, out)
        print("  %s - %s -> ok=%s skipped=%s bytes=%d err=%s file=%s" %
              (s["artist"], s["name"], r["ok"], r["skipped"], r["bytes"],
               r["error"] or "-", r["file"] or "-"))
        if r["ok"]:
            done += 1
    print("下载成功 %d 首" % done)

    # ---------------- 新功能自测：搜人 → 歌单 → 整个歌单边下边报进度 ----------------
    print("=== search_user ===")
    t0 = time.time()
    users = search_user(sess, "陈奕迅", limit=10)
    print("搜「陈奕迅」返回 %d 条，用时 %.1fs" % (len(users), time.time() - t0))
    for u in users[:3]:
        print("  uid=%s name=%s 歌单=%d 签名=%s" %
              (u["uid"], u["name"], u["playlist_count"], u["signature"][:24]))
    if not users:
        print("搜不到用户，后面的自测跳过（接口挂了就是挂了，不编数据）")
        raise SystemExit(0)

    target = None
    for u in users:
        if u["playlist_count"] > 0:
            target = u
            break
    target = target or users[0]
    print("选中的用户：%s (%s)" % (target["name"], target["uid"]))

    print("=== playlist_index（一次拿全）===")
    idx = playlist_index(sess, target["uid"])
    print("user: %s uid=%s 头像=%s" %
          (idx["user"]["name"], idx["user"]["uid"], idx["user"]["avatar"][:50]))
    print("playlists: %d 个" % len(idx["playlists"]))

    print("=== user_playlists（前 3 个）===")
    pls = idx["playlists"]
    for p in pls[:3]:
        print("  pid=%s 《%s》 %d 首 播放=%d 作者=%s" %
              (p["pid"], p["name"], p["track_count"], p["play_count"], p["creator"]))

    # 挑一个有歌、且曲数不太离谱的歌单，先看歌再只下 2 首
    cand = None
    for p in pls:
        if p["track_count"] > 0:
            cand = p
            break
    if not cand:
        print("这个用户没有公开歌单，后面的自测跳过")
        raise SystemExit(0)
    print("=== playlist_tracks ===")
    print("歌单：%s (%s)" % (cand["name"], cand["pid"]))
    tracks = playlist_tracks(sess, cand["pid"], limit=100)
    print("拿到 %d 首" % len(tracks))
    for t in tracks[:3]:
        print("  [%s] %s - %s (%ds) id=%s" %
              (t["chart"], t["artist"], t["name"], t["duration_s"], t["id"]))

    print("=== crawl_playlist（只下 2 首，进度回调逐首打印）===")
    selftest_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "data", "music", "_selftest")
    got_files = []

    def _on_progress(p):
        print("  [%d/%d] ok=%d failed=%d skipped=%d | %s | %s" %
              (p["done"], p["total"], p["ok"], p["failed"], p["skipped"],
               p["current"], os.path.basename(p["file"]) if p["file"] else "-"))
        if p["file"]:
            got_files.append(p["file"])

    t0 = time.time()
    cr = crawl_playlist(sess, cand["pid"], selftest_dir, limit=2,
                        on_progress=_on_progress)
    print("结果：total=%d ok=%d failed=%d skipped=%d 用时 %.1fs error=%s" %
          (cr["total"], cr["ok"], cr["failed"], cr["skipped"],
           time.time() - t0, cr["error"] or "-"))
    print("落地文件：%s" % (cr["files"] or []))

    # D 盘只有 1GB，自测下的这 2 首用完就删
    for f in set(cr["files"]) | set(got_files):
        try:
            os.remove(f)
            print("已删除自测文件：%s" % os.path.basename(f))
        except OSError as exc:
            print("删除失败 %s（%s）" % (f, exc))
    try:
        if not os.listdir(selftest_dir):
            os.rmdir(selftest_dir)
    except OSError:
        pass

# ── 按歌名搜歌（离线点歌用） ─────────────────────────────────────────
#
# 这是「离线时先记个名字，联网了再下」那套的地基。
# 榜单/歌单那两条路都是"批量"，这条是"就搜这一个词"。
#
# 实测：/api/search/get/web?type=1 能搜单曲，返回里自带 fee，
# fee=0/8 能下，fee=1 是 VIP（下不了，跟 download() 里的判断一致）。

SEARCH_SONG_URL = ("https://music.163.com/api/search/get/web"
                   "?type=1&s=%s&limit=%d&offset=0")


def _norm_song(raw: dict, keyword: str) -> dict:
    """把搜索结果的字段掰成和 pick() 一样的形状。"""
    artists = raw.get("artists") or raw.get("ar") or []
    if isinstance(artists, list):
        artist = " / ".join((a.get("name") or "") for a in artists if a.get("name"))
    else:
        artist = str(artists or "")
    album = raw.get("album") or raw.get("al") or {}
    dur = raw.get("duration") or raw.get("dt") or 0
    sid = raw.get("id")
    pic = album.get("picUrl") or ""
    return {
        "id": str(sid or ""),
        "name": raw.get("name") or "",
        "artist": artist,
        "album": album.get("name") or "",
        "duration_s": int(dur) // 1000 if dur and dur > 1000 else int(dur or 0),
        "cover_url": pic,
        "mp3_url": ("https://music.163.com/song/media/outer/url?id=%s.mp3" % sid
                    if sid else ""),
        "chart": keyword,
        "fee": raw.get("fee"),
    }


def search_song(sess, keyword, limit=10, timeout=15, log=print) -> list[dict]:
    """按关键词搜单曲。歌名、歌手名都能搜。

    搜不到返回 []，不抛异常 —— 离线点歌跑在后台，不能因为一个词搜不到就炸。
    """
    keyword = (keyword or "").strip()
    if not keyword:
        return []
    import urllib.parse as _up
    url = SEARCH_SONG_URL % (_up.quote(keyword), max(1, min(50, limit)))
    try:
        data = sess.get_json(url, referer="https://music.163.com/", timeout=timeout)
    except Exception as e:  # noqa: BLE001
        try:
            log("[netmusic] 搜歌「%s」失败：%s: %s" % (keyword, type(e).__name__, e))
        except Exception:  # noqa: BLE001
            pass
        return []
    if not isinstance(data, dict):
        return []
    result = data.get("result") or {}
    songs = result.get("songs") or result.get("tracks") or []
    if not songs:
        # 主接口被限流（常见 code=405）时换 cloudsearch 再试一次
        alt = search_fallback(sess, keyword, 1, limit, timeout=timeout, log=log)
        songs = alt.get("songs") or alt.get("tracks") or []
    out = []
    for raw in songs:
        if not isinstance(raw, dict):
            continue
        it = _norm_song(raw, keyword)
        if it["id"]:
            out.append(it)
    try:
        log("[netmusic] 搜歌「%s」：%d 条" % (keyword, len(out)))
    except Exception:  # noqa: BLE001
        pass
    return out

# ── 按名字搜歌单（type=1000） ──────────────────────────────────────
#
# 上一个只有"搜用户 → 看他的歌单"，但不知道作者名字的时候就没辙了。
# 这条是直接搜歌单名，能搜到全站任何人公开的歌单。
# 实测：/api/search/get/web?type=1000 返回 result.playlists，
# 字段是 id / name / trackCount / coverImgUrl / creator{userId,nickname} / playCount。

SEARCH_PLAYLIST_URL = ("https://music.163.com/api/search/get/web"
                       "?type=1000&s=%s&limit=%d&offset=0")


def _norm_playlist(raw: dict) -> dict:
    creator = raw.get("creator") or {}
    if not isinstance(creator, dict):
        creator = {}
    cover = raw.get("coverImgUrl") or raw.get("coverUrl") or ""
    if cover.startswith("http://"):
        cover = "https://" + cover[7:]
    return {
        "pid": str(raw.get("id") or ""),
        "name": raw.get("name") or "",
        "track_count": int(raw.get("trackCount") or 0),
        "cover_url": cover,
        "creator": creator.get("nickname") or "",
        "uid": str(creator.get("userId") or ""),
        "play_count": int(raw.get("playCount") or 0),
    }


def search_playlist(sess, keyword, limit=20, timeout=15, log=print) -> list[dict]:
    """按歌单名搜（全站公开歌单）。搜不到返回 []，不抛异常。"""
    keyword = (keyword or "").strip()
    if not keyword:
        return []
    import urllib.parse as _up
    url = SEARCH_PLAYLIST_URL % (_up.quote(keyword), max(1, min(50, limit)))
    try:
        data = sess.get_json(url, referer="https://music.163.com/", timeout=timeout)
    except Exception as e:  # noqa: BLE001
        try:
            log("[netmusic] 搜歌单「%s」失败：%s: %s" % (keyword, type(e).__name__, e))
        except Exception:  # noqa: BLE001
            pass
        return []
    if not isinstance(data, dict):
        return []
    result = data.get("result") or {}
    raws = result.get("playlists") or []
    if not raws:
        alt = search_fallback(sess, keyword, 1000, limit, timeout=timeout, log=log)
        raws = alt.get("playlists") or []
    out = []
    for raw in raws:
        if not isinstance(raw, dict):
            continue
        it = _norm_playlist(raw)
        if it["pid"]:
            out.append(it)
    try:
        log("[netmusic] 搜歌单「%s」：%d 个" % (keyword, len(out)))
    except Exception:  # noqa: BLE001
        pass
    return out

# ── 歌词（给全屏歌词页用） ─────────────────────────────────────────
#
# 网易云下回来的 mp3 里基本没有内嵌歌词，但它的接口能直接给 LRC。
# 所以下载完顺手存一份同名 .lrc，播放器扫目录时就近读，
# 断网也一样有歌词滚。

LYRIC_URL = "https://music.163.com/api/song/lyric?id=%s&lv=1&kv=1&tv=-1"


def get_lyric(sess, song_id, timeout=15, log=print) -> str:
    """拿一首歌的 LRC 文本。拿不到返回空串（没歌词很正常，别当错误）。"""
    sid = str(song_id or "").strip()
    if not sid:
        return ""
    try:
        data = sess.get_json(LYRIC_URL % sid,
                             referer="https://music.163.com/", timeout=timeout)
    except Exception:  # noqa: BLE001
        return ""
    if not isinstance(data, dict):
        return ""
    lrc = (data.get("lrc") or {}).get("lyric") or ""
    if not lrc:
        # 有的歌只给翻译版（tlyric），拿那个也比没有强
        lrc = (data.get("tlyric") or {}).get("lyric") or ""
    return lrc if isinstance(lrc, str) else ""

# ── 封面 ──────────────────────────────────────────────────────────
#
# 网易云下回来的 mp3 里没有内嵌封面（APIC），所以之前点歌台一片空白。
# 这里的做法是：下歌时顺手把接口给的封面图下下来，存成同名的 .jpg/.png
# （挨着 mp3 放），music.py 扫描时优先用同目录这张侧边封面。
#
# 格式靠文件头判断，不靠 Content-Type（那玩意儿经常是 application/octet-stream）。

def _sniff_image(head: bytes) -> str:
    if head.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return ".webp"
    if head[:3] == b"GIF":
        return ".gif"
    return ""


def save_cover(sess, url, base_path, log=print) -> str:
    """把封面存成 <base_path>.<ext>，返回写好的路径（失败返回空串）。

    已有的就不再下（同一首歌重复下没意义）。
    """
    url = (url or "").strip()
    if not url:
        return ""
    if url.startswith("http://"):
        url = "https://" + url[7:]
    for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
        if os.path.exists(base_path + ext):
            return base_path + ext
    tmp = base_path + ".cvtmp"
    try:
        sess.save_stream(url, tmp, referer=REFERER, timeout=20,
                         max_bytes=8 * 1024 * 1024)
        with open(tmp, "rb") as f:
            head = f.read(16)
        ext = _sniff_image(head) or ".jpg"
        final = base_path + ext
        os.replace(tmp, final)
        return final
    except Exception:  # noqa: BLE001
        try:
            os.remove(tmp)
        except OSError:
            pass
        return ""

# 搜索接口现在给的 album 里只有 picId，没有 picUrl，
# 所以封面得走 /api/song/detail 拿真正的 al.picUrl。
SONG_DETAIL_URL = "https://music.163.com/api/song/detail?ids=[%s]"


def song_detail(sess, sid, timeout=15) -> dict:
    """查单首歌的详情，主要为了拿封面地址。拿不到返回 {}。"""
    sid = str(sid or "").strip()
    if not sid:
        return {}
    try:
        data = sess.get_json(SONG_DETAIL_URL % sid,
                             referer=REFERER, timeout=timeout)
    except Exception:  # noqa: BLE001
        return {}
    songs = (data or {}).get("songs") or []
    if not songs or not isinstance(songs[0], dict):
        return {}
    raw = songs[0]
    al = raw.get("al") or raw.get("album") or {}
    ar = raw.get("ar") or raw.get("artists") or []
    if isinstance(ar, list):
        artist = " / ".join(a.get("name") or "" for a in ar if a.get("name"))
    else:
        artist = ""
    dt = raw.get("dt") or raw.get("duration") or 0
    try:
        dt = int(dt)
    except (TypeError, ValueError):
        dt = 0
    return {
        "cover_url": al.get("picUrl") or raw.get("picUrl") or "",
        "album": al.get("name") or "",
        "artist": artist,
        "name": raw.get("name") or "",
        # 毫秒 → 秒，播放器要的是秒
        "duration_s": (dt // 1000) if dt > 1000 else dt,
    }


def cover_url_of(sess, item, timeout=15) -> str:
    """先看 item 自己带的封面地址，没有再查详情。"""
    url = (item or {}).get("cover_url") or ""
    if url:
        return url
    d = song_detail(sess, (item or {}).get("id"), timeout=timeout)
    return d.get("cover_url") or ""

# ── 搜索兜底 ──────────────────────────────────────────────────────
#
# 实测：连着搜几十次之后，`api/search/get/web` 会开始回 code=405（拦一阵子），
# 但 `api/cloudsearch/pc` 这时候还能用，返回的字段基本一致
# （songs / playlists / userprofiles，歌单和用户那两种 key 名字一样）。
# 所以两个接口轮着来：主接口挂了就走兜底，别让整个搜索功能哑火。

CLOUDSEARCH_URL = ("https://music.163.com/api/cloudsearch/pc"
                   "?s=%s&type=%d&limit=%d&offset=0")


def search_fallback(sess, keyword, typ, limit=10, timeout=15, log=print) -> dict:
    """主搜索接口的兜底。返回 result dict（拿不到就空 dict）。"""
    from urllib.parse import quote as _q
    url = CLOUDSEARCH_URL % (_q(keyword), int(typ), int(limit))
    try:
        data = sess.get_json(url, referer=REFERER, timeout=timeout)
    except Exception:  # noqa: BLE001
        return {}
    if not isinstance(data, dict) or data.get("code") not in (200, None):
        return {}
    res = data.get("result") or {}
    return res if isinstance(res, dict) else {}

def get_lyric_full(sess, song_id, timeout=15) -> dict:
    """一次拿全三份歌词：{"lrc","tlrc","klyric"}。

    网易云那个接口 lv=1（整行）/ kv=1（逐字）/ tv=-1（翻译）会一起返回：
      lrc.lyric   整行时间轴
      tlyric.lyric 翻译（很多中文歌没有）
      klyric.lyric 逐字时间轴，YRC 格式 [起,时长](起,时长,0)字
    逐字那份最值钱 —— 播放器的逐字高亮就靠它，没有就退回整行。
    """
    sid = str(song_id or "").strip()
    out = {"lrc": "", "tlrc": "", "klyric": ""}
    if not sid:
        return out
    try:
        data = sess.get_json(LYRIC_URL % sid,
                             referer=REFERER, timeout=timeout)
    except Exception:  # noqa: BLE001
        return out
    if not isinstance(data, dict):
        return out
    for key, field in (("lrc", "lrc"), ("tlyric", "tlrc"), ("klyric", "klyric")):
        part = data.get(key) or {}
        text = part.get("lyric") if isinstance(part, dict) else ""
        if isinstance(text, str) and text.strip():
            out[field] = text
    return out
