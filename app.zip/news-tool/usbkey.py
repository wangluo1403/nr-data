# -*- coding: utf-8 -*-
"""U 盘钥匙：插上指定 U 盘就是最高权限。

身份文件放在 U 盘根目录，名字是 .whale-key（隐藏 + 系统属性），
内容是一行 JSON：{"id": "...", "name": "...", "created": "YYYY-MM-DD"}。

只认可移动盘（GetDriveTypeW == 2），不会去翻 C: / D:。
测试或特殊场合可以用环境变量 WHALE_USB_ROOT=E:\\ 指定只查哪个盘，
或者在本目录 data/usb_override.txt 里写一个盘符（比如 E:\\）。

纯标准库 + ctypes，不调用 wmic / PowerShell 子进程。
"""

import ctypes
import json
import os
import secrets
import string
import time
from datetime import date

KEY_FILENAME = ".whale-key"
OVERRIDE_ENV = "WHALE_USB_ROOT"
OVERRIDE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "data", "usb_override.txt")

# GetDriveTypeW 返回值
DRIVE_UNKNOWN = 0
DRIVE_NO_ROOT_DIR = 1
DRIVE_REMOVABLE = 2
DRIVE_FIXED = 3
DRIVE_REMOTE = 4
DRIVE_CDROM = 5
DRIVE_RAMDISK = 6

# SetFileAttributesW 用的属性
FILE_ATTRIBUTE_HIDDEN = 0x2
FILE_ATTRIBUTE_SYSTEM = 0x4

if os.name == "nt":
    _K32 = ctypes.WinDLL("kernel32", use_last_error=True)
else:  # 非 Windows 只做降级演示，不保证完整
    _K32 = None


def _setup_prototypes():
    """一次性把 ctypes 的原型和参数类型定好，64 位下不会截断指针。"""
    if _K32 is None:
        return
    from ctypes import wintypes

    _K32.GetLogicalDrives.argtypes = []
    _K32.GetLogicalDrives.restype = wintypes.DWORD

    _K32.GetDriveTypeW.argtypes = [wintypes.LPCWSTR]
    _K32.GetDriveTypeW.restype = wintypes.UINT

    _K32.GetVolumeInformationW.argtypes = [
        wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD),
        ctypes.POINTER(wintypes.DWORD), wintypes.LPWSTR, wintypes.DWORD,
    ]
    _K32.GetVolumeInformationW.restype = wintypes.BOOL

    _K32.SetFileAttributesW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD]
    _K32.SetFileAttributesW.restype = wintypes.BOOL


if _K32 is not None:
    try:
        _setup_prototypes()
    except Exception:  # noqa: BLE001  个别精简系统上拿不到就降级
        _K32 = None


def _root(letter: str) -> str:
    return letter.upper() + ":\\"


def _volume_info(root: str):
    """取卷标和卷序列号，失败返回 ('', 0)。"""
    if _K32 is None:
        return "", 0
    try:
        from ctypes import wintypes

        name_buf = ctypes.create_unicode_buffer(261)
        fs_buf = ctypes.create_unicode_buffer(261)
        serial = wintypes.DWORD(0)
        max_len = wintypes.DWORD(0)
        flags = wintypes.DWORD(0)
        ok = _K32.GetVolumeInformationW(
            root, name_buf, 261, ctypes.byref(serial),
            ctypes.byref(max_len), ctypes.byref(flags), fs_buf, 261
        )
        if not ok:
            return "", 0
        return name_buf.value or "", int(serial.value)
    except Exception:  # noqa: BLE001
        return "", 0


def list_drives() -> list:
    """所有盘符：[{"root","label","type","serial"}]。

    type 只有“可移动”和“固定”两种；光驱、网络盘、内存盘直接跳过。
    """
    out = []
    if _K32 is None:
        # 非 Windows 的降级：只把存在的盘当固定盘列出来
        for letter in string.ascii_uppercase:
            root = _root(letter)
            if os.path.exists(root):
                out.append({"root": root, "label": "", "type": "固定", "serial": 0})
        return out

    try:
        mask = int(_K32.GetLogicalDrives())
    except Exception:  # noqa: BLE001
        return out

    for idx, letter in enumerate(string.ascii_uppercase):
        if not (mask >> idx) & 1:
            continue
        root = _root(letter)
        try:
            dtype = int(_K32.GetDriveTypeW(root))
        except Exception:  # noqa: BLE001
            continue
        if dtype == DRIVE_REMOVABLE:
            typ = "可移动"
        elif dtype == DRIVE_FIXED:
            typ = "固定"
        else:
            continue
        label, serial = _volume_info(root)
        out.append({"root": root, "label": label, "type": typ, "serial": serial})
    return out


def _normalize_root(text: str) -> str:
    """'E' / 'E:' / 'E:\\' → 'E:\\'；看不懂返回空串。"""
    s = str(text or "").strip().strip('"').strip("'").strip()
    if not s:
        return ""
    s = s.replace("/", "\\")
    if len(s) == 1 and s.upper() in string.ascii_uppercase:
        return _root(s)
    if len(s) == 2 and s[1] == ":" and s[0].upper() in string.ascii_uppercase:
        return _root(s[0])
    if len(s) >= 3 and s[1] == ":" and s[2] == "\\" and s[0].upper() in string.ascii_uppercase:
        return s[0].upper() + s[1:]
    return ""


def _override_root() -> str:
    """测试用的指定盘：环境变量优先，其次 data/usb_override.txt 的第一行。"""
    try:
        r = _normalize_root(os.environ.get(OVERRIDE_ENV, ""))
        if r:
            return r
    except Exception:  # noqa: BLE001
        pass
    try:
        with open(OVERRIDE_FILE, "r", encoding="utf-8-sig") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return _normalize_root(line)
    except OSError:
        pass
    return ""


def _read_key(root: str):
    """读某个盘根目录的钥匙文件，没有/读不了返回 None。"""
    path = os.path.join(root, KEY_FILENAME)
    try:
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8-sig") as f:
            info = json.load(f)
    except (OSError, ValueError):
        # 权限不足、文件坏了：跳过这个盘，别把整个扫描拖垮
        return None
    if not isinstance(info, dict) or not info.get("id"):
        return None
    return {
        "root": root,
        "id": str(info.get("id")),
        "name": str(info.get("name") or ""),
        "created": str(info.get("created") or ""),
    }


def find_key():
    """扫描所有可移动盘根目录，找 .whale-key。找到返回字典，没有返回 None。

    如果指定了 WHALE_USB_ROOT / data/usb_override.txt，就只查那一个盘。
    """
    override = _override_root()
    if override:
        return _read_key(override)

    for d in list_drives():
        if d["type"] != "可移动":
            continue
        key = _read_key(d["root"])
        if key:
            return key
    return None


def _hide(path: str) -> bool:
    """给文件加上隐藏 + 系统属性。"""
    if _K32 is None:
        return False
    try:
        ok = _K32.SetFileAttributesW(
            path, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM
        )
        return bool(ok)
    except Exception:  # noqa: BLE001
        return False


def make_key(root: str, key_id: str = "", name: str = "") -> dict:
    """在指定盘根目录写身份文件，并尝试设成隐藏 + 系统属性。

    root 传根目录（'E:\\'）。key_id 留空就随机生成一个 WHALE-XXXXXX。
    注意：只会写/覆盖根目录的 .whale-key，不动盘上其它任何文件。
    """
    root = _normalize_root(root) or root
    if not root.endswith("\\"):
        root += "\\"

    key_id = str(key_id or "").strip()
    if not key_id:
        key_id = "WHALE-" + secrets.token_hex(6).upper()
    name = str(name or "").strip() or "鲸鲸的 U 盘钥匙"
    created = date.today().isoformat()
    info = {"id": key_id, "name": name, "created": created}

    path = os.path.join(root, KEY_FILENAME)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(info, f, ensure_ascii=False)
        f.write("\n")
    hidden = _hide(path)
    return {
        "root": root,
        "id": key_id,
        "name": name,
        "created": created,
        "path": path,
        "hidden": hidden,
    }


def _nap(stop_evt, seconds: float) -> None:
    """等一会儿，有 stop_evt.wait 就优先用（停止更及时）。"""
    wait = getattr(stop_evt, "wait", None)
    if callable(wait):
        wait(seconds)
        return
    end = time.time() + seconds
    while time.time() < end and not stop_evt.is_set():
        time.sleep(0.2)


def watch(stop_evt, interval_s: float = 3.0, on_plug=None, on_unplug=None,
          log=print) -> None:
    """后台轮询 U 盘钥匙，插/拔各回调一次，直到 stop_evt.is_set()。

    interval_s 最低 2 秒 —— U 盘根目录读太勤会把盘卡住。
    on_plug(key) 插上；on_unplug(old_key) 拔掉（传的是拔掉时那把钥匙的信息）。
    """
    try:
        interval = max(2.0, float(interval_s))
    except (TypeError, ValueError):
        interval = 2.0

    last_key = None
    while not stop_evt.is_set():
        try:
            key = find_key()
        except Exception as e:  # noqa: BLE001
            # 扫描本身出错只记一笔，不当成“拔掉了”
            try:
                log("U 盘扫描出错：%s" % e)
            except Exception:  # noqa: BLE001
                pass
            _nap(stop_evt, interval)
            continue

        ident = (key["root"], key["id"]) if key else None
        old_ident = (last_key["root"], last_key["id"]) if last_key else None

        if ident != old_ident:
            if key and not last_key:
                _safe_call(on_plug, key, log)
                _safe_log(log, "插上 U 盘钥匙：%s（%s）" % (key["id"], key["root"]))
            elif not key and last_key:
                _safe_call(on_unplug, last_key, log)
                _safe_log(log, "拔掉 U 盘钥匙：%s" % last_key["id"])
            elif key and last_key:
                # 换了一把（或同一个 id 换了盘符）
                _safe_call(on_unplug, last_key, log)
                _safe_call(on_plug, key, log)
                _safe_log(log, "换成 U 盘钥匙：%s（%s）" % (key["id"], key["root"]))
            last_key = key

        _nap(stop_evt, interval)


def _safe_call(cb, arg, log) -> None:
    if cb is None:
        return
    try:
        cb(arg)
    except Exception as e:  # noqa: BLE001
        _safe_log(log, "U 盘回调出错：%s" % e)


def _safe_log(log, msg: str) -> None:
    try:
        log(msg)
    except Exception:  # noqa: BLE001
        pass


# ── 自测 ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("[1] 盘符")
    drives = list_drives()
    for d in drives:
        print("  %-4s %-8s %-6s 序列号=%08X" % (
            d["root"], d["label"] or "(无卷标)", d["type"], d["serial"]))
    if not drives:
        print("  （一个盘都没找到）")

    print("\n[2] U 盘钥匙")
    override = _override_root()
    print("  指定盘（override）:", override or "无")
    key = find_key()
    if key:
        print("  找到钥匙      :", json.dumps(key, ensure_ascii=False))
    else:
        print("  没找到钥匙（可移动盘根目录没有 %s）" % KEY_FILENAME)
    print("=" * 60)
