@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "python\python.exe" (
  echo This copy is incomplete: python folder missing.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*

pause
