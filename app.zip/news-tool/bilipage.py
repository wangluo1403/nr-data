# -*- coding: utf-8 -*-
"""
bilipage.py — B 站那一页的状态（搜索结果 / 关键词 / 下载记录）

为什么单独一个文件：
  newsd.py 已经三千多行了，B 站这页的数据全是 JSON 小文件、读写逻辑又独立，
  单独放这儿比继续往 newsd 里塞清楚。

三个文件：
  data/bili_search.json   最近一次搜索结果（断网时拿它兜底）
  data/bili_wants.json    关键词清单（离线也能记，联网时自动搜+下）
  data/bili_dl.json       下载记录（排队 / 下载中 / 完成 / 失败）

下载真正的搬运工在 bili.py（搜和下的接口），这里只管状态。
"""

from __future__ import annotations

import json
import os
import threading
import time

MAX_SEARCH_ITEMS = 60


def _now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


class Store:
    """三个 JSON 文件的读写，带一把锁。"""

    def __init__(self, data_dir: str, log=print):
        self.dir = data_dir
        self.log = log
        self.search_path = os.path.join(data_dir, "bili_search.json")
        self.wants_path = os.path.join(data_dir, "bili_wants.json")
        self.dl_path = os.path.join(data_dir, "bili_dl.json")
        self._lock = threading.RLock()

    # ---------- 通用 ----------

    def _read(self, path: str, default):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return default

    def _write(self, path: str, obj) -> None:
        tmp = path + ".tmp"
        try:
            os.makedirs(self.dir, exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
        except OSError as e:
            self.log("B 站状态写不进去：%s" % e)

    # ---------- 搜索结果 ----------

    def search_load(self) -> dict:
        d = self._read(self.search_path, None)
        if not isinstance(d, dict):
            d = {}
        if not isinstance(d.get("items"), list):
            d["items"] = []
        return d

    def search_save(self, query: str, items: list) -> dict:
        with self._lock:
            d = {"query": query, "at": _now_str(), "ts": time.time(),
                 "items": items[:MAX_SEARCH_ITEMS]}
            self._write(self.search_path, d)
            return d

    # ---------- 关键词 ----------

    def wants_load(self) -> list:
        d = self._read(self.wants_path, None)
        items = d.get("items") if isinstance(d, dict) else d
        return items if isinstance(items, list) else []

    def wants_save(self, items: list) -> None:
        with self._lock:
            self._write(self.wants_path, {"saved_at": _now_str(),
                                          "total": len(items),
                                          "items": items})

    def want_add(self, keyword: str, wid: str) -> dict | None:
        keyword = (keyword or "").strip()
        if not keyword:
            return None
        with self._lock:
            items = self.wants_load()
            for x in items:
                if x.get("keyword") == keyword and x.get("state") in (
                        "pending", "running"):
                    return x
            item = {"id": wid, "keyword": keyword, "state": "pending",
                    "note": "", "created_at": _now_str()}
            items.insert(0, item)
            self.wants_save(items)
            return item

    def want_update(self, wid: str, **fields) -> dict | None:
        with self._lock:
            items = self.wants_load()
            for x in items:
                if str(x.get("id")) == str(wid):
                    for k, v in fields.items():
                        if v is not None:
                            x[k] = v
                    self.wants_save(items)
                    return dict(x)
        return None

    def want_remove(self, wid: str) -> bool:
        with self._lock:
            items = self.wants_load()
            keep = [x for x in items if str(x.get("id")) != str(wid)]
            if len(keep) == len(items):
                return False
            self.wants_save(keep)
            return True

    # ---------- 下载记录 ----------

    def dl_load(self) -> list:
        d = self._read(self.dl_path, None)
        items = d.get("items") if isinstance(d, dict) else d
        return items if isinstance(items, list) else []

    def dl_save(self, items: list) -> None:
        with self._lock:
            self._write(self.dl_path, {"saved_at": _now_str(),
                                       "total": len(items), "items": items[:200]})

    def dl_add(self, bvid: str, title: str, extra: dict | None = None) -> dict:
        with self._lock:
            items = self.dl_load()
            for x in items:
                if x.get("bvid") == bvid and x.get("state") in (
                        "pending", "downloading", "done"):
                    # 已经下过的别重复排，但失败的允许重来
                    return x
            item = {"bvid": bvid, "title": title, "state": "pending",
                    "progress": 0, "error": "", "file": "",
                    "created_at": _now_str()}
            if extra:
                item.update({k: v for k, v in extra.items() if k not in item})
            items.insert(0, item)
            self.dl_save(items)
            return item

    def dl_update(self, bvid: str, **fields) -> dict | None:
        with self._lock:
            items = self.dl_load()
            for x in items:
                if x.get("bvid") == bvid:
                    for k, v in fields.items():
                        if v is not None:
                            x[k] = v
                    self.dl_save(items)
                    return dict(x)
        return None

    # ---------- 给前端的一次性汇总 ----------

    def page(self) -> dict:
        s = self.search_load()
        return {
            "query": s.get("query") or "",
            "items": s.get("items") or [],
            "cached_at": s.get("at") or "",
            "wants": self.wants_load(),
            "downloads": self.dl_load(),
        }
