@echo off
chcp 65001 >nul
title Fetch News Now
cd /d "%~dp0"

rem Pure ASCII only - Chinese text breaks cmd's parser.
set "PY="
if exist "python\python.exe" set "PY=python\python.exe"
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo [X] Python not found. See README.md.
  pause
  exit /b 1
)

echo Fetching news once with %PY% ...
"%PY%" newsd.py --fetch
echo.
pause
