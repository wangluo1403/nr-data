"""必应搜索：按关键词搜网页/新闻，结果单独存一份。

摸出来的门道（2026-10 实测）：

  · ``cn.bing.com/search?q=xx&format=rss`` 直接吐干净 RSS，
    title / link / description / pubDate 都齐，一次 10 条，0.3 秒左右。
    比撸 HTML 稳得多，也不用管 ``b_algo`` 那些 class 改版。
  · ``www.bing.com/news/search?q=xx&format=RSS`` 是新闻那一路，12 条。
    但它给的链接是 ``apiclick.aspx?...&url=<百分号编码的真地址>``，
    真地址就明晃晃写在 ``url=`` 参数里，抠出来 unquote 一下就行，不用跟随跳转。
  · ``&first=11`` 那种翻页在 RSS 上不生效，永远给同一批 10 条。
    想要更多结果就多给几个关键词，别指望翻页。
  · 连发 8 次没有限流迹象。

新闻那边的 ``parse_feed`` 会把 apiclick 链接原样收下，这里再洗一遍。
"""

import os
import re
import sys
import urllib.parse

# 直接跑本文件时也能 import 到隔壁的 newsd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _nd():
    """延迟 import newsd —— 它也要 import 本模块，直接 top-level 会循环。"""
    import newsd
    return newsd


WEB_URL = "https://cn.bing.com/search?q=%s&format=rss"
NEWS_URL = "https://www.bing.com/news/search?q=%s&format=RSS"

_APICLICK_RE = re.compile(r"[?&]url=([^&]+)", re.I)


def unwrap(u: str) -> str:
    """把必应新闻的跳转链还原成真地址，其它链接原样返回。"""
    if not u:
        return ""
    if "bing.com/news/apiclick" not in u and "bing.com/ck/a" not in u:
        return u
    m = _APICLICK_RE.search(u)
    if m:
        real = urllib.parse.unquote(m.group(1))
        if real.startswith(("http://", "https://")):
            return real
    return u


def _host(u: str) -> str:
    try:
        h = urllib.parse.urlparse(u).netloc.lower()
        return h[4:] if h.startswith("www.") else h
    except ValueError:
        return ""


def _search_url(tpl: str, q: str) -> str:
    return tpl % urllib.parse.quote(q)


def _one_query(tpl: str, kw: str, kind: str, timeout: int, limit: int) -> list[dict]:
    nd = _nd()
    url = _search_url(tpl, kw)
    raw, ctype = nd.http_get(url, timeout=timeout, retries=1, max_bytes=2 * 1024 * 1024)
    out = []
    for it in nd.parse_feed(raw, url):
        link = unwrap(it.get("url") or "")
        if not link.startswith(("http://", "https://")):
            continue
        if _host(link).endswith("bing.com"):
            continue          # 还没还原干净的，别留着
        out.append({
            "title": (it.get("title") or "").strip(),
            "url": link,
            "host": _host(link),
            "summary": it.get("summary") or "",
            "image_src": it.get("image_src") or "",
            "published_ts": it.get("published_ts") or 0,
            "keyword": kw,
            "kind": kind,
        })
    return out[:limit]


def run(keywords: list, per_keyword: int = 10, news: bool = True,
        timeout: int = 15, log=print) -> list[dict]:
    """把每个关键词都搜一遍，按 URL 去重，返回结果列表。

    单个关键词失败不影响别的 —— 必应偶尔抽风，不值得整轮作废。
    """
    merged: dict[str, dict] = {}
    for kw in keywords:
        kw = (kw or "").strip()
        if not kw:
            continue
        routes = [(WEB_URL, "web")]
        if news:
            routes.append((NEWS_URL, "news"))
        got = 0
        for tpl, kind in routes:
            try:
                hits = _one_query(tpl, kw, kind, timeout, per_keyword)
            except Exception as e:  # noqa: BLE001
                log("  搜索「%s」%s 那路挂了：%s: %s"
                    % (kw, "新闻" if kind == "news" else "网页", type(e).__name__, str(e)[:80]))
                continue
            for h in hits:
                merged.setdefault(h["url"], h)
            got += len(hits)
        log("  搜索「%s」→ %d 条" % (kw, got))

    items = list(merged.values())
    # 有时间的按时间倒序排前面，没时间的按搜到的先后
    items.sort(key=lambda x: (x.get("published_ts") or 0), reverse=True)
    for i, it in enumerate(items):
        it["id"] = "s%04d" % i
    return items
