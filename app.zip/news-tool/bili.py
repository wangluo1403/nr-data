# -*- coding: utf-8 -*-
"""B 站视频：按关键词搜 → 挑一个下成本地 mp4。

跟 videos.py / anime.py 一个路子：纯标准库、零 pip、显式禁代理。

这一层解决的是"首页热门不一定爱看"的问题——用户给个词，比如「原神」「猫」，
就能搜出来、标记能不能下、下下来进本地视频库坐着。

三个动作：

  search()       按关键词搜视频，返回归一化后的条目（含 bvid/aid/cid/时长/播放量）
  probe_topics() search 的加强版，把时长/播放量补齐并标 too_long，给列表打"能下/太长"
  download_one() 拿 cid → 拿 playurl → 下 mp4，返回 {ok,file,size,error,skipped}

2026-10-31 实测（家宽、显式禁代理）：

  ✔ 搜索      /x/web-interface/search/type 带上任意 buvid3 就稳；不带连打几次必 412。
  ✔ 分P列表   /x/player/pagelist          不用签名，给 cid。
  ✔ 详情      /x/web-interface/view       不用签名，search 里 cid 恒为 0 时靠它兜底，
                                          顺便给 duration/stat.view。
  ✔ 播放地址  /x/player/playurl           不用签名，qn=32 一般回落成 16（360P），
                                          durl 里给 mp4 直链 + size。
  ✘ 搜索接口的 cid 字段 一律是 0，别指望它能直接拿去要播放地址。
"""

import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

import anime
import videos

REFERER = "https://www.bilibili.com/"
UA = anime.UA

API_SEARCH = "https://api.bilibili.com/x/web-interface/search/type"
API_PAGELIST = "https://api.bilibili.com/x/player/pagelist"
API_VIEW = "https://api.bilibili.com/x/web-interface/view"
API_PLAYURL = "https://api.bilibili.com/x/player/playurl"

# 这台机器系统代理/TLS 是坏的：显式禁代理，再留一个不校验证书的兜底
_PLAIN = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_LAX = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))

_BV_RE = re.compile(r"^BV[0-9A-Za-z]{8,14}$")
_EM_RE = re.compile(r"</?em[^>]*>", re.I)
_TAG_RE = re.compile(r"<[^>]+>")
# Windows 文件名非法字符 + 控制字符，一次性抹掉（不替换成下划线，标题里带这些
# 的本来就少，硬替换反而更难看）
_BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f\x7f]')

_MIN_BYTES = 100 * 1024          # 小于这个算没下过 / 没下成


# ---------------------------------------------------------------- 小工具

def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _clean_title(s):
    """搜索标题里带 <em class="keyword"> 高亮，先洗掉。"""
    return _TAG_RE.sub("", _EM_RE.sub("", s or "")).strip()


def _vpic(u):
    if not u:
        return ""
    u = u.strip()
    if u.startswith("//"):
        return "https:" + u
    return u.replace("http://", "https://", 1)


def _dur_s(v):
    """搜索结果里的 duration 是 "MM:SS" / "H:MM:SS"，推荐流那边是秒数。"""
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v or "").strip()
    if not s:
        return 0
    if ":" not in s:
        return _int(s)
    parts = [_int(x) for x in s.split(":")]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return 0


def _buvid3():
    """随便造一个格式合规的 buvid3 就够过 412。

    B 站搜索接口不带 Cookie 时会直接 412（风控），而 sess.get_json 没有
    加 header 的口子，所以本模块自己发请求、自己塞这个假 buvid3——
    实测不需要真去首页领，正则形状对了就行。
    """
    r = anime._rand
    h = "%08X-%04X-%04X-%04X-%012X" % (
        r.getrandbits(32), r.getrandbits(16), r.getrandbits(16),
        r.getrandbits(16), r.getrandbits(48))
    return h + "infoc"


def _own_open(url, timeout=15, referer=REFERER, cookie=""):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", UA)
    req.add_header("Referer", referer)
    req.add_header("Accept", "application/json, text/plain, */*")
    if cookie:
        req.add_header("Cookie", cookie)
    try:
        return _PLAIN.open(req, timeout=timeout)
    except urllib.error.HTTPError:
        raise                     # HTTP 状态码要原样给上层看（412 得认出来）
    except Exception:
        return _LAX.open(req, timeout=timeout)


def _own_json(url, timeout=15, tries=4):
    """自己带 buvid3 发 GET。412 就换一个 buvid3 重试，间隔逐次拉长。

    这坑踩得挺深：412 不只是"没带 buvid3"，短时间连打几个词（原神→猫→猫）
    也会被按 IP 挡一会儿，隔十几秒自己就好了。所以间隔给到秒级，
    被挡一次就整路放弃太亏，但也不能立刻重试——越急挡得越死。
    """
    last = None
    for n in range(tries):
        try:
            with _own_open(url, timeout, cookie=_buvid3()) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 412 and n < tries - 1:
                time.sleep(1.5 + n * 1.5)      # 1.5s → 3s → 4.5s
                continue
            raise
        except Exception as e:  # noqa: BLE001
            last = e
            if n < tries - 1:
                time.sleep(0.4)
                continue
            raise
    raise last if last else RuntimeError("请求失败")


def _api(sess, url, timeout=15, log=print, what="接口", own_first=False):
    """先走 sess，不行再自己带 buvid3 兜底；两条都不通返回 {}，不抛异常。"""
    err = ""
    order = ("own", "sess") if own_first else ("sess", "own")
    for which in order:
        try:
            if which == "sess":
                d = sess.get_json(url, referer=REFERER, timeout=timeout)
            else:
                d = _own_json(url, timeout)
            if isinstance(d, dict) and d.get("code") == 0:
                return d
            err = "code=%s %s" % ((d or {}).get("code"), (d or {}).get("message"))
        except Exception as e:  # noqa: BLE001
            err = "%s: %s" % (type(e).__name__, str(e)[:80])
    try:
        log("  bili：%s 两条通道都没通（%s）" % (what, err))
    except Exception:  # noqa: BLE001
        pass
    return {}


# ---------------------------------------------------------------- 条目归一

def _row(v, source="search"):
    """把搜索结果揉成对外约定的字段。字段缺就填 0 / ""，绝不编。"""
    owner = v.get("owner") or {}
    stat = v.get("stat") or {}
    bvid = (v.get("bvid") or "").strip()
    return {
        "bvid": bvid,
        "aid": _int(v.get("aid") if v.get("aid") is not None else v.get("id")),
        # 搜索结果的 cid 恒为 0，真下载时再问 pagelist
        "cid": _int(v.get("cid")),
        "title": _clean_title(v.get("title")),
        "up": (owner.get("name") or v.get("author") or "").strip(),
        "duration_s": _dur_s(v.get("duration")),
        "view": _int(stat.get("view") if stat.get("view") is not None
                     else v.get("play")),
        "pic_url": _vpic(v.get("pic")),
        "desc": ((v.get("desc") if v.get("desc") is not None
                  else v.get("description")) or "").strip()[:300],
        "url": ("https://www.bilibili.com/video/" + bvid) if bvid else "",
        "source": source,
    }


def _norm(rows, count):
    seen, out = set(), []
    for r in rows:
        bv = r.get("bvid") or ""
        if not _BV_RE.match(bv) or bv in seen:
            continue
        seen.add(bv)
        r.pop("source", None)
        out.append(r)
        if len(out) >= count:
            break
    return out


# ---------------------------------------------------------------- 1. 搜索

def _search_own(keyword, count, timeout, log):
    """anime.search 整路挂掉时的自备通道：自己带 buvid3 打一次。"""
    url = ("%s?search_type=video&page=1&pagesize=20&keyword=%s"
           % (API_SEARCH, urllib.parse.quote(keyword)))
    try:
        d = _own_json(url, timeout)
    except Exception as e:  # noqa: BLE001
        try:
            log("  bili：搜「%s」自己打也挂了（%s: %s）"
                % (keyword, type(e).__name__, str(e)[:60]))
        except Exception:  # noqa: BLE001
            pass
        return []
    if not isinstance(d, dict) or d.get("code") != 0:
        return []
    res = ((d.get("data") or {}).get("result") or [])
    rows = []
    for v in res:
        if (v.get("type") or "video") != "video":
            continue
        rows.append(_row(v))
    return _norm(rows, count)


def search(sess, keyword, count=20, timeout=15, log=print) -> list[dict]:
    """按关键词搜 B 站视频，返回约定字段的列表；搜不到返回 []，不抛异常。

    直接复用 anime.search（它已经把 412 / em 高亮 / "MM:SS" 这些坑踩过了）。
    anime 那条路彻底空了再自己带 buvid3 补一枪，两条都空就是真没有。
    """
    kw = str(keyword or "").strip()
    if not kw:
        return []
    count = max(1, _int(count) or 20)

    rows = []
    try:
        rows = anime.search(sess, kw, count=count, timeout=timeout, log=log) or []
    except Exception as e:  # noqa: BLE001
        try:
            log("  bili：anime.search 抛了 %s: %s，改走自备通道"
                % (type(e).__name__, str(e)[:60]))
        except Exception:  # noqa: BLE001
            pass
        rows = []

    out = _norm(rows, count)
    if not out:
        # anime 和 sess 刚被 412 挡过，立刻换通道只会继续被挡，先喘一口
        time.sleep(1.2)
        out = _search_own(kw, count, timeout, log)
        if out:
            try:
                log("  bili：走自备 buvid3 通道补到 %d 条" % len(out))
            except Exception:  # noqa: BLE001
                pass
    return out


# ---------------------------------------------------------------- 2. 探路

def _view(sess, bvid, timeout=15, log=print):
    """详情接口：补 cid / 时长 / 播放量。拿不到返回 {}。"""
    d = _api(sess, "%s?bvid=%s" % (API_VIEW, bvid), timeout, log,
             "视频详情 %s" % bvid)
    return d.get("data") or {}


def probe_topics(sess, keyword, count=4, timeout=15, log=print) -> list[dict]:
    """搜一个词，把前几条的时长/播放量补齐，并标上 too_long（>30 分钟）。

    给前端列表打"能下 / 太长"的标记用，所以宁可多打一次详情接口，
    也不让前端自己去猜 duration_s=0 到底是什么情况。
    """
    rows = search(sess, keyword, count=max(1, _int(count) or 4),
                  timeout=timeout, log=log)
    out = []
    for r in rows:
        it = dict(r)
        # 时长或播放量缺了才去问详情，别每条都打（省得又触发风控）
        if not it.get("duration_s") or not it.get("view") or not it.get("cid"):
            d = _view(sess, it["bvid"], timeout, log)
            if d:
                it["cid"] = it.get("cid") or _int(d.get("cid"))
                it["aid"] = it.get("aid") or _int(d.get("aid"))
                it["duration_s"] = it.get("duration_s") or _int(d.get("duration"))
                stat = d.get("stat") or {}
                it["view"] = it.get("view") or _int(stat.get("view"))
                if not it.get("pic_url"):
                    it["pic_url"] = _vpic(d.get("pic"))
                if not it.get("desc"):
                    it["desc"] = (d.get("desc") or "").strip()[:300]
        dur = _int(it.get("duration_s"))
        it["too_long"] = bool(dur and dur > 30 * 60)
        out.append(it)
    return out


# ---------------------------------------------------------------- 3. 下载

def _safe_title(title):
    """去掉 Windows 文件名非法字符/控制字符，截 60 字，去掉结尾的点和空格。"""
    t = _BAD_NAME.sub("", str(title or ""))
    t = " ".join(t.replace("\r", " ").replace("\n", " ").split())
    if len(t) > 60:
        t = t[:60]
    return t.strip(" .")


def _filename(bvid, title):
    """`<bvid> <标题>.mp4`；标题洗完是空的就只留 bvid。"""
    t = _safe_title(title)
    return ("%s %s.mp4" % (bvid, t)) if t else ("%s.mp4" % bvid)


def _find_done(video_dir, bvid):
    """找同名 bvid 已下好的 mp4（>100KB 才算），返回绝对路径或 ""。

    文件名里的标题可能被改过，所以按前缀 bvid 找，不按完整文件名。
    """
    try:
        names = os.listdir(video_dir)
    except OSError:
        return ""
    for fn in names:
        if not fn.startswith(bvid) or not fn.lower().endswith(".mp4"):
            continue
        p = os.path.join(video_dir, fn)
        try:
            if os.path.isfile(p) and os.path.getsize(p) > _MIN_BYTES:
                return os.path.abspath(p)
        except OSError:
            pass
    return ""


def _playurl_urls(bvid, cid, qn=32):
    """拿 mp4 直链，返回 (urls, 实际清晰度)。

    自己发而不是用 videos.get_playurl，是因为 durl 里常常有好几条备用地址，
    第一条 CDN 挂了还能换第二条，直接扔给下载器更抗造。
    """
    u = ("%s?bvid=%s&cid=%s&qn=%d&fnval=1&fnver=0&fourk=1"
         % (API_PLAYURL, bvid, cid, qn))
    try:
        d = videos._json(u)
    except Exception:  # noqa: BLE001
        return [], 0
    if d.get("code") != 0:
        return [], 0
    dd = d.get("data") or {}
    urls = [x["url"] for x in (dd.get("durl") or []) if x.get("url")]
    return urls, _int(dd.get("quality"))


def _cid_of(sess, item, bvid, timeout, log):
    """拿 cid。顺序：条目自带 → pagelist → view 详情。

    搜索结果里的 cid 恒为 0，pagelist 偶尔也会空（分区/赛事视频），
    这时候只能问 view 接口，它给的 data.cid 是最稳的那份。
    """
    cid = _int(item.get("cid"))
    if cid:
        return cid
    try:
        cid = _int(videos.get_cid(bvid))
    except Exception:  # noqa: BLE001
        cid = 0
    if cid:
        return cid
    d = _view(sess, bvid, timeout, log)
    return _int(d.get("cid"))


def download_one(sess, item, video_dir, qn=32, max_duration=1800,
                 max_bytes=80 * 1024 * 1024, log=print) -> dict:
    """把一条搜索结果下成本地 mp4。

    返回 {"ok","file"(绝对路径),"size","error","skipped"}。
    - 同 bvid 已经下过（>100KB 的 mp4）→ skipped=True，不重复下
    - 超过 max_duration → ok=False, error="太长了"
    - 时长 0 / 未知 → 照常尝试（宁可下了发现超长被 max_bytes 卡住）
    """
    res = {"ok": False, "file": "", "size": 0, "error": "", "skipped": False}

    if not isinstance(item, dict):
        res["error"] = "item 不是 dict"
        return res
    bvid = str(item.get("bvid") or "").strip()
    if not _BV_RE.match(bvid):
        res["error"] = "bvid 不合法：%s" % (bvid or "空")
        return res

    dur = _int(item.get("duration_s") if item.get("duration_s") is not None
               else item.get("duration"))
    if dur and max_duration and dur > max_duration:
        res["error"] = "太长了"
        return res

    try:
        video_dir = os.path.abspath(video_dir)
        os.makedirs(video_dir, exist_ok=True)
    except OSError as e:
        res["error"] = "建目录失败：%s" % e
        return res

    done = _find_done(video_dir, bvid)
    if done:
        res.update({"ok": True, "file": done,
                    "size": os.path.getsize(done), "skipped": True})
        try:
            log("  已有 %s，跳过" % os.path.basename(done))
        except Exception:  # noqa: BLE001
            pass
        return res

    cid = _cid_of(sess, item, bvid, timeout=15, log=log)
    if not cid:
        # 拿不到 cid 就下不了，但这是"这一条"的问题，不是整批的问题
        res["error"] = "拿不到 cid"
        try:
            log("  %s 拿不到 cid，跳过" % bvid)
        except Exception:  # noqa: BLE001
            pass
        return res

    urls, quality = _playurl_urls(bvid, cid, qn)
    if not urls and qn != 16:
        # qn=32 不一定给，退一档再问一次（实测常常只回 16=360P）
        urls, quality = _playurl_urls(bvid, cid, 16)
    if not urls:
        res["error"] = "拿不到播放地址"
        return res

    path = os.path.join(video_dir, _filename(bvid, item.get("title")))
    last_err = ""
    for n, u in enumerate(urls):
        try:
            size = videos._download(u, path, max_bytes,
                                    referer="https://www.bilibili.com/")
            if size <= 0:
                raise ValueError("下到 0 字节")
            res.update({"ok": True, "file": path, "size": size})
            try:
                log("  下好 %s（%.1f MB，%dp）"
                    % (os.path.basename(path), size / 1048576.0, quality))
            except Exception:  # noqa: BLE001
                pass
            return res
        except Exception as e:  # noqa: BLE001
            last_err = "%s: %s" % (type(e).__name__, str(e)[:80])
            try:
                log("  %s 第 %d 条直链没下成（%s）" % (bvid, n + 1, last_err))
            except Exception:  # noqa: BLE001
                pass
    res["error"] = last_err or "下载失败"
    return res


# ---------------------------------------------------------------- 自测

class _Sess:
    """自测用的最小 sess，跟主控约定的三个方法对齐（不带自定义 header）。"""

    def get_bytes(self, url, referer="", timeout=15):
        with _own_open(url, timeout or 15, referer or REFERER) as r:
            return r.read()

    def get_json(self, url, referer="", timeout=15):
        with _own_open(url, timeout or 15, referer or REFERER) as r:
            return json.loads(r.read().decode("utf-8", "replace"))

    def save_stream(self, url, dest_path, referer="", timeout=30, max_bytes=0):
        total = 0
        with _own_open(url, timeout, referer or REFERER) as r, open(dest_path, "wb") as f:
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                total += len(chunk)
                if max_bytes and total > max_bytes:
                    raise ValueError("超过 max_bytes")
                f.write(chunk)
        return total


if __name__ == "__main__":
    import sys
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:  # noqa: BLE001
        pass
    s = _Sess()
    here = os.path.dirname(os.path.abspath(__file__))
    vdir = os.path.join(here, "data", "videos")

    print("=" * 60)
    print("1) search 原神")
    for it in search(s, "原神", count=5)[:5]:
        print("  ", it["bvid"], it["duration_s"], "s", it["view"], "播放",
              "|", it["title"][:24], "|", it["up"][:10])

    print("=" * 60)
    print("2) probe_topics 猫")
    for it in probe_topics(s, "猫", count=4):
        print("  ", it["bvid"], it["duration_s"], "s too_long=", it["too_long"],
              "|", it["title"][:24])

    print("=" * 60)
    print("3) download_one（挑一条 3 分钟以内的，下完删掉）")
    cand, picked = [], None
    for kw in ("猫", "原神"):
        for it in search(s, kw, count=20):
            if 0 < it.get("duration_s") <= 180:
                cand.append(it)
        if cand:
            break
    for it in cand[:3]:
        r = download_one(s, it, vdir)
        print("  ", it["bvid"], "->", r)
        if r["ok"] and r["file"]:
            picked = r["file"]
            break
    if picked:
        sz = os.path.getsize(picked)
        with open(picked, "rb") as f:
            head = f.read(12)
        print("  文件头 %r，大小 %.1f MB" % (head, sz / 1048576.0))
        os.remove(picked)
        print("  已删除自测文件")
