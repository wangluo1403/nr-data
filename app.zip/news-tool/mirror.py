"""离线网页镜像：给一条网址，把整页连 CSS、图片、字体一起扒下来。

扒完落在 ``data/mirror/<id>/`` 里，入口是 ``index.html``，断网打开基本还原原样。

几个不得不处理的坑：

  · **编码**。原页可能是 GBK。先用 newsd 那套按 meta/XML 声明猜编码解成 str，
    再统一写成 UTF-8，并且把原文的 ``<meta charset>`` / ``http-equiv`` 换掉 ——
    不然浏览器按 GBK 解 UTF-8 的文件，满屏乱码。
  · **``<base href>``**。留着它所有相对路径都会飞掉，直接删掉。
  · **CSS 里的 ``url()``**。字体、背景图全在这儿，得递归往下挖，
    而且 CSS 自己也要重写成指向本地。
  · **``srcset``**。一个属性里塞了「地址 尺寸」好几组，得逐组换。
  · **``@import``**。老站爱用，不跟进去就会缺一大块样式。
  · **JS**。默认一锅端掉（外链的和内联的都端）。内联脚本更危险 ——
    镜像里的 ``window.location = '原站'`` 一到离线就白屏。
    想要就打开 ``mirror_js``，那时外链脚本会下到本地并改写路径。
"""

import hashlib
import os
import re
import sys
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _nd():
    """延迟 import newsd —— 它也要 import 本模块，top-level 会循环。"""
    import newsd
    return newsd


# 只重写这些标签上的资源属性，别的（比如 <a href>）留着指原站，
# 联网时还能点出去看，离线点了就是打不开而已，不影响页面本身。
ASSET_TAGS = {"link", "img", "script", "source", "video", "audio",
              "iframe", "embed", "input", "object", "track"}

TAG_RE = re.compile(r"<(link|img|script|source|video|audio|iframe|embed|input|object|track)\b[^>]*>", re.I)
ATTR_RE = re.compile(r"""(\b(?:src|href|poster|data-src|data-original)\s*=\s*)(["'])(.*?)\2""", re.I | re.S)
SRCSET_RE = re.compile(r"""(\bsrcset\s*=\s*)(["'])(.*?)\2""", re.I | re.S)
STYLE_ATTR_RE = re.compile(r"""(style\s*=\s*)(["'])(.*?)\2""", re.I | re.S)
CHARSET_RE = re.compile(r"""<meta[^>]+charset[^>]*>""", re.I)
BASE_RE = re.compile(r"<base\b[^>]*>", re.I)
STYLE_BLOCK_RE = re.compile(r"(<style\b[^>]*>)(.*?)(</style>)", re.I | re.S)
SCRIPT_BLOCK_RE = re.compile(r"<script\b([^>]*)>(.*?)</script>", re.I | re.S)
NOSCRIPT_KEEP = re.compile(r"<noscript\b", re.I)

CSS_URL_RE = re.compile(r"""url\(\s*(['"]?)([^'")]+)\1\s*\)""", re.I)
CSS_IMPORT_RE = re.compile(
    r"""@import\s+(?:url\(\s*(['"]?)([^'")]+)\1\s*\)|(['"])([^'"]+)\3)""", re.I)

SYS_EXT = {
    "text/css": ".css",
    "text/javascript": ".js", "application/javascript": ".js",
    "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
    "image/webp": ".webp", "image/svg+xml": ".svg", "image/x-icon": ".ico",
    "image/avif": ".avif", "image/bmp": ".bmp",
    "font/woff": ".woff", "font/woff2": ".woff2", "font/ttf": ".ttf",
    "font/otf": ".otf", "application/font-woff": ".woff",
    "application/vnd.ms-fontobject": ".eot",
}

BAD_SCHEME = ("data:", "javascript:", "mailto:", "tel:", "about:", "blob:", "#")


def _ext_of(url: str, ctype: str) -> str:
    ct = (ctype or "").split(";")[0].strip().lower()
    if ct in SYS_EXT:
        return SYS_EXT[ct]
    path = urllib.parse.urlparse(url).path
    e = os.path.splitext(path)[1].lower()
    if e and len(e) <= 6 and re.fullmatch(r"\.[a-z0-9]+", e):
        return e
    if ct.startswith("image/"):
        return "." + ct.split("/", 1)[1].split("+")[0]
    if ct.startswith("font/"):
        return "." + ct.split("/", 1)[1]
    return ".bin"


def _should_grab(u: str) -> bool:
    u = (u or "").strip()
    if not u or u.startswith(BAD_SCHEME) or u.startswith("//"):
        return False
    return u.startswith(("http://", "https://"))


class _Mirror:
    """一次镜像任务。攒够资产、改写路径、落盘。"""

    def __init__(self, out_dir: str, max_bytes: int, want_js: bool,
                 timeout: int, log):
        self.out_dir = out_dir
        self.asset_dir = os.path.join(out_dir, "assets")
        self.max_bytes = max_bytes
        self.want_js = want_js
        self.timeout = timeout
        self.log = log
        self.assets: dict[str, str] = {}      # 绝对 URL -> 相对路径 assets/xxx.ext
        self.texts: dict[str, str] = {}       # 绝对 URL -> 文本内容（CSS/JS）
        self.dead: set[str] = set()           # 下不动的，记下来别再试
        self.used = 0
        self.failed = 0
        self.lock = threading.Lock()

    # ---------- 下载 ----------

    def grab(self, raw_url: str, base: str, referer: str = "") -> str:
        """下一个资源，返回它在镜像里的相对路径（失败返回空串）。"""
        u = urllib.parse.urljoin(base, (raw_url or "").strip())
        u = u.split("#")[0]
        if not _should_grab(u):
            return ""
        with self.lock:
            if u in self.assets:
                return self.assets[u]
            # 失败过一次就别再试 —— 改写阶段会走一遍同样的 URL，
            # 不记住的话每个死链都要白白等一次超时
            if u in self.dead:
                return ""
            if self.used >= self.max_bytes:
                return ""
        nd = _nd()
        try:
            data, ctype = nd.http_get(u, timeout=self.timeout,
                                      referer=referer or base, retries=0,
                                      max_bytes=8 * 1024 * 1024)
        except Exception as e:  # noqa: BLE001
            with self.lock:
                self.failed += 1
                self.dead.add(u)
            self.log("      跳过 %s（%s）" % (u[:70], type(e).__name__))
            return ""

        ext = _ext_of(u, ctype)
        name = hashlib.sha1(u.encode("utf-8")).hexdigest()[:16] + ext
        rel = "assets/" + name
        is_text = ext in (".css", ".js")
        payload = data
        if is_text:
            try:
                self.texts[u] = nd._decode_html(data, ctype)
            except Exception:  # noqa: BLE001
                is_text = False
        try:
            os.makedirs(self.asset_dir, exist_ok=True)
            with open(os.path.join(self.asset_dir, name), "wb") as f:
                f.write(data)
        except OSError as e:
            self.log("      写不进去 %s：%s" % (name, e))
            return ""
        with self.lock:
            self.assets[u] = rel
            self.used += len(payload)
        return rel

    def grab_many(self, urls: list, base: str, referer: str = "", workers: int = 5):
        if not urls:
            return
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(lambda u: self.grab(u, base, referer), urls))

    # ---------- 改写 ----------

    def rewrite_css_text(self, css: str, css_url: str) -> str:
        """把 CSS 里的 url() 和 @import 换成本地路径。"""
        def rep_import(m):
            target = m.group(2) or m.group(4) or ""
            rel = self.grab(target, css_url, css_url)
            if not rel:
                return m.group(0)
            return "@import url(%s)" % rel

        css = CSS_IMPORT_RE.sub(rep_import, css)

        def rep_url(m):
            quote, target = m.group(1), m.group(2)
            if target.startswith(BAD_SCHEME):
                return m.group(0)
            rel = self.grab(target, css_url, css_url)
            if not rel:
                # 抠不到就留着原地址，联网时还能用；离线就是个缺图，别整个样式崩掉
                return m.group(0)
            # CSS 在 assets/ 里，和它引用的东西同层，直接用文件名
            return "url(%s%s%s)" % (quote, os.path.basename(rel), quote)

        return CSS_URL_RE.sub(rep_url, css)

    def rewrite_inline_style(self, css: str, page_url: str) -> str:
        def rep_url(m):
            quote, target = m.group(1), m.group(2)
            if target.startswith(BAD_SCHEME):
                return m.group(0)
            rel = self.grab(target, page_url, page_url)
            if not rel:
                return m.group(0)
            return "url(%s%s%s)" % (quote, rel, quote)
        return CSS_URL_RE.sub(rep_url, css)


def _link_wanted(rel: str, as_: str) -> bool:
    """<link> 只认真正是页面资源的那些。

    早先没过滤，结果 RSS 的 ``<link rel="alternate" type="application/rss+xml">``
    也去下了 —— 那种站内外的 feed 地址十个有九个连不上，白白等一串超时，
    一个 15KB 的页面扒了 74 秒。
    """
    rel = (rel or "").strip().lower()
    if rel in ("stylesheet", "icon", "shortcut icon", "apple-touch-icon",
               "apple-touch-icon-precomposed", "mask-icon"):
        return True
    if rel in ("preload", "prefetch", "preconnect", "dns-prefetch"):
        # 预加载的只挑真资源，dns-prefetch 之类根本不用下
        return (as_ or "").strip().lower() in ("image", "font", "style", "script")
    return False


def _collect_html_refs(html: str, want_js: bool) -> list:
    """先把 HTML 里点到名的资源 URL 收一圈（还没下载）。"""
    urls = []
    for m in TAG_RE.finditer(html):
        tag = m.group(0)
        name = m.group(1).lower()
        if name == "script" and not want_js:
            continue
        if name == "link":
            rel_m = re.search(r"""\brel\s*=\s*(["'])(.*?)\1""", tag, re.I | re.S)
            as_m = re.search(r"""\bas\s*=\s*(["'])(.*?)\1""", tag, re.I | re.S)
            if not _link_wanted(rel_m.group(2) if rel_m else "",
                                as_m.group(2) if as_m else ""):
                continue
        for am in ATTR_RE.finditer(tag):
            attr = am.group(1).split("=")[0].strip().lower()
            val = am.group(3).strip()
            if attr == "href" and name != "link":
                continue          # 只管 <link href>，<a href> 留原站
            if _should_grab(val):
                urls.append(val)
        for sm in SRCSET_RE.finditer(tag):
            for part in sm.group(3).split(","):
                cand = part.strip().split(" ")[0]
                if _should_grab(cand):
                    urls.append(cand)
    for sm in STYLE_BLOCK_RE.finditer(html):
        for um in CSS_URL_RE.finditer(sm.group(2)):
            if _should_grab(um.group(2)):
                urls.append(um.group(2))
    for sm in STYLE_ATTR_RE.finditer(html):
        for um in CSS_URL_RE.finditer(sm.group(3)):
            if _should_grab(um.group(2)):
                urls.append(um.group(2))
    # 去重但保持顺序
    seen, out = set(), []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def mirror_page(url: str, out_root: str, max_bytes: int = 20 * 1024 * 1024,
                want_js: bool = False, timeout: int = 20, log=print) -> dict:
    """扒一条网址，返回索引条目。失败抛异常。"""
    nd = _nd()
    t0 = time.time()
    base = url
    raw, ctype = nd.http_get(url, timeout=timeout, retries=1,
                             max_bytes=min(max_bytes, 8 * 1024 * 1024))
    html = nd._decode_html(raw, ctype)
    title = ""
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    if m:
        title = nd._norm_ws(re.sub(r"<[^>]+>", "", m.group(1)))[:120]
    if not title:
        m = re.search(r"""<meta[^>]+property\s*=\s*["']og:title["'][^>]+content\s*=\s*["']([^"']+)""", html, re.I)
        title = (m.group(1) if m else "")[:120]
    if not title:
        title = urllib.parse.urlparse(url).netloc

    mid = time.strftime("%Y-%m-%d_%H%M%S") + "_" + hashlib.sha1(url.encode("utf-8")).hexdigest()[:8]
    out_dir = os.path.join(out_root, mid)
    os.makedirs(out_dir, exist_ok=True)

    mk = _Mirror(out_dir, max_bytes, want_js, timeout, log)
    mk.used = len(raw)
    log("  扒 %s（%d KB）" % (title[:40], len(raw) // 1024))

    # ---- 第一轮：HTML 里点到名的 ----
    refs = _collect_html_refs(html, want_js)
    log("  页面里引用 %d 个资源，开始下…" % len(refs))
    mk.grab_many(refs, base, base)

    # ---- 第二轮：CSS / JS 里再挖一层（字体、背景图基本都在这）----
    for depth in range(2):
        pending = [u for u in mk.texts if u.split("#")[0] not in getattr(mk, "_scanned", set())]
        if not pending:
            break
        if not hasattr(mk, "_scanned"):
            mk._scanned = set()
        inner = []
        for u in pending:
            mk._scanned.add(u.split("#")[0])
            body = mk.texts.get(u) or ""
            for um in CSS_URL_RE.finditer(body):
                if _should_grab(um.group(2)):
                    inner.append((um.group(2), u))
            for im in CSS_IMPORT_RE.finditer(body):
                tgt = im.group(2) or im.group(4)
                if _should_grab(tgt):
                    inner.append((tgt, u))
        if not inner:
            break
        log("  第 %d 层又挖出 %d 个（字体/背景图）" % (depth + 1, len(inner)))
        # 也并发下，不然几个连不上的字体能串行拖掉一分钟
        with ThreadPoolExecutor(max_workers=5) as ex:
            list(ex.map(lambda p: mk.grab(p[0], p[1], p[1]), inner))

    # ---- 第三轮：把 CSS/JS 重写后写回本地 ----
    for u, body in list(mk.texts.items()):
        rel = mk.assets.get(u)
        if not rel:
            continue
        new = mk.rewrite_css_text(body, u)
        try:
            with open(os.path.join(out_dir, rel), "w", encoding="utf-8") as f:
                f.write(new)
        except OSError:
            pass

    # ---- 最后：改写 HTML ----
    html = _rewrite_html(mk, html, base, want_js)

    # 把原编码声明换成 utf-8，不然 GBK 的页在我们存成 UTF-8 之后会乱码
    head_at = re.search(r"<head\b[^>]*>", html, re.I)
    charset_meta = '<meta charset="utf-8">'
    if head_at:
        html = html[:head_at.end()] + charset_meta + html[head_at.end():]
    else:
        html = re.sub(r"(<html\b[^>]*>)", r"\1<head>" + charset_meta + "</head>",
                      html, count=1, flags=re.I)

    with open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)

    entry = {
        "id": mid,
        "url": url,
        "title": title,
        "host": urllib.parse.urlparse(url).netloc.lower(),
        "created_ts": time.time(),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "bytes": mk.used,
        "assets": len(mk.assets),
        "failed": mk.failed,
        "seconds": round(time.time() - t0, 1),
    }
    log("  镜像好了：%d 个资源 / %.1f MB / %.1fs"
        % (entry["assets"], entry["bytes"] / 1048576.0, entry["seconds"]))
    return entry


def _rewrite_html(mk: _Mirror, html: str, page_url: str, want_js: bool) -> str:
    # <base href> 会架空所有相对路径，删掉
    html = BASE_RE.sub("", html)
    # 原来的 charset 声明留着也没用，反正是我们说了算
    html = CHARSET_RE.sub("", html)

    # 脚本：不要 JS 就整段端掉（内联的更危险，可能会 window.location 跳走）
    if not want_js:
        html = SCRIPT_BLOCK_RE.sub("", html)

    def fix_tag(m):
        tag = m.group(0)
        name = m.group(1).lower()
        if name == "script" and not want_js:
            return ""
        if name == "link":
            # 收的时候就只挑真资源，改写时得用同一套标准，
            # 不然那些 rss/alternate 链接会在这儿第一次被拽去下载
            rel_m = re.search(r"""\brel\s*=\s*(["'])(.*?)\1""", tag, re.I | re.S)
            as_m = re.search(r"""\bas\s*=\s*(["'])(.*?)\1""", tag, re.I | re.S)
            if not _link_wanted(rel_m.group(2) if rel_m else "",
                                as_m.group(2) if as_m else ""):
                return tag

        def rep_attr(am):
            val = am.group(3).strip()
            if not val:
                return am.group(0)
            rel = mk.grab(val, page_url, page_url)
            if not rel:
                return am.group(0)
            return "%s%s%s%s" % (am.group(1), am.group(2), rel, am.group(2))

        tag = ATTR_RE.sub(rep_attr, tag)

        def rep_srcset(sm):
            out = []
            for part in sm.group(3).split(","):
                piece = part.strip()
                if not piece:
                    continue
                bits = piece.split()
                rel = mk.grab(bits[0], page_url, page_url)
                if rel:
                    bits[0] = rel
                out.append(" ".join(bits))
            return "%s%s%s%s" % (sm.group(1), sm.group(2), ", ".join(out), sm.group(2))

        tag = SRCSET_RE.sub(rep_srcset, tag)

        def rep_style(sm):
            return "%s%s%s%s" % (sm.group(1), sm.group(2),
                                 mk.rewrite_inline_style(sm.group(3), page_url), sm.group(2))
        return STYLE_ATTR_RE.sub(rep_style, tag)

    html = TAG_RE.sub(fix_tag, html)

    # 内联 <style> 块
    def rep_style_block(sm):
        return sm.group(1) + mk.rewrite_css_text(sm.group(2), page_url) + sm.group(3)
    html = STYLE_BLOCK_RE.sub(rep_style_block, html)

    # 剩下散落的 style="...url()..."
    html = STYLE_ATTR_RE.sub(
        lambda sm: "%s%s%s%s" % (sm.group(1), sm.group(2),
                                 mk.rewrite_inline_style(sm.group(3), page_url), sm.group(2)),
        html)
    return html
