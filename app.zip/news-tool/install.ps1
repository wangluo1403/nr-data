﻿# -*- coding: utf-8 -*-
<#
  安装器（给主人用，不是给同学用的）

  干的事：
    1. 把整个程序拷到一个比较深的目录（默认藏在一堆系统目录里，不起眼）
    2. 桌面和开始菜单各放一个快捷方式
    3. 可选：开机自启
    4. 生成卸载脚本

  参数：
    -Target  装到哪（默认 C:\ProgramData\Microsoft\Windows\Caches\whale）
    -NoShortcut  不放快捷方式
    -AutoStart   顺带设成开机自启

  用法（在程序目录里）：
    powershell -ExecutionPolicy Bypass -File install.ps1
#>

param(
  [string]$Target = "C:\ProgramData\Microsoft\Windows\Caches\whale",
  [switch]$NoShortcut,
  [switch]$AutoStart
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Out = [Console]::Out

function Say($msg) { Write-Host $msg }
function Die($msg) { Write-Host "出错：$msg" -ForegroundColor Red; exit 1 }

Say "════════════════════════════════"
Say " 离线新闻阅览室 · 安装器"
Say "════════════════════════════════"
Say "源目录：$Here"
Say "装到：  $Target"

if (-not (Test-Path (Join-Path $Here "newsd.py"))) {
  Die "这个目录不像程序目录（找不到 newsd.py）"
}
if (-not (Test-Path (Join-Path $Here "python\python.exe"))) {
  Die "缺少 python\python.exe，这份拷贝不完整"
}

# 已经在跑就先停掉
$lock = Join-Path $Target "data\newsd.lock"
if (Test-Path $lock) {
  Say "目标目录里好像已经装过一份，先停掉旧进程…"
  $pidFile = Get-Content $lock -ErrorAction SilentlyContinue
  if ($pidFile) {
    try { Stop-Process -Id ([int]$pidFile) -Force -ErrorAction SilentlyContinue } catch {}
  }
}

# 建目录
try {
  New-Item -ItemType Directory -Path $Target -Force | Out-Null
} catch { Die "建不了目录：$Target" }

# 拷文件：data 目录不覆盖（用户数据不能丢）
Say "正在拷贝…"
$exclude = @("data", "__pycache__", ".git")
Get-ChildItem -Path $Here -Force | ForEach-Object {
  if ($exclude -contains $_.Name) { return }
  if ($_.Name -like "_*") { return }
  $dest = Join-Path $Target $_.Name
  if ($_.PSIsContainer) {
    Copy-Item $_.FullName $dest -Recurse -Force
  } else {
    Copy-Item $_.FullName $dest -Force
  }
}
Say "拷贝完成"

# 快捷方式
if (-not $NoShortcut) {
  $shell = New-Object -ComObject WScript.Shell
  $desktop = [Environment]::GetFolderPath("Desktop")
  $startMenu = Join-Path ([Environment]::GetFolderPath("Programs")) "离线阅览室"
  New-Item -ItemType Directory -Path $startMenu -Force | Out-Null

  foreach ($dir in @($desktop, $startMenu)) {
    $lnk = Join-Path $dir "离线新闻阅览室.lnk"
    $sc = $shell.CreateShortcut($lnk)
    $sc.TargetPath = Join-Path $Target "start.bat"
    $sc.WorkingDirectory = $Target
    $sc.WindowStyle = 7          # 最小化启动，别弹出黑窗吓人
    $sc.Description = "离线新闻阅览室"
    $sc.Save()
  }
  Say "快捷方式放好了：桌面 + 开始菜单"
}

# 开机自启
if ($AutoStart) {
  $lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "离线新闻阅览室.lnk"
  $shell = New-Object -ComObject WScript.Shell
  $sc = $shell.CreateShortcut($lnk)
  $sc.TargetPath = Join-Path $Target "start.bat"
  $sc.WorkingDirectory = $Target
  $sc.WindowStyle = 7
  $sc.Save()
  Say "设成开机自启了"
}

# 装好的目录设成隐藏（看得见但不显眼）
try {
  $item = Get-Item -LiteralPath $Target -Force
  $item.Attributes = $item.Attributes -bor [IO.FileAttributes]::Hidden
  Say "目录已设成隐藏"
} catch { Say "隐藏属性没设上（不影响使用）" }

# 在 D 盘放一个隐藏的一键卸载
$uninstallDir = "D:\"
if (Test-Path $uninstallDir) {
  # D 盘放一个隐藏的快捷方式，指向安装目录里的卸载脚本。
  # 不用 bat 自删那一套 —— Windows 上批处理删自己是出了名的不靠谱。
  $tl = Join-Path $Target "卸载.bat"
  $lnkPath = Join-Path $uninstallDir "一键卸载.lnk"
  try {
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($lnkPath)
    $sc.TargetPath = $tl
    $sc.WorkingDirectory = $Target
    $sc.WindowStyle = 1
    $sc.Description = "卸载离线新闻阅览室"
    $sc.Save()
    attrib +h "$lnkPath" | Out-Null
    Say "一键卸载已放到 D:\一键卸载.lnk（隐藏）"
  } catch {
    Say "D 盘放不下卸载快捷方式：$($_.Exception.Message)"
  }
} else {
  Say "没有 D 盘，卸载脚本只放在安装目录里"
}

# 卸载脚本（安装目录里也放一份）
$uninstall = @"
@echo off
echo 正在卸载离线新闻阅览室...
taskkill /f /im pythonw.exe >nul 2>nul
del "%USERPROFILE%\Desktop\离线新闻阅览室.lnk" >nul 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\离线新闻阅览室.lnk" >nul 2>nul
rem D 盘根目录的权限只给「写入」不给「删除」（Authenticated Users: Write），
rem 所以这个快捷方式删不掉 —— 留着不管它，很小而且隐藏。
rmdir /s /q "$Target"
echo 卸完了。数据目录也一起删了，有要留的自己先拷出来。
echo （D 盘那个隐藏的「一键卸载」快捷方式删不掉 —— D 盘根目录不让删文件，留着就行）
pause
"@
# 注意：这里必须用 ANSI/GBK 写，别用 UTF-8。
# cmd 读批处理用的是系统代码页，UTF-8 写的中文路径会解析失败（实测删不掉 D 盘那个快捷方式）。
Set-Content -Path (Join-Path $Target "卸载.bat") -Value $uninstall -Encoding Default
Say "卸载脚本：$Target\卸载.bat"

Say ""
Say "装好了。双击桌面那个图标就能用。"
Say "数据（新闻、视频、歌）都在 $Target\data 里。"
