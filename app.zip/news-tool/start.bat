@echo off
chcp 65001 >nul
title Offline News Daemon
cd /d "%~dp0"

rem Prefer the bundled portable Python, fall back to a system-wide install.
rem NOTE: keep this file pure ASCII - Chinese text breaks cmd's parser.
set "PY="
if exist "python\python.exe" set "PY=python\python.exe"
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo [X] Python not found.
  echo     Either put a portable Python into the python\ subfolder,
  echo     or install Python 3.8+ and tick "Add Python to PATH".
  pause
  exit /b 1
)

echo ============================================
echo   Offline News Daemon
echo   Python : %PY%
echo   Web UI : http://127.0.0.1:8765
echo   Close this window (or Ctrl+C) to stop.
echo ============================================
echo.

"%PY%" newsd.py --open
echo.
echo Daemon stopped.
pause
