# -*- coding: utf-8 -*-
"""
activate_tool.py — 激活工具（给主控/主人自己用，不是给学生用的）

能干三件事：
  1. 看本机机器码和按它算出来的启动密码
  2. 给某个机器码生成激活码（可以指定天数、功能）
  3. 给 U 盘做钥匙（往根目录写隐藏的 .whale-key）

跑法：双击 激活工具.bat，或者
      python\\python.exe activate_tool.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import license as lic      # noqa: E402
import usbkey as usb       # noqa: E402


def line(ch="─", n=54):
    print(ch * n)


def show_machine():
    mc = lic.machine_code()
    pw = lic.startup_password(mc)
    line("═")
    print("本机机器码：", mc)
    print("启动密码  ：", pw)
    print("（密码是按机器码算的，算法写在 license.py 文件头，能手算）")
    line("═")
    st = lic.status(os.path.dirname(os.path.abspath(__file__)))
    print("当前版本  ：", st.get("edition"))
    print("激活状态  ：", "已激活" if st.get("activated") else ("试用" if st.get("trial") else "未激活"))
    if st.get("expires"):
        print("到期时间  ：", st["expires"], "（剩 %s 天）" % st.get("days_left"))
    print("U 盘钥匙  ：", "插着（%s）" % (st.get("usb_name") or "") if st.get("usb") else "没插")


def make_code():
    mc = input("给哪个机器码（直接回车 = 本机）：").strip() or lic.machine_code()
    days = input("有效天数（直接回车 = 365）：").strip() or "365"
    try:
        days = int(days)
    except ValueError:
        print("天数得是数字")
        return
    start = input("开始日期 YYYY-MM-DD（直接回车 = 今天）：").strip() or None
    if start:
        code = lic.make_code(mc, days=days, start=start)
    else:
        code = lic.make_code(mc, days=days)
    print()
    line("═")
    print("激活码：")
    print("  " + code)
    line("═")
    info = lic.parse_code(code)
    print("机器码：", info.get("mcode"))
    print("有效期：", info.get("start"), "→", info.get("expires"),
          "（%s 天）" % info.get("days"))
    print("功能  ：", "、".join(info.get("features") or []))


def make_usb():
    print()
    line()
    drives = [d for d in usb.list_drives() if d.get("type") == "可移动"]
    if not drives:
        print("没找到可移动盘。插上 U 盘再来。")
        return
    for i, d in enumerate(drives, 1):
        print("  %d) %s  %s  序列号 %s" % (i, d["root"], d.get("label") or "（无卷标）",
                                          d.get("serial")))
    pick = input("给哪个盘做钥匙（填序号，直接回车上一个）：").strip()
    idx = 0
    if pick.isdigit() and 1 <= int(pick) <= len(drives):
        idx = int(pick) - 1
    root = drives[idx]["root"]
    print("正在往 %s 写钥匙…" % root)
    try:
        info = usb.make_key(root, name="鲸鲸的 U 盘钥匙")
    except Exception as e:  # noqa: BLE001
        print("写不进去：%s: %s" % (type(e).__name__, e))
        print("（U 盘写保护？或者没有管理员权限）")
        return
    print("好了：", info.get("path"))
    print("隐藏属性：", "设上了" if info.get("hidden") else "没设上（文件还在，只是不隐藏）")
    print("插着这个 U 盘打开工具就是最高权限。")


def main():
    while True:
        print()
        print("═══ 离线新闻阅览室 · 激活工具 ═══")
        print("  1) 看机器码 / 启动密码")
        print("  2) 生成激活码")
        print("  3) 给 U 盘做钥匙")
        print("  0) 退出")
        c = input("选一个：").strip()
        if c == "1":
            show_machine()
        elif c == "2":
            make_code()
        elif c == "3":
            make_usb()
        elif c == "0" or not c:
            return


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n再见")
