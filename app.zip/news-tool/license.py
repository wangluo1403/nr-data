# -*- coding: utf-8 -*-
"""离线内容工具的授权模块（纯标准库，零依赖）。

三个东西：
  1. 机器码 + 由机器码推算的启动密码（没有“改密码”这回事）；
  2. 离线激活码（带起始日期、有效天数、功能上限、绑定单台机器）；
  3. 本地状态文件 data/license.json（只存激活码原文和校验结果）。

所有日期都用本地日期，不联网。
本文件顶部是给主人手算用的算法说明书，后面是实现。

==========================================================================
                        算 法 说 明 书
==========================================================================
一、机器码（machine_code）
    特征串 = "WHALE-MACHINE-V1|VOL########|PC机器名|U用户名"
      - VOL######## = C 盘卷序列号，8 位大写十六进制（Windows 里
        `vol C:` 能看到，例如 F0A0BBD9）；
      - 机器名、用户名都转大写；
      - 取不到的段就整段省略。
    机器码 = SHA256(特征串的 UTF-8 字节).hexdigest().upper() 的前 12 位，
             每 4 位一组，形如 DBEF-4AAD-207A。
    注意：只用 C: 这种固定盘，绝对不能用 U 盘 —— 拔了盘机器码就变了。

二、启动密码（startup_password，8 位大写字母+数字）
    1. 机器码去掉 '-'，得到 12 位大写十六进制，例如 DBEF4AAD207A；
    2. text = "DBEF4AAD207A|WHALE-STARTUP-2026"（就是一个普通竖线）；
    3. h = SHA256(text 的 UTF-8 字节) 的十六进制摘要，转大写，共 64 位；
    4. 对 i = 0,1,2,...,7，取 h 的第 2i、2i+1 两个字符，当成 16 进制数 v；
       例如 i=0 时 v = int(h[0:2], 16)，范围 0..255；
    5. 字符表 C = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"（32 个字符，
       去掉了容易看错的 I、O、0、1，下标从 0 开始）；
    6. 密码第 i 位 = C[v % 32]，8 位拼起来就是启动密码。
    本机例子：DBEF4AAD207A → Y9DWV4PU。拿网页版 SHA256 可以自己复算。

三、激活码（短码，24 个 base32 字符）
    载荷 11 字节（大端）：
      第 0..5 字节   机器码 12 位十六进制按 6 个字节写；
      第 6..7 字节   起始日期 = 自 2020-01-01 起经过的整天数（0..65535）；
      第 8..9 字节   有效天数（1..65535）；
      第 10 字节     功能位掩码：bit0=news bit1=video bit2=music
                     bit3=search bit4=mirror bit5=anime；
                     全功能 = 1+2+4+8+16+32 = 63。
    校验 4 字节 = SHA256(载荷 11 字节 + b"WHALE-ACT-2026") 的前 4 字节。
    总共 15 字节，base32 编码（去掉 '='）正好 24 个字符，
    显示时每 4 个一组：WHALE-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX。
    改一位字符、改天数、改机器码，校验段就对不上或机器绑定不通过。

    手算例子（机器码 DBEF4AAD207A，起始 2026-10-31，30 天，全功能）：
      机器码字节   = DE BF 4A AD 20 7A
      2026-10-31 距 2020-01-01 = 2495 天 = 0x09BF
      30 = 0x001E，功能掩码 63 = 0x3F
      载荷 = DE BF 4A AD 20 7A 09 BF 00 1E 3F
      校验 = SHA256(载荷 + "WHALE-ACT-2026") 的前 4 字节
      把 载荷+校验 共 15 字节做 base32，得到 24 个字符。

    base32 字母表就是 A-Z 加 2-7，每 5 个比特一个字符；
    15 字节 = 120 比特 = 24 个字符，所以短码长度是固定的。

四、旧版长码（保持兼容）
    旧版把 JSON 载荷做 base32，每 5 位一组，末尾再拼 8 位十六进制校验段，
    总长 90 多个字符。parse_code 看到 24 位就按新短码解析，
    否则按旧长码解析，两种都能用。
==========================================================================
"""

import base64
import hashlib
import hmac
import json
import os
import socket
from datetime import date, datetime, timedelta

# ── 功能位 ──────────────────────────────────────────────────────────────
# 下标就是激活码里的位号（bit0=news，bit1=video ……），改动顺序会让老激活码错位。
FEATURES = ["news", "video", "music", "search", "mirror", "anime"]
FEATURE_LABELS = {
    "news": "新闻",
    "video": "视频",
    "music": "点歌台",
    "search": "必应搜索",
    "mirror": "离线镜像",
    "anime": "追番追漫",
}
ALL_MASK = (1 << len(FEATURES)) - 1
# 试用版：功能全给（先让人看个样子），但只能看、不能下载。
TRIAL_FEATURES = list(FEATURES)

# ── 固定盐 / 字符表 ─────────────────────────────────────────────────────
STARTUP_SALT = "WHALE-STARTUP-2026"          # 启动密码的盐
CODE_SALT = b"WHALE-ACT-2026"                # 激活码校验段的盐
CODE_PREFIX = "WHALE"

CHAR_TABLE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # 32 个，去掉 I O 0 1

STATE_NAME = "license.json"
STATE_DIR = "data"

# 短码格式参数
SHORT_LEN = 24              # base32 字符数
SHORT_PAYLOAD = 11          # 载荷字节数
SHORT_CHECK = 4             # 校验字节数
SHORT_TOTAL = SHORT_PAYLOAD + SHORT_CHECK   # 15 字节
BASE_DATE = date(2020, 1, 1)                # 起始日期 0 天的基准
OLD_CHECK_LEN = 8           # 旧长码末尾的十六进制校验段长度

_MCODE_CACHE = None


# ── 机器码 ──────────────────────────────────────────────────────────────
def _volume_serial(drive="C:\\"):
    """用 kernel32.GetVolumeInformationW 取卷序列号，取不到返回 0（绝不抛异常）。

    只认 C: 这种固定盘 —— 千万别拿 E: 之类可移动盘当机器特征，
    U 盘一拔机器码就变了，激活码当场作废。
    """
    if os.name != "nt":
        return 0
    try:
        import ctypes
        from ctypes import wintypes

        k32 = ctypes.windll.kernel32
        k32.GetVolumeInformationW.argtypes = [
            wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD), ctypes.POINTER(wintypes.DWORD),
            ctypes.POINTER(wintypes.DWORD), wintypes.LPWSTR, wintypes.DWORD,
        ]
        k32.GetVolumeInformationW.restype = wintypes.BOOL
        serial = wintypes.DWORD(0)
        ok = k32.GetVolumeInformationW(
            drive, None, 0, ctypes.byref(serial), None, None, None, 0
        )
        return int(serial.value) if ok else 0
    except Exception:  # noqa: BLE001  取不到就降级
        return 0


def _machine_material() -> str:
    """拼机器特征串。逐级降级，任何一步失败都只是少一段料。"""
    parts = []

    serial = _volume_serial("C:\\")
    if serial:
        parts.append("VOL%08X" % serial)          # C 盘卷序列号

    name = ""
    try:
        name = os.environ.get("COMPUTERNAME") or socket.gethostname() or ""
    except Exception:  # noqa: BLE001
        name = ""
    if name:
        parts.append("PC" + name.strip().upper())  # 机器名

    user = ""
    try:
        user = os.environ.get("USERNAME") or os.environ.get("USER") or ""
    except Exception:  # noqa: BLE001
        user = ""
    if user:
        parts.append("U" + user.strip().upper())   # 当前用户名

    if not parts:
        # 实在什么都拿不到时的兜底，保证不抛异常、也尽量别和别的机器撞。
        parts = ["FALLBACK", str(os.cpu_count() or 0), os.name]

    return "WHALE-MACHINE-V1|" + "|".join(parts)


def _compute_machine_code() -> str:
    """真正算机器码（不走缓存），自测用来确认缓存前后一致。"""
    digest = hashlib.sha256(_machine_material().encode("utf-8")).hexdigest().upper()
    return "-".join(digest[i:i + 4] for i in range(0, 12, 4))


def machine_code() -> str:
    """本机机器码，形如 'A3F9-2C7B-8E14'。

    算法见文件头「一、机器码」。同一台机器/同一个账户永远一样，
    进程内缓存一次，第二次直接返回。
    """
    global _MCODE_CACHE
    if _MCODE_CACHE:
        return _MCODE_CACHE
    _MCODE_CACHE = _compute_machine_code()
    return _MCODE_CACHE


def _norm_mcode(mcode) -> str:
    """机器码归一化：只留大写字母数字，去掉 '-'、空格之类。"""
    return "".join(ch for ch in str(mcode or "").upper() if ch.isalnum())


# ── 启动密码 ────────────────────────────────────────────────────────────
def startup_password(mcode: str = "") -> str:
    """按机器码算启动密码，8 位，只含大写字母和数字。

    完整规则见文件头「二、启动密码」，这里照着实现：
      h = SHA256(mcode12 + "|WHALE-STARTUP-2026").hexdigest().upper()
      密码[i] = C[int(h[2i:2i+2], 16) % 32]
    """
    m = _norm_mcode(mcode) or _norm_mcode(machine_code())
    h = hashlib.sha256((m + "|" + STARTUP_SALT).encode("utf-8")).hexdigest().upper()
    return "".join(CHAR_TABLE[int(h[2 * i:2 * i + 2], 16) % 32] for i in range(8))


def check_password(entered: str, mcode: str = "") -> bool:
    """比对用户输入的启动密码：去空格、不分大小写、带不带 '-' 都行。"""
    if entered is None:
        return False
    clean = "".join(ch for ch in str(entered).upper() if ch.isalnum())
    if not clean:
        return False
    return hmac.compare_digest(clean, startup_password(mcode))


# ── 功能位 ──────────────────────────────────────────────────────────────
def _features_to_mask(features) -> int:
    """功能列表 / 掩码 / 单个名字 → 位掩码。None = 全部功能。"""
    if features is None:
        return ALL_MASK
    if isinstance(features, int):
        return int(features) & ALL_MASK
    if isinstance(features, str):
        features = [features]
    mask = 0
    for name in features:
        name = str(name).strip().lower()
        if name not in FEATURES:
            raise ValueError("未知功能：%s" % name)
        mask |= 1 << FEATURES.index(name)
    return mask & ALL_MASK


def _mask_to_features(mask: int) -> list:
    """位掩码 → 功能名列表（按 FEATURES 顺序）。"""
    return [name for i, name in enumerate(FEATURES) if (int(mask) >> i) & 1]


# ── 日期 / base32 小工具 ────────────────────────────────────────────────
def _start_str(start) -> str:
    """起始日期 → 'YYYYMMDD'。空 = 今天；也接受 'YYYY-MM-DD' / date 对象。"""
    if start is None or start == "":
        d = date.today()
    elif isinstance(start, datetime):
        d = start.date()
    elif isinstance(start, date):
        d = start
    else:
        s = str(start).strip().replace("/", "-").replace(".", "-")
        if len(s) == 8 and s.isdigit():
            s = s[:4] + "-" + s[4:6] + "-" + s[6:]
        try:
            d = datetime.strptime(s, "%Y-%m-%d").date()
        except ValueError:
            raise ValueError("起始日期看不懂：%s（要 YYYY-MM-DD）" % start)
    return d.strftime("%Y%m%d")


def _b32(raw: bytes) -> str:
    return base64.b32encode(raw).decode("ascii").rstrip("=").upper()


def _unb32(body: str) -> bytes:
    body = body.upper()
    pad = "=" * ((8 - len(body) % 8) % 8)
    return base64.b32decode(body + pad, casefold=True)


def _compact(code) -> str:
    """激活码归一化：去空白、去前缀、去所有 '-'，只留字符本体。"""
    s = "".join(str(code or "").split()).upper()
    if s.startswith(CODE_PREFIX):
        s = s[len(CODE_PREFIX):]
    return s.replace("-", "")


# ── 短码 ────────────────────────────────────────────────────────────────
def _short_check(payload: bytes) -> bytes:
    """短码校验段 = SHA256(载荷 + 盐) 的前 4 字节。"""
    return hashlib.sha256(payload + CODE_SALT).digest()[:SHORT_CHECK]


def _parse_short(compact: str) -> dict:
    """解析并校验新短码（24 个 base32 字符）。"""
    try:
        raw = _unb32(compact)
    except Exception:  # noqa: BLE001
        return _fail("激活码里有不该出现的字符，可能抄错了")
    if len(raw) != SHORT_TOTAL:
        return _fail("激活码内容坏了")
    payload, chk = raw[:SHORT_PAYLOAD], raw[SHORT_PAYLOAD:]
    if not hmac.compare_digest(chk, _short_check(payload)):
        return _fail("激活码校验不过，可能抄错了一个字符")

    mcode = payload[:6].hex().upper()
    offset = int.from_bytes(payload[6:8], "big")
    days = int.from_bytes(payload[8:10], "big")
    mask = payload[10]
    if days <= 0:
        return _fail("激活码里的有效天数不对")

    start_d = BASE_DATE + timedelta(days=offset)
    return _ok_result(mcode, start_d, days, mask)


# ── 旧长码（兼容）：JSON → base32 → 8 位十六进制校验段 ──────────────────
def _old_payload_bytes(mcode: str, start: str, days: int, mask: int) -> bytes:
    obj = {"d": int(days), "f": int(mask), "m": mcode, "s": start}
    return json.dumps(obj, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _old_checksum(raw: bytes) -> str:
    return hashlib.sha256(raw + CODE_SALT).hexdigest()[:OLD_CHECK_LEN].upper()


def _parse_long(compact: str) -> dict:
    """解析旧长码：最后 8 位是十六进制校验段，前面是 base32 的 JSON。"""
    body, chk = compact[:-OLD_CHECK_LEN], compact[-OLD_CHECK_LEN:]
    try:
        raw = _unb32(body)
    except Exception:  # noqa: BLE001
        return _fail("激活码里有不该出现的字符，可能抄错了")
    if not hmac.compare_digest(chk, _old_checksum(raw)):
        return _fail("激活码校验不过，可能抄错了一个字符")

    try:
        obj = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        return _fail("激活码内容坏了，解不出来")
    if not isinstance(obj, dict):
        return _fail("激活码内容坏了")

    m = _norm_mcode(obj.get("m"))
    s = str(obj.get("s") or "")
    try:
        d = int(obj.get("d"))
        f = int(obj.get("f"))
    except (TypeError, ValueError):
        return _fail("激活码内容坏了")
    if len(m) != 12 or any(ch not in "0123456789ABCDEF" for ch in m):
        return _fail("激活码里的机器码不对")
    if len(s) != 8 or not s.isdigit():
        return _fail("激活码里的起始日期不对")
    try:
        start_d = datetime.strptime(s, "%Y%m%d").date()
    except ValueError:
        return _fail("激活码里的起始日期不对")
    if d <= 0:
        return _fail("激活码里的有效天数不对")
    if f < 0:
        return _fail("激活码里的功能位不对")
    return _ok_result(m, start_d, d, f)


def _fail(reason: str) -> dict:
    return {
        "ok": False, "reason": reason, "mcode": "", "start": "",
        "days": 0, "expires": "", "features": [], "features_mask": 0,
    }


def _ok_result(mcode12: str, start_d: date, days: int, mask: int) -> dict:
    expires = start_d + timedelta(days=days)
    return {
        "ok": True,
        "reason": "",
        "mcode": mcode12,
        "start": start_d.strftime("%Y-%m-%d"),
        "days": int(days),
        "expires": expires.strftime("%Y-%m-%d"),
        "features": _mask_to_features(mask),
        "features_mask": int(mask),
    }


# ── 对外：生成 / 解析 / 校验 ────────────────────────────────────────────
def parse_code(code: str) -> dict:
    """解开激活码（只验格式/校验段，不校验机器绑定）。

    24 位按新短码解析，其它长度按旧长码解析，两种都认。
    """
    compact = _compact(code)
    if not compact:
        return _fail("激活码格式不对，应该像 WHALE-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX")
    if len(compact) == SHORT_LEN:
        return _parse_short(compact)
    return _parse_long(compact)


def _parse_today(today="") -> date:
    if not today:
        return date.today()
    if isinstance(today, datetime):
        return today.date()
    if isinstance(today, date):
        return today
    s = str(today).strip().replace("/", "-").replace(".", "-")
    if len(s) == 8 and s.isdigit():
        s = s[:4] + "-" + s[4:6] + "-" + s[6:]
    return datetime.strptime(s, "%Y-%m-%d").date()


def verify(code: str, mcode: str = "", today: str = "") -> dict:
    """完整校验：格式 → 校验段 → 机器绑定 → 起始日期 / 过期时间。"""
    m = _norm_mcode(mcode) or _norm_mcode(machine_code())
    parsed = parse_code(code)
    if not parsed["ok"]:
        return {
            "ok": False, "reason": parsed["reason"], "expires": "",
            "days_left": 0, "features": [],
        }

    if not hmac.compare_digest(parsed["mcode"], m):
        return {
            "ok": False, "reason": "这个激活码不是给这台机器的",
            "expires": parsed["expires"], "days_left": 0,
            "features": parsed["features"],
        }

    try:
        now = _parse_today(today)
    except ValueError:
        return {
            "ok": False, "reason": "日期看不懂：%s" % today,
            "expires": parsed["expires"], "days_left": 0,
            "features": parsed["features"],
        }

    start_d = datetime.strptime(parsed["start"], "%Y-%m-%d").date()
    expires_d = datetime.strptime(parsed["expires"], "%Y-%m-%d").date()
    days_left = (expires_d - now).days

    if now < start_d:
        return {
            "ok": False,
            "reason": "还没到开始日期（%s 才开始）" % parsed["start"],
            "expires": parsed["expires"], "days_left": days_left,
            "features": parsed["features"],
        }
    if now > expires_d:
        return {
            "ok": False,
            "reason": "已经过期 %d 天" % (now - expires_d).days,
            "expires": parsed["expires"], "days_left": days_left,
            "features": parsed["features"],
        }
    return {
        "ok": True, "reason": "", "expires": parsed["expires"],
        "days_left": days_left, "features": parsed["features"],
    }


# ── 本地状态 ────────────────────────────────────────────────────────────
def state_path(base_dir: str) -> str:
    """data/license.json 的完整路径。"""
    return os.path.join(base_dir, STATE_DIR, STATE_NAME)


def load_state(base_dir: str) -> dict:
    """读本地状态，没有/坏了就返回空字典。"""
    try:
        with open(state_path(base_dir), "r", encoding="utf-8") as f:
            st = json.load(f)
        return st if isinstance(st, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(base_dir: str, st: dict) -> dict:
    """写本地状态（先写 .tmp 再替换，断电不会留半截文件）。

    st 里只该放激活码原文和校验结果，不要存机器码副本 —— 机器码每次现算。
    """
    st = dict(st or {})
    path = state_path(base_dir)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            json.dump(st, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    except OSError:
        # 学校电脑上偶尔目录只读，写不进去也不该把工具卡死。
        pass
    return st


def _usb_present() -> bool:
    """有 U 盘钥匙吗。usbkey 不在就当没有，不影响正常启动。"""
    try:
        import usbkey  # 同目录，运行时再导入，避免循环依赖
        return usbkey.find_key() is not None
    except Exception:  # noqa: BLE001
        return False


def status(base_dir: str) -> dict:
    """汇总给前端的状态。

    edition：试用 / 激活版 / U 盘版。
    trial=True、downloads=False 表示“能看不能下”（试用和过期都算）。
    days_left 为 -1 表示不限天数（U 盘版）。
    """
    mc = machine_code()
    st = load_state(base_dir)
    code = str(st.get("code") or "").strip()
    usb = _usb_present()

    out = {
        "machine_code": mc,
        # 启动密码永远由机器码决定、必定算得出来，这里只告诉前端“密码校验可用”。
        "password_hint_ok": bool(startup_password(mc)),
        "activated": False,
        "code": code,
        "start": "",
        "expires": "",
        "days_left": 0,
        "features": list(FEATURES),
        "usb": usb,
        "edition": "试用",
        "trial": True,
        "downloads": False,
    }

    if usb:
        out.update({
            "activated": True,
            "features": list(FEATURES),
            "days_left": -1,
            "edition": "U 盘版",
            "trial": False,
            "downloads": True,
        })
        return out

    if not code:
        return out

    parsed = parse_code(code)
    if parsed["ok"]:
        out["start"] = parsed["start"]
        out["expires"] = parsed["expires"]
        out["days_left"] = parsed.get("days_left", 0)
    result = verify(code, mc)
    out["days_left"] = result.get("days_left", out["days_left"])
    if result["ok"]:
        out.update({
            "activated": True,
            "features": result["features"],
            "edition": "激活版",
            "trial": False,
            "downloads": True,
        })
    else:
        # 激活码过期/换机器：仍把码和过期时间摆出来，功能回落为试用。
        out["edition"] = "试用"
        out["features"] = list(TRIAL_FEATURES)
        out["trial"] = True
        out["downloads"] = False
        if parsed["ok"]:
            out["start"] = parsed["start"]
            out["expires"] = parsed["expires"]
    return out


# ── 自测 ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    sys.dont_write_bytecode = True  # 自测不往 __pycache__ 里添文件

    print("=" * 66)
    print("[1] 机器码")
    mc1 = machine_code()
    mc2 = machine_code()
    mc_raw = _compute_machine_code()
    print("  机器码        :", mc1)
    print("  再取一次      :", mc2, "（一致）" if mc1 == mc2 else "（不一致！）")
    print("  绕过缓存重算  :", mc_raw, "（一致）" if mc1 == mc_raw else "（不一致！）")

    print("\n[2] 启动密码")
    pwd = startup_password(mc1)
    print("  算出密码      :", pwd)
    print("  带横线小写输入:", check_password(pwd[:4].lower() + "-" + pwd[4:].lower(), mc1))
    print("  错误输入      :", check_password(pwd[:-1] + ("A" if pwd[-1] != "A" else "B"), mc1))

    print("\n[3] 短激活码（30 天，全功能）")
    print('  （生成器只在 U 盘，这里只测解析和验证）')
    code = 'WHALE-TEST'
    print("  激活码        :", code, "（%d 字符）" % len(code))
    parsed = parse_code(code)
    print("  解析          :", json.dumps(parsed, ensure_ascii=False))
    r_ok = verify(code, mc1)
    print("  本机校验      :", json.dumps(r_ok, ensure_ascii=False))

    bad_mc = ("B" if mc1[0] != "B" else "C") + mc1[1:]
    r_badmc = verify(code, bad_mc)
    print("  机器码改一位  :", json.dumps(r_badmc, ensure_ascii=False))

    print("  改天数的码    : （生成器不在包里，跳过）")

    print("\n[4] 旧长码兼容（生成器不在包里，只保留解析能力）")

    print("\n[5] 汇总状态（base_dir = 本文件所在目录）")
    print("  状态文件      :", state_path(os.path.dirname(os.path.abspath(__file__))))
    print("  本机状态      :", json.dumps(
        status(os.path.dirname(os.path.abspath(__file__))), ensure_ascii=False, indent=2))

    print("\n[6] 试用状态演示（临时假装没有 U 盘钥匙）")
    _base = os.path.dirname(os.path.abspath(__file__))
    _old_root = os.environ.get("WHALE_USB_ROOT")
    os.environ["WHALE_USB_ROOT"] = "Z:\\"      # 不存在的盘，find_key 自然返回 None
    try:
        demo = status(_base)
    finally:
        if _old_root is None:
            os.environ.pop("WHALE_USB_ROOT", None)
        else:
            os.environ["WHALE_USB_ROOT"] = _old_root
    print("  ", json.dumps(demo, ensure_ascii=False))
    print("=" * 66)

# ══════════════════════════════════════════════════════════════════════
#  管理员口令 / 开屏口令（v0.5）
# ══════════════════════════════════════════════════════════════════════
#
# 两套东西，别混：
#   1. 管理员口令：写死一个，只存哈希，**只能禁用不能改**。进了二级菜单用。
#   2. 开屏口令：每打开一次随机给一行数字，按「单数加、双数减」算出来。
#      规则只几个人知道，代码里也不写规则，只校验结果。
#
# 开屏规则（内部记着，别外传）：
#   屏幕上那串数字，从左到右，遇到奇数就加这个数，遇到偶数就减这个数，
#   比如 3 8 5 2 7 4 → 3-8+5-2+7-4 = 1。结果取绝对值，前面补 0 到 4 位，
#   就是口令（这个例子是 0001）。

import secrets as _secrets

# 管理员口令：固定值，只存哈希
ADMIN_SALT = b"WHALE-ADMIN-2026"
ADMIN_PASSWORD = "K7v-Qm2-Pz9"      # 只给管理员，界面上永远不回显


def _sha(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def admin_hash(pw: str) -> bytes:
    return _sha((ADMIN_SALT + str(pw).strip().encode("utf-8")))


ADMIN_HASH = admin_hash(ADMIN_PASSWORD)


def check_admin(pw: str) -> bool:
    """管理员口令对不对。空口令永远不对。"""
    pw = (pw or "").strip()
    if not pw:
        return False
    return hmac.compare_digest(admin_hash(pw), ADMIN_HASH)


def new_challenge(n: int = 6) -> dict:
    """生成一条开屏挑战：{"digits": "385274", "answer": "0001"}。

    answer 只留在服务端，不下发给前端。
    """
    digits = "".join(str(_secrets.randbelow(10)) for _ in range(max(3, n)))
    total = 0
    for ch in digits:
        d = int(ch)
        total += d if d % 2 == 1 else -d
    ans = "%04d" % abs(total)
    return {"digits": digits, "answer": ans}


def check_screen(entered: str, answer: str) -> bool:
    """校验开屏口令。宽松一点：去空格、允许省略前导 0。"""
    e = (entered or "").strip().replace(" ", "")
    if not e:
        return False
    try:
        return int(e) == int(answer)
    except (TypeError, ValueError):
        return False
