# -*- coding: utf-8 -*-
"""GitHub 版本管理 + 云端禁用名单。

纯标准库，跟 anime.py / videos.py 一个风格：显式禁代理、超时短、外面断了也不抛异常。

2026-10-31 实测（家宽，urllib + ProxyHandler({})）：

  · github.com 的 HTML 页 ✅ 0.8 秒
  · codeload.github.com 的源码 zip ✅ 0.5 秒，PK 开头，能直接下
  · api.github.com ❌ **本机 IP 的免签额度用完了**：releases/latest 和 tags
    都回 HTTP 403 {"message":"API rate limit exceeded ..."}，core 额度
    60/小时、remaining=0，要等 reset（实测约 20 分钟）才恢复。

所以 check_update 是四段式降级，而不是照着文档只打两个 API：
  1) /repos/<repo>/releases/latest  （JSON，最全，带 body 更新日志）
  2) /repos/<repo>/tags             （JSON，没发 release 的仓库靠它）
  3) https://github.com/<repo>/releases/latest 的 HTML——有 release 时它会
     302 到 /releases/tag/<tag>，从最终 URL 里抠 tag（实测 vscode → 1.144.0）
  4) https://github.com/<repo>/tags 的 HTML——把 /releases/tag/<tag> 链接
     按出现顺序取第一个（实测 vscode 首页第一个就是 1.144.0）
第 3、4 段走自己的 opener 而不是 sess，因为 GitHub 对 Accept 头挑剔：
只给 UA 不给 Accept 时 github.com 直接 406，而 sess.get_bytes 没有 header 口子。

zip 一律用 codeload：https://codeload.github.com/<repo>/zip/refs/tags/<tag>，
实测 200 且是 PK 开头，不吃 api.github.com 的额度，比 zipball_url 稳。

降级语义（调用方要知道）：
  · check_update 拿不到 → ok=False，前端就当"没更新"，不挡人。
  · cloud_block 拿不到 → ok=False、blocked=False，**调用方按"没被禁"继续跑**，
    学校断网时也能正常用；只有明确拉到名单才拦。
"""

import json
import os
import re
import shutil
import socket
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

APP_VERSION = "0.6.5"      # 当前版本，别处统一 import 这个，不要硬编码

API_ROOT = "https://api.github.com/repos"

# GitHub 国内经常连不上，这里放几个镜像前缀，直连失败就挨个试。
# 空串表示直连。实测（2026-10-31）：
#   直连 codeload 0.6s / gh-proxy.com 0.9s 都能下 zip；
#   ghproxy.net 拉 zip 会回 403；ghfast.top / ghp.ci / gitmirror / jsdelivr / kgithub 全部 TLS 掐断。
MIRRORS = ["", "https://gh-proxy.com/", "https://ghproxy.net/"]

# 用来测速的小文件（GitHub 上一直有的一个 24 字节 README）
PROBE_URL = "https://raw.githubusercontent.com/octocat/Hello-World/master/README"
_BEST = {"prefix": None, "ts": 0.0, "cost": 0.0}
MIRROR_TTL = 6 * 3600          # 多久重新测一次


def _probe_once(sess, prefix, timeout=5):
    """测一条镜像：返回耗时（秒），失败返回 None。"""
    url = _via_mirror(PROBE_URL, prefix)
    t0 = time.time()
    try:
        data = sess.get_bytes(url, timeout=timeout)
    except Exception:  # noqa: BLE001
        return None
    if not data:
        return None
    return time.time() - t0


def pick_mirror(sess, force: bool = False, timeout: int = 5, log=print) -> str:
    """挨个测一遍，挑最快的那个前缀。结果缓存半小时到 6 小时。

    为什么要测：国内网络下直连 GitHub 可能通也可能堵，镜像站今天快明天慢，
    写死一个顺序等于赌运气。这里每次只用 5 秒测一个 24 字节的小文件，很便宜。
    """
    now = time.time()
    if not force and _BEST["prefix"] is not None and now - _BEST["ts"] < MIRROR_TTL:
        return _BEST["prefix"]

    best, best_cost = None, None
    for prefix in MIRRORS:
        cost = _probe_once(sess, prefix, timeout)
        if cost is None:
            continue
        if best_cost is None or cost < best_cost:
            best, best_cost = prefix, cost
        # 直连够快就别折腾镜像了
        if prefix == "" and cost < 1.2:
            break
    if best is None:
        best, best_cost = "", 0.0
    _BEST.update(prefix=best, ts=now, cost=best_cost or 0.0)
    try:
        log("  镜像测速：用 %s（%.1f 秒）" % (best or "直连", best_cost or 0))
    except Exception:  # noqa: BLE001
        pass
    return best
HTML_ROOT = "https://github.com"
CODELOAD_ROOT = "https://codeload.github.com"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_HTML_ACCEPT = "text/html,application/xhtml+xml"

# 这台机器系统代理/TLS 是坏的，显式禁代理
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

_TAG_LINK_RE = re.compile(r"/releases/tag/([^\"'<>?\s]+)")
_VER_RE = re.compile(r"\d+")

# apply_zip 只认这些扩展名（外加整个 web/ 目录），别的文件一概不碰
SAFE_EXTS = (".py", ".bat", ".ps1")
ALWAYS_SKIP_DIRS = ("python",)      # embeddable 解释器，绝不覆盖
MAX_MEMBERS = 20000                 # 防 zip 炸弹：成员数上限


# ---------------------------------------------------------------- 版本号

def parse_ver(s: str) -> tuple:
    """'v1.2.3' / '1.2' / 'V1.10.0' 都掰成可比较的整数元组。

    取字符串里所有连续数字段，所以 'v1.10.0-beta.2' → (1, 10, 0, 2)。
    预发布后缀不参与语义（只看数字），这点在注释里说清，别指望 -beta 的比较规则。
    一个数字都没有就返回 (0,)。
    """
    parts = _VER_RE.findall(str(s or ""))
    if not parts:
        return (0,)
    return tuple(int(p) for p in parts)


def _ver_cmp(a, b) -> int:
    """按数值比较两个元组，短的补 0：1.10 > 1.9，1.2 == 1.2.0。"""
    ta, tb = parse_ver(a), parse_ver(b)
    n = max(len(ta), len(tb))
    ta = ta + (0,) * (n - len(ta))
    tb = tb + (0,) * (n - len(tb))
    return (ta > tb) - (ta < tb)


# ---------------------------------------------------------------- 网络小工具

def _open(url, timeout=10, accept="application/vnd.github+json",
          referer=""):
    req = urllib.request.Request(url)
    req.add_header("User-Agent", UA)
    req.add_header("Accept", accept)
    if referer:
        req.add_header("Referer", referer)
    return _OPENER.open(req, timeout=timeout)


def _sess_json(sess, url, timeout):
    """sess.get_json 的兼容调用：有的实现只收 (url)。"""
    try:
        return sess.get_json(url, referer="", timeout=timeout)
    except TypeError:
        return sess.get_json(url)


def _get_text(url, timeout=10, max_bytes=3 * 1024 * 1024):
    """自己发 GET，返回 (最终 URL, 文本)。GitHub HTML 必须要 Accept 头。"""
    with _open(url, timeout, _HTML_ACCEPT, "https://github.com/") as r:
        return r.geturl(), r.read(max_bytes).decode("utf-8", "replace")


def _err(exc):
    """把异常压成一句话，别把 traceback 塞进 UI。"""
    if isinstance(exc, urllib.error.HTTPError):
        return "HTTP %s" % exc.code
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return "超时"
    return "%s: %s" % (type(exc).__name__, str(exc)[:80])


# ---------------------------------------------------------------- 1. 检查更新

def _from_api(sess, repo, timeout):
    """两段 JSON API。返回 (tag, body, 用了哪个源) 或 (None, "", 失败原因)。"""
    reasons = []

    url = "%s/%s/releases/latest" % (API_ROOT, repo)
    try:
        d = _sess_json(sess, url, timeout)
        if isinstance(d, dict) and d.get("tag_name"):
            return d["tag_name"], d.get("body") or "", "release"
        reasons.append("latest: 没 tag_name")
    except Exception as e:  # noqa: BLE001
        reasons.append("latest: %s" % _err(e))

    url = "%s/%s/tags" % (API_ROOT, repo)
    try:
        d = _sess_json(sess, url, timeout)
        if isinstance(d, list) and d and (d[0] or {}).get("name"):
            # tags 接口是倒序列的吗？实测 GitHub 按提交时间倒序，但别赌，
            # 拿回来自己按版本号挑最大的那个 tag。
            names = [(t.get("name") or "") for t in d if isinstance(t, dict)]
            names = [n for n in names if n]
            if names:
                best = names[0]
                for n in names[1:]:
                    if _ver_cmp(n, best) > 0:
                        best = n
                return best, "", "tags"
        reasons.append("tags: 空列表")
    except Exception as e:  # noqa: BLE001
        reasons.append("tags: %s" % _err(e))

    return None, "", "；".join(reasons)


MANIFEST_URL = "https://raw.githubusercontent.com/%s/main/version.json"


def _from_manifest(sess, repo, timeout, log=print):
    """先看数据仓里的 version.json（这个仓是公开的，里面只有版本号和封禁名单，没有源码）。

    返回 {"version","zip","notes"} 或 None。
    """
    try:
        best = pick_mirror(sess, log=log)
    except Exception:  # noqa: BLE001
        best = ""
    order = [best] + [m for m in MIRRORS if m != best]
    found = []
    for prefix in order:
        # 加个时间戳绕开 raw / 镜像的缓存（实测 ghproxy 会缓存旧版本）
        url = _via_mirror(MANIFEST_URL % repo, prefix) + "?t=%d" % int(time.time())
        try:
            raw = sess.get_bytes(url, timeout=timeout)
            data = json.loads(raw.decode("utf-8-sig", "replace"))
        except Exception:  # noqa: BLE001
            continue
        if isinstance(data, dict) and data.get("version"):
            found.append({
                "version": str(data.get("version") or "").strip(),
                "zip": str(data.get("zip") or "").strip(),
                "notes": str(data.get("notes") or ""),
            })
    if not found:
        return None
    # 不同镜像可能缓存到不同版本：优先挑「带 zip 地址」且版本最高的那个
    found.sort(key=lambda d: (1 if d.get("zip") else 0,
                              _ver_cmp(d.get("version") or "0", "0")), reverse=True)
    return found[0]


def _from_html(repo, timeout):
    """API 被限流时的降级：从网页抠 tag。返回 tag 或 None。

    直连 github.com 不行就套镜像试一遍（国内经常只有镜像能开）。
    """
    try:
        best = pick_mirror(sess, log=log)
    except Exception:  # noqa: BLE001
        best = ""
    for prefix in [best] + [m for m in MIRRORS if m != best][:1]:
        tag = _from_html_once(repo, timeout, prefix)
        if tag:
            return tag
    return None


def _from_html_once(repo, timeout, prefix=""):
    # 3) /releases/latest 会 302 到 /releases/tag/<tag>
    try:
        final, _ = _get_text(_via_mirror("%s/%s/releases/latest" % (HTML_ROOT, repo),
                                         prefix), timeout)
        m = re.search(r"/releases/tag/([^/?#]+)", final)
        if m:
            tag = urllib.parse.unquote(m.group(1))
            if tag and "*" not in tag:
                return tag
    except Exception:  # noqa: BLE001
        pass

    # 4) /tags 页里按出现顺序取第一个 /releases/tag/ 链接
    try:
        _, html = _get_text(_via_mirror("%s/%s/tags" % (HTML_ROOT, repo), prefix),
                            timeout)
        for tag in _TAG_LINK_RE.findall(html):
            tag = urllib.parse.unquote(tag)
            # 页面里还有 "*name"（排序参数）这种假链接，过滤掉
            if tag and "*" not in tag and not tag.startswith(("%", ".")):
                return tag
    except Exception:  # noqa: BLE001
        pass
    return None


def check_update(sess, repo: str, current: str = APP_VERSION,
                 timeout: int = 10, log=print) -> dict:
    """查最新版本。四段降级，永不抛异常。

    repo 形如 'someone/news-tool'。API 两段都挂了就转网页扒 tag，
    因为这台机器 api.github.com 的免签额度经常是 0（实测 403）。
    网页那一路拿不到更新日志（notes 只能是 ""），要 notes 就得等 API 恢复。
    """
    out = {"ok": False, "current": current, "latest": "", "has_update": False,
           "zip_url": "", "page_url": "", "notes": "", "error": ""}
    repo = (repo or "").strip().strip("/")
    if not repo or "/" not in repo:
        out["error"] = "repo 要写成 owner/name"
        return out

    # 四段降级最多 4 个请求，别让最坏情况拖到 40 秒：
    # 每段请求给 timeout/2（至少 2 秒），API 两段加起来 ≈ timeout，
    # 网页两段再加 ≈ timeout，最坏 2*timeout。分段给预算而不是全局倒计时，
    # 是因为实测 API 限流时偶发"卡满超时"，全局预算会被前两段吃光、
    # 网页降级根本没机会跑。
    step = max(2, int(timeout) // 2)

    # 0) 优先看数据仓的 version.json —— 那样源码不用公开，只公开版本号
    man = None
    try:
        man = _from_manifest(sess, repo, max(3, step), log=log)
    except Exception:  # noqa: BLE001
        man = None
    if man and man.get("version") and man.get("zip"):
        latest = man["version"]
        out.update({
            "ok": True, "latest": latest,
            "has_update": _ver_cmp(latest, current) > 0,
            "zip_url": man.get("zip") or "",
            "page_url": man.get("zip") or "",
            "notes": (man.get("notes") or "")[:4000],
            "error": "" if man.get("zip") else "version.json 里没填 zip 地址",
        })
        try:
            log("  当前 %s，最新 %s（来源：version.json），%s"
                % (current, latest,
                   "有新版本" if out["has_update"] else "已是最新"))
        except Exception:  # noqa: BLE001
            pass
        return out

    tag, notes, why, src = "", "", "", ""
    try:
        tag, notes, why = _from_api(sess, repo, step)
        src = why
    except Exception as e:  # noqa: BLE001  _from_api 自己已经吞了，这层是保险
        src = _err(e)
    if not tag:
        t = _from_html(repo, step)
        if t:
            tag, notes, src = t, "", "网页降级"
        else:
            src = (src + "；" if src else "") + "网页降级也没抠到 tag"
    if not tag:
        out["error"] = "GitHub 拿不到版本号（%s）" % (src or "网络不通")
        try:
            log("  检查更新失败：%s" % out["error"])
        except Exception:
            pass
        return out

    latest = tag.strip()
    out.update({
        "ok": True,
        "latest": latest,
        "has_update": _ver_cmp(latest, current) > 0,
        "zip_url": "%s/%s/zip/refs/tags/%s"
                   % (CODELOAD_ROOT, repo, urllib.request.quote(latest)),
        "page_url": "%s/%s/releases/tag/%s"
                    % (HTML_ROOT, repo, urllib.request.quote(latest)),
        "notes": (notes or "").strip()[:4000],
        "error": "",
    })
    try:
        log("  当前 %s，最新 %s（来源：%s），%s"
            % (current, latest, src,
               "有新版本" if out["has_update"] else "已是最新"))
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- 2. 下载 zip

def _via_mirror(url: str, prefix: str) -> str:
    """把 GitHub 地址套上镜像前缀。空前缀 = 原样。"""
    if not prefix:
        return url
    return prefix.rstrip("/") + "/" + url


def download_zip(sess, zip_url: str, dest_dir: str, timeout: int = 60,
                 max_bytes: int = 200 * 1024 * 1024, log=print) -> dict:
    """把 zip 下到 dest_dir/update.zip。

    GitHub 限流时回的是 JSON（或 HTML），所以下完必须验前两字节是不是 PK，
    不是就删掉报错——不然 apply_zip 会拿一个 JSON 当 zip 去解。
    """
    out = {"ok": False, "path": "", "bytes": 0, "error": ""}
    if not zip_url:
        out["error"] = "zip_url 为空"
        return out
    try:
        os.makedirs(dest_dir, exist_ok=True)
    except OSError as e:
        out["error"] = "建目录失败：%s" % e
        return out

    path = os.path.join(dest_dir, "update.zip")
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass

    n = 0
    last_err = None
    try:
        best = pick_mirror(sess, log=log)
    except Exception:  # noqa: BLE001
        best = ""
    order = [best] + [m for m in MIRRORS if m != best]
    for prefix in order:
        url = _via_mirror(zip_url, prefix)
        try:
            try:
                n = sess.save_stream(url, path, referer="https://github.com/",
                                     timeout=timeout, max_bytes=max_bytes)
            except TypeError:
                # 兼容只收 (url, dest) 的 sess 实现
                n = sess.save_stream(url, path)
            if n:
                if prefix:
                    try:
                        log("  直连不行，走镜像下到了：%s" % prefix.rstrip("/"))
                    except Exception:
                        pass
                break
        except Exception as e:  # noqa: BLE001
            last_err = e
            try:
                os.remove(path)
            except OSError:
                pass
            continue
    if not n:
        out["error"] = "下载失败：%s" % _err(last_err) if last_err else "下载失败"
        try:
            log("  " + out["error"])
        except Exception:
            pass
        return out

    if not os.path.exists(path):
        out["error"] = "下载完没落盘"
        return out
    n = int(n or os.path.getsize(path))

    with open(path, "rb") as f:
        head = f.read(200)
    if head[:2] != b"PK":
        # 省得留个假 zip 在盘上
        try:
            os.remove(path)
        except OSError:
            pass
        hint = head[:80].decode("utf-8", "replace").replace("\n", " ")
        out["error"] = ("下载到的不是 zip（开头是 %r）——GitHub 限流时回 JSON"
                        % hint[:60])
        try:
            log("  " + out["error"])
        except Exception:
            pass
        return out
    if not zipfile.is_zipfile(path):
        try:
            os.remove(path)
        except OSError:
            pass
        out["error"] = "文件头是 PK 但不是完整 zip"
        return out

    out.update({"ok": True, "path": path, "bytes": n, "error": ""})
    try:
        log("  更新包下好：%.1f KB → %s" % (n / 1024.0, path))
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- 3. 解压覆盖

def _member_ok(name):
    """路径穿越检查：绝对路径、盘符、.. 段、反斜杠伪装，一律拒绝。"""
    if not name or "\x00" in name:
        return False
    n = name.replace("\\", "/")
    if n.startswith("/") or re.match(r"^[A-Za-z]:", n):
        return False
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        return False
    return True


def _protected(rel, keep):
    """rel 是相对 app_dir 的 posix 路径；判断是不是不许动的。"""
    first = rel.split("/")[0]
    if first in ALWAYS_SKIP_DIRS:
        return True
    for k in keep or ():
        k = str(k).replace("\\", "/").strip("/")
        if not k:
            continue
        if rel == k or rel.startswith(k + "/"):
            return True
    return False


def _wanted(rel):
    """只要 .py/.bat/.ps1 和整个 web/，别的（README、图片、config…）不动。"""
    low = rel.lower()
    if low.startswith("web/"):
        return True
    return low.endswith(SAFE_EXTS)


def _staging_dir(app_dir):
    """给解压找个真能写的临时目录。

    这台机器的文件沙箱会让 tempfile.mkdtemp() "成功建目录但写不进去"
    （extractall 时 PermissionError），所以建完必须拿一个小文件实测写权限，
    写不进去就删掉换下一个；最后退到 app_dir 下的 .update-staging-<秒>。
    两处都不行返回 ""。
    """
    cands = []
    try:
        cands.append(tempfile.mkdtemp(prefix="news-tool-update-"))
    except Exception:  # noqa: BLE001
        pass
    d2 = os.path.join(app_dir, ".update-staging-%d" % int(time.time()))
    try:
        os.makedirs(d2, exist_ok=False)
        cands.append(d2)
    except Exception:  # noqa: BLE001
        pass
    for d in cands:
        try:
            probe = os.path.join(d, ".probe")
            with open(probe, "wb") as f:
                f.write(b"x")
            os.remove(probe)
            return d
        except Exception:  # noqa: BLE001
            shutil.rmtree(d, ignore_errors=True)
            continue
    return ""


def apply_zip(zip_path: str, app_dir: str, keep=("data", "config.json"),
              log=print) -> dict:
    """把 update.zip 里的新文件覆盖到 app_dir。

    保护清单：
      · keep 里的（默认 data/、config.json）
      · python/（embeddable 解释器，覆盖了就没法跑了）
      · 非 .py/.bat/.ps1 且不在 web/ 下的文件
    覆盖前把要改的旧文件备份到 app_dir/data/backup/<时间戳>/，出错能手工还原。
    解压前先把所有成员名检查一遍，有一个穿越路径就整包拒绝、不写任何东西。
    """
    out = {"ok": False, "files": [], "backup_dir": "", "error": ""}
    if not os.path.isfile(zip_path):
        out["error"] = "zip 不存在：%s" % zip_path
        return out
    app_dir = os.path.abspath(app_dir)
    if not os.path.isdir(app_dir):
        out["error"] = "目标目录不存在：%s" % app_dir
        return out

    try:
        zf = zipfile.ZipFile(zip_path)
    except Exception as e:  # noqa: BLE001
        out["error"] = "打不开 zip：%s" % e
        return out

    with zf:
        members = [i for i in zf.infolist() if not i.is_dir()]
        if len(members) > MAX_MEMBERS:
            out["error"] = "zip 成员太多（%d），不敢解" % len(members)
            return out
        bad = [i.filename for i in members if not _member_ok(i.filename)]
        if bad:
            out["error"] = "压缩包含可疑路径，整包拒绝：%s" % bad[:3]
            try:
                log("  " + out["error"])
            except Exception:
                pass
            return out

        tmp = _staging_dir(app_dir)
        if not tmp:
            out["error"] = "建不了临时解压目录"
            return out
        try:
            try:
                zf.extractall(tmp)
            except Exception as e:  # noqa: BLE001
                out["error"] = "解压失败：%s" % e
                return out

            # GitHub zipball 顶层固定是 <repo>-<sha>/，找到这个唯一顶层目录
            tops = [d for d in os.listdir(tmp)
                    if os.path.isdir(os.path.join(tmp, d))]
            loose = [f for f in os.listdir(tmp)
                     if os.path.isfile(os.path.join(tmp, f))]
            if len(tops) == 1 and not loose:
                root = os.path.join(tmp, tops[0])
            elif not tops and not loose:
                out["error"] = "压缩包是空的"
                return out
            else:
                out["error"] = ("压缩包结构不像 GitHub zipball（顶层有 %d 个目录）"
                                % len(tops))
                return out

            stamp = time.strftime("%Y%m%d-%H%M%S")
            backup_dir = os.path.join(app_dir, "data", "backup", stamp)
            copied, backed = [], set()

            for dirpath, dirnames, filenames in os.walk(root):
                # 顶层就跳过 python/ data/ 这类大目录，省得白走
                rel_dir = os.path.relpath(dirpath, root).replace("\\", "/")
                if rel_dir == ".":
                    dirnames[:] = [d for d in dirnames
                                   if d not in ALWAYS_SKIP_DIRS
                                   and d not in ("data",)]
                    rel_dir = ""
                for fn in filenames:
                    src = os.path.join(dirpath, fn)
                    rel = (rel_dir + "/" + fn).lstrip("/")
                    if not _wanted(rel) or _protected(rel, keep):
                        continue
                    dst = os.path.join(app_dir, rel.replace("/", os.sep))
                    # 目标已经在 app_dir 外面（理论上不会，双保险）
                    if not os.path.abspath(dst).startswith(app_dir + os.sep):
                        continue
                    if os.path.exists(dst):
                        if rel not in backed:
                            bak = os.path.join(backup_dir,
                                               rel.replace("/", os.sep))
                            os.makedirs(os.path.dirname(bak), exist_ok=True)
                            shutil.copy2(dst, bak)
                            backed.add(rel)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)
                    copied.append(rel)
            out.update({"ok": True, "files": copied,
                        "backup_dir": backup_dir if backed else "",
                        "error": ""})
            try:
                log("  更新覆盖 %d 个文件，备份 %d 个 → %s"
                    % (len(copied), len(backed), out["backup_dir"] or "无"))
            except Exception:
                pass
            return out
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------- 4. 云端禁用

def _norm_code(s):
    return re.sub(r"[-_\s]", "", str(s or "")).lower()


def cloud_block(sess, cloud_url: str, machine_code: str,
                timeout: int = 10, log=print) -> dict:
    """拉云端禁用名单，三种 JSON 写法都认：

      1) {"blocked": ["A3F9-2C7B-8E14", ...]}
      2) {"partial": {"A3F9-2C7B-8E14": ["video","music"]}}
      3) 上面两种混着来，外加 "note": "说明文字"

    机型码比对忽略大小写和 '-'。

    ⚠ 语义：拉不到（断网 / 404 / 格式不对）返回 ok=False、blocked=False，
    调用方**当没被禁继续跑**。学校断网是常态，不能因为名单拉不到就把工具锁死；
    只有真拿到名单、且机型码命中，才拦。
    """
    out = {"ok": False, "blocked": False, "scopes": [], "note": "", "error": ""}
    mc = _norm_code(machine_code)
    if not cloud_url:
        out["error"] = "cloud_url 为空"
        return out
    try:
        d = _sess_json(sess, cloud_url, timeout)
    except Exception as e:  # noqa: BLE001
        out["error"] = "拉名单失败：%s" % _err(e)
        try:
            log("  云端名单没拉到（按没被禁处理）：%s" % out["error"])
        except Exception:
            pass
        return out
    if not isinstance(d, dict):
        out["error"] = "名单不是 JSON 对象"
        return out

    blocked_list = d.get("blocked") or []
    if isinstance(blocked_list, dict):          # 允许 {"码": "原因"} 这种写法
        blocked_list = list(blocked_list.keys())
    if not isinstance(blocked_list, (list, tuple, set)):
        blocked_list = []
    hit = any(_norm_code(x) == mc for x in blocked_list)

    scopes = []
    partial = d.get("partial") or {}
    if isinstance(partial, dict):
        for k, v in partial.items():
            if _norm_code(k) != mc:
                continue
            if isinstance(v, dict):             # {"video": true} 也认
                scopes = [str(x) for x, on in v.items() if on]
            elif isinstance(v, (list, tuple, set)):
                scopes = [str(x) for x in v if str(x).strip()]
            elif v:
                scopes = ["all"]
            break

    out.update({
        "ok": True,
        "blocked": bool(hit),
        # 整机被禁时功能范围没意义，给个 all 让调用方少判断一次
        "scopes": (["all"] if hit else scopes),
        "note": str(d.get("note") or "").strip()[:1000],
        "error": "",
    })
    try:
        if out["blocked"]:
            log("  本机在禁用名单里：%s" % (out["note"] or "无说明"))
        elif out["scopes"]:
            log("  本机被停用部分功能：%s" % "、".join(out["scopes"]))
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- 自测

class _Sess:
    """自测用最小 sess：GET/下载都自己发，跟主控约定的三个方法对齐。"""

    def get_bytes(self, url, referer="", timeout=10):
        with _open(url, timeout, _HTML_ACCEPT, referer) as r:
            return r.read()

    def get_json(self, url, referer="", timeout=10):
        with _open(url, timeout, "application/vnd.github+json", referer) as r:
            return json.loads(r.read().decode("utf-8", "replace"))

    def save_stream(self, url, dest_path, referer="", timeout=30, max_bytes=0):
        total = 0
        with _open(url, timeout, "*/*", referer) as r, open(dest_path, "wb") as f:
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if max_bytes and total > max_bytes:
                    raise ValueError("超过 max_bytes")
                f.write(chunk)
        return total


def _fake_zip(path, entries):
    """自测造 zip。entries 是 [(成员名, 内容)]，故意不经过 _member_ok 检查。"""
    with zipfile.ZipFile(path, "w") as zf:
        for name, data in entries:
            zf.writestr(name, data)
    return path


def _scratch_dir():
    """自测用的临时目录。

    这台机器 tempfile.mkdtemp() 会被文件沙箱挡掉（PermissionError），
    所以先试当前目录，再试系统 temp，全都用 os.makedirs，用完 rmtree。
    """
    for base in (os.getcwd(), tempfile.gettempdir(),
                 os.environ.get("TEMP") or ""):
        if not base or not os.path.isdir(base):
            continue
        p = os.path.join(base, "updater-selftest-%d" % int(time.time() * 1000 % 1e6))
        try:
            os.makedirs(p, exist_ok=False)
            return p
        except Exception:  # noqa: BLE001
            continue
    return ""


def _self_test():
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass

    print("=" * 62)
    print("1) parse_ver")
    cases = [("v1.2.3", (1, 2, 3)), ("1.2", (1, 2)), ("V1.10.0", (1, 10, 0)),
             ("0.3.0", (0, 3, 0)), ("release-2.0", (2, 0)), ("", (0,))]
    for s, want in cases:
        got = parse_ver(s)
        print("   %-16r → %-14s %s" % (s, got, "OK" if got == want else "FAIL"))
        assert got == want, s
    assert _ver_cmp("1.10", "1.9") > 0, "1.10 要大于 1.9"
    assert _ver_cmp("v1.2", "1.2.0") == 0, "1.2 应等于 1.2.0"
    print("   1.10 > 1.9 ✔   1.2 == 1.2.0 ✔")

    sess = _Sess()

    print("=" * 62)
    print("2) check_update 实测 microsoft/vscode（当前假装 1.100.0）")
    r = check_update(sess, "microsoft/vscode", current="1.100.0", timeout=10)
    print("  ", json.dumps(r, ensure_ascii=False)[:420])

    print("-" * 62)
    print("2b) check_update 打一个不存在 / 没 release 的仓库")
    r2 = check_update(sess, "octocat/Hello-World", current="1.0.0", timeout=10)
    print("  ", json.dumps(r2, ensure_ascii=False)[:300])

    print("=" * 62)
    print("3) download_zip 实测（真下 octocat/Hello-World 的源码 zip）")
    tmp = _scratch_dir()
    if not tmp:
        print("   建不了自测用的临时目录，3/4 段跳过")
    try:
        if not tmp:
            return
        url = ("https://codeload.github.com/octocat/Hello-World/"
               "zip/refs/heads/master")
        d = download_zip(sess, url, tmp, timeout=60)
        print("  ", json.dumps(d, ensure_ascii=False))
        if d["ok"]:
            print("   前两字节：", open(d["path"], "rb").read(2))

        print("-" * 62)
        print("3b) 拿一个会回 JSON 的地址当 zip（模拟限流），验证会被拒")
        d2 = download_zip(sess, "https://api.github.com/rate_limit",
                          os.path.join(tmp, "bad"), timeout=20)
        print("  ", json.dumps(d2, ensure_ascii=False))
        print("   目录里还剩：", sorted(os.listdir(os.path.join(tmp, "bad")))
              if os.path.isdir(os.path.join(tmp, "bad")) else "(空)")

        print("=" * 62)
        print("4) apply_zip 自测（全在临时目录，绝不动 news-tool）")
        app_dir = os.path.join(tmp, "app")
        os.makedirs(os.path.join(app_dir, "web"), exist_ok=True)
        os.makedirs(os.path.join(app_dir, "data", "backup"), exist_ok=True)
        os.makedirs(os.path.join(app_dir, "python"), exist_ok=True)
        # 旧文件：config.json / data 里的东西 / python 里的东西都是命根子
        files = {
            os.path.join(app_dir, "newsd.py"): "# old newsd\n",
            os.path.join(app_dir, "config.json"): '{"keep":true}\n',
            os.path.join(app_dir, "data", "index.json"): '{"n":1}\n',
            os.path.join(app_dir, "python", "python.exe"): "MZfake",
            os.path.join(app_dir, "web", "a.js"): "// old js\n",
        }
        for p, c in files.items():
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(c)

        good = _fake_zip(os.path.join(tmp, "good.zip"), [
            ("x-abc123/newsd.py", "# NEW newsd\n"),
            ("x-abc123/web/a.js", "// NEW js\n"),
            ("x-abc123/config.json", '{"HIJACKED":true}\n'),
            ("x-abc123/data/index.json", '{"n":999}\n'),
            ("x-abc123/python/python.exe", "MZevil"),
            ("x-abc123/README.md", "readme"),
        ])
        res = apply_zip(good, app_dir)
        print("  ", json.dumps(res, ensure_ascii=False))
        print("   现在 config.json =", open(os.path.join(app_dir, "config.json"),
                                            encoding="utf-8").read().strip())
        print("   data/index.json =", open(os.path.join(app_dir, "data", "index.json"),
                                            encoding="utf-8").read().strip())
        print("   python/python.exe =", open(os.path.join(app_dir, "python", "python.exe"),
                                              encoding="utf-8").read())
        print("   newsd.py =", open(os.path.join(app_dir, "newsd.py"),
                                    encoding="utf-8").read().strip())
        print("   web/a.js =", open(os.path.join(app_dir, "web", "a.js"),
                                    encoding="utf-8").read().strip())
        if res["backup_dir"]:
            print("   备份内容：", sorted(
                os.path.relpath(os.path.join(dp, f), res["backup_dir"])
                .replace("\\", "/")
                for dp, _, fs in os.walk(res["backup_dir"]) for f in fs))
        assert "config.json" not in " ".join(res["files"])
        assert "data/index.json" not in " ".join(res["files"])
        assert "python/python.exe" not in " ".join(res["files"])

        print("-" * 62)
        print("4b) 路径穿越：../evil.txt 必须整包拒")
        evil = _fake_zip(os.path.join(tmp, "evil.zip"), [
            ("x-abc123/ok.py", "# ok\n"),
            ("x-abc123/../evil.txt", "pwned"),
        ])
        res2 = apply_zip(evil, app_dir)
        print("  ", json.dumps(res2, ensure_ascii=False))
        print("   evil.txt 存在吗：", os.path.exists(os.path.join(tmp, "evil.txt")),
              os.path.exists(os.path.join(app_dir, "evil.txt")))
        assert res2["ok"] is False

        print("-" * 62)
        print("4c) 绝对路径 / 兄弟目录穿越")
        for name in ("/abs/evil.py", "x-abc123/../../out.py",
                     "C:/Windows/evil.py"):
            z = _fake_zip(os.path.join(tmp, "bad2.zip"),
                          [("x-abc123/a.py", "a"), (name, "pwned")])
            rr = apply_zip(z, app_dir)
            print("   %-28r ok=%s %s" % (name, rr["ok"], rr["error"][:40]))
            assert rr["ok"] is False

        print("=" * 62)
        print("5) cloud_block 实测（本地起 http 服务喂三种格式）")
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

        payloads = {
            "/blocked.json": {"blocked": ["A3F9-2C7B-8E14", "B111-2222"]},
            "/partial.json": {"partial": {"a3f9-2c7b-8e14": ["video", "music"]}},
            "/both.json": {"blocked": ["AAAA-0000"], "note": "学校机房整机停用",
                           "partial": {"A3F9-2C7B-8E14": ["video"]}},
            "/empty.json": {},
        }

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                body = payloads.get(self.path)
                if body is None:
                    self.send_error(404)
                    return
                raw = json.dumps(body).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def log_message(self, *a):
                pass

        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = "http://127.0.0.1:%d" % srv.server_address[1]
        mc = "A3F9-2C7B-8E14"
        try:
            for p in ("/blocked.json", "/partial.json", "/both.json",
                      "/empty.json", "/nope.json"):
                rr = cloud_block(sess, base + p, mc, timeout=5)
                print("   %-14s → %s" % (p, json.dumps(rr, ensure_ascii=False)))
            print("   大小写/短横线不敏感：", cloud_block(
                sess, base + "/partial.json", "a3f92c7b8e14", timeout=5)["scopes"])
        finally:
            srv.shutdown()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("=" * 62)
    print("自测完毕")


if __name__ == "__main__":
    _self_test()
