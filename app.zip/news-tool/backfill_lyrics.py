# -*- coding: utf-8 -*-
"""
backfill_lyrics.py — 给已经下好的歌补歌词

为什么需要这个：
  歌词是后来才加的功能，之前下回来的那些歌没有同名 .lrc。
  但歌名歌手都在，拿去网易云搜一下就能把 id 找回来，
  再用 /api/song/lyric 换 LRC，存成同名 .lrc 就完事了。

跑法：
    python\\python.exe backfill_lyrics.py          # 补所有缺歌词的
    python\\python.exe backfill_lyrics.py --limit 10

没网的时候跑也没事，搜不到就跳过，不会报错。
"""

import argparse
import os
import sys

# 控制台是 GBK 的时候，歌名里带个特殊字符就把脚本打崩了，先兜住
try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:  # noqa: BLE001
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import newsd                      # noqa: E402  借它的 Session（带限速）
import music as musicmod          # noqa: E402
import netmusic                   # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="补歌词")
    ap.add_argument("--limit", type=int, default=0, help="最多补几首，0 = 全部")
    ap.add_argument("--dry", action="store_true", help="只看不动手")
    args = ap.parse_args()

    music_dir = newsd.MUSIC_DIR
    items = musicmod.scan(music_dir, newsd.MUSIC_COVER_DIR)
    need = [x for x in items
            if not x.get("lrc") or not x.get("cover") or not x.get("duration_s")]
    if args.limit:
        need = need[:args.limit]
    print("共 %d 首，缺歌词 %d 首" % (len(items), len(need)))
    if args.dry:
        for x in need[:20]:
            print("  缺：", x.get("artist"), "-", x.get("title"))
        return 0

    sess = newsd._SESSION
    done = 0
    for i, x in enumerate(need, 1):
        title = (x.get("title") or "").strip()
        artist = (x.get("artist") or "").strip()
        if not title:
            continue
        kw = ("%s %s" % (artist, title)).strip()
        try:
            hits = netmusic.search_song(sess, kw, limit=5, log=lambda *a: None)
        except Exception:  # noqa: BLE001
            hits = []
        if not hits and artist:
            try:
                hits = netmusic.search_song(sess, title, limit=5, log=lambda *a: None)
            except Exception:  # noqa: BLE001
                hits = []
        # 挑一个名字对得上的，别把别的歌的歌词塞进来
        pick = None
        for h in hits:
            if (h.get("name") or "").strip().lower() == title.lower():
                pick = h
                break
        if pick is None and hits:
            pick = hits[0]
        if pick is None:
            print("  [%d/%d] 搜不到：%s" % (i, len(need), kw))
            continue
        base = os.path.splitext(os.path.join(music_dir, x["name"]))[0]
        got = []
        # 时长：索引里没有就从详情补一份进 music_meta
        if not x.get("duration_s"):
            try:
                det = netmusic.song_detail(sess, pick.get("id")) or {}
                dt = int(det.get("duration_s") or 0)
            except Exception:  # noqa: BLE001
                dt = 0
            if dt:
                mm = newsd._read_json(newsd.MUSIC_META, {}) or {}
                rec = mm.get(x["name"]) or {}
                rec.setdefault("id", pick.get("id") or "")
                rec["duration_s"] = int(dt)
                rec.setdefault("chart", x.get("chart") or "")
                rec.setdefault("added_at", "")
                mm[x["name"]] = rec
                newsd._write_json(newsd.MUSIC_META, mm)
                got.append("时长")
        if not x.get("cover"):
            try:
                cv = netmusic.save_cover(sess, netmusic.cover_url_of(sess, pick), base)
                if cv:
                    got.append("封面")
            except Exception:  # noqa: BLE001
                pass
        if not x.get("lrc"):
            full = netmusic.get_lyric_full(sess, pick.get("id"))
            body = full.get("klyric") or full.get("lrc") or ""
            if body.strip():
                try:
                    with open(base + ".lrc", "w", encoding="utf-8",
                              newline="\n") as f:
                        f.write(body)
                    got.append("歌词" + ("（逐字）" if full.get("klyric") else ""))
                except OSError as e:
                    print("  [%d/%d] 写不进去：%s" % (i, len(need), e))
        if not x.get("tlrc"):
            full2 = netmusic.get_lyric_full(sess, pick.get("id"))
            tl = full2.get("tlrc") or ""
            if tl.strip():
                try:
                    with open(base + ".tlrc", "w", encoding="utf-8",
                              newline="\n") as f:
                        f.write(tl)
                    got.append("翻译")
                except OSError:
                    pass
        if got:
            done += 1
            print("  [%d/%d] OK  %s：补了 %s"
                  % (i, len(need), x["title"], "、".join(got)))
        else:
            print("  [%d/%d] 都没有：%s" % (i, len(need), kw))

    print("补好 %d 首" % done)
    if done:
        newsd._rebuild_music()
        print("索引已重建")
    return 0


if __name__ == "__main__":
    sys.exit(main())
