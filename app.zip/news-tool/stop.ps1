# stop.ps1 - kill the process listening on 8765 (newsd), plus any newsd.py

$ErrorActionPreference = "SilentlyContinue"
$killed = $false

# 1) 先按端口找：有些 python 进程的 CommandLine 读出来是空的，按命令行杀不掉
$conns = Get-NetTCPConnection -LocalPort 8765
foreach ($c in $conns) {
    if ($c.OwningProcess) {
        Stop-Process -Id $c.OwningProcess -Force
        Write-Host ("[OK] stopped listener on 8765 (PID " + $c.OwningProcess + ")")
        $killed = $true
    }
}
if (-not $killed) {
    $lines = netstat -ano | Select-String ":8765\s"
    $seen = @{}
    foreach ($ln in $lines) {
        $parts = ($ln.ToString() -split "\s+") | Where-Object { $_ }
        $procId = $parts[-1]
        if ($procId -match "^\d+$" -and -not $seen.ContainsKey($procId)) {
            $seen[$procId] = $true
            Stop-Process -Id ([int]$procId) -Force
            Write-Host ("[OK] stopped 8765 owner (PID " + $procId + ")")
            $killed = $true
        }
    }
}

# 2) 再按命令行兜底
$procs = Get-CimInstance Win32_Process -Filter "Name = 'python.exe' OR Name = 'pythonw.exe'"
foreach ($p in $procs) {
    if ($p.CommandLine -like "*newsd.py*") {
        Stop-Process -Id $p.ProcessId -Force
        Write-Host ("[OK] stopped newsd (PID " + $p.ProcessId + ")")
        $killed = $true
    }
}

if (-not $killed) {
    Write-Host "[i] newsd is not running."
}
