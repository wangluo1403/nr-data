# stop.ps1 - kill any running newsd.py process

$ErrorActionPreference = "SilentlyContinue"

$procs = Get-CimInstance Win32_Process -Filter "Name = 'python.exe' OR Name = 'pythonw.exe'"
$found = $false

foreach ($p in $procs) {
    if ($p.CommandLine -like "*newsd.py*") {
        Stop-Process -Id $p.ProcessId -Force
        Write-Host ("[OK] stopped newsd (PID " + $p.ProcessId + ")")
        $found = $true
    }
}

if (-not $found) {
    Write-Host "[i] newsd is not running."
}
