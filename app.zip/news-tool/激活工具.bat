@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "python\python.exe" (
  echo python folder missing, this copy is incomplete.
  pause
  exit /b 1
)

"python\python.exe" activate_tool.py

pause
