# -*- coding: utf-8 -*-
"""
sched.py — 下载任务队列

为什么要有这个东西：

以前是「距上次抓满 3 小时 → 每秒探测 → 一联网就一口气把所有东西抓完」。
但那套假定「联网的那段时间够长」，学校热点说关就关，一节课 40 分钟里
真正能用的窗口可能只有三五分钟。抓到一半断了，下次又从头来，永远抓不完。

所以改成任务队列：

  - 每个「要下载的东西」是一条任务（新闻、视频、推荐、搜索、歌、追番……）
  - 联网窗口开了就把任务一条条往外取，取完一条标一条
  - 网断了不丢进度，队列躺在磁盘上，下次联网接着从没做完的那条继续
  - 同一件事不会重复排（dedupe key），免得一个窗口里排了八个「抓新闻」

队列存 data/queue.json，写法是「先写 .tmp 再 os.replace」，
这样网页那边永远读不到写了一半的 JSON。

这个模块只管「排」「取」「标」，不管怎么下载 —— 下载逻辑在 newsd.py 里，
那边把真正的活干完再调 set_state() 汇报结果。
"""

from __future__ import annotations

import json
import os
import threading
import time

# 任务种类。weight 只是给前端排显示顺序用的（数字大的排前面），不影响执行顺序 ——
# 执行顺序就是队列里的先后，排的时候按这个权重排好，重要的先干。
KINDS = {
    "news":        {"label": "新闻",     "weight": 100},
    "search":      {"label": "必应搜索", "weight": 70},
    "videos":      {"label": "B 站热门", "weight": 60},
    "music":       {"label": "网易云推荐", "weight": 50},
    "playlist":    {"label": "歌单下载", "weight": 48},
    "wish":        {"label": "离线点歌", "weight": 46},
    "song_dl":     {"label": "单曲下载", "weight": 47},
    "pl_tracks":   {"label": "歌单曲目", "weight": 48},
    "bili_dl":     {"label": "B 站下载", "weight": 44},
    "bili_kw":     {"label": "B 站关键词", "weight": 43},
    "bili_rec":    {"label": "B 站推荐", "weight": 45},
    "bili_search": {"label": "B 站搜索", "weight": 40},
    "anime":       {"label": "追番追漫", "weight": 35},
    "update":      {"label": "检查更新", "weight": 12},
    "mirror":      {"label": "离线镜像", "weight": 30},
}

# 一条任务最多试几次。失败了重排，试满就标 dead 扔一边，
# 别让它永远堵在队头 —— 一个坏网址能把整个窗口耗光。
MAX_TRIES = 3

# 失败之后隔多久才肯再排同一条（秒）。刚断网那种是暂时的，
# 立刻重排只会连撞三次直接判死，所以给个冷却。
RETRY_COOLDOWN = 30 * 60

_STATE_PENDING = "pending"
_STATE_RUNNING = "running"
_STATE_DONE = "done"
_STATE_FAILED = "failed"
_STATE_DEAD = "dead"
_STATE_SKIPPED = "skipped"


def label_of(kind: str) -> str:
    return (KINDS.get(kind) or {}).get("label") or kind


def weight_of(kind: str) -> int:
    return int((KINDS.get(kind) or {}).get("weight") or 0)


def _now() -> float:
    return time.time()


def _fmt(ts: float) -> str:
    if not ts:
        return ""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


class Queue:
    """磁盘上的任务队列。多线程安全（内部一把锁）。"""

    def __init__(self, path: str, log=print):
        self.path = path
        self.log = log
        self._lock = threading.RLock()
        self._tasks: list[dict] = []
        self._seq = 0
        self.load()

    # ---------- 读写 ----------

    def load(self) -> None:
        """读队列。文件坏了就当空的，别把整个进程拖死。"""
        with self._lock:
            data = None
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = None

            tasks = []
            if isinstance(data, dict):
                tasks = data.get("tasks") or []
                self._seq = int(data.get("seq") or 0)
            elif isinstance(data, list):     # 老格式或者手写的
                tasks = data
            if not isinstance(tasks, list):
                tasks = []

            clean = []
            for t in tasks:
                if not isinstance(t, dict):
                    continue
                kind = str(t.get("kind") or "").strip()
                if kind not in KINDS:
                    continue
                # 上次进程被杀时正在跑的任务，重启后得放回 pending，
                # 不然它会永远卡在 running，谁也取不到。
                st = t.get("state") or _STATE_PENDING
                if st == _STATE_RUNNING:
                    st = _STATE_PENDING
                clean.append({
                    "id": int(t.get("id") or 0),
                    "kind": kind,
                    "key": str(t.get("key") or ""),
                    "payload": t.get("payload") if isinstance(t.get("payload"), dict) else {},
                    "state": st,
                    "tries": int(t.get("tries") or 0),
                    "error": str(t.get("error") or ""),
                    "note": str(t.get("note") or ""),
                    "created_ts": float(t.get("created_ts") or 0),
                    "started_ts": float(t.get("started_ts") or 0),
                    "finished_ts": float(t.get("finished_ts") or 0),
                    "next_try_ts": float(t.get("next_try_ts") or 0),
                })
            # id 别撞
            top = max([t["id"] for t in clean] + [self._seq])
            self._seq = max(top, self._seq)
            for t in clean:
                if not t["id"]:
                    self._seq += 1
                    t["id"] = self._seq
            self._tasks = clean

    def save(self) -> None:
        with self._lock:
            body = json.dumps({
                "seq": self._seq,
                "saved_at": _fmt(_now()),
                "tasks": self._tasks[-400:],   # 别无限长，老任务已经没意义了
            }, ensure_ascii=False, indent=1)
        tmp = self.path + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(body)
            os.replace(tmp, self.path)
        except OSError as e:
            self.log("任务队列写不进去：%s" % e)

    # ---------- 排队 ----------

    def add(self, kind: str, key: str = "", payload: dict | None = None,
            dedupe: bool = True, note: str = "") -> dict:
        """排一条任务。同 kind+key 已经在队里（pending/running）就不重复排。"""
        if kind not in KINDS:
            raise ValueError("不认识的 task 种类：%s" % kind)
        key = key or kind
        with self._lock:
            if dedupe:
                for t in self._tasks:
                    if t["kind"] == kind and t["key"] == key and \
                            t["state"] in (_STATE_PENDING, _STATE_RUNNING):
                        return t
            self._seq += 1
            task = {
                "id": self._seq, "kind": kind, "key": key,
                "payload": dict(payload or {}),
                "state": _STATE_PENDING, "tries": 0, "error": "", "note": note,
                "created_ts": _now(), "started_ts": 0, "finished_ts": 0,
                "next_try_ts": 0,
            }
            self._tasks.append(task)
            # 排在队尾，但按权重往前挪一点 —— 新闻总该先于镜像
            self._tasks.sort(key=lambda t: (0 if t["state"] == _STATE_RUNNING else 1,
                                            -weight_of(t["kind"]),
                                            t["created_ts"]))
        self.save()
        return task

    def pop_next(self, allowed=None) -> dict | None:
        """取一条能干的：pending、没到冷却时间、种类在 allowed 里。

        主人自己点的（单曲下载 / 点歌）插队先跑 —— 不然前面排着二十条新闻，
        他点完半天没反应，会以为按钮坏了。
        """
        now = _now()
        with self._lock:
            for jumps in (True, False):
                for t in self._tasks:
                    if t["state"] != _STATE_PENDING:
                        continue
                    if allowed is not None and t["kind"] not in allowed:
                        continue
                    if jumps and t["kind"] not in ("song_dl", "wish"):
                        continue
                    if not jumps and t["kind"] in ("song_dl", "wish"):
                        continue
                    if t.get("next_try_ts", 0) > now:
                        continue
                    t["state"] = _STATE_RUNNING
                    t["started_ts"] = now
                    return dict(t)
        return None

    def set_state(self, task_id: int, state: str, error: str = "",
                  note: str = "") -> dict | None:
        """汇报结果。failed 且没试满会自动排回去等冷却。"""
        with self._lock:
            task = None
            for t in self._tasks:
                if t["id"] == task_id:
                    task = t
                    break
            if task is None:
                return None

            if state == _STATE_FAILED:
                task["tries"] = int(task.get("tries") or 0) + 1
                task["error"] = error[:300]
                if task["tries"] >= MAX_TRIES:
                    task["state"] = _STATE_DEAD
                    task["finished_ts"] = _now()
                else:
                    task["state"] = _STATE_PENDING
                    task["next_try_ts"] = _now() + RETRY_COOLDOWN
            else:
                task["state"] = state
                task["error"] = error[:300]
                task["finished_ts"] = _now()
            if note:
                task["note"] = note[:200]
            out = dict(task)
        self.save()
        return out

    def clear_finished(self) -> int:
        """把做完的、彻底死掉的清掉，保留最近失败记录供前端看。"""
        with self._lock:
            keep, dropped = [], 0
            for t in self._tasks:
                if t["state"] in (_STATE_DONE, _STATE_SKIPPED, _STATE_DEAD):
                    dropped += 1
                    continue
                keep.append(t)
            self._tasks = keep
        if dropped:
            self.save()
        return dropped

    # ---------- 查询 ----------

    def snapshot(self) -> dict:
        """给前端看的：分状态计数 + 最近几条。"""
        with self._lock:
            counts = {}
            for t in self._tasks:
                counts[t["state"]] = counts.get(t["state"], 0) + 1
            recent = []
            for t in sorted(self._tasks, key=lambda x: x["created_ts"], reverse=True)[:60]:
                recent.append({
                    "id": t["id"], "kind": t["kind"],
                    "label": label_of(t["kind"]),
                    "key": t["key"], "state": t["state"],
                    "tries": t["tries"], "error": t["error"], "note": t["note"],
                    "created_at": _fmt(t["created_ts"]),
                    "started_at": _fmt(t["started_ts"]),
                    "finished_at": _fmt(t["finished_ts"]),
                })
            return {
                "counts": counts,
                "pending": counts.get(_STATE_PENDING, 0),
                "running": counts.get(_STATE_RUNNING, 0),
                "done": counts.get(_STATE_DONE, 0),
                "failed": counts.get(_STATE_FAILED, 0) + counts.get(_STATE_DEAD, 0),
                "total": len(self._tasks),
                "items": recent,
            }

    def has_pending(self, allowed=None) -> bool:
        now = _now()
        with self._lock:
            for t in self._tasks:
                if t["state"] != _STATE_PENDING:
                    continue
                if allowed is not None and t["kind"] not in allowed:
                    continue
                if t.get("next_try_ts", 0) > now:
                    continue
                return True
        return False

    def running(self) -> list[dict]:
        with self._lock:
            return [dict(t) for t in self._tasks if t["state"] == _STATE_RUNNING]

    def drop(self, kind: str, key: str = "") -> int:
        """把还没做的某类任务撤掉（用户关了某个功能时用）。"""
        with self._lock:
            keep, dropped = [], 0
            for t in self._tasks:
                if t["kind"] == kind and t["state"] == _STATE_PENDING and \
                        (not key or t["key"] == key):
                    dropped += 1
                    continue
                keep.append(t)
            self._tasks = keep
        if dropped:
            self.save()
        return dropped


if __name__ == "__main__":
    import tempfile
    d = tempfile.mkdtemp()
    q = Queue(os.path.join(d, "queue.json"))
    q.add("news", "all")
    q.add("news", "all")          # 重复，应该被 dedupe 掉
    q.add("music", "hot:5", {"count": 5})
    assert len(q.snapshot()["items"]) == 2, q.snapshot()
    t = q.pop_next()
    assert t["kind"] == "news", t
    q.set_state(t["id"], "failed", "网络断了")
    assert not q.has_pending({"news"}), "刚失败的不该马上又取到"
    t2 = q.pop_next({"music"})
    q.set_state(t2["id"], "done")
    q2 = Queue(os.path.join(d, "queue.json"))
    assert q2.snapshot()["done"] == 1, q2.snapshot()
    print("sched.py 自测通过", q2.snapshot()["counts"])
