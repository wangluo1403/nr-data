"""设置项的定义、默认值、读写。

newsd.py 启动时读一次 config.json，把值盖到自己的模块常量上；
网页上的设置面板就是照这份 SCHEMA 画出来的，改完存回 config.json 并当场生效，
不用重启（只有极个别项要重启，SCHEMA 里会标出来）。

放这儿单独一个文件，是因为 newsd.py 已经够长了。
"""

import json
import os

# ══════════════════════════════════════════════════════════════════════
#  默认值
# ══════════════════════════════════════════════════════════════════════

DEFAULTS = {
    # 联网节奏（v0.3：不再按 3 小时触发，一有网就抓，靠这个窗口去重）
    "online_dedupe_min": 20,
    "round_budget_min": 15,
    "disk_min_mb": 800,
    "idle_poll_s": 20,
    # 抓取
    "max_age_days": 14,
    "keep_snapshots": 6,
    # 正文
    "fetch_article": True,
    "max_articles_per_source": 5,
    "max_article_chars": 10000,
    # 图片
    "enrich_images": True,
    "max_images_per_source": 6,
    "img_max_kb": 3072,
    # 视频
    "fetch_video": True,
    "video_count": 50,
    "video_keep": 150,
    "video_max_min": 10,
    "video_qn": 32,
    # 速度
    "max_rate_mb": 1.5,
    # 必应搜索
    "search_keywords": [],
    "search_news": True,
    "search_fetch_article": True,
    "search_per_keyword": 10,
    # 镜像
    "mirror_js": False,
    "mirror_max_mb": 20,
    "mirror_auto": False,
    "mirror_auto_count": 3,
    "mirror_keep": 30,
    # 点歌台（网易云公开榜单）
    "music_enabled": True,
    "music_per_run": 4,
    "music_charts": ["热歌榜", "新歌榜"],
    "music_keep": 200,
    # B 站推荐 + 关键词搜索
    "bili_rec_enabled": True,
    "bili_rec_count": 12,
    "bili_keywords": [],
    "bili_search_count": 8,
    # 追番 / 追漫
    "anime_enabled": True,
    "anime_auto_follow": True,
    "anime_keywords": ["凡人修仙传", "鬼灭之刃", "间谍过家家",
                       "葬送的芙莉莲", "咒术回战", "进击的巨人"],
    # 权限与菜单
    "boot_mode": "password",       # password=开屏要口令 / direct=直接进新闻
    "admin_password_on": True,     # 管理员口令（只能禁用，不能改）
    "l1_search": True,             # 一级菜单里给不给搜索
    "l1_library": True,            # 一级菜单里给不给收藏/归档
    "weekday_open": "1,2,3,4,5,6,7",   # 这几天开放二级菜单（逗号分隔）
    "usb_bypass_time": True,       # U 盘插着无视时间表
    "exam_lock": False,            # 考试周：二级全锁（U 盘除外）
    "hide_log": False,             # 隐藏顶部实时日志
    "hide_buttons": False,         # 隐藏「立刻抓取 / 下载 / 激活」
    "lock_settings": False,        # 学生不能改设置
    "feat_video": True,
    "feat_music": True,
    "feat_bili": True,
    "feat_anime": True,
    "feat_mirror": True,
    "feat_search": True,
    # 更新
    "update_auto": True,           # 联网时自动检查更新（默认开）
    "update_interval_h": 24,
    # 权限与更新
    "password_on": True,
    "update_repo": "wangluo1403/nr-data",
    "cloud_url": "https://raw.githubusercontent.com/wangluo1403/nr-data/main/blocked.json",
    # 自定义源（结构见下面的 SCHEMA 说明）
    "custom_sources": [],
}

# ══════════════════════════════════════════════════════════════════════
#  设置面板的画法
# ══════════════════════════════════════════════════════════════════════
#
# type:
#   number  数字输入，带 min/max/step/unit
#   bool    开关
#   select  下拉，options 是 [[值, 显示文字], ...]
#   intlist 一行一个的文本框，存成字符串数组（用来编关键词）
#   sources 自定义源列表编辑器（专门的组件，不走通用渲染）
#   restart 改了要重启才生效（会显示个小标记）
#
# 想加设置项：DEFAULTS 里加个默认值，SCHEMA 里加一条，newsd.apply_config()
# 里加一行映射到谁身上。网页那边不用动，它是照这份表生成的。

SCHEMA = [
    {
        "group": "联网节奏",
        "hint": "一有网就抓，不用等三小时；这个窗口是用来防止「刚断又连」重复抓的",
        "items": [
            {"key": "online_dedupe_min", "label": "断网后等多久再找网", "type": "number",
             "unit": "分钟", "min": 0, "max": 180, "step": 5,
             "hint": "抓取完成之后不计时；一旦发现断网，才从这里开始计时，"
                     "到点才开始试探联网。点歌台和手动加的不受这条限制，有网就办"},
            {"key": "round_budget_min", "label": "单次窗口上限", "type": "number",
             "unit": "分钟", "min": 1, "max": 120, "step": 1,
             "hint": "一次联网最多抓多久。到点就停手，剩下的任务留到下次继续"},
            {"key": "disk_min_mb", "label": "磁盘警戒线", "type": "number",
             "unit": "MB", "min": 0, "max": 10000, "step": 100,
             "hint": "剩余空间低于这个数就不下新的了，先把已下载的看完。0 = 不管"},
            {"key": "idle_poll_s", "label": "探测间隔", "type": "number",
             "unit": "秒", "min": 5, "max": 300, "step": 5,
             "hint": "多久探一次网。越短越不容易错过热点，别低于 5 秒"},
        ],
    },
    {
        "group": "抓取",
        "hint": "抓回来留多久、怎么筛",
        "items": [
            {"key": "max_age_days", "label": "丢弃旧闻", "type": "number",
             "unit": "天", "min": 0, "max": 365, "step": 1,
             "hint": "发出来超过这么多天的新闻不要。0 = 不过滤"},
            {"key": "keep_snapshots", "label": "历史快照", "type": "number",
             "unit": "份", "min": 1, "max": 50, "step": 1,
             "hint": "网页上那个历史快照下拉能翻几份"},
        ],
    },
    {
        "group": "正文",
        "hint": "点开卡片看到的东西",
        "items": [
            {"key": "fetch_article", "label": "抓正文存本地", "type": "bool",
             "hint": "关掉就只剩摘要，能省不少时间和磁盘"},
            {"key": "max_articles_per_source", "label": "每源配正文", "type": "number",
             "unit": "篇", "min": 0, "max": 20, "step": 1,
             "hint": "每个源挑最靠前的几篇抓整篇"},
            {"key": "max_article_chars", "label": "正文长度上限", "type": "number",
             "unit": "字", "min": 1000, "max": 50000, "step": 1000,
             "hint": "一篇最多存多少字，超了截断"},
        ],
    },
    {
        "group": "封面图",
        "items": [
            {"key": "enrich_images", "label": "去原文页补封面", "type": "bool",
             "hint": "RSS 里没图时，打开原文页抠 og:image。关掉能快不少"},
            {"key": "max_images_per_source", "label": "每源封面数", "type": "number",
             "unit": "张", "min": 0, "max": 20, "step": 1},
            {"key": "img_max_kb", "label": "单图大小上限", "type": "number",
             "unit": "KB", "min": 100, "max": 10240, "step": 100,
             "hint": "超过这个的图不下，挡住那种几兆的大图"},
        ],
    },
    {
        "group": "短视频",
        "hint": "B 站热门榜",
        "items": [
            {"key": "fetch_video", "label": "抓短视频", "type": "bool",
             "hint": "关掉就只剩图文新闻"},
            {"key": "video_count", "label": "一轮抓几个", "type": "number",
             "unit": "个", "min": 0, "max": 200, "step": 1},
            {"key": "video_keep", "label": "本地留几个", "type": "number",
             "unit": "个", "min": 0, "max": 1000, "step": 10,
             "hint": "超了从最旧的开始删"},
            {"key": "video_max_min", "label": "最长时长", "type": "number",
             "unit": "分钟", "min": 1, "max": 60, "step": 1,
             "hint": "超过这个长度的不要"},
            {"key": "video_qn", "label": "清晰度", "type": "select",
             "options": [[16, "360P（最小）"], [32, "480P"], [64, "720P（最大）"]],
             "hint": "没登录 B 站时，实际最多给到 480P，2160P 那些要大会员"},
        ],
    },
    {
        "group": "下载速度",
        "hint": "别把老师的网占满",
        "items": [
            {"key": "max_rate_mb", "label": "限速", "type": "number",
             "unit": "MB/s", "min": 0, "max": 20, "step": 0.1,
             "hint": "所有下载加起来的总量，不是每个连接一份。0 = 不限速。"
                     "一轮约 750MB，1.5 档要 8.5 分钟，0.5 档要 25 分钟"},
        ],
    },
    {
        "group": "必应搜索",
        "hint": "按关键词去必应搜，结果单独放在「搜索」标签页",
        "items": [
            {"key": "search_keywords", "label": "搜索关键词", "type": "intlist",
             "rows": 5, "placeholder": "一行一个关键词",
             "hint": "每轮抓取时每个关键词都搜一遍。留空就不搜"},
            {"key": "search_news", "label": "顺便搜新闻", "type": "bool",
             "hint": "除了网页结果，再多搜一路必应新闻"},
            {"key": "search_fetch_article", "label": "搜索结果也抓正文", "type": "bool",
             "hint": "抓了才能断网读全文，代价是慢一些"},
            {"key": "search_per_keyword", "label": "每个词留几条", "type": "number",
             "unit": "条", "min": 1, "max": 30, "step": 1},
        ],
    },
    {
        "group": "点歌台",
        "hint": "趁有网从网易云公开榜单抓几首歌下来，断网也能听",
        "items": [
            {"key": "music_enabled", "label": "联网抓歌", "type": "bool",
             "hint": "关掉就只播本地 data\\music 里你自己放进去的歌"},
            {"key": "music_per_run", "label": "一次抓几首", "type": "number",
             "unit": "首", "min": 0, "max": 30, "step": 1,
             "hint": "一首约 4MB。抓的时候会跳过 VIP、无版权的歌"},
            {"key": "music_charts", "label": "从哪些榜挑", "type": "intlist",
             "rows": 2, "placeholder": "热歌榜, 新歌榜",
             "hint": "可选：热歌榜 / 新歌榜 / 飙升榜 / 原创榜。用逗号分开"},
            {"key": "music_keep", "label": "本地留几首", "type": "number",
             "unit": "首", "min": 10, "max": 2000, "step": 10,
             "hint": "超了从最久没听的开始删，收藏的不删"},
        ],
    },
    {
        "group": "B 站",
        "hint": "首页推荐和关键词搜索，只存条目信息，热门榜那种才下视频",
        "items": [
            {"key": "bili_rec_enabled", "label": "每次联网抓首页推荐", "type": "bool"},
            {"key": "bili_rec_count", "label": "推荐留几条", "type": "number",
             "unit": "条", "min": 0, "max": 50, "step": 1},
            {"key": "bili_keywords", "label": "搜索关键词", "type": "intlist",
             "rows": 3, "placeholder": "一行一个关键词",
             "hint": "每次联网轮流搜一个词，搜到的条目攒起来"},
            {"key": "bili_search_count", "label": "每个词留几条", "type": "number",
             "unit": "条", "min": 1, "max": 50, "step": 1},
        ],
    },
    {
        "group": "追番追漫",
        "items": [
            {"key": "anime_enabled", "label": "联网检查更新", "type": "bool",
             "hint": "在「追更」里加的番剧、漫画，每次联网查一次有没有新集"},
            {"key": "anime_auto_follow", "label": "自动追几部热门的", "type": "bool",
             "hint": "追更列表空着的时候，先按下面的名字自动追几部，省得一个个搜"},
            {"key": "anime_keywords", "label": "自动追这些", "type": "intlist",
             "rows": 3, "placeholder": "一行一个番剧名",
             "hint": "联网时按这些名字各搜一次，第一个结果加进追更。"
                     "注意：漫画接口 B 站锁了（要 APP 签名），只能追番剧"},
        ],
    },
    {
        "group": "权限与菜单",
        "admin": True,
        "hint": "谁能在什么时候看到什么 —— 学生端只看新闻，二级菜单要口令或 U 盘",
        "items": [
            {"key": "boot_mode", "label": "打开时", "type": "select",
             "options": [["password", "先要口令"], ["direct", "直接进新闻"]],
             "hint": "要口令时屏幕上会给一行数字，按单双数加减算出答案"},
            {"key": "admin_password_on", "label": "启用管理员口令", "type": "bool",
             "hint": "关掉之后二级菜单只能靠 U 盘进。口令是写死的，不能改"},
            {"key": "l1_search", "label": "一级给搜索", "type": "bool"},
            {"key": "l1_library", "label": "一级给收藏/归档", "type": "bool"},
            {"key": "weekday_open", "label": "二级开放日", "type": "text",
             "placeholder": "1,2,3,4,5,6,7",
             "hint": "周一到周日填数字，逗号分隔。没列出来的日子只剩新闻"},
            {"key": "usb_bypass_time", "label": "U 盘无视时间表", "type": "bool"},
            {"key": "exam_lock", "label": "考试周锁死二级", "type": "bool",
             "hint": "开了之后二级全锁，只有 U 盘能进"},
            {"key": "hide_log", "label": "隐藏实时日志", "type": "bool"},
            {"key": "hide_buttons", "label": "隐藏抓取/下载/激活按钮", "type": "bool"},
            {"key": "lock_settings", "label": "禁止学生改设置", "type": "bool"},
            {"key": "feat_video", "label": "显示视频", "type": "bool"},
            {"key": "feat_music", "label": "显示点歌台", "type": "bool"},
            {"key": "feat_bili", "label": "显示 B 站", "type": "bool"},
            {"key": "feat_anime", "label": "显示追更", "type": "bool"},
            {"key": "feat_mirror", "label": "显示镜像", "type": "bool"},
            {"key": "feat_search", "label": "显示搜索页", "type": "bool"},
        ],
    },
    {
        "group": "更新",
        "admin": True,
        "hint": "从 GitHub 拉新版覆盖代码，data 和 config 不动",
        "items": [
            {"key": "update_auto", "label": "联网时自动更新", "type": "bool"},
            {"key": "update_interval_h", "label": "多久查一次", "type": "number",
             "unit": "小时", "min": 1, "max": 720, "step": 1},
        ],
    },
    {
        "group": "权限与更新",
        "admin": True,
        "hint": "启动密码、激活码、U 盘钥匙、在线更新",
        "items": [
            {"key": "password_on", "label": "打开时要密码", "type": "bool",
             "hint": "密码不是自己设的，是按本机机器码算出来的，界面上能看到算法"},
            {"key": "update_repo", "label": "版本仓库", "type": "text",
             "placeholder": "用户名/仓库名",
             "hint": "填了就在 U 盘插上时去 GitHub 拉最新版；留空不检查更新"},
            {"key": "cloud_url", "label": "云端禁用名单", "type": "text",
             "placeholder": "https://raw.githubusercontent.com/用户名/仓库/main/blocked.json",
             "hint": "一个 JSON 文件地址，里面是本机的机器码就停服务。留空不检查"},
        ],
    },
    {
        "group": "自定义抓取地址",
        "hint": "RSS 和普通网页都行，喂进去自动判断",
        "items": [
            {"key": "custom_sources", "label": "自定义源", "type": "sources"},
        ],
    },
    {
        "group": "离线网页镜像",
        "hint": "把整个页面连 CSS、图片、字体一起扒下来，断网打开还原原样",
        "items": [
            {"key": "mirror_js", "label": "连 JavaScript 也扒", "type": "bool",
             "hint": "部分靠 JS 渲染的站点才显示得出来。默认关 —— 文件大，"
                     "而且有些站的脚本会偷偷往外连"},
            {"key": "mirror_max_mb", "label": "单个镜像上限", "type": "number",
             "unit": "MB", "min": 1, "max": 100, "step": 1,
             "hint": "扒到这个大小就停，免得一个页面把磁盘吃光"},
            {"key": "mirror_auto", "label": "顺手扒搜索结果", "type": "bool",
             "hint": "每轮把搜索到的前几个页面也扒成镜像。不开的话，"
                     "就在「镜像」标签页里手动填网址扒"},
            {"key": "mirror_auto_count", "label": "每轮扒几个", "type": "number",
             "unit": "个", "min": 1, "max": 10, "step": 1,
             "hint": "一个镜像几 MB 到十几 MB，别贪多"},
            {"key": "mirror_keep", "label": "最多留几个", "type": "number",
             "unit": "个", "min": 1, "max": 200, "step": 5,
             "hint": "超了从最旧的开始删"},
        ],
    },
]


def config_path(base_dir: str) -> str:
    return os.path.join(base_dir, "config.json")


def _coerce(key: str, val):
    """把从网上来的值掰成该有的类型。掰不动就用默认值。"""
    dflt = DEFAULTS[key]
    try:
        if isinstance(dflt, bool):
            if isinstance(val, str):
                return val.strip().lower() in ("1", "true", "yes", "on")
            return bool(val)
        if isinstance(dflt, int) and not isinstance(dflt, bool):
            return int(float(val))
        if isinstance(dflt, float):
            return float(val)
        if isinstance(dflt, list):
            if isinstance(val, str):
                return [ln.strip() for ln in val.splitlines() if ln.strip()]
            if isinstance(val, list):
                return val
            return list(dflt)
        if isinstance(dflt, str):
            # 中文逗号统一成英文的
            return str(val).strip().replace("，", ",")
    except (TypeError, ValueError):
        return dflt
    return val


def get_limits(key: str):
    """从 SCHEMA 里抠出这个键的 min/max/step/options，没有就返回空。"""
    for grp in SCHEMA:
        for it in grp["items"]:
            if it["key"] == key:
                return it
    return {}


def _clamp(key: str, val):
    spec = get_limits(key)
    if spec.get("type") == "number" and isinstance(val, (int, float)):
        lo, hi = spec.get("min"), spec.get("max")
        if lo is not None and val < lo:
            val = lo
        if hi is not None and val > hi:
            val = hi
        if isinstance(DEFAULTS[key], int) and not isinstance(DEFAULTS[key], bool):
            val = int(round(val))
    if spec.get("type") == "select":
        allowed = [o[0] for o in spec.get("options", [])]
        if allowed and val not in allowed:
            val = DEFAULTS[key]
    return val


def normalize_custom_sources(raw) -> list:
    """自定义源列表：丢掉残缺的，补齐字段，id 给个稳定的 custom_N。"""
    out = []
    if not isinstance(raw, list):
        return out
    for i, s in enumerate(raw):
        if not isinstance(s, dict):
            continue
        url = (s.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            continue
        out.append({
            "id": "custom_%d" % (i + 1),
            "name": (s.get("name") or "").strip() or ("自定义源 %d" % (i + 1)),
            "cat": (s.get("cat") or "科技").strip(),
            "url": url,
            "limit": max(1, min(50, int(s.get("limit") or 10))),
            "enabled": bool(s.get("enabled", True)),
        })
    # 重新编号，保证删掉中间某个之后 id 还是连着的
    for i, s in enumerate(out):
        s["id"] = "custom_%d" % (i + 1)
    return out


def normalize(raw: dict) -> dict:
    """补齐缺的键、纠类型、夹范围。config.json 被人手改坏了也能救回来。"""
    raw = raw if isinstance(raw, dict) else {}
    out = {}
    for k, dflt in DEFAULTS.items():
        if k not in raw:
            out[k] = list(dflt) if isinstance(dflt, list) else dflt
            continue
        if k == "custom_sources":
            out[k] = normalize_custom_sources(raw[k])
        else:
            out[k] = _clamp(k, _coerce(k, raw[k]))
    # 关键词顺手去重、去空
    seen, kws = set(), []
    for w in out.get("search_keywords") or []:
        w = str(w).strip()
        if w and w not in seen:
            seen.add(w)
            kws.append(w)
    out["search_keywords"] = kws
    return out


def load(base_dir: str) -> dict:
    """读 config.json，没有/坏了都回落到默认值。"""
    path = config_path(base_dir)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return normalize(json.load(f))
    except (OSError, ValueError):
        return normalize({})


def save(base_dir: str, cfg: dict) -> dict:
    """存回 config.json，返回规范化之后的结果。"""
    cfg = normalize(cfg)
    path = config_path(base_dir)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2, sort_keys=False)
    os.replace(tmp, path)
    return cfg
