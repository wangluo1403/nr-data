# -*- coding: utf-8 -*-
"""B 站二创内容：首页随机推荐 / 关键词搜索 / 追番追漫 / 番剧候选。

跟 videos.py 一个路子——纯标准库、零 pip、显式禁代理。这一版只拿元数据，
视频文件和封面图交给调用方（拿 pic_url / bvid 自己下），本模块不落盘。

2026-10-31 实测（家宽 + 显式禁代理，见文末自测）：

  ✔ 推荐流  /x/web-interface/index/top/feed/rcmd  不用 wbi 签名，code=0，
            fresh_idx 换个数字就换一批内容，天然满足"每轮不一样"。
  ✔ 热门榜  /x/web-interface/ranking/v2            不用签名，一次 100 条，推荐流挂了拿它兜底。
  ✔ 热门    /x/web-interface/popular               不用签名，20 条/页。
  ✔ 搜索    /x/web-interface/search/type           不带 cookie 连打几次会 412，
            带上任意 buvid3（格式 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxinfoc）就稳定。
            所以本模块自己发这个请求、自己塞 buvid3；sess 的方法没有 header 口子。
  ✔ 番剧详情 /pgc/view/web/season                  不用签名，连 bvid/cid 都给，调用方能直接下。
  ✔ 番剧时间线 /pgc/web/timeline                   不用签名，单部详情挂了拿它按 season_id 兜底。
  ✔ 番剧搜索 /x/web-interface/search/type?search_type=media_bangumi   能搜到 season_id。
  ✘ 漫画     manga.bilibili.com/twirp/...          Comic/Search、ComicDetail 全返回
            {"code":99}；补 Origin / Referer / device=pc&platform=web / buvid3 都还是 99，
            说明它要 twirp 的签名头（APP 那套 access_key），离线工具做不了。
            所以漫画这一路**明确返回 []**，不硬造字段。
"""

import json
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

REFERER = "https://www.bilibili.com/"
MANGA_REFERER = "https://manga.bilibili.com/"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

API_RCMD = "https://api.bilibili.com/x/web-interface/index/top/feed/rcmd"
API_RANKING = "https://api.bilibili.com/x/web-interface/ranking/v2"
API_POPULAR = "https://api.bilibili.com/x/web-interface/popular"
API_SEARCH = "https://api.bilibili.com/x/web-interface/search/type"
API_SEASON = "https://api.bilibili.com/pgc/view/web/season"
API_TIMELINE = "https://api.bilibili.com/pgc/web/timeline"
API_MANGA_DETAIL = "https://manga.bilibili.com/twirp/comic.v1.Comic/ComicDetail"
API_MANGA_SEARCH = "https://manga.bilibili.com/twirp/comic.v1.Comic/Search"

# 这台机器系统代理/TLS 是坏的，两个 opener 都显式禁代理；
# 第二个放开证书校验，B 站部分 CDN 证书链不全。
_PLAIN = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_LAX = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))

_BV_RE = re.compile(r"^BV[0-9A-Za-z]{8,14}$")
_EM_RE = re.compile(r"</?em[^>]*>", re.I)
_TAG_RE = re.compile(r"<[^>]+>")

_rand = random.Random()

# 上一轮推过的 bvid，用来保证"这轮跟上轮不一样"
_REC_SEEN = set()
_REC_ORDER = []

# 追番的内存基线：follows 里没带 last_ep_id 时，靠它判断"有没有新集"
_SEEN_EP = {}

_WARNED = set()


# ---------------------------------------------------------------- 小工具

def _warn(log, msg):
    """同一句话只喊一次，免得日志被刷屏。"""
    if msg in _WARNED:
        return
    _WARNED.add(msg)
    try:
        log(msg)
    except Exception:
        pass


def _vpic(u):
    if not u:
        return ""
    u = u.strip()
    if u.startswith("//"):
        return "https:" + u
    return u.replace("http://", "https://", 1)


def _clean_title(s):
    """搜索结果标题里带 <em class="keyword"> 高亮，喂给前端前洗掉。"""
    return _TAG_RE.sub("", _EM_RE.sub("", s or "")).strip()


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _dur_s(v):
    """duration 两种形态：推荐/热门给秒数，搜索结果给 "MM:SS" 或 "H:MM:SS"。"""
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v or "").strip()
    if not s:
        return 0
    if ":" not in s:
        return _int(s)
    parts = [_int(x) for x in s.split(":")]
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return 0


def _dur_text(s):
    s = _int(s)
    if s <= 0:
        return "0:00"
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return ("%d:%02d:%02d" % (h, m, sec)) if h else ("%d:%02d" % (m, sec))


def _buvid3():
    """任意合规格式的 buvid3 就够过 412，不需要真去首页领。"""
    h = "%08X-%04X-%04X-%04X-%012X" % (
        _rand.getrandbits(32), _rand.getrandbits(16), _rand.getrandbits(16),
        _rand.getrandbits(16), _rand.getrandbits(48))
    return h + "infoc"


# ---------------------------------------------------------------- 网络

def _own_open(url, timeout=15, referer=REFERER, cookie="", data=None,
              content_type=""):
    req = urllib.request.Request(url, data=data)
    req.add_header("User-Agent", UA)
    req.add_header("Referer", referer)
    req.add_header("Accept", "application/json, text/plain, */*")
    if cookie:
        req.add_header("Cookie", cookie)
    if content_type:
        req.add_header("Content-Type", content_type)
    try:
        return _PLAIN.open(req, timeout=timeout)
    except urllib.error.HTTPError:
        raise
    except Exception:
        # 证书链坏掉的 CDN 走宽松通道
        return _LAX.open(req, timeout=timeout)


def _own_json(url, timeout=15, cookie=None, referer=REFERER):
    """自己发 GET。cookie=None 表示不带；"" 表示不带；否则用给定值。

    412 是 B 站的风控（缺 buvid3，或者关键词连发太快）。连续两次
    "猫"就被挡了，"柴犬"隔一下又好了，所以这里换个 buvid3 重试两轮，
    间隔逐次拉长，别一被挡就整路作废。
    """
    last = None
    for attempt in range(3):
        ck = _buvid3() if cookie is None else cookie
        try:
            with _own_open(url, timeout, referer, ck) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 412 and attempt < 2:
                time.sleep(0.5 + attempt)
                continue
            raise
    raise last


def _sess_json(sess, url, timeout):
    d = sess.get_json(url, referer=REFERER, timeout=timeout)
    if not isinstance(d, dict):
        raise ValueError("sess.get_json 返回的不是 dict")
    return d


def _api(sess, url, timeout=15, log=print, what="接口", own_first=False):
    """按约定先走 sess，不行再自己带 buvid3 兜底。

    两条通道都失败就返回 {}，调用方自己决定退回哪一路，本函数不抛异常。
    """
    err = ""
    order = ("own", "sess") if own_first else ("sess", "own")
    for which in order:
        try:
            if which == "sess":
                d = _sess_json(sess, url, timeout)
            else:
                d = _own_json(url, timeout)
            if isinstance(d, dict) and d.get("code") == 0:
                return d
            err = "code=%s %s" % ((d or {}).get("code"), (d or {}).get("message"))
        except Exception as e:  # noqa: BLE001
            err = "%s: %s" % (type(e).__name__, str(e)[:80])
    _warn(log, "  %s 两条通道都没通（%s）" % (what, err))
    return {}


# ---------------------------------------------------------------- 条目归一

def _row_video(v, source):
    """把推荐流 / 热门榜 / 搜索 三种结构揉成同一个 dict。

    推荐流的 desc 常是 null，搜索结果用 description，热门用 desc；
    duration 在搜索里是 "MM:SS"；view 在搜索里叫 play。
    字段缺就填 0 / ""，绝不瞎编。
    """
    owner = v.get("owner") or {}
    stat = v.get("stat") or {}
    bvid = (v.get("bvid") or "").strip()
    return {
        "bvid": bvid,
        "aid": _int(v.get("aid") if v.get("aid") is not None else v.get("id")),
        "cid": _int(v.get("cid")),
        "title": _clean_title(v.get("title")),
        # 搜索只有 author 没有 owner
        "up": (owner.get("name") or v.get("author") or "").strip(),
        "duration_s": _dur_s(v.get("duration")),
        "view": _int(stat.get("view") if stat.get("view") is not None
                     else v.get("play")),
        "pic_url": _vpic(v.get("pic")),
        "desc": ((v.get("desc") if v.get("desc") is not None
                  else v.get("description")) or "").strip()[:300],
        "url": ("https://www.bilibili.com/video/" + bvid) if bvid else "",
        "source": source,
    }


def _merge(rows, count):
    """按 bvid 去重、丢掉没有 bvid 的，凑够 count 条。"""
    seen, out = set(), []
    for r in rows:
        bv = r.get("bvid") or ""
        if not _BV_RE.match(bv) or bv in seen:
            continue
        seen.add(bv)
        out.append(r)
        if len(out) >= count:
            break
    return out


def _remember(bvids):
    """记下这轮推过的，下一轮优先换新面孔。"""
    for bv in bvids:
        if bv in _REC_SEEN:
            continue
        _REC_SEEN.add(bv)
        _REC_ORDER.append(bv)
    while len(_REC_ORDER) > 400:          # 只留最近 400 个，内存别涨
        _REC_SEEN.discard(_REC_ORDER.pop(0))


# ---------------------------------------------------------------- 1. 首页随机推荐

def home_rec(sess, count=10, timeout=15, log=print):
    """B 站首页随机推荐。

    三路依次试：推荐流（换 fresh_idx 就是随机）→ 热门榜 → 热门。
    推荐流不用签名，实测 fresh_idx=1/2/7 拿到的是三批完全不同的视频，
    所以"随机"不靠洗牌硬凑，而是每轮抽一个 fresh_idx。
    再叠一层"避开上一轮 bvid"的过滤，保证连续两轮不撞车。

    只返回元数据 + pic_url，封面图要调用方自己 save_stream，
    因为签名里没有存图路径参数。
    """
    rows = []

    idx = _rand.randint(1, 12)
    url = ("%s?ps=20&fresh_idx=%d&fresh_type=3&feed_version=V8"
           % (API_RCMD, idx))
    d = _api(sess, url, timeout, log, "首页推荐流")
    items = ((d.get("data") or {}).get("item") or [])
    n0 = 0
    for v in items:
        # 推荐流里混着直播卡、广告卡，goto 不是 av 的不要
        if (v.get("goto") or "av") not in ("av", ""):
            continue
        if not _BV_RE.match((v.get("bvid") or "").strip()):
            continue
        rows.append(_row_video(v, "rcmd"))
        n0 += 1
    if n0:
        log("  首页推荐流 fresh_idx=%d → %d 条" % (idx, n0))
    else:
        _warn(log, "  首页推荐流这轮没给视频卡，改用榜单")

    if len(rows) < count:
        d = _api(sess, API_RANKING + "?rid=0&type=all", timeout, log, "热门榜")
        lst = ((d.get("data") or {}).get("list") or [])
        for v in lst:
            rows.append(_row_video(v, "ranking"))
        if lst:
            log("  热门榜 → %d 条" % len(lst))

    if len(rows) < count:
        d = _api(sess, "%s?ps=20&pn=%d" % (API_POPULAR, _rand.randint(1, 3)),
                 timeout, log, "热门视频")
        lst = ((d.get("data") or {}).get("list") or [])
        for v in lst:
            rows.append(_row_video(v, "popular"))
        if lst:
            log("  热门视频 → %d 条" % len(lst))

    if not rows:
        return []

    uniq = _merge(rows, len(rows))
    fresh = [r for r in uniq if r["bvid"] not in _REC_SEEN]
    pool = fresh if len(fresh) >= count else uniq       # 新面孔不够就整池洗牌
    _rand.shuffle(pool)
    picked = pool[:count]
    _remember(r["bvid"] for r in picked)
    return picked


# ---------------------------------------------------------------- 2. 关键词搜索

def search(sess, keyword, count=10, timeout=15, log=print):
    """按关键词搜 B 站视频（search_type=video），字段同 home_rec。

    keyword 传 str 就搜一个词；传 list/tuple 就是"多关键词"——本模块自己
    循环打接口再按 bvid 合并，因为 B 站这个接口一次只吃一个 keyword。
    （翻页参数 page=2 实测也能用，但前端一次只要十来条，没做。）

    这条接口不带 buvid3 会被 412 挡，而 sess.get_json 没有 header 口子，
    所以这里 own_first=True：先用本模块自己的 opener 带 buvid3 发，
    失败再退回 sess。
    """
    if isinstance(keyword, (list, tuple, set)):
        kws = [str(k).strip() for k in keyword if str(k or "").strip()]
    else:
        kws = [str(keyword or "").strip()]
    kws = [k for k in kws if k]
    if not kws:
        return []

    rows, got_log = [], []
    for n, kw in enumerate(kws):
        if n:
            time.sleep(0.8)     # 连发关键词会被 412，隔一下稳得多
        url = ("%s?search_type=video&page=1&pagesize=20&keyword=%s"
               % (API_SEARCH, urllib.parse.quote(kw)))
        d = _api(sess, url, timeout, log, "搜索「%s」" % kw, own_first=True)
        res = ((d.get("data") or {}).get("result") or [])
        for v in res:
            # 偶尔混进 type=ketang(课堂)/article 的别要
            if (v.get("type") or "video") != "video":
                continue
            rows.append(_row_video(v, "search"))
        got_log.append("「%s」%d" % (kw, len(res)))

    out = _merge(rows, count)
    log("  搜索 %s → 合并去重 %d 条" % ("、".join(got_log), len(out)))
    return out


# ---------------------------------------------------------------- 3. 追番 / 追漫

def _season(sess, sid, timeout, log):
    d = _api(sess, "%s?season_id=%s" % (API_SEASON, sid), timeout, log,
             "番剧详情 %s" % sid)
    return d.get("result") or {}


def _timeline_map(sess, timeout, log):
    """今日更新总表，单部详情挂了按 season_id 兜底用。全站一份，别每部都拉。"""
    d = _api(sess, API_TIMELINE + "?types=1&before=0&after=0", timeout, log,
             "番剧更新时间线")
    m = {}
    for day in (d.get("result") or []):
        for e in (day.get("episodes") or []):
            sid = str(e.get("season_id") or "")
            if not sid:
                continue
            # 同一天同一部可能有多集，留 pub_index 最大的那条（就是最新）
            old = m.get(sid)
            if old is None or str(e.get("pub_index") or "") > str(old.get("pub_index") or ""):
                m[sid] = e
    return m


def _ep_index(ep, fallback):
    t = str(ep.get("title") or "").strip()
    return t if t else str(fallback)


def check_bangumi(sess, follows, timeout=15, log=print):
    """检查"在追"的番剧/漫画有没有更新。

    判"新"的基线，按优先级取：
      1) follows[i]["last_ep_id"] —— 调用方存的上次返回的 ep_id（推荐用这个）
      2) follows[i]["last_ep"]    —— 上次的集号/集名，字符串比
      3) 本进程里上次检查记下的 ep_id
    三样都没有就是首次检查，直接把当前最新一集报上去（并写入内存基线），
    不装作"没更新"，也不编一条假的更新事件。

    返回项里除了约定的字段，多给 ep_id / bvid / cid / updated_ts：
    ep_id 让调用方存基线，bvid+cid 拿得到片源时能直接交给下载器。

    漫画：manga.bilibili.com 的 twirp 接口一律 code=99（要 APP 签名），
    所以 type=漫画 的条目直接跳过，并在日志里说清楚，绝不硬造。
    """
    out = []
    tl = None
    manga_warned = False

    for f in (follows or []):
        if not isinstance(f, dict):
            continue
        sid = str(f.get("sid") or "").strip()
        typ = str(f.get("type") or "番剧").strip()
        title = str(f.get("title") or "").strip()
        if not sid:
            continue

        if "漫画" in typ:
            if not manga_warned:
                manga_warned = True
                _warn(log, "  漫画接口被拦（twirp 要 APP 签名，code=99），漫画条目本轮跳过")
            continue

        detail = _season(sess, sid, timeout, log)
        eps = detail.get("episodes") or []
        if eps:
            last = eps[-1] or {}
            ep_id = last.get("id") or last.get("ep_id") or 0
            idx_txt = _ep_index(last, len(eps))
            ep_title = (last.get("long_title") or "").strip()
            cover = _vpic(last.get("cover") or detail.get("cover") or "")
            ts = _int(last.get("pub_time"))
            bvid = last.get("bvid") or ""
            cid = _int(last.get("cid"))
            total = len(eps)
        else:
            # 单部详情挂了：用今日更新时间线兜底（只有今天更新的才查得到）
            if tl is None:
                tl = _timeline_map(sess, timeout, log)
            e = tl.get(sid)
            if not e:
                log("  追番 %s(%s) 查不到，跳过" % (title or "?", sid))
                continue
            ep_id = e.get("episode_id") or 0
            idx_txt = str(e.get("pub_index") or "")
            ep_title = ""
            cover = _vpic(e.get("cover") or "")
            # 时间线只给 "10:00" 这种时刻，没有日期戳，不能瞎凑秒数
            ts = 0
            bvid = ""
            cid = 0
            total = 0

        key = ("番剧", sid)
        base = (f.get("last_ep_id") or f.get("last_ep")
                or _SEEN_EP.get(key) or "")
        if base:
            b = str(base).strip()
            same = (b == str(ep_id)) or (b == idx_txt) or (b == "第%s话" % idx_txt)
            if same:
                continue        # 没新集

        _SEEN_EP[key] = ep_id or idx_txt
        item = {
            "sid": sid,
            "type": "番剧",
            "title": title or (detail.get("title") or "").strip(),
            "new_ep": idx_txt,
            "new_ep_title": ep_title,
            "updated_at": (time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
                           if ts else ""),
            "cover_url": cover,
            "url": ("https://www.bilibili.com/bangumi/play/ep%d" % ep_id
                    if ep_id else "https://www.bilibili.com/bangumi/play/ss%s" % sid),
            # 下面几项是给调用方的附加信息，不影响上面约定字段
            "ep_id": ep_id,
            "bvid": bvid,
            "cid": cid,
            "updated_ts": ts,
            "total_ep": total,
        }
        out.append(item)
        log("  追番「%s」有新集：%s %s"
            % (item["title"] or sid, idx_txt, ep_title))

    return out


# ---------------------------------------------------------------- 4. 番剧候选

def bangumi_candidates(sess, keyword, timeout=15, log=print):
    """按关键词搜番剧/漫画，给前端"加追"用。

    番剧走 search_type=media_bangumi，实测能出 season_id / 封面 / 集数。
    漫画走 manga.bilibili.com 的 twirp 搜索，实测一律 code=99（要 APP 签名），
    所以这一路直接返回空，不伪造条目——前端加追漫画暂时只能手填 sid。

    total_ep：优先 ep_size（接口给的集数），没有再数 eps 数组长度；
    index_show 那种"更新至第197话"塞进 desc 尾巴里，不单开字段。
    """
    kw = str(keyword or "").strip()
    if not kw:
        return []
    url = ("%s?search_type=media_bangumi&page=1&keyword=%s"
           % (API_SEARCH, urllib.parse.quote(kw)))
    d = _api(sess, url, timeout, log, "番剧搜索「%s」" % kw, own_first=True)
    res = ((d.get("data") or {}).get("result") or [])
    if not res:
        log("  番剧搜索「%s」没结果" % kw)

    out, seen = [], set()
    for r in res:
        sid = str(r.get("season_id") or r.get("pgc_season_id") or "").strip()
        if not sid or sid in seen:
            continue
        seen.add(sid)
        eps = r.get("eps") or []
        total = _int(r.get("ep_size")) or len(eps)
        desc = _clean_title(r.get("desc") or "")
        show = (r.get("index_show") or "").strip()
        if show:
            desc = (desc + " ｜ " + show).strip(" ｜")[:300]
        out.append({
            "sid": sid,
            "type": "番剧",
            "title": _clean_title(r.get("title")),
            "cover_url": _vpic(r.get("cover") or ""),
            "total_ep": total,
            "desc": desc[:300],
            "url": "https://www.bilibili.com/bangumi/play/ss%s" % sid,
        })
    return out


# ---------------------------------------------------------------- 自测

class _Sess:
    """自测用的最小 sess，跟主控约定的三个方法对齐（都不带自定义 header）。"""

    def __init__(self, timeout=15):
        self.timeout = timeout

    def get_bytes(self, url, referer="", timeout=15):
        with _own_open(url, timeout or self.timeout, referer or REFERER, "") as r:
            return r.read()

    def get_json(self, url, referer="", timeout=15):
        with _own_open(url, timeout or self.timeout, referer or REFERER, "") as r:
            return json.loads(r.read().decode("utf-8", "replace"))

    def save_stream(self, url, dest_path, referer="", timeout=30, max_bytes=0):
        """下载到 dest_path，返回字节数；超 max_bytes 就中断。"""
        total = 0
        with _own_open(url, timeout, referer or REFERER, "") as r, open(dest_path, "wb") as f:
            while True:
                chunk = r.read(262144)
                if not chunk:
                    break
                total += len(chunk)
                if max_bytes and total > max_bytes:
                    raise ValueError("超过 max_bytes")
                f.write(chunk)
        return total


def _self_test():
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass

    sess = _Sess()
    print("=" * 60)
    print("1) home_rec（连跑两轮看是不是换了内容）")
    for rnd in (1, 2):
        items = home_rec(sess, count=5, timeout=15)
        print("  第 %d 轮 %d 条" % (rnd, len(items)))
        for it in items[:3]:
            print("   ", it["bvid"], "|", it["title"][:28], "|", it["up"][:10],
                  "|", _dur_text(it["duration_s"]), "s |", it["view"], "播放",
                  "|", it["source"])

    print("=" * 60)
    print("2) search 单个关键词")
    items = search(sess, "原神", count=5)
    print("  拿到 %d 条" % len(items))
    for it in items[:3]:
        print("   ", it["bvid"], "|", it["title"][:28], "|", it["up"][:10],
              "|", _dur_text(it["duration_s"]), "|", it["pic_url"][:50])

    print("-" * 60)
    print("2b) search 多关键词（list 形式）")
    items = search(sess, ["猫", "柴犬"], count=6)
    print("  拿到 %d 条：%s" % (len(items), "、".join(i["bvid"] for i in items[:6])))

    print("=" * 60)
    print("3) check_bangumi")
    follows = [
        {"sid": "28747", "type": "番剧", "title": "凡人修仙传"},
        {"sid": "332584", "type": "番剧", "title": "功夫熊猫：神龙骑士 第二季"},
        {"sid": "26009", "type": "漫画", "title": "某漫画（预期被拦）"},
    ]
    ups = check_bangumi(sess, follows)
    print("  有更新 %d 条" % len(ups))
    for u in ups:
        print("   ", u["title"], "| 新集:", u["new_ep"], u["new_ep_title"],
              "| ep_id:", u["ep_id"], "| bvid:", u["bvid"] or "-",
              "|", u["updated_at"])
    print("  再查一次（同一批 follows，应判没新集）")
    ups2 = check_bangumi(sess, follows)
    print("  第二遍有更新 %d 条" % len(ups2))

    print("=" * 60)
    print("4) bangumi_candidates 「鬼灭」")
    cands = bangumi_candidates(sess, "鬼灭")
    print("  拿到 %d 条" % len(cands))
    for c in cands[:3]:
        print("   ", c["sid"], "|", c["title"][:26], "|", c["total_ep"], "集 |",
              c["desc"][:30])


if __name__ == "__main__":
    _self_test()
