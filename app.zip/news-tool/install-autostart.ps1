# install-autostart.ps1
# Add a shortcut to the Startup folder so newsd.py runs at logon.
# No administrator rights needed. Output is English to avoid console encoding issues.

$ErrorActionPreference = "Stop"

$proj = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $proj "newsd.py"

if (-not (Test-Path $script)) {
    Write-Host "[X] newsd.py not found next to this script."
    exit 1
}

# Prefer the bundled portable Python, fall back to whatever is in PATH.
$portableW = Join-Path $proj "python\pythonw.exe"
$portable  = Join-Path $proj "python\python.exe"

if (Test-Path $portableW) {
    $target = $portableW
} elseif (Test-Path $portable) {
    $target = $portable
} else {
    $pyExe = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
    if (-not $pyExe) {
        $pyExe = (Get-Command py.exe -ErrorAction SilentlyContinue).Source
    }
    if (-not $pyExe) {
        Write-Host "[X] No Python found: neither python\python.exe here nor python.exe in PATH."
        Write-Host "    Put a portable Python into the python\ subfolder, or install Python 3.8+."
        exit 1
    }
    # Prefer pythonw.exe: no console window popping up at every logon.
    $pyw = Join-Path (Split-Path $pyExe) "pythonw.exe"
    if (Test-Path $pyw) { $target = $pyw } else { $target = $pyExe }
}

$startup = [Environment]::GetFolderPath('Startup')
$lnkPath = Join-Path $startup "OfflineNews.lnk"

$shell = New-Object -ComObject WScript.Shell
$sc = $shell.CreateShortcut($lnkPath)
$sc.TargetPath       = $target
$sc.Arguments        = '"' + $script + '"'
$sc.WorkingDirectory = $proj
$sc.WindowStyle      = 7
$sc.Description      = "Offline news fetcher (newsd.py)"
$sc.Save()

Write-Host "[OK] autostart installed."
Write-Host ("     shortcut : " + $lnkPath)
Write-Host ("     target   : " + $target)
Write-Host ("     script   : " + $script)
Write-Host ""
Write-Host "It will start automatically next time you log in."
Write-Host "To start it right now:  start.bat   (or just double-click it)"
