/* ============================================================
   anime.js — 追更（整页）
   ------------------------------------------------------------
   对外只暴露 window.AnimeUI：
     AnimeUI.mount(container)  把界面画进 container
     AnimeUI.unmount()         停轮询、拆监听

   纯原生 JS，无模块、无外部依赖；数据来自 /api/anime 和 /api/follows。
   类名统一 an- 前缀，样式全在 anime.css 里。
   ============================================================ */
(function () {
  'use strict';

  if (window.AnimeUI && typeof window.AnimeUI.mount === 'function') return;

  var API_ANIME = '/api/anime';
  var API_SEARCH = '/api/anime/search';
  var API_FOLLOWS = '/api/follows';

  var POLL_FAST_MS = 8000;
  var POLL_SLOW_MS = 15000;
  var TOAST_MS = 3200;

  var VIEWS = [
    { key: 'new', label: '有新集', icon: 'tv', title: '有新集', sub: '追的番更新了，就摆在这儿' },
    { key: 'following', label: '在追', icon: 'bookmark', title: '在追', sub: '联网时自己盯着更新，不用动手' },
    { key: 'find', label: '找番', icon: 'search', title: '找番', sub: '搜个名字加进来，联网自动检查新集' }
  ];

  var ICONS = {
    tv: '<rect x="3" y="5" width="18" height="13" rx="2.6"/><path d="M8 21h8M12 18v3"/><path d="M8.4 9.4l2 2 4-4"/>',
    bookmark: '<path d="M6.5 4h11v16.4l-5.5-3.8-5.5 3.8z"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.4 15.4L20 20"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4.5V9h-4.5"/>',
    alert: '<path d="M12 4.6l8.4 14.8H3.6z"/><path d="M12 10v3.4"/><circle cx="12" cy="16.6" r=".85" fill="currentColor" stroke="none"/>',
    check: '<path d="M5 12.6l4.4 4.4L19 7.2"/>',
    clock: '<circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 1.9"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    link: '<path d="M10.5 13.5l3.9-3.9"/><path d="M13.4 7.2l1.5-1.5a3.9 3.9 0 0 1 5.5 5.5l-1.5 1.5"/><path d="M10.6 16.8l-1.5 1.5a3.9 3.9 0 0 1-5.5-5.5l1.5-1.5"/>',
    filmOff: '<rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2.4"/><path d="M9 9l6 6M15 9l-6 6"/>',
    spark: '<path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z"/>'
  };

  function svg(name, extraClass) {
    var body = ICONS[name] || '';
    return '<svg class="an-ico' + (extraClass ? ' ' + extraClass : '') +
      '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  /* ------------------------------------------------------------
     小工具
     ------------------------------------------------------------ */
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function num(v) {
    var n = Number(v);
    return isFinite(n) ? n : 0;
  }

  function shortTime(text) {
    var s = String(text == null ? '' : text);
    var m = /(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2})/.exec(s);
    if (m) return m[1].replace('T', ' ');
    var d = /(\d{4}-\d{2}-\d{2})/.exec(s);
    if (d) return d[1];
    return s;
  }

  function epLabel(v) {
    var s = String(v == null ? '' : v).trim();
    if (!s) return '';
    if (/^第/.test(s)) return s;
    if (/^\d+$/.test(s)) return '第 ' + s + ' 集';
    return s;
  }

  function fetchJSON(url, opt) {
    return fetch(url, opt || {}).then(function (res) {
      if (!res || !res.ok) {
        var err = new Error('HTTP ' + (res ? res.status : '?'));
        err.status = res ? res.status : 0;
        throw err;
      }
      return res.json();
    });
  }

  function postJSON(url, body) {
    return fetchJSON(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
  }

  /* ------------------------------------------------------------
     空态 / 载入
     ------------------------------------------------------------ */
  function emptyMarkup(icon, title, hint, action) {
    return '<div class="an-empty">' +
      '<div class="an-empty-ico">' + svg(icon) + '</div>' +
      '<p class="an-empty-title">' + esc(title) + '</p>' +
      '<p class="an-empty-hint">' + esc(hint) + '</p>' +
      (action ? '<button type="button" class="an-btn" data-act="' + esc(action.act) + '"' +
        (action.view ? ' data-view="' + esc(action.view) + '"' : '') + '>' +
        esc(action.label) + '</button>' : '') +
      '</div>';
  }

  function loadingMarkup(text) {
    return '<div class="an-loading"><span class="an-spinner"></span>' + esc(text) + '</div>';
  }

  /* ------------------------------------------------------------
     模块状态
     ------------------------------------------------------------ */
  var mounted = false;
  var host = null;
  var root = null;
  var refs = {};
  var st = null;

  var pollTimer = null;
  var toastTimer = null;
  var animeSeq = 0;
  var searchSeq = 0;
  var visHandler = null;
  var keyHandler = null;

  function createState() {
    return {
      view: 'new',
      loading: true,
      error: '',
      checkedAt: '',
      items: [],
      follows: [],
      followById: {},
      newRefs: [],
      followRefs: {},
      searchRefs: {},
      followBusy: {},
      searchBusy: {},
      search: {
        q: '',
        loading: false,
        items: [],
        total: 0,
        error: '',
        searched: false
      }
    };
  }

  /* ------------------------------------------------------------
     骨架
     ------------------------------------------------------------ */
  function shellHTML() {
    return '' +
      '<aside class="an-side">' +
        '<div class="an-brand">' +
          '<span class="an-brand-mark">' + svg('tv') + '</span>' +
          '<span class="an-brand-txt"><b>追更</b><small>番剧更新</small></span>' +
        '</div>' +
        '<nav class="an-nav" id="an-nav"></nav>' +
        '<div class="an-side-note">' +
          '<p class="an-note-t">漫画暂时追不了</p>' +
          '<p class="an-note-x">B 站漫画接口要 APP 签名，这里只盯番剧；漫画追不了，也搜不出来。</p>' +
        '</div>' +
        '<div class="an-side-foot">' +
          '<div class="an-side-stat" id="an-side-stat">在追 0 部</div>' +
          '<div class="an-side-time" id="an-side-time">还没检查过</div>' +
        '</div>' +
      '</aside>' +

      '<section class="an-stage">' +
        '<header class="an-head">' +
          '<div class="an-head-txt">' +
            '<h2 id="an-title">有新集</h2>' +
            '<p id="an-sub">追的番更新了，就摆在这儿</p>' +
          '</div>' +
          '<div class="an-head-right">' +
            '<span class="an-updated" id="an-updated">还没检查过</span>' +
            '<button type="button" class="an-icon-btn" id="an-refresh" data-act="refresh" title="重新读取">' +
              svg('refresh') + '</button>' +
          '</div>' +
        '</header>' +

        '<div class="an-content" id="an-content">' +
          '<section class="an-pane" id="an-pane-new">' +
            '<div class="an-sechead">' +
              '<h3>追的番有新集</h3><span class="an-secn" id="an-new-n"></span>' +
            '</div>' +
            '<div class="an-cards" id="an-new"></div>' +
          '</section>' +

          '<section class="an-pane" id="an-pane-following" hidden>' +
            '<div class="an-sechead">' +
              '<h3>在追</h3><span class="an-secn" id="an-follow-n"></span>' +
            '</div>' +
            '<div class="an-follows" id="an-follows"></div>' +
          '</section>' +

          '<section class="an-pane" id="an-pane-find" hidden>' +
            '<div class="an-searchbar">' +
              '<span class="an-searchbar-ico">' + svg('search') + '</span>' +
              '<input id="an-q" type="search" placeholder="搜番剧名：鬼灭 / 凡人修仙传…" ' +
                'autocomplete="off" spellcheck="false" aria-label="搜索番剧">' +
              '<button type="button" class="an-searchbtn" id="an-do-search" data-act="do-search">搜</button>' +
            '</div>' +
            '<p class="an-tip" id="an-find-tip">只搜番剧。漫画要 APP 签名，追不了。</p>' +
            '<div class="an-results" id="an-results"></div>' +
          '</section>' +
        '</div>' +
      '</section>' +

      '<div class="an-toast" id="an-toast" role="status" aria-live="polite"></div>';
  }

  function cacheRefs() {
    refs.nav = root.querySelector('#an-nav');
    refs.title = root.querySelector('#an-title');
    refs.sub = root.querySelector('#an-sub');
    refs.updated = root.querySelector('#an-updated');
    refs.refresh = root.querySelector('#an-refresh');
    refs.content = root.querySelector('#an-content');
    refs.paneNew = root.querySelector('#an-pane-new');
    refs.paneFollow = root.querySelector('#an-pane-following');
    refs.paneFind = root.querySelector('#an-pane-find');
    refs.newList = root.querySelector('#an-new');
    refs.newN = root.querySelector('#an-new-n');
    refs.followList = root.querySelector('#an-follows');
    refs.followN = root.querySelector('#an-follow-n');
    refs.q = root.querySelector('#an-q');
    refs.searchBtn = root.querySelector('#an-do-search');
    refs.results = root.querySelector('#an-results');
    refs.findTip = root.querySelector('#an-find-tip');
    refs.sideStat = root.querySelector('#an-side-stat');
    refs.sideTime = root.querySelector('#an-side-time');
    refs.toast = root.querySelector('#an-toast');
  }

  /* ------------------------------------------------------------
     挂载 / 卸载
     ------------------------------------------------------------ */
  function mount(container) {
    if (!container || !container.appendChild) return;
    if (mounted) unmount();

    mounted = true;
    host = container;
    st = createState();

    container.classList.add('an-host');
    container.innerHTML = '';
    root = document.createElement('div');
    root.className = 'an-app';
    var embed = container.getAttribute('data-embed');
    if (!embed || embed === '0' || embed === 'false') root.className += ' an-fixed';
    root.innerHTML = shellHTML();
    container.appendChild(root);

    cacheRefs();
    document.body.classList.add('mu-fs');

    renderNav();
    renderHead();
    renderStats();
    renderNew();
    renderFollows();
    renderSearch(true);
    applyView();

    bindUi();
    loadAnime();
    schedulePoll();
  }

  function unmount() {
    if (!mounted) return;
    mounted = false;

    stopPoll();
    if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }

    if (keyHandler) { document.removeEventListener('keydown', keyHandler, false); keyHandler = null; }
    if (visHandler) { document.removeEventListener('visibilitychange', visHandler, false); visHandler = null; }

    document.body.classList.remove('mu-fs');

    if (root && root.parentNode) root.parentNode.removeChild(root);
    if (host) host.classList.remove('an-host');

    root = null;
    refs = {};
    host = null;
    st = null;
    animeSeq = 0;
    searchSeq = 0;
  }

  function bindUi() {
    root.addEventListener('click', onClick, false);

    // 外链封面挂了就藏起来，露出底下的占位图标
    root.addEventListener('error', function (e) {
      var t = e.target;
      if (t && t.classList && t.classList.contains('an-cover-img')) t.style.display = 'none';
    }, true);

    if (refs.q) {
      refs.q.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          runSearch(refs.q.value);
        }
      }, false);
    }

    keyHandler = function (e) {
      if (!mounted) return;
      if (e.key === 'Escape' && st.view === 'find' && refs.q) refs.q.blur();
    };
    document.addEventListener('keydown', keyHandler, false);

    visHandler = function () {
      if (!mounted) return;
      if (document.hidden) {
        stopPoll();
        return;
      }
      loadAnime();
      schedulePoll();
    };
    document.addEventListener('visibilitychange', visHandler, false);
  }

  function onClick(e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || !root || !root.contains(el)) return;
    var act = el.getAttribute('data-act');

    if (act === 'view') {
      setView(el.getAttribute('data-view'));
      return;
    }
    if (act === 'refresh') {
      loadAnime();
      toast('刷新了一下');
      return;
    }
    if (act === 'do-search') {
      runSearch(refs.q ? refs.q.value : '');
      return;
    }
    if (act === 'retry-anime') {
      loadAnime();
      return;
    }
    if (act === 'retry-search') {
      runSearch(st.search.q || (refs.q ? refs.q.value : ''));
      return;
    }
    if (act === 'follow-add') {
      addFollow(el.getAttribute('data-sid'));
      return;
    }
    if (act === 'follow-del') {
      removeFollow(el.getAttribute('data-sid'));
      return;
    }
    if (act === 'follow-bind') {
      // 绑定小站番剧 id：有了它才能下载这一集
      var sid = el.getAttribute('data-sid') || '';
      var cur = '';
      for (var i = 0; i < (st.follows || []).length; i++) {
        if (String(st.follows[i].sid) === String(sid)) cur = st.follows[i].site_aid || '';
      }
      var v = window.prompt('填小站（OmoFun）的番剧 id 或详情页地址\n比如 1999470661 或 https://omofun.in/vod/detail/1999470661.html', cur);
      if (v === null) return;
      v = String(v).trim();
      var m = v.match(/(\d{4,})/);
      var aid = m ? m[1] : v;
      bindSite(sid, aid);
      return;
    }
    if (act === 'ep-dl') {
      downloadEp(el.getAttribute('data-aid'), el.getAttribute('data-ep'),
                 el.getAttribute('data-title'), el);
      return;
    }
  }

  function bindSite(sid, aid) {
    postJSON('/api/follows', { action: 'bind', item: { sid: sid, site_aid: aid } })
      .then(function (d) {
        if (!d || !d.ok) { toast('绑不上'); return; }
        st.follows = d.items || st.follows;
        reloadFollowLists();
        toast(aid ? '已绑定 ' + aid : '解绑了');
      })
      .catch(function () { toast('绑不上，服务没响应'); });
  }

  function downloadEp(aid, ep, title, btn) {
    if (!aid || !ep) { toast('缺参数'); return; }
    var old = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = '排队中…'; }
    postJSON('/api/anime/site/download', { aid: aid, ep: ep, title: title })
      .then(function (d) {
        if (!d || !d.ok) {
          toast((d && d.error) || '排不进去');
          if (btn) { btn.disabled = false; btn.textContent = old; }
          return;
        }
        toast('排上了，分段下，断了下次接着下');
        if (btn) btn.textContent = '已排队';
      })
      .catch(function () {
        toast('排不进去，服务没响应');
        if (btn) { btn.disabled = false; btn.textContent = old; }
      });
  }

  function reloadFollowLists() {
    if (refs.followList) renderFollows();
    if (refs.newList) renderNew();
  }

  /* ------------------------------------------------------------
     视图切换
     ------------------------------------------------------------ */
  function viewDef(key) {
    for (var i = 0; i < VIEWS.length; i++) {
      if (VIEWS[i].key === key) return VIEWS[i];
    }
    return VIEWS[0];
  }

  function setView(view) {
    if (!st) return;
    if (!view || !viewDef(view)) view = 'new';
    st.view = view;
    applyView();
    renderNav();
    renderHead();
    if (view === 'find' && refs.q) refs.q.focus();
  }

  function applyView() {
    if (!refs.paneNew) return;
    refs.paneNew.hidden = st.view !== 'new';
    refs.paneFollow.hidden = st.view !== 'following';
    refs.paneFind.hidden = st.view !== 'find';
    if (refs.content) refs.content.scrollTop = 0;
  }

  /* ------------------------------------------------------------
     数据整理
     ------------------------------------------------------------ */
  function normNewItem(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var sid = raw.sid == null ? '' : String(raw.sid);
    if (!sid) return null;
    return {
      sid: sid,
      type: raw.type ? String(raw.type) : '番剧',
      title: raw.title ? String(raw.title) : '没标题的番',
      new_ep: raw.new_ep == null ? '' : String(raw.new_ep),
      new_ep_title: raw.new_ep_title ? String(raw.new_ep_title) : '',
      updated_at: raw.updated_at ? String(raw.updated_at) : '',
      cover_url: raw.cover_url ? String(raw.cover_url) : '',
      url: raw.url ? String(raw.url) : '',
      bvid: raw.bvid ? String(raw.bvid) : '',
      ep_id: raw.ep_id == null ? '' : String(raw.ep_id),
      found_at: raw.found_at ? String(raw.found_at) : ''
    };
  }

  function normFollow(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var sid = raw.sid == null ? '' : String(raw.sid);
    if (!sid) return null;
    return {
      sid: sid,
      type: raw.type ? String(raw.type) : '番剧',
      title: raw.title ? String(raw.title) : '没标题的番',
      cover_url: raw.cover_url ? String(raw.cover_url) : '',
      url: raw.url ? String(raw.url) : '',
      added_at: raw.added_at ? String(raw.added_at) : '',
      last_ep: raw.last_ep == null ? '' : String(raw.last_ep),
      last_ep_id: raw.last_ep_id == null ? '' : String(raw.last_ep_id),
      last_checked: raw.last_checked ? String(raw.last_checked) : ''
    };
  }

  function normSearchItem(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var sid = raw.sid == null ? '' : String(raw.sid);
    if (!sid) return null;
    return {
      sid: sid,
      type: raw.type ? String(raw.type) : '番剧',
      title: raw.title ? String(raw.title) : '没标题的番',
      cover_url: raw.cover_url ? String(raw.cover_url) : '',
      total_ep: num(raw.total_ep),
      desc: raw.desc ? String(raw.desc) : '',
      url: raw.url ? String(raw.url) : ''
    };
  }

  function mapList(raw, fn) {
    var out = [];
    if (!Array.isArray(raw)) return out;
    for (var i = 0; i < raw.length; i++) {
      var it = fn(raw[i]);
      if (it) out.push(it);
    }
    return out;
  }

  /* ------------------------------------------------------------
     读取 / 刷新
     ------------------------------------------------------------ */
  function loadAnime() {
    if (!mounted || !st) return Promise.resolve();
    var seq = ++animeSeq;
    return fetchJSON(API_ANIME + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== animeSeq) return;
        applyData(data || {});
      })
      .catch(function (err) {
        if (!mounted || !st || seq !== animeSeq) return;
        st.loading = false;
        st.error = animeErrorText(err);
        renderAll();
      });
  }

  function animeErrorText(err) {
    if (err && err.status === 404) return '本地服务还没开放追更接口（/api/anime 返回 404）。';
    if (err && err.status) return '读取追更失败（HTTP ' + err.status + '），等会儿点右上角刷新。';
    if (window.navigator && window.navigator.onLine === false) {
      return '现在没网，也连不上本地服务。等 newsd 起来再看。';
    }
    return '连不上本地服务，确认 newsd 起来了再刷新。';
  }

  function applyData(data) {
    st.loading = false;
    st.error = '';
    st.items = mapList(data.items, normNewItem);
    st.follows = mapList(data.follows, normFollow);
    st.checkedAt = data.checked_at ? String(data.checked_at) : '';
    st.followById = {};
    for (var i = 0; i < st.follows.length; i++) {
      st.followById[st.follows[i].sid] = true;
    }
    renderAll();
    schedulePoll();
  }

  function renderAll() {
    renderNav();
    renderHead();
    renderStats();
    renderNew();
    renderFollows();
    updateFollowButtons();
  }

  /* ------------------------------------------------------------
     渲染：导航 / 头部 / 底部
     ------------------------------------------------------------ */
  function renderNav() {
    if (!refs.nav) return;
    var counts = {
      new: st.items.length,
      following: st.follows.length,
      find: ''
    };
    var html = VIEWS.map(function (v) {
      var n = counts[v.key];
      return '<button type="button" class="an-nav-item' + (st.view === v.key ? ' active' : '') + '"' +
        ' data-act="view" data-view="' + v.key + '">' +
        svg(v.icon) + '<span>' + esc(v.label) + '</span>' +
        (n ? '<em class="an-nav-n">' + n + '</em>' : '') +
        '</button>';
    }).join('');
    refs.nav.innerHTML = html;
  }

  function renderHead() {
    if (!refs.title) return;
    var v = viewDef(st.view);
    refs.title.textContent = v.title;
    refs.sub.textContent = v.sub;

    var text;
    if (st.loading) text = '正在读追更列表…';
    else if (st.error) text = '读取失败';
    else if (st.view === 'new') text = st.items.length ? (st.items.length + ' 部有新集') : '暂无新集';
    else if (st.view === 'following') text = st.follows.length ? ('在追 ' + st.follows.length + ' 部') : '还没追番';
    else text = st.search.q ? ('搜了「' + st.search.q + '」') : '搜番剧名';
    refs.updated.textContent = text;
  }

  function renderStats() {
    if (!refs.sideStat) return;
    var n = st.follows.length;
    var extra = st.items.length ? (' ・ ' + st.items.length + ' 部有新集') : '';
    refs.sideStat.textContent = '在追 ' + n + ' 部' + extra;
    var when = shortTime(st.checkedAt);
    refs.sideTime.textContent = when ? ('上次检查 ' + when) : '还没检查过';
  }

  /* ------------------------------------------------------------
     渲染：有新集
     ------------------------------------------------------------ */
  function newCardHTML(it) {
    var pic = it.cover_url
      ? '<img class="an-cover-img" src="' + esc(it.cover_url) + '" alt="" loading="lazy" referrerpolicy="no-referrer">'
      : '';
    var ep = epLabel(it.new_ep);
    var go = it.bvid
      ? '<a class="an-card-go" href="https://www.bilibili.com/video/' + esc(it.bvid) + '"' +
        ' target="_blank" rel="noreferrer">' + svg('link') + '去 B 站</a>' +
        ((function () {
          var f0 = (st.follows || []).filter(function (f) {
            return String(f.sid) === String(it.sid);
          })[0];
          return (f0 && f0.site_aid)
            ? '<button type="button" class="an-card-go an-dl" data-act="ep-dl"' +
              ' data-aid="' + esc(f0.site_aid) + '" data-ep="ep' + esc(it.new_ep) + '"' +
              ' data-title="' + esc(it.title) + '">下载本集</button>'
            : '';
        })())
      : '';
    return '<article class="an-card">' +
      '<div class="an-cover">' + pic +
        '<span class="an-cover-ph">' + svg('filmOff') + '</span>' +
        '<span class="an-cover-badge">' + esc(ep || '新集') + '</span>' +
      '</div>' +
      '<div class="an-card-body">' +
        '<h4 class="an-card-title" title="' + esc(it.title) + '">' + esc(it.title) + '</h4>' +
        '<p class="an-card-ep">' + esc(ep) +
          (it.new_ep_title ? ' ・ ' + esc(it.new_ep_title) : '') + '</p>' +
        '<div class="an-card-foot">' +
          '<span class="an-card-time">' + esc(shortTime(it.updated_at || it.found_at) || '时间不明') + '</span>' +
          go +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function renderNew() {
    if (!refs.newList || !st) return;
    if (refs.newN) refs.newN.textContent = st.items.length ? (st.items.length + ' 部') : '';

    if (st.loading && !st.follows.length) {
      refs.newList.innerHTML = loadingMarkup('正在读追更列表…');
      refs.newList.removeAttribute('data-sig');
      return;
    }
    if (st.error) {
      refs.newList.innerHTML = emptyMarkup('alert', '追更列表没读出来', st.error, {
        label: '再读一次', act: 'retry-anime'
      });
      refs.newList.removeAttribute('data-sig');
      return;
    }
    if (!st.items.length) {
      refs.newList.innerHTML = emptyMarkup('tv', '追的番还没更新',
        '联网时自动检查，有新集就会冒出来。先去「在追」里看看追了什么，或者去「找番」加几部。',
        { label: '去在追', act: 'view', view: 'following' });
      refs.newList.removeAttribute('data-sig');
      return;
    }

    var sig = st.items.map(function (x) { return x.sid + '-' + x.new_ep; }).join('|');
    if (refs.newList.getAttribute('data-sig') === sig) return;
    refs.newList.setAttribute('data-sig', sig);
    refs.newList.innerHTML = st.items.map(newCardHTML).join('');
  }

  /* ------------------------------------------------------------
     渲染：在追（增量）
     ------------------------------------------------------------ */
  function followStateText(f) {
    if (f.last_ep || f.last_ep_id) {
      var ep = epLabel(f.last_ep) || ('ep' + f.last_ep_id);
      return '看到 ' + ep;
    }
    return '还没看到新集';
  }

  function createFollowRow(f) {
    var row = document.createElement('div');
    row.className = 'an-frow';
    row.setAttribute('data-sid', f.sid);
    row.innerHTML =
      '<div class="an-fcover">' + svg('filmOff', 'an-fph') + '</div>' +
      '<div class="an-fbody">' +
        '<div class="an-ftitle"></div>' +
        '<div class="an-fmeta"><span class="an-ftype"></span><span class="an-fep"></span></div>' +
        '<div class="an-ftime"></div>' +
      '</div>' +
      '<button type="button" class="an-fdel" data-act="follow-del" data-sid="' + esc(f.sid) + '">不追了</button>';

    return {
      row: row,
      cover: row.querySelector('.an-fcover'),
      title: row.querySelector('.an-ftitle'),
      type: row.querySelector('.an-ftype'),
      ep: row.querySelector('.an-fep'),
      time: row.querySelector('.an-ftime'),
      del: row.querySelector('.an-fdel')
    };
  }

  function updateFollowRow(rec, f) {
    if (rec.title.textContent !== f.title) {
      rec.title.textContent = f.title;
      rec.title.title = f.title;
    }
    if (rec.type.textContent !== (f.type || '番剧')) rec.type.textContent = f.type || '番剧';
    var ep = followStateText(f);
    if (rec.ep.textContent !== ep) rec.ep.textContent = ep;
    var when = shortTime(f.last_checked);
    var timeTxt = when ? ('上次检查 ' + when) : '还没检查过';
    if (rec.time.textContent !== timeTxt) rec.time.textContent = timeTxt;
    var pic = f.cover_url;
    if (rec.cover.getAttribute('data-pic') !== pic) {
      rec.cover.setAttribute('data-pic', pic || '');
      rec.cover.innerHTML = svg('filmOff', 'an-fph') +
        (pic ? '<img class="an-cover-img" src="' + esc(pic) + '" alt="" loading="lazy" referrerpolicy="no-referrer">' : '');
    }
  }

  function renderFollows() {
    if (!refs.followList || !st) return;
    if (refs.followN) refs.followN.textContent = st.follows.length ? (st.follows.length + ' 部') : '';

    var hint = refs.followList.querySelector('.an-empty');
    if (!st.follows.length) {
      for (var key in st.followRefs) {
        if (!st.followRefs.hasOwnProperty(key)) continue;
        var gone = st.followRefs[key];
        if (gone.row.parentNode) gone.row.parentNode.removeChild(gone.row);
      }
      st.followRefs = {};
      if (!hint) {
        refs.followList.innerHTML = emptyMarkup('bookmark', '还没追任何番',
          '去「找番」搜个名字加进来。加进去后联网会自己盯着更新，有新集就出现在「有新集」。',
          { label: '去找番', act: 'view', view: 'find' });
      }
      return;
    }
    if (hint && hint.parentNode) hint.parentNode.removeChild(hint);

    var seen = {};
    var prev = null;
    for (var i = 0; i < st.follows.length; i++) {
      var f = st.follows[i];
      seen[f.sid] = true;
      var rec = st.followRefs[f.sid];
      if (!rec) {
        rec = createFollowRow(f);
        st.followRefs[f.sid] = rec;
      }
      updateFollowRow(rec, f);
      var ref = prev ? prev.nextSibling : refs.followList.firstChild;
      if (ref !== rec.row) refs.followList.insertBefore(rec.row, ref);
      prev = rec.row;
    }
    for (var k in st.followRefs) {
      if (!st.followRefs.hasOwnProperty(k) || seen[k]) continue;
      var dead = st.followRefs[k];
      if (dead.row.parentNode) dead.row.parentNode.removeChild(dead.row);
      delete st.followRefs[k];
    }
  }

  /* ------------------------------------------------------------
     渲染：找番 / 搜索
     ------------------------------------------------------------ */
  function searchCardHTML(it) {
    var followed = !!st.followById[it.sid];
    var busy = !!st.searchBusy[it.sid];
    var pic = it.cover_url
      ? '<img class="an-cover-img" src="' + esc(it.cover_url) + '" alt="" loading="lazy" referrerpolicy="no-referrer">'
      : '';
    var label = followed ? '已追' : busy ? '加追中…' : '加进追更';
    return '<article class="an-scard" data-sid="' + esc(it.sid) + '">' +
      '<div class="an-scover">' + pic +
        '<span class="an-cover-ph">' + svg('filmOff') + '</span>' +
      '</div>' +
      '<div class="an-sbody">' +
        '<h4 class="an-stitle" title="' + esc(it.title) + '">' + esc(it.title) + '</h4>' +
        '<div class="an-smeta">' +
          '<span class="an-chip">' + esc(it.type || '番剧') + '</span>' +
          (it.total_ep ? '<span class="an-sep">' + it.total_ep + ' 集</span>' : '') +
        '</div>' +
        '<p class="an-sdesc">' + esc(it.desc || '这条没有简介。') + '</p>' +
        '<div class="an-sfoot">' +
          '<button type="button" class="an-sadd' + (followed || busy ? ' is-off' : '') + '"' +
            ' data-act="follow-add" data-sid="' + esc(it.sid) + '"' +
            (followed || busy ? ' aria-disabled="true"' : '') + '>' +
            (followed ? svg('check') : svg('plus')) + label + '</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function renderSearch(force) {
    if (!refs.results || !st) return;
    var sr = st.search;

    if (sr.loading) {
      refs.results.innerHTML = loadingMarkup('正在 B 站搜番剧…');
      refs.results.removeAttribute('data-sig');
      return;
    }
    if (sr.error) {
      refs.results.innerHTML = emptyMarkup('alert', '没搜成', sr.error, {
        label: '重新搜一次', act: 'retry-search'
      });
      refs.results.removeAttribute('data-sig');
      return;
    }
    if (!sr.searched) {
      refs.results.innerHTML = emptyMarkup('search', '搜个番名试试',
        '比如「鬼灭之刃」「凡人修仙传」。只能搜番剧，漫画追不了，也不会硬塞假条目。');
      refs.results.removeAttribute('data-sig');
      return;
    }
    if (!sr.items.length) {
      refs.results.innerHTML = emptyMarkup('search', '没搜到「' + sr.q + '」',
        '换个说法、打全名再试试；也可能是这会儿没网，等联网后搜。');
      refs.results.removeAttribute('data-sig');
      return;
    }

    var sig = sr.q + '|' + sr.items.map(function (x) { return x.sid; }).join(',') +
      '|' + (sr.items.length) + '|' + (sr.q ? 'q' : '');
    if (!force && refs.results.getAttribute('data-sig') === sig) {
      updateSearchButtons();
      return;
    }
    refs.results.setAttribute('data-sig', sig);
    var head = '<div class="an-results-head">' +
      '<h3>「' + esc(sr.q) + '」的番剧</h3>' +
      '<span class="an-results-n">' + sr.items.length + ' 个' +
        (sr.total && sr.total !== sr.items.length ? '（共 ' + sr.total + '）' : '') + '</span>' +
      '</div>';
    refs.results.innerHTML = head + '<div class="an-scards">' +
      sr.items.map(searchCardHTML).join('') + '</div>';
    st.searchRefs = {};
    var nodes = refs.results.querySelectorAll('.an-scard');
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      st.searchRefs[card.getAttribute('data-sid')] = {
        card: card,
        btn: card.querySelector('.an-sadd')
      };
    }
    updateSearchButtons();
  }

  function runSearch(raw) {
    if (!mounted || !st) return;
    var q = String(raw == null ? '' : raw).replace(/\s+/g, ' ').trim();
    if (!q) {
      toast('先打个番名再搜');
      if (refs.q) refs.q.focus();
      return;
    }
    if (refs.q && refs.q.value !== q) refs.q.value = q;

    var seq = ++searchSeq;
    st.search.q = q;
    st.search.loading = true;
    st.search.error = '';
    st.search.items = [];
    st.search.total = 0;
    st.search.searched = true;
    st.searchRefs = {};
    renderSearch(true);
    renderHead();

    fetchJSON(API_SEARCH + '?q=' + encodeURIComponent(q) + '&t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== searchSeq) return;
        data = data || {};
        st.search.loading = false;
        st.search.items = mapList(data.items, normSearchItem);
        st.search.total = num(data.total) || st.search.items.length;
        st.search.q = data.q ? String(data.q) : q;
        st.search.error = data.error ? String(data.error) : '';
        if (st.search.error && !st.search.items.length) {
          renderSearch(true);
          renderHead();
          return;
        }
        renderSearch(true);
        renderHead();
        if (!st.search.items.length) toast('没搜到，换个说法试试');
      })
      .catch(function (err) {
        if (!mounted || !st || seq !== searchSeq) return;
        st.search.loading = false;
        st.search.items = [];
        st.searchRefs = {};
        st.search.error = searchErrorText(err);
        renderSearch(true);
        renderHead();
      });
  }

  function searchErrorText(err) {
    if (err && err.status === 404) return '本地服务还没开放番剧搜索接口（/api/anime/search 返回 404）。';
    if (err && err.status) return '搜索失败（HTTP ' + err.status + '），等会儿再点「搜」重试。';
    if (window.navigator && window.navigator.onLine === false) {
      return '现在没网，搜不了番。等老师开热点再来。';
    }
    return '连不上本地服务，确认 newsd 起来了再搜。';
  }

  function updateSearchButtons() {
    if (!st) return;
    var sids = Object.keys(st.searchRefs);
    for (var i = 0; i < sids.length; i++) {
      var rec = st.searchRefs[sids[i]];
      if (!rec.btn) continue;
      var followed = !!st.followById[sids[i]];
      var busy = !!st.searchBusy[sids[i]];
      var label = followed ? '已追' : busy ? '加追中…' : '加进追更';
      var cls = 'an-sadd' + (followed || busy ? ' is-off' : '');
      if (rec.btn.className !== cls) rec.btn.className = cls;
      var icon = followed ? 'check' : 'plus';
      if (rec.btn.getAttribute('data-icon') !== icon || rec.btn.getAttribute('data-label') !== label) {
        rec.btn.setAttribute('data-icon', icon);
        rec.btn.setAttribute('data-label', label);
        rec.btn.innerHTML = svg(icon) + '<span>' + esc(label) + '</span>';
      }
      rec.btn.setAttribute('aria-disabled', followed || busy ? 'true' : 'false');
    }
  }

  function updateFollowButtons() {
    updateSearchButtons();
    var sids = Object.keys(st.followRefs);
    for (var i = 0; i < sids.length; i++) {
      var rec = st.followRefs[sids[i]];
      if (!rec.del) continue;
      var busy = !!st.followBusy[sids[i]];
      rec.del.disabled = busy;
      rec.del.textContent = busy ? '处理中…' : '不追了';
    }
  }

  /* ------------------------------------------------------------
     动作：加追 / 不追
     ------------------------------------------------------------ */
  function addFollow(sid) {
    if (!mounted || !st || !sid) return;
    if (st.followById[sid] || st.searchBusy[sid]) return;

    var item = null;
    for (var i = 0; i < st.search.items.length; i++) {
      if (st.search.items[i].sid === sid) { item = st.search.items[i]; break; }
    }
    if (!item) return;

    st.searchBusy[sid] = true;
    updateSearchButtons();

    postJSON(API_FOLLOWS, {
      action: 'add',
      item: {
        sid: item.sid, type: item.type || '番剧', title: item.title,
        cover_url: item.cover_url, url: item.url
      }
    })
      .then(function (res) {
        if (!mounted || !st) return;
        st.searchBusy[sid] = false;
        if (res && res.ok === false) {
          toast(res.error || '加不进去，本地服务没响应');
          updateSearchButtons();
          return;
        }
        toast('加进追更了，联网会自己检查新集');
        loadAnime();
        updateSearchButtons();
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.searchBusy[sid] = false;
        toast('加不进去，本地服务没响应');
        updateSearchButtons();
      });
  }

  function removeFollow(sid) {
    if (!mounted || !st || !sid) return;
    if (st.followBusy[sid]) return;
    st.followBusy[sid] = true;
    updateFollowButtons();

    postJSON(API_FOLLOWS, { action: 'del', item: { sid: sid } })
      .then(function (res) {
        if (!mounted || !st) return;
        st.followBusy[sid] = false;
        if (res && res.ok === false) {
          toast(res.error || '删不掉，本地服务没响应');
          updateFollowButtons();
          return;
        }
        toast('不追了');
        loadAnime();
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.followBusy[sid] = false;
        toast('删不掉，本地服务没响应');
        updateFollowButtons();
      });
  }

  /* ------------------------------------------------------------
     轮询
     ------------------------------------------------------------ */
  function activeNow() {
    return !!st && st.items.length > 0;
  }

  function stopPoll() {
    if (pollTimer) {
      window.clearTimeout(pollTimer);
      pollTimer = null;
    }
  }

  function schedulePoll() {
    stopPoll();
    if (!mounted || !st || document.hidden) return;
    pollTimer = window.setTimeout(function () {
      pollTimer = null;
      if (!mounted) return;
      loadAnime().then(function () {
        if (mounted) schedulePoll();
      });
    }, activeNow() ? POLL_FAST_MS : POLL_SLOW_MS);
  }

  /* ------------------------------------------------------------
     提示
     ------------------------------------------------------------ */
  function toast(msg) {
    if (!refs.toast || !mounted) return;
    refs.toast.textContent = msg;
    refs.toast.classList.add('is-show');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      if (!refs.toast) return;
      refs.toast.classList.remove('is-show');
      toastTimer = null;
    }, TOAST_MS);
  }

  /* ------------------------------------------------------------
     对外接口
     ------------------------------------------------------------ */
  window.AnimeUI = {
    mount: mount,
    unmount: unmount
  };
})();
