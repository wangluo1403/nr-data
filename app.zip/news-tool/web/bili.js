/* ============================================================
   bili.js — B 站（整页）
   ------------------------------------------------------------
   对外只暴露 window.BiliUI：
     BiliUI.mount(container)  把界面画进 container
     BiliUI.unmount()         停轮询、关播放器、拆监听

   纯原生 JS，无模块、无外部依赖；数据来自 /api/bili/*。
   类名统一 bi- 前缀，样式全在 bili.css 里。
   ============================================================ */
(function () {
  'use strict';

  if (window.BiliUI && typeof window.BiliUI.mount === 'function') return;

  var API_SEARCH = '/api/bili/search';
  var API_PAGE = '/api/bili/page';
  var API_WANT = '/api/bili/want';
  var API_DOWNLOAD = '/api/bili/download';
  var API_REC = '/api/bili';
  var API_VIDEOS = '/api/videos';
  var API_OPEN = '/api/open';
  var API_FINISHED = '/api/finished';
  var API_FAV = '/api/fav';
  var API_LIBRARY = '/api/library';

  var POLL_FAST_MS = 2000;
  var POLL_SLOW_MS = 10000;
  var TOAST_MS = 3200;

  var AUTO_DL_COUNT = 3;
  var TOO_LONG_S = 1800;

  var LS_SIZES = 'bi.sizes';
  var LS_AUTODL = 'bi.autodl';
  var MAX_SIZES = 500;

  var VIEWS = [
    { key: 'feed', label: '推荐', icon: 'film', title: '推荐视频', sub: '每次联网自动下几条推荐，下好的躺这儿，断网也能看' },
    { key: 'search', label: '搜索', icon: 'search', title: '搜索', sub: '打关键词，搜到就能下下来离线看' },
    { key: 'downloads', label: '我的下载', icon: 'download', title: '我的下载', sub: '下好的视频躺在这，断网也能看' },
    { key: 'wants', label: '关键词', icon: 'tag', title: '关键词', sub: '断网也能记，联网后自动搜并下载前几条' }
  ];

  var ICONS = {
    bili: '<rect x="3" y="6" width="18" height="13.6" rx="3.4"/><path d="M8.6 3.4l1.9 2.2M15.4 3.4l-1.9 2.2"/><path d="M8.4 11.4v2.8M15.6 11.4v2.8"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.4 15.4L20 20"/>',
    download: '<path d="M12 3.5v10M8 10l4 4 4-4M4.5 17.5v2h15v-2"/>',
    tag: '<path d="M4 4h7l9 9-7 7-9-9z"/><circle cx="8.5" cy="8.5" r="1.3"/>',
    play: '<path d="M8 5.5v13l11-6.5z" fill="currentColor" stroke="none"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4.5V9h-4.5"/>',
    alert: '<path d="M12 4.6l8.4 14.8H3.6z"/><path d="M12 10v3.4"/><circle cx="12" cy="16.6" r=".85" fill="currentColor" stroke="none"/>',
    check: '<path d="M5 12.6l4.4 4.4L19 7.2"/>',
    disc: '<circle cx="12" cy="12" r="8.6"/><circle cx="12" cy="12" r="2.3"/><path d="M12 3.4a8.6 8.6 0 0 1 6.1 2.6"/>',
    clock: '<circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 1.9"/>',
    film: '<rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2.4"/><path d="M8 4.6v14.8M16 4.6v14.8M3.4 9.4h4.6M16 9.4h4.6M3.4 14.6h4.6M16 14.6h4.6"/>',
    eye: '<path d="M2.6 12s3.6-6.4 9.4-6.4S21.4 12 21.4 12s-3.6 6.4-9.4 6.4S2.6 12 2.6 12z"/><circle cx="12" cy="12" r="2.8"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    heart: '<path d="M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.7a4.1 4.1 0 0 1 7.5 2.9C19.5 15.6 12 20 12 20z"/>',
    heartFill: '<path d="M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.7a4.1 4.1 0 0 1 7.5 2.9C19.5 15.6 12 20 12 20z" fill="currentColor" stroke="currentColor"/>',
    volume: '<path d="M4 9.5h3l5-3.5v12l-5-3.5H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.6 7.6 0 0 1 0 11"/>',
    mute: '<path d="M4 9.5h3l5-3.5v12l-5-3.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    filmOff: '<rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2.4"/><path d="M9 9l6 6M15 9l-6 6"/>'
  };

  function svg(name, extraClass) {
    var body = ICONS[name] || '';
    return '<svg class="bi-ico' + (extraClass ? ' ' + extraClass : '') +
      '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  /* ------------------------------------------------------------
     小工具
     ------------------------------------------------------------ */
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function pad2(n) {
    return (n < 10 ? '0' : '') + n;
  }

  function num(v) {
    var n = Number(v);
    return isFinite(n) ? n : 0;
  }

  function fmtClock(sec) {
    var s = Number(sec);
    if (!isFinite(s) || s <= 0) return '--:--';
    s = Math.floor(s);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var r = s % 60;
    if (h > 0) return h + ':' + pad2(m) + ':' + pad2(r);
    return pad2(m) + ':' + pad2(r);
  }

  function fmtViews(n) {
    n = Number(n);
    if (!isFinite(n) || n <= 0) return '0 播放';
    if (n >= 100000000) return (n / 100000000).toFixed(1).replace(/\.0$/, '') + ' 亿播放';
    if (n >= 10000) return (n / 10000).toFixed(1).replace(/\.0$/, '') + ' 万播放';
    return n + ' 播放';
  }

  function fmtSize(bytes) {
    var n = Number(bytes);
    if (!isFinite(n) || n <= 0) return '0 MB';
    var mb = n / 1048576;
    if (mb >= 1024) return (mb / 1024).toFixed(2) + ' GB';
    if (mb >= 100) return Math.round(mb) + ' MB';
    return mb.toFixed(1) + ' MB';
  }

  function shortTime(text) {
    var s = String(text == null ? '' : text);
    var m = /(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2})/.exec(s);
    if (m) return m[1].replace('T', ' ');
    var t = /(\d{2}:\d{2})/.exec(s);
    if (t) return t[1];
    return s;
  }

  function readLS(key, fallback) {
    try {
      var raw = window.localStorage.getItem(key);
      if (!raw) return fallback;
      var v = JSON.parse(raw);
      return v == null ? fallback : v;
    } catch (e) {
      return fallback;
    }
  }

  function writeLS(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (e) { /* 存不下就算了 */ }
  }

  function pathURL(p) {
    var clean = String(p == null ? '' : p).replace(/^\/+/, '');
    if (!clean) return '';
    return '/' + clean.split('/').filter(function (x) { return x !== ''; })
      .map(encodeURIComponent).join('/');
  }

  function baseName(p) {
    var parts = String(p == null ? '' : p).split(/[\\/]/);
    return parts[parts.length - 1] || '';
  }

  function pickPic(url) {
    var s = String(url == null ? '' : url);
    if (!s) return '';
    if (s.indexOf('//') === 0) return 'https:' + s;
    return s;
  }

  function fetchJSON(url, opt) {
    return fetch(url, opt || {}).then(function (res) {
      if (!res || !res.ok) {
        var err = new Error('HTTP ' + (res ? res.status : '?'));
        err.status = res ? res.status : 0;
        throw err;
      }
      return res.json();
    });
  }

  function postJSON(url, body) {
    return fetchJSON(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    }).catch(function () { return null; });
  }

  /* ------------------------------------------------------------
     空态 / 载入
     ------------------------------------------------------------ */
  function emptyMarkup(icon, title, hint, action) {
    return '<div class="bi-empty">' +
      '<div class="bi-empty-ico">' + svg(icon) + '</div>' +
      '<p class="bi-empty-title">' + esc(title) + '</p>' +
      '<p class="bi-empty-hint">' + esc(hint) + '</p>' +
      (action ? '<button type="button" class="bi-btn" data-act="' + esc(action.act) + '"' +
        (action.view ? ' data-view="' + esc(action.view) + '"' : '') + '>' +
        esc(action.label) + '</button>' : '') +
      '</div>';
  }

  function loadingMarkup(text) {
    return '<div class="bi-loading"><span class="bi-spinner"></span>' + esc(text) + '</div>';
  }

  /* ------------------------------------------------------------
     模块状态
     ------------------------------------------------------------ */
  var mounted = false;
  var host = null;
  var root = null;
  var refs = {};
  var st = null;

  var pollTimer = null;
  var toastTimer = null;
  var searchSeq = 0;
  var pageSeq = 0;
  var feedSeq = 0;
  var sizeSeq = 0;
  var visHandler = null;
  var keyHandler = null;

  function createState() {
    return {
      view: 'search',
      search: {
        q: '',
        loading: false,
        items: [],
        total: 0,
        offline: false,
        cached_at: '',
        error: '',
        searchedOnce: false
      },
      page: {
        loaded: false,
        offline: false,
        online: null,
        cached_at: '',
        wants: [],
        downloads: []
      },
      feed: {
        loaded: false,
        loading: false,
        error: '',
        videos: [],
        recs: [],
        generated: '',
        videosBytes: 0
      },
      autodl: loadAutodl(),
      autodlTried: false,
      feedRefs: {},
      cardRefs: {},
      dlRefs: {},
      wantRefs: {},
      busy: {},
      wantBusy: false,
      playing: '',
      playingKey: '',
      favBusy: false,
      sizes: loadSizes()
    };
  }

  function loadSizes() {
    var raw = readLS(LS_SIZES, {});
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
    var out = {};
    var keys = Object.keys(raw);
    for (var i = 0; i < keys.length && i < MAX_SIZES; i++) {
      var n = Number(raw[keys[i]]);
      if (isFinite(n) && n > 0) out[keys[i]] = n;
    }
    return out;
  }

  function persistSizes() {
    if (!st) return;
    var keys = Object.keys(st.sizes);
    if (keys.length <= MAX_SIZES) {
      writeLS(LS_SIZES, st.sizes);
      return;
    }
    var cut = {};
    for (var i = keys.length - MAX_SIZES; i < keys.length; i++) cut[keys[i]] = st.sizes[keys[i]];
    st.sizes = cut;
    writeLS(LS_SIZES, cut);
  }

  function loadAutodl() {
    var raw = readLS(LS_AUTODL, {});
    if (!raw || typeof raw !== 'object') return { day: '', at: '', n: 0 };
    return {
      day: raw.day ? String(raw.day) : '',
      at: raw.at ? String(raw.at) : '',
      n: num(raw.n)
    };
  }

  function dayStr(d) {
    var t = d || new Date();
    return t.getFullYear() + '-' + pad2(t.getMonth() + 1) + '-' + pad2(t.getDate());
  }

  function clockStr(d) {
    var t = d || new Date();
    return pad2(t.getHours()) + ':' + pad2(t.getMinutes());
  }

  /* ------------------------------------------------------------
     骨架
     ------------------------------------------------------------ */
  function shellHTML() {
    return '' +
      '<aside class="bi-side">' +
        '<div class="bi-brand">' +
          '<span class="bi-brand-mark">' + svg('bili') + '</span>' +
          '<span class="bi-brand-txt"><b>B 站</b><small>离线视频</small></span>' +
        '</div>' +
        '<nav class="bi-nav" id="bi-nav"></nav>' +
        '<div class="bi-side-note">' +
          '<p class="bi-note-t">断网也能翻</p>' +
          '<p class="bi-note-x">搜到的结果、下好的视频都存在这台电脑上，没网也照常看。</p>' +
        '</div>' +
        '<div class="bi-side-foot">' +
          '<div class="bi-side-stat" id="bi-side-stat">共 0 个视频 ・ 占用 0 MB</div>' +
          '<div class="bi-side-time" id="bi-side-time">本地缓存</div>' +
        '</div>' +
      '</aside>' +

      '<section class="bi-stage">' +
        '<header class="bi-head">' +
          '<div class="bi-head-txt">' +
            '<h2 id="bi-title">搜索</h2>' +
            '<p id="bi-sub">打关键词，搜到就能下下来离线看</p>' +
          '</div>' +
          '<div class="bi-head-right">' +
            '<span class="bi-updated" id="bi-updated">还没搜过</span>' +
            '<button type="button" class="bi-icon-btn" id="bi-refresh" data-act="refresh" title="重新读取">' +
              svg('refresh') + '</button>' +
          '</div>' +
        '</header>' +

        '<div class="bi-content" id="bi-content">' +
          '<section class="bi-pane" id="bi-pane-feed" hidden>' +
            '<div class="bi-feedhero">' +
              '<div class="bi-feedhero-txt">' +
                '<span class="bi-kicker">ONLINE PICKS</span>' +
                '<h3>每次联网，自动下几条推荐</h3>' +
                '<p id="bi-feed-note">下好的躺这儿，断网也能看。</p>' +
              '</div>' +
              '<button type="button" class="bi-btn bi-btn-solid" data-act="feed-dl">再下几条</button>' +
            '</div>' +
            '<div class="bi-sechead">' +
              '<h3>本地视频</h3><span class="bi-secn" id="bi-videos-n"></span>' +
            '</div>' +
            '<div class="bi-cards" id="bi-feed-videos"></div>' +
            '<div class="bi-sechead">' +
              '<h3>B 站推荐</h3><span class="bi-secn" id="bi-recs-n"></span>' +
            '</div>' +
            '<div class="bi-cards" id="bi-feed-recs"></div>' +
          '</section>' +

          '<section class="bi-pane" id="bi-pane-search">' +
            '<div class="bi-searchbar">' +
              '<span class="bi-searchbar-ico">' + svg('search') + '</span>' +
              '<input id="bi-q" type="search" placeholder="搜 B 站视频：鬼畜 / 原神 / 高数…" ' +
                'autocomplete="off" spellcheck="false" aria-label="搜索 B 站视频">' +
              '<button type="button" class="bi-searchbtn" id="bi-do-search" data-act="do-search">搜</button>' +
            '</div>' +
            '<div class="bi-offline" id="bi-offline" role="status" hidden>' +
              '<span class="bi-offline-dot" aria-hidden="true"></span><span id="bi-offline-txt"></span>' +
            '</div>' +
            '<div class="bi-results" id="bi-results"></div>' +
          '</section>' +

          '<section class="bi-pane" id="bi-pane-downloads" hidden>' +
            '<div class="bi-sechead">' +
              '<h3>下载队列</h3><span class="bi-secn" id="bi-dl-n"></span>' +
            '</div>' +
            '<div class="bi-dls" id="bi-dls"></div>' +
          '</section>' +

          '<section class="bi-pane" id="bi-pane-wants" hidden>' +
            '<div class="bi-wantbar">' +
              '<input id="bi-want-input" type="text" placeholder="记个关键词，比如 鬼畜" ' +
                'autocomplete="off" spellcheck="false" aria-label="记一个关键词">' +
              '<button type="button" class="bi-wantadd" id="bi-want-add" data-act="want-add">' +
                svg('plus') + '<span>记下</span></button>' +
            '</div>' +
            '<p class="bi-wanthint">断网也能记，联网后自动搜并下载前几条。记太多会占地方，挑真想要的。</p>' +
            '<div class="bi-wants" id="bi-wants"></div>' +
          '</section>' +
        '</div>' +
      '</section>' +

      '<div class="bi-player" id="bi-player" hidden role="dialog" aria-modal="true" aria-label="播放视频">' +
        '<div class="bi-player-bg" data-act="player-close"></div>' +
        '<div class="bi-player-box">' +
          '<div class="bi-player-head">' +
            '<span class="bi-player-title" id="bi-player-title"></span>' +
            '<button type="button" class="bi-pl-sound" id="bi-pl-sound" data-act="player-sound" title="开声音">' +
              svg('mute') + '<span>静音</span></button>' +
            '<button type="button" class="bi-pl-fav" id="bi-pl-fav" data-act="player-fav" hidden>' + svg('heart') + '收藏</button>' +
            '<button type="button" class="bi-icon-btn" data-act="player-close" title="关掉">' + svg('close') + '</button>' +
          '</div>' +
          '<div class="bi-player-body">' +
            '<video id="bi-video" controls playsinline preload="metadata"></video>' +
          '</div>' +
          '<div class="bi-player-info" id="bi-player-info">' +
            '<p class="bi-pl-meta" id="bi-pl-meta"></p>' +
            '<p class="bi-pl-desc" id="bi-pl-desc" hidden></p>' +
            '<div class="bi-pl-cmts" id="bi-pl-cmts"></div>' +
          '</div>' +
        '</div>' +
      '</div>' +

      '<div class="bi-toast" id="bi-toast" role="status" aria-live="polite"></div>';
  }

  function cacheRefs() {
    refs.nav = root.querySelector('#bi-nav');
    refs.title = root.querySelector('#bi-title');
    refs.sub = root.querySelector('#bi-sub');
    refs.updated = root.querySelector('#bi-updated');
    refs.refresh = root.querySelector('#bi-refresh');
    refs.content = root.querySelector('#bi-content');
    refs.paneSearch = root.querySelector('#bi-pane-search');
    refs.paneFeed = root.querySelector('#bi-pane-feed');
    refs.paneDl = root.querySelector('#bi-pane-downloads');
    refs.paneWant = root.querySelector('#bi-pane-wants');
    refs.feedNote = root.querySelector('#bi-feed-note');
    refs.feedVideos = root.querySelector('#bi-feed-videos');
    refs.feedRecs = root.querySelector('#bi-feed-recs');
    refs.videosN = root.querySelector('#bi-videos-n');
    refs.recsN = root.querySelector('#bi-recs-n');
    refs.q = root.querySelector('#bi-q');
    refs.searchBtn = root.querySelector('#bi-do-search');
    refs.offline = root.querySelector('#bi-offline');
    refs.offlineTxt = root.querySelector('#bi-offline-txt');
    refs.results = root.querySelector('#bi-results');
    refs.dlList = root.querySelector('#bi-dls');
    refs.dlN = root.querySelector('#bi-dl-n');
    refs.wantInput = root.querySelector('#bi-want-input');
    refs.wantAdd = root.querySelector('#bi-want-add');
    refs.wantList = root.querySelector('#bi-wants');
    refs.sideStat = root.querySelector('#bi-side-stat');
    refs.sideTime = root.querySelector('#bi-side-time');
    refs.player = root.querySelector('#bi-player');
    refs.playerTitle = root.querySelector('#bi-player-title');
    refs.plMeta = root.querySelector('#bi-pl-meta');
    refs.plDesc = root.querySelector('#bi-pl-desc');
    refs.plCmts = root.querySelector('#bi-pl-cmts');
    refs.plFav = root.querySelector('#bi-pl-fav');
    refs.plSound = root.querySelector('#bi-pl-sound');
    refs.video = root.querySelector('#bi-video');
    refs.toast = root.querySelector('#bi-toast');
  }

  /* ------------------------------------------------------------
     挂载 / 卸载
     ------------------------------------------------------------ */
  function mount(container) {
    if (!container || !container.appendChild) return;
    if (mounted) unmount();

    mounted = true;
    host = container;
    st = createState();

    container.classList.add('bi-host');
    container.innerHTML = '';
    root = document.createElement('div');
    root.className = 'bi-app';
    var embed = container.getAttribute('data-embed');
    if (!embed || embed === '0' || embed === 'false') root.className += ' bi-fixed';
    root.innerHTML = shellHTML();
    container.appendChild(root);

    cacheRefs();
    document.body.classList.add('mu-fs');

    st.view = 'search';
    renderNav();
    renderHead();
    renderStats();
    renderFeed();
    renderSearch(true);
    renderDownloads();
    renderWants();
    applyView();

    bindUi();
    loadPage();
    schedulePoll();
  }

  function unmount() {
    if (!mounted) return;
    mounted = false;

    stopPoll();
    if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }

    if (keyHandler) { document.removeEventListener('keydown', keyHandler, false); keyHandler = null; }
    if (visHandler) { document.removeEventListener('visibilitychange', visHandler, false); visHandler = null; }

    closePlayer();
    document.body.classList.remove('mu-fs');

    if (root && root.parentNode) root.parentNode.removeChild(root);
    if (host) host.classList.remove('bi-host');

    root = null;
    refs = {};
    host = null;
    st = null;
    searchSeq = 0;
    pageSeq = 0;
    feedSeq = 0;
    sizeSeq = 0;
  }

  function bindUi() {
    root.addEventListener('click', onClick, false);

    // 封面挂了就藏起来，露出底下的占位图标（断网时很常见）
    root.addEventListener('error', function (e) {
      var t = e.target;
      if (t && t.classList && t.classList.contains('bi-cover-img')) {
        t.style.display = 'none';
      }
    }, true);

    if (refs.q) {
      refs.q.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          runSearch(refs.q.value);
        }
      }, false);
    }

    if (refs.wantInput) {
      refs.wantInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          addWant();
        }
      }, false);
    }

    keyHandler = function (e) {
      if (!mounted) return;
      if (e.key === 'Escape' && refs.player && !refs.player.hidden) {
        closePlayer();
      }
    };
    document.addEventListener('keydown', keyHandler, false);

    visHandler = function () {
      if (!mounted) return;
      if (document.hidden) {
        stopPoll();
        return;
      }
      loadPage();
      schedulePoll();
    };
    document.addEventListener('visibilitychange', visHandler, false);
  }

  function onClick(e) {
    var el = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || !root || !root.contains(el)) return;
    var act = el.getAttribute('data-act');

    if (act === 'view') {
      setView(el.getAttribute('data-view'));
      return;
    }
    if (act === 'do-search') {
      runSearch(refs.q ? refs.q.value : '');
      return;
    }
    if (act === 'refresh') {
      loadPage();
      loadFeed();
      if (st.search.q) runSearch(st.search.q);
      return;
    }
    if (act === 'retry-search') {
      runSearch(st.search.q || (refs.q ? refs.q.value : ''));
      return;
    }
    if (act === 'feed-dl') {
      feedDownloadMore();
      return;
    }
    if (act === 'playlocal') {
      playLocalVideo(el.getAttribute('data-file'));
      return;
    }
    if (act === 'player-fav') {
      toggleFav();
      return;
    }
    if (act === 'player-sound') {
      toggleSound();
      return;
    }
    if (act === 'dl') {
      startDownload(el.getAttribute('data-bvid'));
      return;
    }
    if (act === 'play') {
      var bvid = el.getAttribute('data-bvid');
      var d = downloadOf(bvid);
      if (d) openPlayer(d);
      return;
    }
    if (act === 'player-close') {
      closePlayer();
      return;
    }
    if (act === 'want-add') {
      addWant();
      return;
    }
    if (act === 'want-del') {
      removeWant(el.getAttribute('data-id'));
    }
  }

  /* ------------------------------------------------------------
     视图切换
     ------------------------------------------------------------ */
  function viewDef(key) {
    for (var i = 0; i < VIEWS.length; i++) {
      if (VIEWS[i].key === key) return VIEWS[i];
    }
    return VIEWS[0];
  }

  function setView(view) {
    if (!st) return;
    if (!view || !viewDef(view)) view = 'search';
    st.view = view;
    applyView();
    renderNav();
    renderHead();
    if (view === 'feed') loadFeed();
    if (view === 'downloads') loadPage();
  }

  function applyView() {
    if (!refs.paneSearch) return;
    refs.paneFeed.hidden = st.view !== 'feed';
    refs.paneSearch.hidden = st.view !== 'search';
    refs.paneDl.hidden = st.view !== 'downloads';
    refs.paneWant.hidden = st.view !== 'wants';
    if (refs.content) refs.content.scrollTop = 0;
  }

  /* ------------------------------------------------------------
     数据整理
     ------------------------------------------------------------ */
  function normItem(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var bvid = raw.bvid ? String(raw.bvid) : '';
    if (!bvid) return null;
    var dur = num(raw.duration_s);
    return {
      bvid: bvid,
      aid: raw.aid == null ? '' : String(raw.aid),
      cid: raw.cid == null ? '' : String(raw.cid),
      title: raw.title ? String(raw.title) : '没标题的视频',
      up: raw.up ? String(raw.up) : '',
      duration_s: dur,
      view: num(raw.view),
      pic: raw.pic ? String(raw.pic) : '',
      pic_url: pickPic(raw.pic_url),
      desc: raw.desc ? String(raw.desc) : '',
      url: raw.url ? String(raw.url) : '',
      too_long: raw.too_long === true || dur > TOO_LONG_S
    };
  }

  function normItems(raw) {
    var out = [];
    if (!Array.isArray(raw)) return out;
    for (var i = 0; i < raw.length; i++) {
      var it = normItem(raw[i]);
      if (it) out.push(it);
    }
    return out;
  }

  function normDownload(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var bvid = raw.bvid ? String(raw.bvid) : '';
    if (!bvid) return null;
    var state = String(raw.state || 'pending');
    if (state !== 'pending' && state !== 'downloading' && state !== 'done' && state !== 'error') {
      state = 'pending';
    }
    var p = num(raw.progress);
    if (p > 0 && p <= 1) p = p * 100;
    if (!isFinite(p)) p = 0;
    p = Math.max(0, Math.min(100, Math.round(p)));
    return {
      bvid: bvid,
      title: raw.title ? String(raw.title) : '',
      state: state,
      progress: p,
      error: raw.error ? String(raw.error) : '',
      file: raw.file ? String(raw.file) : ''
    };
  }

  function normDownloads(raw) {
    var out = [];
    if (!Array.isArray(raw)) return out;
    for (var i = 0; i < raw.length; i++) {
      var d = normDownload(raw[i]);
      if (d) out.push(d);
    }
    return out;
  }

  function normWant(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var id = raw.id == null ? '' : String(raw.id);
    if (!id) return null;
    var state = String(raw.state || 'pending');
    if (state !== 'pending' && state !== 'done' && state !== 'failed') state = 'pending';
    return {
      id: id,
      keyword: raw.keyword ? String(raw.keyword) : '没写关键词',
      created_at: raw.created_at ? String(raw.created_at) : '',
      state: state,
      note: raw.note ? String(raw.note) : ''
    };
  }

  function normWants(raw) {
    var out = [];
    if (!Array.isArray(raw)) return out;
    for (var i = 0; i < raw.length; i++) {
      var w = normWant(raw[i]);
      if (w) out.push(w);
    }
    return out;
  }

  function normVideo(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var file = raw.file ? String(raw.file) : '';
    if (!file) return null;
    var id = raw.id || raw.bvid || '';
    var dur = num(raw.duration != null ? raw.duration : raw.duration_s);
    var cmts = [];
    if (Array.isArray(raw.comments)) {
      for (var i = 0; i < raw.comments.length && i < 8; i++) {
        var c = raw.comments[i];
        if (!c || typeof c !== 'object') continue;
        cmts.push({
          user: c.user ? String(c.user) : '匿名',
          like: num(c.like),
          text: c.text ? String(c.text) : ''
        });
      }
    }
    return {
      bvid: id ? String(id) : '',
      title: raw.title ? String(raw.title) : '没标题的视频',
      up: raw.up ? String(raw.up) : '',
      duration_s: dur,
      view: num(raw.view),
      pic: raw.pic ? String(raw.pic) : '',
      file: file,
      size: num(raw.size),
      desc: raw.desc ? String(raw.desc) : '',
      url: raw.url ? String(raw.url) : '',
      comments: cmts
    };
  }

  function normVideos(raw) {
    var out = [];
    if (!Array.isArray(raw)) return out;
    for (var i = 0; i < raw.length; i++) {
      var v = normVideo(raw[i]);
      if (v) out.push(v);
    }
    return out;
  }

  function downloadOf(bvid) {    if (!st || !bvid) return null;
    var list = st.page.downloads;
    for (var i = 0; i < list.length; i++) {
      if (list[i].bvid === bvid) return list[i];
    }
    return null;
  }

  function itemOf(bvid) {
    var list = st.search.items;
    for (var i = 0; i < list.length; i++) {
      if (list[i].bvid === bvid) return list[i];
    }
    var recs = st.feed.recs;
    for (var j = 0; j < recs.length; j++) {
      if (recs[j].bvid === bvid) return recs[j];
    }
    return null;
  }

  /* ------------------------------------------------------------
     读取服务端状态
     ------------------------------------------------------------ */
  function loadPage() {
    if (!mounted || !st) return Promise.resolve();
    var seq = ++pageSeq;
    return fetchJSON(API_PAGE + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== pageSeq) return;
        applyPage(data || {});
        renderUpdated('已同步');
      })
      .catch(function () {
        if (!mounted || !st || seq !== pageSeq) return;
        st.page.loaded = true;
        renderStats();
        renderDownloads();
        renderWants();
        updateCardStates();
        renderUpdated('没连上本地服务，稍后再试');
      });
  }

  function applyPage(data) {
    var offline = data.offline === true || data.online === false;
    st.page.loaded = true;
    st.page.offline = offline;
    if (data.online === true) st.page.online = true;
    else if (data.online === false || data.offline === true) st.page.online = false;
    else st.page.online = null;
    st.page.cached_at = data.cached_at ? String(data.cached_at) : '';
    st.page.wants = normWants(data.wants);
    st.page.downloads = normDownloads(data.downloads);

    if (!st.search.searchedOnce) {
      var items = normItems(data.items);
      var q = data.query ? String(data.query) : '';
      if (items.length || q) {
        st.search.q = q || st.search.q;
        if (refs.q && !refs.q.value) refs.q.value = st.search.q;
        st.search.items = items;
        st.search.total = items.length;
        st.search.offline = offline;
        st.search.cached_at = st.page.cached_at;
        st.search.error = '';
        st.search.loading = false;
        st.search.searchedOnce = true;
        renderSearch(true);
      }
    }

    if (st.view === 'search') {
      var sr = st.search;
      if (sr.items.length && (offline || sr.cached_at)) updateOfflineBar();
    }

    renderNav();
    renderStats();
    renderDownloads();
    renderWants();
    renderFeedNote();
    updateCardStates();
    renderHead();
    measureSizes();
    maybeAutoDownload();
  }

  /* ------------------------------------------------------------
     渲染：导航 / 头部 / 底部统计
     ------------------------------------------------------------ */
  function doneCount() {
    var n = 0;
    var list = st.page.downloads;
    for (var i = 0; i < list.length; i++) if (list[i].state === 'done' && list[i].file) n++;
    return n;
  }

  function renderNav() {
    if (!refs.nav) return;
    var counts = {
      search: '',
      downloads: st.page.downloads.length,
      wants: st.page.wants.length
    };
    var html = VIEWS.map(function (v) {
      var n = counts[v.key];
      return '<button type="button" class="bi-nav-item' + (st.view === v.key ? ' active' : '') + '"' +
        ' data-act="view" data-view="' + v.key + '">' +
        svg(v.icon) + '<span>' + esc(v.label) + '</span>' +
        (n ? '<em class="bi-nav-n">' + n + '</em>' : '') +
        '</button>';
    }).join('');
    refs.nav.innerHTML = html;
  }

  function renderHead() {
    if (!refs.title) return;
    var v = viewDef(st.view);
    refs.title.textContent = v.title;
    refs.sub.textContent = v.sub;

    var text;
    if (st.view === 'search') {
      if (st.search.loading) text = '正在搜…';
      else if (st.search.q) {
        text = '搜了「' + st.search.q + '」';
        if (st.search.offline) text += ' ・ 断网结果';
      } else text = '还没搜过';
    } else if (st.view === 'downloads') {
      var run = 0;
      for (var i = 0; i < st.page.downloads.length; i++) {
        var s = st.page.downloads[i].state;
        if (s === 'pending' || s === 'downloading') run++;
      }
      text = run ? ('正在下 ' + run + ' 个') : ('已下好 ' + doneCount() + ' 个');
    } else if (st.view === 'feed') {
      text = st.feed.loaded
        ? (st.feed.videos.length + ' 个本地视频 ・ ' + st.feed.recs.length + ' 条推荐')
        : '正在读推荐…';
    } else {
      text = st.page.wants.length ? (st.page.wants.length + ' 个关键词') : '还没记过';
    }
    refs.updated.textContent = text;
  }

  function renderUpdated(text) {
    if (!refs.updated) return;
    refs.updated.textContent = text;
    if (!text) renderHead();
  }

  function renderStats() {
    if (!refs.sideStat) return;
    var n = doneCount() + st.feed.videos.length;
    var bytes = 0;
    for (var i = 0; i < st.page.downloads.length; i++) {
      var d = st.page.downloads[i];
      if (d.state !== 'done' || !d.file) continue;
      var size = st.sizes[d.file];
      if (isFinite(size) && size > 0) bytes += size;
    }
    bytes += st.feed.videosBytes;
    refs.sideStat.textContent = '共 ' + n + ' 个视频 ・ 占用 ' + fmtSize(bytes);
    var when = shortTime(st.page.cached_at);
    refs.sideTime.textContent = when ? ('最近同步 ' + when) : '本地缓存';
  }

  /* ------------------------------------------------------------
     渲染：推荐（本地视频 + B 站推荐 + 联网自动下）
     ------------------------------------------------------------ */
  function renderFeedNote() {
    if (!refs.feedNote || !st) return;
    var a = st.autodl;
    var text;
    if (st.feed.loading && !st.feed.loaded) {
      text = '正在读本地视频和 B 站推荐…';
    } else if (st.feed.error) {
      text = st.feed.error;
    } else if (a && a.day === dayStr()) {
      text = '今天 ' + (a.at || '--:--') + ' 已经自动下了 ' + a.n + ' 条，下好在上面躺着，断网也能看。';
    } else if (st.page.online === false) {
      text = '现在没网。等联网后自动下 ' + AUTO_DL_COUNT + ' 条推荐。';
    } else {
      text = '联网后自动下 ' + AUTO_DL_COUNT + ' 条推荐（超过 30 分钟的不下），下好的躺这儿。';
    }
    if (refs.feedNote.textContent !== text) refs.feedNote.textContent = text;
  }

  function videoCardHTML(v) {
    var pic = v.pic
      ? '<img class="bi-cover-img" src="' + esc(pathURL(v.pic)) + '" alt="" loading="lazy">'
      : '';
    return '<article class="bi-vcard" data-act="playlocal" data-file="' + esc(v.file) + '"' +
      ' tabindex="0" role="button" aria-label="播放：' + esc(v.title) + '">' +
      '<div class="bi-cover">' + pic +
        '<span class="bi-cover-ph">' + svg('filmOff') + '</span>' +
        '<span class="bi-cover-dur">' + esc(fmtClock(v.duration_s)) + '</span>' +
        '<span class="bi-cover-play">' + svg('play') + '</span>' +
      '</div>' +
      '<div class="bi-card-body">' +
        '<h4 class="bi-card-title" title="' + esc(v.title) + '">' + esc(v.title) + '</h4>' +
        '<div class="bi-card-meta">' +
          '<span class="bi-card-up">' + esc(v.up || '未知 UP') + '</span>' +
          '<span class="bi-card-view">' + esc(fmtSize(v.size)) + '</span>' +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function assignFeedRefs() {
    st.feedRefs = {};
    if (!refs.feedRecs) return;
    var nodes = refs.feedRecs.querySelectorAll('.bi-card');
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      var bvid = card.getAttribute('data-bvid');
      st.feedRefs[bvid] = {
        card: card,
        btn: card.querySelector('.bi-card-act'),
        prog: card.querySelector('.bi-card-prog'),
        fill: card.querySelector('.bi-card-prog i')
      };
    }
  }

  function renderFeed(force) {
    if (!refs.feedVideos || !st) return;
    var f = st.feed;

    var vSig = f.videos.map(function (v) { return v.file; }).join('|');
    if (force || refs.feedVideos.getAttribute('data-sig') !== vSig) {
      refs.feedVideos.setAttribute('data-sig', vSig);
      refs.feedVideos.innerHTML = f.videos.length
        ? f.videos.map(videoCardHTML).join('')
        : emptyMarkup('film', '还没有下好的视频',
          '联网后这儿会自己多出几条；在「搜索」里点「下载」的视频也会进来。',
          { label: '去搜索', act: 'view', view: 'search' });
    }
    if (refs.videosN) refs.videosN.textContent = f.videos.length ? (f.videos.length + ' 个') : '';

    var rSig = f.recs.map(function (x) { return x.bvid; }).join('|');
    if (force || refs.feedRecs.getAttribute('data-sig') !== rSig) {
      refs.feedRecs.setAttribute('data-sig', rSig);
      refs.feedRecs.innerHTML = f.recs.length
        ? f.recs.map(cardHTML).join('')
        : emptyMarkup('search', '这轮还没抓到 B 站推荐',
          '等老师开热点、后台抓一轮首页推荐，这儿就有了。也可以先在「搜索」里自己找。',
          { label: '去搜索', act: 'view', view: 'search' });
      assignFeedRefs();
    }
    if (refs.recsN) refs.recsN.textContent = f.recs.length ? (f.recs.length + ' 条') : '';

    updateCardStates();
    renderFeedNote();
  }

  function loadFeed() {
    if (!mounted || !st) return Promise.resolve();
    var seq = ++feedSeq;
    st.feed.loading = true;
    renderFeedNote();
    return Promise.all([
      fetchJSON(API_VIDEOS + '?t=' + Date.now(), { cache: 'no-store' }).catch(function () { return null; }),
      fetchJSON(API_REC + '?t=' + Date.now(), { cache: 'no-store' }).catch(function () { return null; })
    ]).then(function (res) {
      if (!mounted || !st || seq !== feedSeq) return;
      var vids = res[0];
      var recs = res[1];
      st.feed.loading = false;
      st.feed.loaded = true;
      if (!vids && !recs) {
        st.feed.error = '本地服务没响应，推荐暂时读不出来，等会儿点右上角刷新。';
        renderFeed(false);
        return;
      }
      st.feed.error = '';
      if (vids) {
        st.feed.videos = normVideos(vids.items);
        st.feed.videosBytes = num(vids.total_bytes);
        st.feed.generated = vids.generated_at ? String(vids.generated_at) : '';
      }
      if (recs) st.feed.recs = normItems(recs.items);
      renderFeed(true);
      renderStats();
      renderHead();
      maybeAutoDownload();
    });
  }

  function pickedRecs(n) {
    var out = [];
    if (!st) return out;
    var list = st.feed.recs;
    for (var i = 0; i < list.length && out.length < n; i++) {
      var it = list[i];
      if (it.too_long) continue;
      var d = downloadOf(it.bvid);
      if (d && (d.state === 'done' || d.state === 'pending' || d.state === 'downloading')) continue;
      out.push(it);
    }
    return out;
  }

  function queueDownloads(items, done) {
    var i = 0;
    function step() {
      if (!mounted || !st || i >= items.length) {
        if (done) done();
        return;
      }
      var it = items[i++];
      if (!downloadOf(it.bvid)) {
        st.page.downloads.unshift({
          bvid: it.bvid, title: it.title, state: 'pending',
          progress: 0, error: '', file: ''
        });
        renderDownloads();
        renderNav();
        renderFeed(false);
      }
      fetchJSON(API_DOWNLOAD, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bvid: it.bvid, title: it.title, duration_s: it.duration_s })
      })
        .catch(function () { /* 一条排不上不耽误后面的 */ })
        .then(function () { step(); });
    }
    step();
  }

  function maybeAutoDownload() {
    if (!mounted || !st || st.autodlTried) return;
    if (st.page.online === false) return;
    // 每次挂载、每次联网都补一轮；已经排过 / 下过的会被 pickedRecs 跳过
    st.autodlTried = true;

    fetchJSON(API_REC + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st) return;
        var recs = normItems((data && data.items) || []);
        if (recs.length) st.feed.recs = recs;
        var picked = pickedRecs(AUTO_DL_COUNT);
        if (!picked.length) {
          renderFeed(false);
          return;
        }
        queueDownloads(picked, function () {
          if (!mounted || !st) return;
          st.autodl = { day: dayStr(), at: clockStr(), n: picked.length };
          writeLS(LS_AUTODL, st.autodl);
          toast('联网了，自动下了 ' + picked.length + ' 条推荐');
          renderFeed(true);
          renderFeedNote();
          loadPage();
          schedulePoll();
        });
      })
      .catch(function () {
        if (st) st.autodlTried = false;
      });
  }

  function feedDownloadMore() {
    if (!mounted || !st) return;
    var picked = pickedRecs(AUTO_DL_COUNT);
    if (!picked.length) {
      toast(st.feed.recs.length ? '这些推荐都排过了，等后台再抓一轮' : '还没抓到推荐，等联网后再说');
      return;
    }
    queueDownloads(picked, function () {
      if (!mounted || !st) return;
      toast('排了 ' + picked.length + ' 条，联网就下');
      renderFeed(true);
      renderDownloads();
      renderNav();
      loadPage();
      schedulePoll();
    });
  }

  /* ------------------------------------------------------------
     渲染：搜索
     ------------------------------------------------------------ */
  function runSearch(raw) {
    if (!mounted || !st) return;
    var q = String(raw == null ? '' : raw).replace(/\s+/g, ' ').trim();
    if (!q) {
      toast('先打点什么再搜');
      if (refs.q) refs.q.focus();
      return;
    }
    if (refs.q && refs.q.value !== q) refs.q.value = q;

    var seq = ++searchSeq;
    st.search.q = q;
    st.search.loading = true;
    st.search.error = '';
    st.search.items = [];
    st.search.total = 0;
    st.search.offline = false;
    st.search.cached_at = '';
    st.search.searchedOnce = true;
    st.cardRefs = {};
    renderSearch(true);
    renderHead();

    fetchJSON(API_SEARCH + '?q=' + encodeURIComponent(q) + '&t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== searchSeq) return;
        data = data || {};
        st.search.loading = false;
        st.search.items = normItems(data.items);
        st.search.total = num(data.total) || st.search.items.length;
        st.search.offline = data.offline === true;
        st.search.cached_at = data.cached_at ? String(data.cached_at) : '';
        st.search.error = data.error ? String(data.error) : '';
        st.search.q = data.q ? String(data.q) : q;
        st.cardRefs = {};
        renderSearch(true);
        renderHead();
        if (st.search.offline) {
          toast('现在没网，这是上次存下的结果');
        } else if (!st.search.items.length) {
          toast('没搜到，换个说法试试');
        }
      })
      .catch(function (err) {
        if (!mounted || !st || seq !== searchSeq) return;
        st.search.loading = false;
        st.search.items = [];
        st.cardRefs = {};
        st.search.error = searchErrorText(err);
        renderSearch(true);
        renderHead();
      });
  }

  function searchErrorText(err) {
    if (err && err.status === 404) return '本地服务还没开放 B 站搜索接口（/api/bili/search 返回 404）。';
    if (err && err.status) return '搜索失败（HTTP ' + err.status + '），等会儿再点「搜」重试。';
    if (window.navigator && window.navigator.onLine === false) {
      return '现在没网，也还没存下这个关键词的结果。先记进「关键词」，联网后自动搜。';
    }
    return '连不上本地服务，确认 newsd 起来了再搜一次。';
  }

  function renderSearch(force) {
    if (!refs.results || !st) return;
    var sr = st.search;

    if (sr.loading) {
      refs.results.innerHTML = loadingMarkup('正在问 B 站要结果…');
      refs.results.removeAttribute('data-sig');
      renderOffline();
      return;
    }

    renderOffline();

    if (sr.error) {
      refs.results.innerHTML = emptyMarkup('alert', '没搜成', sr.error, {
        label: '重新搜一次', act: 'retry-search'
      });
      refs.results.removeAttribute('data-sig');
      return;
    }

    if (!sr.q) {
      refs.results.innerHTML = emptyMarkup(
        'search',
        '还没搜过东西',
        '在上面打个关键词搜一下。断网也不怕，先在「关键词」里记着，联网后自动搜。',
        { label: '去记关键词', act: 'view', view: 'wants' }
      );
      refs.results.removeAttribute('data-sig');
      return;
    }

    if (!sr.items.length) {
      if (sr.offline) {
        refs.results.innerHTML = emptyMarkup(
          'filmOff',
          '断网，本地也没存下「' + sr.q + '」的结果',
          '这个关键词是联网时才会搜的。先在「关键词」里记下来，等老师开热点、后台同步完再看。',
          { label: '记下这个关键词', act: 'view', view: 'wants' }
        );
      } else {
        refs.results.innerHTML = emptyMarkup(
          'search',
          '没搜到「' + sr.q + '」',
          '换个说法、少打几个字再试试。也可能是 B 站这会儿抽风，过会儿再搜。',
          { label: '重新搜一次', act: 'retry-search' }
        );
      }
      refs.results.removeAttribute('data-sig');
      return;
    }

    var sig = sr.q + '|' + sr.items.map(function (it) { return it.bvid; }).join(',');
    if (!force && refs.results.getAttribute('data-sig') === sig) {
      updateCardStates();
      return;
    }
    refs.results.setAttribute('data-sig', sig);

    var head = '<div class="bi-results-head">' +
      '<h3>「' + esc(sr.q) + '」的结果</h3>' +
      '<span class="bi-results-n">' + sr.items.length + ' 个' +
        (sr.total && sr.total !== sr.items.length ? '（共 ' + sr.total + '）' : '') + '</span>' +
      '</div>';

    var cards = sr.items.map(function (it) { return cardHTML(it); }).join('');
    refs.results.innerHTML = head + '<div class="bi-cards">' + cards + '</div>';
    st.cardRefs = {};
    var nodes = refs.results.querySelectorAll('.bi-card');
    for (var i = 0; i < nodes.length; i++) {
      var card = nodes[i];
      var bvid = card.getAttribute('data-bvid');
      st.cardRefs[bvid] = {
        card: card,
        btn: card.querySelector('.bi-card-act'),
        prog: card.querySelector('.bi-card-prog'),
        fill: card.querySelector('.bi-card-prog i')
      };
    }
    updateCardStates();
  }

  function renderOffline() {
    if (!refs.offline) return;
    var sr = st.search;
    if (!sr.items.length || !sr.offline) {
      refs.offline.hidden = true;
      return;
    }
    var when = shortTime(sr.cached_at || st.page.cached_at);
    var tail = when ? ('这是 ' + when + ' 搜到的结果') : '这是上次联网时存下的结果';
    var txt = '断网中，' + tail + '。现在下不了，可以先记关键词。';
    refs.offlineTxt.textContent = txt;
    refs.offline.hidden = false;
  }

  function updateOfflineBar() {
    renderOffline();
  }

  function cardHTML(it) {
    var src = it.pic ? pathURL(it.pic) : it.pic_url;
    var pic = src
      ? '<img class="bi-cover-img" src="' + esc(src) + '" alt="" loading="lazy" referrerpolicy="no-referrer">'
      : '';
    return '<article class="bi-card" data-bvid="' + esc(it.bvid) + '">' +
      '<div class="bi-cover">' +
        pic +
        '<span class="bi-cover-ph">' + svg('filmOff') + '</span>' +
        '<span class="bi-cover-dur">' + esc(fmtClock(it.duration_s)) + '</span>' +
        (it.too_long ? '<span class="bi-cover-long">超 30 分钟</span>' : '') +
      '</div>' +
      '<div class="bi-card-body">' +
        '<h4 class="bi-card-title" title="' + esc(it.title) + '">' + esc(it.title) + '</h4>' +
        '<div class="bi-card-meta">' +
          '<span class="bi-card-up" title="UP 主">' + esc(it.up || '未知 UP 主') + '</span>' +
          '<span class="bi-card-view">' + svg('eye') + esc(fmtViews(it.view)) + '</span>' +
        '</div>' +
        '<div class="bi-card-foot">' +
          '<div class="bi-card-prog" hidden><i></i></div>' +
          '<button type="button" class="bi-card-act" data-act="dl" data-bvid="' + esc(it.bvid) + '">下载</button>' +
        '</div>' +
      '</div>' +
    '</article>';
  }

  function cardState(item) {
    var d = downloadOf(item.bvid);
    if (!d) {
      if (item.too_long) return { label: '太长', cls: ' is-long' };
      return { label: '下载', cls: '' };
    }
    if (d.state === 'pending') return { label: '排队中', cls: ' is-wait' };
    if (d.state === 'downloading') return { label: '下载中 ' + d.progress + '%', cls: ' is-run' };
    if (d.state === 'done') return { label: '已下载', cls: ' is-done' };
    return { label: '重试', cls: ' is-err' };
  }

  function updateCardStates() {
    if (!st) return;
    syncCards(st.cardRefs);
    syncCards(st.feedRefs);
  }

  function syncCards(map) {
    var keys = Object.keys(map);
    for (var i = 0; i < keys.length; i++) {
      var rec = map[keys[i]];
      var item = itemOf(keys[i]);
      if (!item || !rec.btn) continue;
      var cs = cardState(item);
      if (rec.btn.textContent !== cs.label) rec.btn.textContent = cs.label;
      var cls = 'bi-card-act' + cs.cls;
      if (rec.btn.className !== cls) rec.btn.className = cls;
      rec.btn.setAttribute('aria-disabled', cs.cls && cs.cls !== ' is-long' ? 'true' : 'false');

      var d = downloadOf(item.bvid);
      var running = !!d && (d.state === 'downloading' || d.state === 'pending');
      if (rec.prog) {
        rec.prog.hidden = !running;
        if (running && rec.fill) rec.fill.style.width = (d.state === 'downloading' ? d.progress : 12) + '%';
      }
    }
  }

  /* ------------------------------------------------------------
     动作：下载 / 关键词
     ------------------------------------------------------------ */
  function startDownload(bvid) {
    if (!mounted || !st || !bvid) return;
    var item = itemOf(bvid);
    if (!item) return;

    var d = downloadOf(bvid);
    if (d) {
      if (d.state === 'done') {
        openPlayer(d);
        return;
      }
      if (d.state === 'pending' || d.state === 'downloading') {
        toast('已经排着了，等它下完');
        return;
      }
    }
    if (item.too_long) {
      toast('这条超过 30 分钟，先不下，太占地方了');
      return;
    }
    if (st.busy[bvid]) return;
    st.busy[bvid] = true;

    var idx = -1;
    for (var i = 0; i < st.page.downloads.length; i++) {
      if (st.page.downloads[i].bvid === bvid) { idx = i; break; }
    }
    var fake = {
      bvid: bvid, title: item.title, state: 'pending', progress: 0, error: '', file: ''
    };
    if (idx >= 0) st.page.downloads[idx] = fake;
    else st.page.downloads.unshift(fake);
    renderDownloads();
    renderNav();
    updateCardStates();

    fetchJSON(API_DOWNLOAD, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bvid: bvid, title: item.title, duration_s: item.duration_s })
    })
      .then(function (res) {
        if (!mounted || !st) return;
        st.busy[bvid] = false;
        res = res || {};
        if (res.ok === false) {
          toast(res.msg || '排不上，服务没响应');
        } else {
          toast(res.msg || '排队中，联网就下');
        }
        loadPage();
        schedulePoll();
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.busy[bvid] = false;
        toast('排不上，本地服务没响应');
        loadPage();
      });
  }

  function dlStateText(d) {
    if (d.state === 'pending') return '排队中，等前面的下完';
    if (d.state === 'downloading') return '下载中 ' + d.progress + '%';
    if (d.state === 'done') {
      if (!d.file) return '已完成，但文件没找到';
      return '已完成 ・ ' + baseName(d.file);
    }
    return '失败了：' + (d.error || '原因不明');
  }

  function createDlRow(d) {
    var row = document.createElement('div');
    row.className = 'bi-dlrow';
    row.setAttribute('data-bvid', d.bvid);
    row.innerHTML =
      '<span class="bi-dlico" aria-hidden="true">' +
        svg('clock', 'bi-ico-wait') + svg('disc', 'bi-ico-run') +
        svg('check', 'bi-ico-ok') + svg('alert', 'bi-ico-bad') +
      '</span>' +
      '<div class="bi-dlbody">' +
        '<div class="bi-dltitle"></div>' +
        '<div class="bi-dlsub"></div>' +
        '<div class="bi-dlbar" hidden><i></i></div>' +
      '</div>' +
      '<div class="bi-dlacts">' +
        '<button type="button" class="bi-dlplay" data-act="play" data-bvid="' + esc(d.bvid) + '" hidden>' +
          svg('play') + '播放</button>' +
      '</div>';

    return {
      row: row,
      title: row.querySelector('.bi-dltitle'),
      sub: row.querySelector('.bi-dlsub'),
      bar: row.querySelector('.bi-dlbar'),
      fill: row.querySelector('.bi-dlbar i'),
      play: row.querySelector('.bi-dlplay')
    };
  }

  function updateDlRow(rec, d) {
    if (rec.row.getAttribute('data-state') !== d.state) rec.row.setAttribute('data-state', d.state);
    var title = d.title || '（没标题，BVID ' + d.bvid + '）';
    if (rec.title.textContent !== title) {
      rec.title.textContent = title;
      rec.title.title = title;
    }
    var sub = dlStateText(d);
    if (rec.sub.textContent !== sub) {
      rec.sub.textContent = sub;
      rec.sub.title = sub;
    }
    var running = d.state === 'downloading' || d.state === 'pending';
    if (rec.bar) {
      rec.bar.hidden = !running;
      if (running) {
        rec.bar.className = 'bi-dlbar' + (d.state === 'pending' ? ' is-wait' : '');
        if (rec.fill) rec.fill.style.width = (d.state === 'downloading' ? d.progress : 10) + '%';
      }
    }
    var canPlay = d.state === 'done' && !!d.file;
    if (rec.play) {
      rec.play.hidden = !canPlay;
      if (canPlay) rec.play.title = '播放 ' + baseName(d.file);
    }
  }

  function renderDownloads() {
    if (!refs.dlList || !st) return;
    var list = st.page.downloads;
    if (refs.dlN) {
      var run = 0;
      for (var i = 0; i < list.length; i++) {
        if (list[i].state === 'pending' || list[i].state === 'downloading') run++;
      }
      refs.dlN.textContent = run ? (run + ' 个在排队或下载中') : (list.length + ' 个任务');
    }

    var hint = refs.dlList.querySelector('.bi-empty');
    if (!list.length) {
      for (var key in st.dlRefs) {
        if (!st.dlRefs.hasOwnProperty(key)) continue;
        var gone = st.dlRefs[key];
        if (gone.row.parentNode) gone.row.parentNode.removeChild(gone.row);
      }
      st.dlRefs = {};
      if (!hint) {
        refs.dlList.innerHTML = emptyMarkup(
          'download',
          '还没有下载的视频',
          '去「搜索」里找喜欢的，点「下载」。超过 30 分钟的会先跳过，省地方也看不完。',
          { label: '去搜索', act: 'view', view: 'search' }
        );
      }
      return;
    }
    if (hint && hint.parentNode) hint.parentNode.removeChild(hint);

    var seen = {};
    var prev = null;
    for (var j = 0; j < list.length; j++) {
      var d = list[j];
      seen[d.bvid] = true;
      var rec = st.dlRefs[d.bvid];
      if (!rec) {
        rec = createDlRow(d);
        st.dlRefs[d.bvid] = rec;
      }
      updateDlRow(rec, d);
      var ref = prev ? prev.nextSibling : refs.dlList.firstChild;
      if (ref !== rec.row) refs.dlList.insertBefore(rec.row, ref);
      prev = rec.row;
    }

    for (var k in st.dlRefs) {
      if (!st.dlRefs.hasOwnProperty(k) || seen[k]) continue;
      var dead = st.dlRefs[k];
      if (dead.row.parentNode) dead.row.parentNode.removeChild(dead.row);
      delete st.dlRefs[k];
    }
  }

  function wantStateText(w) {
    if (w.state === 'pending') return '排队中，联网后自动搜';
    if (w.state === 'done') return w.note || '已经搜过一轮了';
    return w.note || '没搜成，等下次联网再试';
  }

  function createWantRow(w) {
    var row = document.createElement('div');
    row.className = 'bi-want';
    row.setAttribute('data-id', w.id);
    row.innerHTML =
      '<span class="bi-wantico" aria-hidden="true">' +
        svg('clock', 'bi-ico-wait') + svg('check', 'bi-ico-ok') + svg('alert', 'bi-ico-bad') +
      '</span>' +
      '<span class="bi-wantinfo">' +
        '<span class="bi-wantkw"></span>' +
        '<span class="bi-wantsub"></span>' +
      '</span>' +
      '<button type="button" class="bi-wantdel" data-act="want-del" data-id="' + esc(w.id) + '" title="删掉这条">' +
        svg('close') + '</button>';
    return {
      row: row,
      kw: row.querySelector('.bi-wantkw'),
      sub: row.querySelector('.bi-wantsub')
    };
  }

  function updateWantRow(rec, w) {
    if (rec.row.getAttribute('data-state') !== w.state) rec.row.setAttribute('data-state', w.state);
    if (rec.kw.textContent !== w.keyword) {
      rec.kw.textContent = w.keyword;
      rec.kw.title = w.keyword;
    }
    var sub = wantStateText(w) + (w.created_at ? ' ・ ' + shortTime(w.created_at) : '');
    if (rec.sub.textContent !== sub) {
      rec.sub.textContent = sub;
      rec.sub.title = sub;
    }
  }

  function renderWants() {
    if (!refs.wantList || !st) return;
    var list = st.page.wants;
    var hint = refs.wantList.querySelector('.bi-empty');
    if (!list.length) {
      for (var key in st.wantRefs) {
        if (!st.wantRefs.hasOwnProperty(key)) continue;
        var gone = st.wantRefs[key];
        if (gone.row.parentNode) gone.row.parentNode.removeChild(gone.row);
      }
      st.wantRefs = {};
      if (!hint) {
        refs.wantList.innerHTML = emptyMarkup(
          'tag',
          '还没记过关键词',
          '比如记「鬼畜」「高数 网课」。断网也能记，联网后自动搜并下载前几条。',
          null
        );
      }
      return;
    }
    if (hint && hint.parentNode) hint.parentNode.removeChild(hint);

    var seen = {};
    var prev = null;
    for (var i = 0; i < list.length; i++) {
      var w = list[i];
      seen[w.id] = true;
      var rec = st.wantRefs[w.id];
      if (!rec) {
        rec = createWantRow(w);
        st.wantRefs[w.id] = rec;
      }
      updateWantRow(rec, w);
      var ref = prev ? prev.nextSibling : refs.wantList.firstChild;
      if (ref !== rec.row) refs.wantList.insertBefore(rec.row, ref);
      prev = rec.row;
    }
    for (var k in st.wantRefs) {
      if (!st.wantRefs.hasOwnProperty(k) || seen[k]) continue;
      var dead = st.wantRefs[k];
      if (dead.row.parentNode) dead.row.parentNode.removeChild(dead.row);
      delete st.wantRefs[k];
    }
  }

  function syncWantBusy() {
    if (!refs.wantAdd) return;
    refs.wantAdd.disabled = !!st.wantBusy;
    var label = refs.wantAdd.querySelector('span');
    if (label) label.textContent = st.wantBusy ? '记下中…' : '记下';
  }

  function addWant() {
    if (!mounted || !st || st.wantBusy) return;
    var text = refs.wantInput ? String(refs.wantInput.value || '') : '';
    text = text.replace(/\s+/g, ' ').trim();
    if (!text) {
      toast('先写个关键词');
      if (refs.wantInput) refs.wantInput.focus();
      return;
    }
    st.wantBusy = true;
    syncWantBusy();

    fetchJSON(API_WANT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keyword: text })
    })
      .then(function (res) {
        if (!mounted || !st) return;
        st.wantBusy = false;
        syncWantBusy();
        res = res || {};
        if (res.ok === false) {
          toast(res.msg || '记不下，服务没响应');
        } else {
          toast(res.msg || '记下了，联网时自动搜');
          if (refs.wantInput) {
            refs.wantInput.value = '';
            refs.wantInput.focus();
          }
        }
        loadPage();
        schedulePoll();
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.wantBusy = false;
        syncWantBusy();
        toast('记不下，本地服务没响应');
      });
  }

  function removeWant(id) {
    if (!id || !mounted) return;
    fetchJSON(API_WANT + '?id=' + encodeURIComponent(id), { method: 'DELETE' })
      .then(function () {
        if (!mounted || !st) return;
        loadPage();
        schedulePoll();
      })
      .catch(function () {
        if (!mounted) return;
        toast('删不掉，本地服务没响应');
      });
  }

  /* ------------------------------------------------------------
     播放（原来的视频面板那套：简介、热门评论、看完归档、收藏）
     ------------------------------------------------------------ */
  function playLocalVideo(file) {
    if (!file || !st) return;
    var list = st.feed.videos;
    for (var i = 0; i < list.length; i++) {
      if (list[i].file === file) {
        openPlayer(list[i]);
        return;
      }
    }
    openPlayer({ file: file, title: baseName(file), bvid: '', up: '', duration_s: 0, view: 0, size: 0, desc: '', comments: [] });
  }

  function playerMeta(v) {
    return [
      v.up || '',
      v.duration_s ? fmtClock(v.duration_s) : '',
      v.view ? fmtViews(v.view) : '',
      v.size ? fmtSize(v.size) : ''
    ].filter(Boolean).join(' ・ ');
  }

  function renderPlayerInfo(v) {
    if (refs.plMeta) refs.plMeta.textContent = playerMeta(v) || '本地文件';
    if (refs.plDesc) {
      refs.plDesc.textContent = v.desc || '';
      refs.plDesc.hidden = !v.desc;
    }
    if (refs.plCmts) {
      var cs = Array.isArray(v.comments) ? v.comments : [];
      refs.plCmts.innerHTML = cs.length
        ? '<h4 class="bi-cmt-h">热门评论</h4>' + cs.map(function (c) {
            return '<div class="bi-cmt">' +
              '<div class="bi-cmt-head"><b>' + esc(c.user || '匿名') + '</b>' +
              (c.like ? '<span class="bi-cmt-like">' + fmtViews(c.like).replace('播放', '赞') + '</span>' : '') +
              '</div>' +
              '<p class="bi-cmt-txt">' + esc(c.text || '') + '</p>' +
            '</div>';
          }).join('')
        : '';
    }
  }

  function openPlayer(d) {
    if (!refs.player || !refs.video) return;
    if (!d.file) {
      toast('文件还没下好或者丢了');
      return;
    }
    try {
      refs.video.pause();
      refs.video.removeAttribute('src');
      refs.video.load();
    } catch (e) { /* 忽略 */ }
    refs.playerTitle.textContent = d.title || baseName(d.file);
    refs.playerTitle.title = refs.playerTitle.textContent;
    refs.video.src = pathURL(d.file);
    // 默认静音打开，别一上来就吵到人；想听点右上角
    refs.video.muted = true;
    refs.video.volume = 1;
    renderSound();
    refs.player.hidden = false;
    if (st) {
      st.playing = d.bvid || '';
      st.playingKey = d.bvid ? ('video:' + d.bvid) : '';
    }
    renderPlayerInfo(d);
    applyFavState(false);
    refreshFav(d);
    if (d.bvid) {
      postJSON(API_OPEN, {
        kind: 'video', rid: d.bvid,
        title: d.title || '', sub: d.up || '',
        url: d.url || '', image: d.pic ? pathURL(d.pic) : ''
      });
    }
    try {
      var p = refs.video.play();
      if (p && typeof p.catch === 'function') p.catch(function () { /* 自动播放被拦就算了 */ });
    } catch (e) { /* 忽略 */ }
  }

  function closePlayer() {
    if (refs.video) {
      try {
        refs.video.pause();
        refs.video.removeAttribute('src');
        refs.video.load();
      } catch (e) { /* 忽略 */ }
    }
    if (refs.player) refs.player.hidden = true;
    if (refs.playerTitle) {
      refs.playerTitle.textContent = '';
      refs.playerTitle.title = '';
    }
    if (refs.plMeta) refs.plMeta.textContent = '';
    if (refs.plDesc) { refs.plDesc.textContent = ''; refs.plDesc.hidden = true; }
    if (refs.plCmts) refs.plCmts.innerHTML = '';
    if (refs.plFav) refs.plFav.hidden = true;
    if (st && st.playingKey) {
      postJSON(API_FINISHED, { key: st.playingKey });
      st.playingKey = '';
    }
    if (st) st.playing = '';
  }

  /* ------------------------------ 静音开关 ------------------------------ */

  function renderSound() {
    if (!refs.plSound || !refs.video) return;
    var muted = refs.video.muted || refs.video.volume === 0;
    refs.plSound.innerHTML = svg(muted ? 'mute' : 'volume') + '<span>' + (muted ? '静音' : '有声') + '</span>';
    refs.plSound.title = muted ? '点一下开声音' : '点一下静音';
    refs.plSound.classList.toggle('is-off', muted);
    refs.plSound.setAttribute('aria-pressed', muted ? 'true' : 'false');
  }

  function toggleSound() {
    if (!refs.video) return;
    refs.video.muted = !refs.video.muted;
    if (!refs.video.muted && refs.video.volume === 0) refs.video.volume = 1;
    renderSound();
  }

  /* ------------------------------ 收藏 ------------------------------ */

  function applyFavState(on) {
    if (!refs.plFav) return;
    refs.plFav.dataset.fav = on ? '1' : '0';
    refs.plFav.innerHTML = svg(on ? 'heartFill' : 'heart') + (on ? '已收藏' : '收藏');
    refs.plFav.classList.toggle('is-on', !!on);
  }

  function refreshFav(v) {
    if (!refs.plFav) return;
    if (!v || !v.bvid) {
      refs.plFav.hidden = true;
      return;
    }
    refs.plFav.hidden = false;
    refs.plFav.setAttribute('data-key', 'video:' + v.bvid);
    refs.plFav.setAttribute('data-title', v.title || '');
    refs.plFav.setAttribute('data-url', v.url || '');
    refs.plFav.setAttribute('data-image', v.pic ? pathURL(v.pic) : '');
    refs.plFav.setAttribute('data-sub', v.up || '');
    fetchJSON(API_LIBRARY + '?fav=1&limit=1000', { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || !refs.plFav) return;
        if (refs.plFav.getAttribute('data-key') !== 'video:' + v.bvid) return;
        var items = (data && data.items) || [];
        var hit = false;
        for (var i = 0; i < items.length; i++) {
          if (items[i] && items[i].key === 'video:' + v.bvid) { hit = true; break; }
        }
        applyFavState(hit);
      })
      .catch(function () { /* 收藏状态查不到就先当没收藏 */ });
  }

  function toggleFav() {
    if (!refs.plFav || !mounted || !st || st.favBusy) return;
    var key = refs.plFav.getAttribute('data-key') || '';
    var bvid = key.replace(/^video:/, '');
    if (!bvid) return;
    var on = refs.plFav.dataset.fav !== '1';
    st.favBusy = true;
    postJSON(API_OPEN, {
      kind: 'video', rid: bvid,
      title: refs.plFav.getAttribute('data-title') || '',
      sub: refs.plFav.getAttribute('data-sub') || '',
      url: refs.plFav.getAttribute('data-url') || '',
      image: refs.plFav.getAttribute('data-image') || ''
    })
      .then(function () {
        return fetchJSON(API_FAV, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key: key, on: on })
        });
      })
      .then(function () {
        if (!mounted || !st) return;
        st.favBusy = false;
        applyFavState(on);
        toast(on ? '收藏了，看完也不会被归档' : '取消收藏了');
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.favBusy = false;
        toast('收藏没成功，本地服务没响应');
      });
  }

  /* ------------------------------------------------------------
     文件大小（本地 HEAD，用来算占用）
     ------------------------------------------------------------ */
  function measureSizes() {
    if (!mounted || !st) return;
    var todo = [];
    var list = st.page.downloads;
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (d.state !== 'done' || !d.file) continue;
      if (isFinite(st.sizes[d.file]) && st.sizes[d.file] > 0) continue;
      todo.push(d.file);
    }
    if (!todo.length) return;

    var seq = ++sizeSeq;
    var idx = 0;

    function next() {
      if (!mounted || !st || seq !== sizeSeq) return;
      if (idx >= todo.length) {
        persistSizes();
        renderStats();
        return;
      }
      var file = todo[idx++];
      fetch(pathURL(file), { method: 'HEAD', cache: 'no-store' })
        .then(function (res) {
          if (!res || !res.ok || !res.headers || !res.headers.get) return;
          var len = Number(res.headers.get('content-length'));
          if (!mounted || !st || seq !== sizeSeq) return;
          if (isFinite(len) && len > 0) {
            st.sizes[file] = len;
            renderStats();
          }
        })
        .catch(function () { /* 量不到就算了 */ })
        .then(function () { next(); });
    }
    next();
  }

  /* ------------------------------------------------------------
     轮询
     ------------------------------------------------------------ */
  function activeNow() {
    if (!st) return false;
    var i;
    for (i = 0; i < st.page.downloads.length; i++) {
      var s = st.page.downloads[i].state;
      if (s === 'pending' || s === 'downloading') return true;
    }
    var busy = Object.keys(st.busy);
    for (i = 0; i < busy.length; i++) if (st.busy[busy[i]]) return true;
    for (i = 0; i < st.page.wants.length; i++) {
      if (st.page.wants[i].state === 'pending') return true;
    }
    return false;
  }

  function stopPoll() {
    if (pollTimer) {
      window.clearTimeout(pollTimer);
      pollTimer = null;
    }
  }

  function schedulePoll() {
    stopPoll();
    if (!mounted || !st || document.hidden) return;
    var fast = activeNow();
    pollTimer = window.setTimeout(function () {
      pollTimer = null;
      if (!mounted) return;
      loadPage().then(function () {
        if (mounted) schedulePoll();
      });
    }, fast ? POLL_FAST_MS : POLL_SLOW_MS);
  }

  /* ------------------------------------------------------------
     提示
     ------------------------------------------------------------ */
  function toast(msg) {
    if (!refs.toast || !mounted) return;
    refs.toast.textContent = msg;
    refs.toast.classList.add('is-show');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      if (!refs.toast) return;
      refs.toast.classList.remove('is-show');
      toastTimer = null;
    }, TOAST_MS);
  }

  /* ------------------------------------------------------------
     对外接口
     ------------------------------------------------------------ */
  window.BiliUI = {
    mount: mount,
    unmount: unmount
  };
})();
