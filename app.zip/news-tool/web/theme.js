/* theme.js — 主题管理
 *
 * 管三件事：
 *   - 亮 / 暗 / 跟随系统
 *   - 调色板（6 个色相，M3 那套按色相出整组的做法）
 *   - 圆角大小
 *
 * 全部存在 localStorage，改完立刻生效，不用刷新。
 * 颜色本体在 theme.css，这里只负责改 <html> 上的 data-* 属性。
 */

(function () {
  'use strict';

  const KEY = { theme: 'whale.theme', palette: 'whale.palette', radius: 'whale.radius' };

  const PALETTES = [
    ['violet', '紫', 258],
    ['blue', '蓝', 205],
    ['teal', '青', 172],
    ['green', '绿', 132],
    ['orange', '橙', 32],
    ['rose', '玫瑰', 345],
  ];

  const RADII = [
    ['10px', '紧凑', '10px', '6px', '16px'],
    ['16px', '标准', '16px', '10px', '24px'],
    ['24px', '圆润', '24px', '14px', '32px'],
  ];

  const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function stored(k, dflt) {
    try { return localStorage.getItem(k) || dflt; } catch (e) { return dflt; }
  }

  function getMode() { return stored(KEY.theme, 'auto'); }
  function getPalette() { return stored(KEY.palette, 'violet'); }
  function getRadius() { return stored(KEY.radius, '16px'); }

  function resolvedMode() {
    const m = getMode();
    if (m === 'auto') return (mq && mq.matches) ? 'dark' : 'light';
    return m === 'dark' ? 'dark' : 'light';
  }

  function apply() {
    const root = document.documentElement;
    const dark = resolvedMode() === 'dark';
    root.dataset.theme = dark ? 'dark' : 'light';
    root.dataset.palette = getPalette();
    const r = RADII.find((x) => x[0] === getRadius()) || RADII[1];
    root.style.setProperty('--m3-radius', r[2]);
    root.style.setProperty('--m3-radius-sm', r[3]);
    root.style.setProperty('--m3-radius-lg', r[4]);
    // 让浏览器原生控件（滚动条之类）也跟着变
    root.style.colorScheme = dark ? 'dark' : 'light';
  }

  function setMode(m) { localStorage.setItem(KEY.theme, m); apply(); }
  function setPalette(p) { localStorage.setItem(KEY.palette, p); apply(); }
  function setRadius(r) { localStorage.setItem(KEY.radius, r); apply(); }

  function swatchStyle(hue, dark) {
    const base = dark ? `hsl(${hue} 62% 72%)` : `hsl(${hue} 45% 42%)`;
    const cont = dark ? `hsl(${hue} 38% 26%)` : `hsl(${hue} 62% 91%)`;
    return `background: linear-gradient(135deg, ${base} 0 55%, ${cont} 55% 100%);`;
  }

  function buildDialog() {
    let dlg = document.getElementById('theme');
    if (dlg) return dlg;
    dlg = document.createElement('dialog');
    dlg.id = 'theme';
    dlg.className = 'theme-dlg';
    dlg.innerHTML = `
      <div class="dlg-head">
        <div class="rd-meta"><strong>主题管理</strong>
          <span class="dim" id="th-hint">改完立刻生效，存在这台电脑上</span></div>
        <button class="btn" id="th-close">关闭</button>
      </div>
      <div class="th-body">
        <section class="th-sec">
          <h4>明暗</h4>
          <div class="th-row" id="th-mode"></div>
        </section>
        <section class="th-sec">
          <h4>调色板</h4>
          <div class="th-palettes" id="th-palette"></div>
        </section>
        <section class="th-sec">
          <h4>圆角</h4>
          <div class="th-row" id="th-radius"></div>
        </section>
        <section class="th-sec">
          <h4>预览</h4>
          <div class="th-preview" id="th-preview">
            <button class="btn btn-primary">主要按钮</button>
            <button class="btn">次要按钮</button>
            <span class="tab active">选中的标签</span>
            <span class="tar">没选中的标签</span>
            <div class="th-card">
              <strong>一张卡片</strong>
              <p class="dim">卡片、标签、按钮都跟着主题走。</p>
            </div>
          </div>
        </section>
        <p class="dim th-note">点歌台是自带深色皮肤的独立组件，
          不受这里的配色影响（它本来就该是黑的）。</p>
      </div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('#th-close').onclick = () => dlg.close();
    return dlg;
  }

  function render(dlg) {
    const dark = resolvedMode() === 'dark';

    const modes = [['light', '亮色'], ['dark', '暗色'], ['auto', '跟随系统']];
    dlg.querySelector('#th-mode').innerHTML = modes.map(([k, label]) => `
      <button class="th-opt${getMode() === k ? ' on' : ''}" data-mode="${k}">${label}</button>`).join('');

    dlg.querySelector('#th-palette').innerHTML = PALETTES.map(([k, label, hue]) => `
      <button class="th-swatch${getPalette() === k ? ' on' : ''}" data-pal="${k}"
              title="${label}">
        <span class="th-dot" style="${swatchStyle(hue, dark)}"></span>
        <span class="th-name">${label}</span>
      </button>`).join('');

    dlg.querySelector('#th-radius').innerHTML = RADII.map(([k, label]) => `
      <button class="th-opt${getRadius() === k ? ' on' : ''}" data-radius="${k}">${label}</button>`).join('');

    dlg.querySelectorAll('[data-mode]').forEach((b) => {
      b.onclick = () => { setMode(b.dataset.mode); render(dlg); };
    });
    dlg.querySelectorAll('[data-pal]').forEach((b) => {
      b.onclick = () => { setPalette(b.dataset.pal); render(dlg); };
    });
    dlg.querySelectorAll('[data-radius]').forEach((b) => {
      b.onclick = () => { setRadius(b.dataset.radius); render(dlg); };
    });
  }

  function open() {
    const dlg = buildDialog();
    render(dlg);
    if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
  }

  // 系统主题变了要跟着变（只在「跟随系统」时）
  if (mq) {
    const onChange = () => { if (getMode() === 'auto') apply(); };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if (mq.addListener) mq.addListener(onChange);
  }

  // 尽早应用，别闪一下白
  apply();

  window.Theme = { open, apply, setMode, setPalette, getMode, getPalette };

  document.addEventListener('DOMContentLoaded', () => {
    const b = document.getElementById('btn-theme');
    if (b) b.onclick = open;
  });
})();
