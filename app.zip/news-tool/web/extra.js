/* extra.js — v0.3 加在原有界面上的一层
 *
 * 原 app.js 保持原样，这边只做加法：
 *   - 启动密码 / 解锁
 *   - 顶部那条滚动日志
 *   - 点歌台、追更、B 站推荐、收藏、归档这几个新标签页
 *   - 全局搜索（一个框搜遍本地所有东西）
 *   - 下载管理器（浏览器那种抽屉）
 *   - 机器码 / 激活码面板
 *
 * app.js 里只留了三个钩子：EXTRA.render(cat)、EXTRA.appendTabs()、
 * EXTRA.afterStatus(st)。都在它自己那几个函数里，改动很小。
 */

(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const TOKEN_KEY = 'whale.token';

  const TAB_MUSIC = '点歌台';
  const TAB_ANIME = '追更';
  const TAB_BILI = 'B 站';
  const TAB_FAV = '收藏';
  const TAB_ARCH = '归档';
  const TAB_FIND = '全局搜索';

  const ex = {
    music: null,
    anime: null,
    follows: [],
    bili: null,
    lib: null,
    find: null,
    license: null,
    lastLog: '',
    logTimer: 0,
    dlOpen: false,
    readerKey: '',
    playerKey: '',
  };

  /* ───────────── 带令牌的 fetch ─────────────
     原来的 app.js 直接 fetch，这里在它加载之前把 window.fetch 包一层：
     有令牌就带上，401 就弹锁。这样 app.js 一行都不用改。 */
  const rawFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    init = init || {};
    const headers = Object.assign({}, init.headers || {});
    const tok = localStorage.getItem(TOKEN_KEY);
    if (tok) headers['X-Whale-Token'] = tok;
    init.headers = headers;
    return rawFetch(input, init).then((r) => {
      if (r.status === 401) {
        showLock();
        if (window.__refreshLockDigits) window.__refreshLockDigits();
      } else if (r.status === 403) {
        // 二级门 / 设置被锁：后端也会拦，别让页面只报个空错
        r.clone().json().then((d) => {
          d = d || {};
          if (d.level2) {
            polToast(reasonText(d.reason || 'need_admin'));
          } else if (d.locked || d.lock_settings) {
            polToast(d.msg || d.error || '设置被锁了，要管理员才能改');
          }
        }).catch(() => {});
      }
      return r;
    });
  };

  function api(path, opts) {
    return window.fetch(path, opts).then((r) => r.json().catch(() => ({})));
  }
  function post(path, body) {
    return api(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
  }

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));

  function pad(n) { return String(n).padStart(2, '0'); }
  function fmtClock(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  }
  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n >= 1048576) return (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB';
    if (n >= 1024) return Math.round(n / 1024) + ' KB';
    return n + ' B';
  }
  function fmtNum(n) {
    n = Number(n) || 0;
    if (n >= 100000000) return (n / 100000000).toFixed(1) + ' 亿';
    if (n >= 10000) return (n / 10000).toFixed(1) + ' 万';
    return String(n);
  }

  /* ═════════════ 启动锁屏（开屏数字 / 启动密码） ═════════════ */

  let screenDigits = '';
  let lockMode = 'password';     // screen | password

  function setLockCopy() {
    // 锁屏上只留数字和输入框，别的字一律不显示
    const chal = $('lock-challenge');
    if (chal) chal.hidden = !(lockMode === 'screen' && screenDigits);
  }

  function showLock(msg) {
    const box = $('lock');
    if (!box) return;
    if (screenDigits) lockMode = 'screen';
    setLockCopy();
    box.hidden = false;
    const m = $('lock-msg');
    if (m) m.textContent = msg || '';
    const inp = $('lock-input');
    if (inp) {
      inp.placeholder = '';
      setTimeout(() => { try { inp.focus(); } catch (e) {} }, 60);
    }
  }
  function hideLock() {
    const box = $('lock');
    if (box) box.hidden = true;
  }

  function renderDigits(st) {
    screenDigits = (st && st.digits) || '';
    lockMode = 'screen';
    const digits = $('lock-digits');
    if (digits) digits.textContent = screenDigits || '（暂无数字）';
    setLockCopy();
    if (screenDigits) showLock('');
  }

  async function doLogin() {
    const val = ($('lock-input').value || '').trim();
    if (!val) return;
    $('lock-msg').textContent = '正在验…';
    const d = await post('/api/screen', { answer: val });
    if (d.ok && d.token) {
      localStorage.setItem(TOKEN_KEY, d.token);
      $('lock-input').value = '';
      hideLock();
      $('lock-msg').textContent = '';
      location.reload();          // 重新加载，所有数据带着令牌再取一遍
      return;
    }
    $('lock-msg').textContent = d.error || '不对';
    if (d.state) renderDigits(d.state);
    $('lock-input').select();
  }

  async function lockHelp() {}


  /* ═════════════ 顶部日志条 ═════════════ */

  async function pollLog() {
    try {
      const r = await window.fetch('/api/log?n=6', { cache: 'no-store' });
      if (!r.ok) return;
      const txt = await r.text();
      if (txt === ex.lastLog) return;
      ex.lastLog = txt;
      const lines = txt.split('\n').filter((s) => s.trim());
      const last = lines.length ? lines[lines.length - 1] : '（还没有日志）';
      $('log-strip-text').textContent = last.replace(/^\[[^\]]*\]\s*/, '');
      const busy = /开工|开始|抓|下载|搜索|扒/.test(last);
      $('log-dot').className = 'log-dot' + (busy ? ' busy' : '');
    } catch (e) { /* 服务没起来就先不管 */ }
  }

  /* ═════════════ 激活 / 机器码面板 ═════════════ */

  async function openLicense() {
    const dlg = $('license');
    $('les-body').innerHTML = '载入中…';
    dlg.showModal();
    const d = await api('/api/license');
    ex.license = d;
    $('les-edition').textContent = d.edition || '';
    const feats = (d.features || []).join('、') || '—';
    const rows = [
      ['机器码', d.machine_code || '—'],
      ['版本', d.edition || '—'],
      ['激活状态', d.activated ? '已激活' : (d.trial ? '试用（能看不能下）' : '未激活')],
      ['到期', d.expires || (d.usb ? 'U 盘在，不过期' : '—')],
      ['剩余天数', d.days_left != null && d.days_left >= 0 ? d.days_left + ' 天' : '—'],
      ['可用功能', feats],
      ['U 盘钥匙', d.usb ? ('已插上：' + (d.usb_name || '')) : '没插'],
    ];
    $('les-body').innerHTML = `
      <table class="les-table">
        ${rows.map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')}
      </table>
      <div class="les-form">
        <input type="text" id="les-code" placeholder="贴激活码（WHALE-XXXX-…）" spellcheck="false">
        <button class="btn btn-primary" id="btn-les-act">激活</button>
      </div>
      <p class="dim les-note">激活码按机器码绑定，一台机器一个码。
        插着 U 盘的时候不用激活，所有功能都开着。</p>
      <div class="les-actions">
        <button class="btn btn-ghost" id="btn-les-update">检查更新</button>
        <span class="dim" id="les-msg"></span>
      </div>`;
    const act = $('btn-les-act');
    if (act) act.onclick = doActivate;
    const upd = $('btn-les-update');
    if (upd) upd.onclick = async () => {
      $('les-msg').textContent = '查着…';
      const r = await post('/api/update', { action: 'check' });
      $('les-msg').textContent = r.ok
        ? (r.has_update ? `有新版本 ${r.latest}` : '已是最新')
        : (r.error || '查不到');
    };
  }

  async function doActivate() {
    const code = ($('les-code').value || '').trim();
    if (!code) return;
    $('les-msg').textContent = '验着…';
    const r = await post('/api/activate', { code });
    $('les-msg').textContent = r.ok
      ? ('激活成功，到期 ' + (r.expires || ''))
      : (r.reason || r.error || '这个码不对');
    if (r.ok) setTimeout(openLicense, 700);
  }

  /* ═════════════ 下载管理器 ═════════════ */

  function toggleDrawer(on) {
    ex.dlOpen = on === undefined ? !ex.dlOpen : !!on;
    $('dl-drawer').hidden = !ex.dlOpen;
    if (ex.dlOpen) renderDrawer();
  }

  function renderDrawer() {
    const st = (typeof state !== 'undefined' && state.status) || {};
    const q = st.queue || { items: [], counts: {} };
    const items = q.items || [];
    const running = items.filter((t) => t.state === 'running');
    const pending = items.filter((t) => t.state === 'pending');
    const bad = items.filter((t) => t.state === 'failed' || t.state === 'dead');
    const done = items.filter((t) => t.state === 'done' || t.state === 'skipped');

    $('dl-summary').textContent =
      `${running.length} 个在跑 ・ ${pending.length} 个排队 ・ ${bad.length} 个出过问题 ・ `
      + `队列共 ${q.total || 0} 条`;

    const defs = { running: '进行中', pending: '排队', failed: '失败', dead: '放弃', done: '完成', skipped: '跳过' };
    const order = ['running', 'pending', 'failed', 'dead', 'skipped', 'done'];
    let html = '';
    for (const s of order) {
      const list = items.filter((t) => t.state === s);
      if (!list.length) continue;
      html += `<div class="dl-group"><h4>${defs[s]}（${list.length}）</h4>`;
      html += list.map((t) => `
        <div class="dl-item dl-${esc(t.state)}">
          <span class="dl-kind">${esc(t.label || t.kind)}</span>
          <span class="dl-key">${esc(t.key || '')}</span>
          <span class="dl-time dim">${esc(t.finished_at || t.started_at || t.created_at || '')}</span>
          ${t.note ? `<span class="dl-note dim">${esc(t.note)}</span>` : ''}
          ${t.error ? `<span class="dl-err">${esc(t.error)}</span>` : ''}
          ${t.tries ? `<span class="dl-tries dim">试了 ${t.tries} 次</span>` : ''}
        </div>`).join('');
      html += '</div>';
    }
    if (!html) html = '<p class="dim dl-empty">队列是空的。联网之后会自动排进来。</p>';
    $('dl-list').innerHTML = html;
  }

  /* ═════════════ 标签页扩展 ═════════════ */

  function extraTabs() {
    const out = [];
    const nm = (ex.music && ex.music.items || []).length;
    if (nm) out.push([TAB_MUSIC, nm]);
    else out.push([TAB_MUSIC, 0]);
    const na = (ex.anime && ex.anime.items || []).length;
    out.push([TAB_ANIME, na]);
    const nb = (ex.bili && ex.bili.items || []).length;
    if (nb) out.push([TAB_BILI, nb]);
    const nf = (ex.lib && ex.lib.counts && ex.lib.counts.favs) || 0;
    out.push([TAB_FAV, nf]);
    const nr = (ex.lib && ex.lib.counts && ex.lib.counts.archived) || 0;
    out.push([TAB_ARCH, nr]);
    if (ex.find) out.push([TAB_FIND, ex.find.total || 0]);
    return out;
  }

  function appendTabs() {
    const box = $('tabs');
    if (!box) return;
    for (const b of box.querySelectorAll('.tab-extra')) b.remove();
    for (const [key, n] of extraTabs()) {
      const b = document.createElement('button');
      b.className = 'tab tab-extra' + (state.cat === key ? ' active' : '');
      b.innerHTML = `${esc(key)}<span class="n">${n}</span>`;
      b.onclick = () => {
        state.cat = key;
        renderCat();
        // 重画一遍标签，把「全部 / 视频」那些的高亮取消掉
        if (typeof buildTabs === 'function') buildTabs(state.snap || {});
      };
      box.appendChild(b);
    }
  }

  function renderCat() {
    // 交给 app.js 的 render()，它会先问 EXTRA.render
    if (typeof render === 'function') render();
  }

  /* ═════════════ 点歌台 ═════════════ */

  async function loadMusic() {
    try { ex.music = await api('/api/music'); } catch (e) { ex.music = null; }
    if (!ex.music || !ex.music.items) {
      ex.music = { generated_at: '', total: 0, total_bytes: 0, items: [] };
    }
  }

  function renderMusic() {
    const root = $('music-root');
    const grid = $('grid');
    grid.hidden = true;
    grid.classList.remove('video-grid');
    root.hidden = false;
    $('empty').hidden = true;
    // 已经在放歌了就别重画 —— 重画等于把整个播放器推倒重来
    if (!root.classList.contains('mu-host')) {
      if (window.MusicUI && typeof MusicUI.mount === 'function') {
        try { MusicUI.mount(root); } catch (e) {
          root.innerHTML = `<p class="dim" style="padding:24px">点歌台画不出来：${esc(e.message)}</p>`;
        }
      } else {
        root.innerHTML = '<p class="dim" style="padding:24px">点歌台的前端（music.js）没加载上。</p>';
      }
    }
    $('meta-line').textContent =
      `点歌台 ・ 本地 ${(ex.music.items || []).length} 首 ・ 占用 ${fmtBytes(ex.music.total_bytes)}`;
    $('source-line').textContent = '联网时从网易云公开榜单自动下几首，断网也能听';
  }

  function renderAnimePage() {
    const root = $('anime-root');
    const grid = $('grid');
    if (!root) return;
    grid.hidden = true;
    grid.classList.remove('video-grid');
    root.hidden = false;
    $('empty').hidden = true;
    ensurePageExit('anime-exit', '← 返回首页', leaveAnime);
    if (window.AnimeUI && typeof AnimeUI.mount === 'function') {
      try { AnimeUI.mount(root); } catch (e) {
        root.innerHTML = `<p class="dim" style="padding:24px">追更页面画不出来：${esc(e.message)}</p>`;
      }
    } else {
      root.innerHTML = '<p class="dim" style="padding:24px">追更页面的前端（anime.js）没加载上。</p>';
    }
    $('meta-line').textContent = '追更 ・ 在追的番剧更新';
    $('source-line').textContent = '联网时自动检查有没有新集；漫画接口被锁，只能追番';
  }

  function leaveAnime() {
    ensurePageExit('anime-exit', '', null);
    const root = $('anime-root');
    if (!root || root.hidden) return;
    if (window.AnimeUI && typeof AnimeUI.unmount === 'function') {
      try { AnimeUI.unmount(); } catch (e) { /* 忽略 */ }
    }
    root.hidden = true;
    root.innerHTML = '';
    const grid = $('grid');
    if (grid) grid.hidden = false;
  }

  function renderBiliPage() {
    const root = $('bili-root');
    const grid = $('grid');
    if (!root) return;
    grid.hidden = true;
    grid.classList.remove('video-grid');
    root.hidden = false;
    $('empty').hidden = true;
    if (window.BiliUI && typeof BiliUI.mount === 'function') {
      try { BiliUI.mount(root); } catch (e) {
        root.innerHTML = `<p class="dim" style="padding:24px">B 站页面画不出来：${esc(e.message)}</p>`;
      }
    } else {
      root.innerHTML = '<p class="dim" style="padding:24px">B 站页面的前端（bili.js）没加载上。</p>';
    }
    ensureBiliExit(true);
    $('meta-line').textContent = 'B 站 ・ 搜关键词、下载、离线看';
    $('source-line').textContent = '搜到的结果和下载的视频都存本地，断网照常翻';
  }

  function backToHome() {
    state.cat = '全部';
    render();
    if (typeof buildTabs === 'function') buildTabs(state.snap || {});
  }

  function ensurePageExit(id, label, onLeave) {
    let b = document.getElementById(id);
    if (!label) { if (b) b.remove(); return; }
    if (b) return;
    b = document.createElement('button');
    b.id = id;
    b.className = 'page-exit';
    b.type = 'button';
    b.textContent = label;
    b.title = '退出这一页（Esc 也行）';
    b.onclick = () => { if (onLeave) onLeave(); backToHome(); };
    document.body.appendChild(b);
  }

  function ensureBiliExit(on) {
    ensurePageExit('bili-exit', on ? '← 返回首页' : '', leaveBili);
  }

  function leaveBili() {
    ensureBiliExit(false);
    const root = $('bili-root');
    if (!root || root.hidden) return;
    if (window.BiliUI && typeof BiliUI.unmount === 'function') {
      try { BiliUI.unmount(); } catch (e) { /* 忽略 */ }
    }
    root.hidden = true;
    root.innerHTML = '';
    const grid = $('grid');
    if (grid) grid.hidden = false;
  }

  function leaveMusic() {
    const root = $('music-root');
    if (window.MusicUI && typeof MusicUI.unmount === 'function') {
      try { MusicUI.unmount(); } catch (e) { /* 忽略 */ }
    }
    if (root) { root.hidden = true; root.innerHTML = ''; }
    const grid = $('grid');
    if (grid) grid.hidden = false;
  }

  /* ═════════════ 追更 ═════════════ */

  async function loadAnime() {
    try { ex.anime = await api('/api/anime'); } catch (e) { ex.anime = null; }
    if (!ex.anime || !ex.anime.items) ex.anime = { items: [], checked_at: '' };
    ex.follows = ex.anime.follows || [];
  }

  function renderAnime() {
    const grid = $('grid');
    grid.classList.remove('video-grid');
    const ups = ex.anime.items || [];
    const fl = ex.follows || [];
    const followRows = fl.length
      ? fl.map((f) => `
        <div class="fw-row">
          <span class="fw-title">${esc(f.title || f.sid)}</span>
          <span class="dim">${esc(f.type || '番剧')} ・ 看到 ${esc(f.last_ep || '—')}</span>
          <button class="linkbtn fw-del" data-sid="${esc(f.sid)}">不追了</button>
        </div>`).join('')
      : '<p class="dim">还没追任何东西。下面搜一个加上就行。</p>';

    $('meta-line').textContent = ex.anime.checked_at
      ? `上次检查 ${ex.anime.checked_at} ・ ${ups.length} 条更新 ・ 在追 ${fl.length} 部`
      : `还没检查过 ・ 在追 ${fl.length} 部`;
    $('source-line').textContent = '联网时自动检查有没有新集；漫画接口 B 站锁了，只能追番';

    grid.innerHTML = `
      <div class="fw-panel">
        <div class="fw-add">
          <input type="text" id="fw-q" placeholder="搜番剧名字，比如 鬼灭、凡人修仙传">
          <button class="btn" id="btn-fw-search">搜</button>
        </div>
        <div class="fw-follows"><h4>在追（${fl.length}）</h4>${followRows}</div>
      </div>
      <div id="fw-result" class="fw-result"></div>
      ${ups.length ? '<h3 class="sec-h">有新集</h3>' + ups.map(animeCardHtml).join('') : ''}`;
    $('empty').hidden = true;
    if (grid.querySelector('#btn-fw-search')) {
      $('btn-fw-search').onclick = searchBangumi;
      $('fw-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') searchBangumi(); });
    }
    grid.querySelectorAll('.fw-del').forEach((b) => {
      b.onclick = async () => {
        await post('/api/follows', { action: 'del', item: { sid: b.dataset.sid } });
        await loadAnime();
        renderCat();
      };
    });
  }

  async function searchBangumi() {
    const q = ($('fw-q').value || '').trim();
    if (!q) return;
    const box = $('fw-result');
    box.innerHTML = '<p class="dim">搜着…</p>';
    const d = await api('/api/anime/search?q=' + encodeURIComponent(q));
    const items = d.items || [];
    if (!items.length) {
      box.innerHTML = '<p class="dim">没搜到。' + esc(d.error || '') + '</p>';
      return;
    }
    box.innerHTML = `<h4>搜到 ${items.length} 部</h4>` + items.map((it) => `
      <div class="fw-row">
        <span class="fw-title">${esc(it.title)}</span>
        <span class="dim">${esc(it.total_ep || '')} ${it.total_ep ? '集' : ''}</span>
        <button class="btn btn-ghost fw-add-btn" data-sid="${esc(it.sid)}"
          data-title="${esc(it.title)}" data-cover="${esc(it.cover_url || '')}">加进追更</button>
      </div>`).join('');
    box.querySelectorAll('.fw-add-btn').forEach((b) => {
      b.onclick = async () => {
        const sid = b.dataset.sid;
        await post('/api/follows', {
          action: 'add',
          item: { sid, type: '番剧', title: b.dataset.title, cover_url: b.dataset.cover },
        });
        await loadAnime();
        renderCat();
      };
    });
  }

  function animeCardHtml(u, i) {
    const img = u.cover_url
      ? `<img class="thumb" src="${esc(u.cover_url)}" alt="" loading="lazy">`
      : '<div class="thumb-ph">📺</div>';
    return `
    <article class="card acard" data-i="${i}" tabindex="0" role="button">
      ${img}
      <div class="card-body">
        <h2>${esc(u.title)}</h2>
        <p class="summary">第 ${esc(u.new_ep)} 集${u.new_ep_title ? ' ・ ' + esc(u.new_ep_title) : ''}</p>
        <div class="card-foot">
          <span class="cat-chip cat-追更">追更</span>
          <span>${esc(u.updated_at || '')}</span>
          ${u.bvid ? `<a class="linkbtn" target="_blank" rel="noreferrer"
             href="https://www.bilibili.com/video/${esc(u.bvid)}">去 B 站 ↗</a>` : ''}
        </div>
      </div>
    </article>`;
  }

  /* ═════════════ B 站推荐 ═════════════ */

  async function loadBili() {
    try { ex.bili = await api('/api/bili'); } catch (e) { ex.bili = null; }
    if (!ex.bili || !ex.bili.items) ex.bili = { items: [], total: 0 };
  }

  function renderBili() {
    const grid = $('grid');
    grid.classList.remove('video-grid');
    let items = ex.bili.items || [];
    if (state.q) {
      const q = state.q.toLowerCase();
      items = items.filter((v) => (v.title || '').toLowerCase().includes(q)
        || (v.up || '').toLowerCase().includes(q));
    }
    $('meta-line').textContent = `B 站推荐 / 搜索 ・ 显示 ${items.length} / 共 ${(ex.bili.items || []).length} 条`;
    $('source-line').textContent = '首页随机推荐和关键词搜索攒下来的，只存条目，不下视频文件';
    grid.innerHTML = items.map((v, i) => {
      const img = v.pic
        ? `<img class="thumb" src="/${esc(v.pic)}" alt="" loading="lazy">`
        : (v.pic_url ? `<img class="thumb" src="${esc(v.pic_url)}" alt="" loading="lazy">`
                     : '<div class="thumb-ph">📺</div>');
      return `
      <article class="card bcard" data-i="${i}" tabindex="0" role="button">
        ${v.duration_s ? `<span class="dur-badge">${esc(fmtClock(v.duration_s))}</span>` : ''}
        ${img}
        <div class="card-body">
          <h2>${esc(v.title)}</h2>
          <div class="card-foot">
            <span class="cat-chip cat-视频">${esc(v.kind === 'search' ? (v.keyword || '搜索') : '推荐')}</span>
            <span>${esc(v.up || '')}${v.view ? ' ・ ' + esc(fmtNum(v.view)) : ''}</span>
          </div>
        </div>
      </article>`;
    }).join('');
    $('empty').hidden = items.length > 0;
  }

  /* ═════════════ 收藏 / 归档 ═════════════ */

  async function loadLib(kind, archived) {
    const qs = new URLSearchParams();
    if (kind) qs.set('kind', kind);
    if (archived !== undefined) qs.set('archived', archived ? '1' : '0');
    const d = await api('/api/library?' + qs.toString());
    ex.lib = d;
    return d;
  }

  function renderLib(archived) {
    const grid = $('grid');
    grid.classList.remove('video-grid');
    const items = (ex.lib && ex.lib.items) || [];
    const shown = state.q
      ? items.filter((r) => (r.title || '').toLowerCase().includes(state.q.toLowerCase()))
      : items;
    $('meta-line').textContent = archived
      ? `归档 ・ ${items.length} 条（看完就收进来的，收藏的不在这）`
      : `收藏 ・ ${items.length} 条（收藏的永远不会被归档）`;
    $('source-line').textContent = archived
      ? '点开看完的东西会进这里；想再看就点开，想重下就点「重新下载」'
      : '在阅读/播放面板点「收藏」就会出现在这';
    grid.innerHTML = shown.length ? shown.map(libCardHtml).join('')
      : `<p class="dim lib-empty">${archived ? '还没有归档。点开一篇文章再关掉，它就会自动进这儿。'
        : '还没有收藏。点开一篇，右上角点 ♡。'}</p>`;
    $('empty').hidden = true;
  }

  function libCardHtml(r, i) {
    const img = r.image
      ? `<img class="thumb" src="/${esc(r.image)}" alt="" loading="lazy">`
      : '<div class="thumb-ph">📄</div>';
    return `
    <article class="card lcard" data-i="${i}" tabindex="0" role="button"
             data-key="${esc(r.key)}">
      ${img}
      <div class="card-body">
        <h2>${esc(r.title || r.key)}</h2>
        <div class="card-foot">
          <span class="cat-chip cat-${esc(r.cat || '归档')}">${esc(r.kind || '')}</span>
          <span>${esc(r.sub || '')}</span>
          <button class="linkbtn l-fav" data-key="${esc(r.key)}">${r.fav ? '♥ 已收藏' : '♡ 收藏'}</button>
          <button class="linkbtn l-re" data-key="${esc(r.key)}" data-url="${esc(r.url || '')}">重新下载</button>
        </div>
      </div>
    </article>`;
  }

  /* ═════════════ 全局搜索 ═════════════ */

  async function doGlobalSearch(q) {
    q = (q || '').trim();
    if (q.length < 1) { ex.find = null; return; }
    ex.find = await api('/api/search-all?q=' + encodeURIComponent(q));
    state.cat = TAB_FIND;
    state.q = '';
    renderCat();
    if (typeof buildTabs === 'function') buildTabs(state.snap || {});
  }

  function renderFind() {
    const grid = $('grid');
    grid.classList.remove('video-grid');
    const d = ex.find || { groups: [], total: 0, q: '' };
    $('meta-line').textContent = `「${d.q}」在本地找到 ${d.total} 条`;
    $('source-line').textContent = '搜的是本地已经存下来的东西，不联网';
    if (!d.total) {
      grid.innerHTML = '<p class="dim lib-empty">没找到。换个词试试。</p>';
      $('empty').hidden = true;
      return;
    }
    grid.innerHTML = (d.groups || []).map((g) => `
      <div class="fg-group">
        <h3 class="fg-h">${esc(g.label)} <span class="dim">${g.count}</span></h3>
        ${g.items.map(findRowHtml).join('')}
      </div>`).join('');
    $('empty').hidden = true;
  }

  function findRowHtml(h) {
    return `
    <div class="fg-row" data-kind="${esc(h.kind)}" data-rid="${esc(h.rid)}"
         data-url="${esc(h.url || '')}">
      <span class="fg-kind">${esc(h.kind)}</span>
      <span class="fg-title">${esc(h.title)}</span>
      <span class="fg-sub dim">${esc(h.sub || '')}</span>
    </div>`;
  }

  /* ═════════════ 收藏按钮 / 看完归档 ═════════════ */

  async function favToggle(kind, rid, meta, btn) {
    const key = kind + ':' + rid;
    const on = !(btn && btn.dataset.fav === '1');
    await post('/api/open', Object.assign({ kind, rid }, meta || {}));
    const d = await post('/api/fav', { key, on });
    if (btn) {
      btn.dataset.fav = on ? '1' : '0';
      btn.textContent = on ? '♥ 已收藏' : '♡ 收藏';
    }
    return d;
  }

  async function markFinished(key) {
    if (!key) return;
    try { await post('/api/finished', { key }); } catch (e) { /* 忽略 */ }
    await loadLib('', true);
    appendTabs();
  }

  /* ═════════════ 文章 / 原网页 模式 ═════════════ */

  function readMode() {
    return localStorage.getItem('whale.mode') === 'mirror' ? 'mirror' : 'article';
  }

  function setReadMode(m) {
    localStorage.setItem('whale.mode', m);
    document.querySelectorAll('#mode-toggle .mt-btn').forEach((b) => {
      b.classList.toggle('active', b.dataset.mode === m);
    });
  }

  function applyFold() {
    const on = localStorage.getItem('whale.fold') === '1';
    document.body.classList.toggle('tabs-folded', on);
    const b = $('tab-fold');
    if (b) {
      b.textContent = on ? '展开标签' : '收起';
      b.style.marginLeft = on ? '0' : 'auto';
    }
  }

  function showMirror(src) {
    let dlg = document.getElementById('mirror-dlg');
    if (!dlg) {
      dlg = document.createElement('dialog');
      dlg.id = 'mirror-dlg';
      dlg.className = 'mirror-dlg';
      dlg.innerHTML = `
        <div class="dlg-head">
          <div class="rd-meta"><strong>原网页</strong>
            <span class="dim">整页扒下来的离线副本</span></div>
          <div class="rd-actions">
            <a class="linkbtn" id="mirror-dlg-open" target="_blank"
               rel="noreferrer">新标签打开 ↗</a>
            <button class="btn" id="mirror-dlg-close">关闭</button>
          </div>
        </div>
        <iframe id="mirror-dlg-frame" class="mirror-frame"
                sandbox="allow-same-origin allow-popups"></iframe>`;
      document.body.appendChild(dlg);
      dlg.querySelector('#mirror-dlg-close').onclick = () => dlg.close();
    }
    dlg.querySelector('#mirror-dlg-frame').src = src;
    dlg.querySelector('#mirror-dlg-open').href = src;
    if (dlg.showModal) dlg.showModal();
  }

  function forceArticle(it) {
    ex.noMirror = true;
    try { if (typeof openReader === 'function') openReader(it); } finally { ex.noMirror = false; }
  }

  /* ═════════════ 给 app.js 的钩子 ═════════════ */

  window.EXTRA = {
    render(cat) {
      if (cat !== TAB_MUSIC) leaveMusic();
      if (cat !== TAB_BILI) leaveBili();
      if (cat !== TAB_ANIME) leaveAnime();
      if (cat === TAB_MUSIC) { renderMusic(); return true; }
      if (cat === TAB_BILI) { renderBiliPage(); return true; }
      if (cat === TAB_ANIME) { renderAnimePage(); return true; }
      if (cat === TAB_BILI) { renderBili(); return true; }
      if (cat === TAB_FAV) { renderLib(false); return true; }
      if (cat === TAB_ARCH) { renderLib(true); return true; }
      if (cat === TAB_FIND) { renderFind(); return true; }
      return false;
    },

    appendTabs() { appendTabs(); },

    // 「文章 / 原网页」模式。文章 = 本地正文（干净、快、省流量），
    // 原网页 = 打开之前扒下来的整页镜像（原样，但有些站扒不全会缺样式）。
    // 只有「搜索」这一页才有原网页/正文切换 —— 别的地方一律走本地正文
    readMode() { return readMode(); },

    wantsMirror(it) {
      if (ex.noMirror) return false;
      if (state.cat !== '搜索') return false;
      return readMode() === 'mirror' && !!(it && it.url);
    },

    openMirror(it) {
      const url = it.url;
      // 搜索结果的整页是抓取时顺手扒的，直接按 id 打开最稳。
      // 不用 window.open —— 被弹窗拦截器拦掉就变成"点了没反应"，
      // 改成在页面里开一个内嵌窗口看，还能顺手给个"新标签打开"的链接。
      if (it && it.mirror) {
        showMirror('/mirror/' + encodeURIComponent(it.mirror) + '/index.html');
        return;
      }
      const list = (state.mirrors && state.mirrors.items) || [];
      const hit = list.find((m) => m.url === url);
      if (hit) { showMirror(mirrorUrlOf(hit)); return; }
      // 没扒过这个页面 —— 说清楚为什么，再退回本地正文
      el.metaLine.textContent =
        '这个页面还没扒成离线镜像（「镜像」标签页里可以手动扒）。先给你看本地正文。';
      ex.readerItem = it;
      forceArticle(it);
    },

    afterStatus(st) {
      // 不用密码（比如 U 盘插着）就把锁收起来
      if (!st.auth_required) hideLock();
      // 权限徽章
      const lic = st.license || {};
      const txt = st.usb ? 'U 盘' : (lic.activated ? '已激活' : (lic.trial ? '试用' : '未激活'));
      const el = $('lic-text');
      if (el) el.textContent = txt;
      const badge = $('lic-badge');
      if (badge) badge.className = 'badge badge-lic'
        + (st.usb ? ' lic-usb' : (lic.activated ? ' lic-ok' : ' lic-trial'));
      if (ex.dlOpen) renderDrawer();
    },

    // 打开面板时记一笔
    async onOpen(kind, rid, meta) {
      if (!kind || !rid) return;
      try { await post('/api/open', Object.assign({ kind, rid }, meta || {})); } catch (e) {}
    },

    // app.js 打开阅读面板时把条目塞过来，收藏按钮要用
    setReaderItem(it) {
      ex.readerItem = it;
      const btn = $('btn-rd-fav');
      if (btn) {
        btn.dataset.fav = '0';
        btn.textContent = '♡ 收藏';
        btn.disabled = !it || !it.id;
      }
      if (it && it.id) {
        post('/api/open', {
          kind: 'news', rid: it.id, title: it.title,
          sub: [it.source, it.published].filter(Boolean).join(' ・ '),
          cat: it.category, url: it.url || '', image: it.image || '',
          ts: it.published_ts || 0,
        }).then(() => {
          // 已经收藏过的把心涂上
          return api('/api/library?fav=1&limit=1000');
        }).then((d) => {
          if (!d || !d.items) return;
          const hit = d.items.find((r) => r.key === ('news:' + it.id));
          if (hit && btn) { btn.dataset.fav = '1'; btn.textContent = '♥ 已收藏'; }
        }).catch(() => {});
      }
    },

    setPlayerItem(v) {
      ex.playerItem = v;
      const btn = $('btn-pl-fav');
      if (btn) {
        btn.dataset.fav = '0';
        btn.textContent = '♡ 收藏';
      }
    },

    // 关掉阅读面板 = 看完。收藏过的后端不会归档
    onReaderClose() {
      const it = ex.readerItem;
      ex.readerItem = null;
      if (it && it.id) markFinished('news:' + it.id);
    },

    onPlayerClose() {
      const v = ex.playerItem;
      ex.playerItem = null;
      if (v) markFinished('video:' + (v.bvid || v.id));
    },

    favButton(btn, kind, rid, meta) {
      if (!btn) return;
      btn.dataset.fav = '0';
      btn.onclick = () => favToggle(kind, rid, meta, btn);
    },

    async boot() {
      // 开屏没过就先别拉业务数据：所有接口现在都要令牌，拉也是 401 刷一屏错
      try {
        await loadPolicy(true);
      } catch (e) { /* 服务没起来就照常往下走 */ }
      if (policy && policy.screen && policy.screen.required && !policy.screen.solved) {
        renderDigits(policy.screen);
        showLock('先过这道开屏验证');
        return new Promise(() => {});   // 门开了会 reload，不会走到这里
      }

      await loadMusic();
      await loadAnime();
      await loadBili();
      await loadLib('', true);
      appendTabs();
      pollLog();
      ex.logTimer = setInterval(pollLog, 2000);
      // 每 60 秒把新抓到的歌/番/推荐跟一下
      setInterval(async () => {
        const before = JSON.stringify(extraTabs());
        await loadMusic(); await loadAnime(); await loadBili(); await loadLib('', true);
        if (JSON.stringify(extraTabs()) !== before) appendTabs();
        if (state.cat === TAB_MUSIC && window.MusicUI) {
          // 点歌台自己会刷列表，不用重画
        }
      }, 60000);
    },
  };

  /* ═════════════ 事件绑定 ═════════════ */

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const aroot = document.getElementById('anime-root');
    if (aroot && !aroot.hidden) {
      leaveAnime();
      backToHome();
      return;
    }
    const root = document.getElementById('bili-root');
    if (root && !root.hidden) {
      ensureBiliExit(false);
      root.hidden = true;
      root.innerHTML = '';
      if (window.BiliUI && typeof BiliUI.unmount === 'function') {
        try { BiliUI.unmount(); } catch (err) { /* 忽略 */ }
      }
      const g = document.getElementById('grid');
      if (g) g.hidden = false;
      state.cat = '全部';
      render();
      if (typeof buildTabs === 'function') buildTabs(state.snap || {});
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    // 锁
    const go = $('lock-go');
    if (go) go.onclick = doLogin;
    const inp = $('lock-input');
    if (inp) inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });
    const help = $('lock-help');
    if (help) help.onclick = lockHelp;

    // 头部按钮
    const bdl = $('btn-dl');
    if (bdl) bdl.onclick = () => toggleDrawer();
    const bdc = $('btn-dl-close');
    if (bdc) bdc.onclick = () => toggleDrawer(false);
    const bclear = $('btn-dl-clear');
    if (bclear) bclear.onclick = async () => {
      await post('/api/queue', { action: 'clear' });
      renderDrawer();
    };
    const blic = $('btn-license');
    if (blic) blic.onclick = openLicense;
    const blc = $('btn-license-close');
    if (blc) blc.onclick = () => $('license').close();

    const lm = $('btn-log-more');
    if (lm) lm.onclick = () => { const b = $('btn-log'); if (b) b.click(); };

    // 阅读面板的收藏
    const rdf = $('btn-rd-fav');
    if (rdf) rdf.onclick = () => {
      const it = ex.readerItem;
      if (!it) return;
      favToggle('news', it.id, {
        title: it.title, sub: [it.source, it.published].filter(Boolean).join(' ・ '),
        cat: it.category, url: it.url, image: it.image, ts: it.published_ts || 0,
      }, rdf);
    };
    const plf = $('btn-pl-fav');
    if (plf) plf.onclick = () => {
      const v = ex.playerItem;
      if (!v) return;
      favToggle('video', v.bvid || v.id, {
        title: v.title, sub: v.up || '', url: v.url || '', image: v.pic || '',
      }, plf);
    };

    // 搜索页那个「正文 / 原网页」开关是动态画的，得用事件委托
    setReadMode(readMode());

    // 标签栏收起 / 展开
    applyFold();
    const fold = $('tab-fold');
    if (fold) fold.onclick = () => {
      const on = !document.body.classList.contains('tabs-folded');
      localStorage.setItem('whale.fold', on ? '1' : '0');
      applyFold();
    };

    // 全局搜索
    const gs = $('global-search');
    if (gs) {
      gs.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') doGlobalSearch(gs.value);
      });
    }

    // 网格里的收藏/重下/追更点击
    const grid = $('grid');
    if (grid) {
      grid.addEventListener('click', async (e) => {
        const fav = e.target.closest('.l-fav');
        if (fav) {
          e.stopPropagation();
          const on = !fav.dataset.on;
          await post('/api/fav', { key: fav.dataset.key, on });
          fav.dataset.on = on ? '1' : '0';
          fav.textContent = on ? '♥ 已收藏' : '♡ 收藏';
          loadLib('', true);
          return;
        }
        const re = e.target.closest('.l-re');
        if (re) {
          e.stopPropagation();
          const url = re.dataset.url;
          if (!url) { re.textContent = '没有原文地址'; return; }
          const r = await post('/api/refetch', { url });
          re.textContent = r.ok ? '已排队' : (r.error || '排不上');
          return;
        }
        const mb = e.target.closest('#search-mode-toggle .mt-btn');
        if (mb) {
          e.stopPropagation();
          setReadMode(mb.dataset.mode);
          renderCat();
          return;
        }
        const row = e.target.closest('.fg-row');
        if (row) { openFindRow(row); }
      });
    }
  });

  async function openFindRow(row) {
    const kind = row.dataset.kind;
    const rid = row.dataset.rid;
    const url = row.dataset.url;
    if (kind === 'music' && window.MusicUI && MusicUI.playById) {
      state.cat = TAB_MUSIC; renderCat();
      setTimeout(() => MusicUI.playById(rid), 300);
      return;
    }
    if (url && (kind === 'bili' || kind === 'video' || kind === 'anime')) {
      window.open(url, '_blank');
      return;
    }
    if (kind === 'archive') {
      // 归档记录里存的是原文地址，有就打开
      if (url) window.open(url, '_blank');
      return;
    }
  }

  /* ═══════════ 权限：开屏 / 二级门 / 管理员面板（v0.5） ═══════════ */

  const GATE_TABS = {
    '视频': 'video', '点歌台': 'music', 'B 站': 'bili',
    '追更': 'anime', '镜像': 'mirror', '搜索': 'search',
  };
  let policy = null;
  let pendingCat = '';

  function reasonText(reason) {
    if (reason === 'need_admin') return '这一块要管理员口令才能进';
    if (reason === 'not_today') return '今天不开放（只在设置里勾的日子开放）';
    if (reason === 'exam_lock') return '考试周锁住了，插 U 盘才能进';
    return '权限不够';
  }

  let tabObserver = null;
  let setObserver = null;

  function polToast(msg) {
    if (!msg) return;
    let t = document.getElementById('pol-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'pol-toast';
      t.className = 'pol-toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('is-show');
    clearTimeout(t.__timer);
    t.__timer = setTimeout(() => t.classList.remove('is-show'), 3200);
  }

  function tabLabelOf(b) {
    const n = b && b.firstChild;
    return String((n && n.nodeType === 3 ? n.textContent : b.textContent) || '').trim();
  }

  function applyTabVisibility() {
    if (!policy) return;
    const feats = policy.features || {};
    const reason = (policy.level2 || {}).reason || '';
    const gateReasons = ['need_admin', 'not_today', 'exam_lock'];
    document.querySelectorAll('#tabs .tab').forEach((b) => {
      const label = tabLabelOf(b);
      let hide = false;
      if (label === '搜索' && policy.l1_search === false) hide = true;
      if ((label === '收藏' || label === '归档') && policy.l1_library === false) hide = true;
      const key = GATE_TABS[label];
      if (key && feats[key] === false && gateReasons.indexOf(reason) < 0) hide = true;
      b.style.display = hide ? 'none' : '';
      b.dataset.polHidden = hide ? '1' : '';
    });
  }

  function watchTabs() {
    const box = $('tabs');
    if (!box || tabObserver) return;
    tabObserver = new MutationObserver(() => {
      window.requestAnimationFrame(applyTabVisibility);
    });
    tabObserver.observe(box, { childList: true });
  }

  function watchSettingsBody() {
    if (setObserver) return;
    const body = $('set-body');
    if (!body) return;
    setObserver = new MutationObserver(() => {
      const dlg = $('settings');
      if (dlg && dlg.open) applySettingsLock();
    });
    setObserver.observe(body, { childList: true, subtree: true });
  }

  function applySettingsLock() {
    const dlg = $('settings');
    if (!dlg || !dlg.open) return;
    const body = $('set-body');
    if (!body) return;
    const locked = !!(policy && policy.lock_settings && !policy.admin);
    dlg.classList.toggle('pol-readonly', locked);
    let bar = body.querySelector('.pol-lockbar');
    if (locked) {
      if (!bar) {
        bar = document.createElement('div');
        bar.className = 'pol-lockbar';
        bar.textContent = '设置被锁了：可以看，不能改。插 U 盘或用管理员口令才能保存。';
        body.insertBefore(bar, body.firstChild);
      }
      body.querySelectorAll('input,select,textarea,button').forEach((n) => {
        if (n.closest('.admin-card')) return;
        if (!n.disabled) { n.dataset.polDisabled = '1'; n.disabled = true; }
      });
      ['btn-settings-save', 'btn-settings-reset'].forEach((id) => {
        const b = $(id);
        if (b) b.disabled = true;
      });
    } else {
      if (bar) bar.remove();
      body.querySelectorAll('[data-pol-disabled="1"]').forEach((n) => {
        n.disabled = false;
        delete n.dataset.polDisabled;
      });
      ['btn-settings-save', 'btn-settings-reset'].forEach((id) => {
        const b = $(id);
        if (b) b.disabled = false;
      });
    }
  }

  function applyPolicy() {
    if (!policy) return;
    const logStrip = $('log-strip');
    if (logStrip) logStrip.hidden = !!policy.hide_log;
    const logBtn = $('btn-log');
    if (logBtn) logBtn.hidden = !!policy.hide_log;

    const hideBtns = !!policy.hide_buttons;
    ['btn-fetch', 'btn-dl', 'btn-license'].forEach((id) => {
      const b = $(id);
      if (b) b.hidden = hideBtns;
    });

    document.body.classList.toggle('pol-lock-settings',
      !!(policy.lock_settings && !policy.admin));
    watchTabs();
    watchSettingsBody();
    applyTabVisibility();
    applySettingsLock();

    const save = $('btn-settings-save');
    if (save && !($('settings') && $('settings').open)) {
      save.disabled = !!policy.lock_settings && !policy.admin;
      save.title = save.disabled ? '设置被锁了，要管理员才能改' : '';
    }
  }

  async function loadPolicy(force) {
    if (policy && !force) return policy;
    try { policy = await api('/api/policy'); } catch (e) { policy = null; }
    applyPolicy();
    return policy;
  }

  function ensureGateDialog() {
    let dlg = document.getElementById('gate-dlg');
    if (dlg) return dlg;
    dlg = document.createElement('dialog');
    dlg.id = 'gate-dlg';
    dlg.className = 'gate-dlg';
    dlg.innerHTML = `
      <div class="dlg-head">
        <div class="rd-meta"><strong>这里要管理员</strong>
          <span class="dim" id="gate-why"></span></div>
        <button class="btn" id="gate-close">关闭</button>
      </div>
      <div class="gate-body">
        <p class="dim" id="gate-tip">插 U 盘，或者输管理员口令。</p>
        <input type="password" id="gate-pw" class="gate-input"
               placeholder="管理员口令" autocomplete="off" spellcheck="false">
        <div class="gate-row">
          <button class="btn btn-primary" id="gate-go">开门</button>
          <span class="dim" id="gate-msg"></span>
        </div>
      </div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('#gate-close').onclick = () => dlg.close();
    dlg.querySelector('#gate-go').onclick = submitGate;
    dlg.querySelector('#gate-pw').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') submitGate();
    });
    return dlg;
  }

  async function submitGate() {
    const pw = ($('gate-pw').value || '').trim();
    if (!pw) return;
    $('gate-msg').textContent = '验着…';
    const d = await post('/api/admin', { password: pw });
    if (!d.ok) {
      $('gate-msg').textContent = d.error || '不对';
      $('gate-pw').select();
      return;
    }
    $('gate-pw').value = '';
    $('gate-msg').textContent = '';
    document.getElementById('gate-dlg').close();
    await loadPolicy(true);
    const stillBlocked = pendingCat && gateBlocked(pendingCat);
    if (stillBlocked) {
      const why = (policy.level2 && policy.level2.reason) || 'need_admin';
      polToast(reasonText(why));
      pendingCat = '';
      return;
    }
    if (pendingCat) {
      const c = pendingCat;
      pendingCat = '';
      state.cat = c;
      renderCat();
      if (typeof buildTabs === 'function') buildTabs(state.snap || {});
    }
  }

  function openGate(cat, reason) {
    pendingCat = cat;
    const dlg = ensureGateDialog();
    $('gate-why').textContent = reasonText(reason);
    const needPw = reason === 'need_admin';
    const tip = $('gate-tip');
    tip.textContent = needPw
      ? ((policy && policy.usb) ? 'U 盘插着，刷新一下应该就能进。' : '插 U 盘，或者输管理员口令。')
      : reasonText(reason);
    const pw = $('gate-pw');
    const go = $('gate-go');
    if (pw) {
      pw.hidden = !needPw;
      if (needPw) { pw.value = ''; pw.focus(); }
    }
    if (go) go.hidden = !needPw;
    $('gate-msg').textContent = '';
    if (dlg.showModal) dlg.showModal();
  }

  function gateBlocked(cat) {
    if (!policy) return false;
    const key = GATE_TABS[cat];
    if (!key) return false;
    if ((policy.features || {})[key] !== false) return false;
    const reason = (policy.level2 || {}).reason || '';
    return ['need_admin', 'not_today', 'exam_lock'].indexOf(reason) >= 0;
  }

  // 包一层 render：受限的页先过门
  const _renderInner = EXTRA.render;
  EXTRA.render = function (cat) {
    if (gateBlocked(cat)) {
      openGate(cat, (policy.level2 && policy.level2.reason) || 'need_admin');
      return true;              // 别让原逻辑去画那一页
    }
    return _renderInner.apply(this, arguments);
  };

  // 设置最下面加一行「管理员更改」，点开是独立的面板
  function injectAdminEntry() {
    const body = $('set-body');
    if (!body || body.querySelector('.admin-entry')) return;
    const p = policy || {};
    const row = document.createElement('div');
    row.className = 'admin-entry';
    row.innerHTML =
      '<div class="admin-entry-main">'
      + '<b>管理员更改</b>'
      + '<span class="dim">' + (p.admin ? '已经是管理员' : '要口令或 U 盘')
      + ' ・ 开屏 / 菜单 / 时间表 / 更新</span>'
      + '</div>'
      + '<button class="btn" id="admin-entry-go">打开</button>';
    body.appendChild(row);
    row.querySelector('#admin-entry-go').onclick = () => {
      const dlg = ensureAdminDialog();
      renderAdminDialog(dlg);
      if (dlg.showModal) dlg.showModal();
    };
  }

  function ensureAdminDialog() {
    let dlg = document.getElementById('admin-dlg');
    if (dlg) return dlg;
    dlg = document.createElement('dialog');
    dlg.id = 'admin-dlg';
    dlg.className = 'admin-dlg';
    dlg.innerHTML = `
      <div class="dlg-head">
        <div class="rd-meta"><strong>管理员更改</strong>
          <span class="dim" id="ad-status"></span></div>
        <div class="rd-actions">
          <span class="dim" id="ad-msg"></span>
          <button class="btn" id="ad-save">保存</button>
          <button class="btn btn-ghost" id="ad-close">关闭</button>
        </div>
      </div>
      <div class="admin-body" id="admin-body"></div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('#ad-close').onclick = () => dlg.close();
    dlg.querySelector('#ad-save').onclick = saveAdmin;
    return dlg;
  }

  function renderAdminDialog(dlg) {
    const body = dlg.querySelector('#admin-body');
    const p = policy || {};
    const wd = ['一', '二', '三', '四', '五', '六', '日'];
    const today = p.weekday ? wd[p.weekday - 1] : '?';
    const days = (p.weekdays || []).map((n) => '周' + wd[n - 1]).join('、');

    if (!p.admin) {
      body.innerHTML =
        '<p class="set-hint">今天是周' + esc(today) + '，开放日：' + esc(days)
        + '。要看/改这些，先插 U 盘或者输管理员口令。</p>'
        + '<div class="admin-pw-row">'
        + '<input type="password" id="admin-pw" placeholder="管理员口令">'
        + '<button class="btn btn-primary" id="admin-pw-go">解锁</button>'
        + '<span class="dim" id="admin-pw-msg"></span></div>';
      body.querySelector('#admin-pw-go').onclick = async () => {
        const pw = (body.querySelector('#admin-pw').value || '').trim();
        if (!pw) return;
        body.querySelector('#admin-pw-msg').textContent = '验着…';
        const d = await post('/api/admin', { password: pw });
        if (!d.ok) {
          body.querySelector('#admin-pw-msg').textContent = d.error || '不对';
          return;
        }
        await loadPolicy(true);
        renderAdminDialog(dlg);
      };
      return;
    }

    const groups = (state.schema || []).filter((g) => g.admin);
    const rows = groups.map((g) => (typeof setGroupHtml === 'function')
      ? setGroupHtml(g) : '').join('');
    body.innerHTML =
      '<p class="set-hint">今天是周' + esc(today) + '，二级开放日：' + esc(days)
      + (p.exam_lock ? ' ・ <b>考试周已锁</b>' : '')
      + ' ・ ' + (p.usb ? 'U 盘插着（最高权限）' : '没插 U 盘')
      + '</p>' + rows;
  }

  async function saveAdmin() {
    const body = $('admin-body');
    if (!body) return;
    const cfg = Object.assign({}, state.cfg || {});
    body.querySelectorAll('[data-key]').forEach((n) => {
      const k = n.dataset.key, t = n.dataset.type;
      if (t === 'bool') cfg[k] = n.checked;
      else if (t === 'number') cfg[k] = Number(n.value);
      else if (t === 'intlist') {
        cfg[k] = (n.value || '').split(/[,，]+/).map((s) => s.trim()).filter(Boolean);
      } else cfg[k] = n.value;
    });
    // 中文逗号统一成英文的，免得服务端解析不到
    Object.keys(cfg).forEach((k) => {
      if (typeof cfg[k] === 'string') cfg[k] = cfg[k].replace(/，/g, ',');
    });
    $('ad-msg').textContent = '保存中…';
    try {
      const r = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      });
      const d = await r.json();
      if (!r.ok) { $('ad-msg').textContent = d.error || '保存失败'; return; }
      state.cfg = d.config || cfg;
      $('ad-msg').textContent = '已保存 ✓';
      await loadPolicy(true);
      setTimeout(() => { $('ad-msg').textContent = ''; }, 2200);
    } catch (e) {
      $('ad-msg').textContent = '保存失败：' + e.message;
    }
  }

  // 设置面板的钩子要等 app.js 跑完再挂（extra.js 在它前面加载）
  function hookSettings() {
    if (typeof openSettings !== 'function' || window.__settingsHooked) return;
    window.__settingsHooked = true;
    const orig = openSettings;
    const patched = async function () {
      await loadPolicy();
      await orig();
      injectAdminEntry();
    };
    window.openSettings = patched;
    const b = document.getElementById('btn-settings');
    if (b) b.onclick = patched;
  }
  document.addEventListener('DOMContentLoaded', hookSettings);
  setTimeout(hookSettings, 1200);

  async function refreshLockDigits() {
    for (let i = 0; i < 3; i++) {
      try {
        const p = await api('/api/policy');
        if (p && p.screen && p.screen.required && !p.screen.solved) {
          renderDigits(p.screen);
          return;
        }
        if (p && p.screen && p.screen.solved) return;
      } catch (e) { /* 服务没起来，等一下再试 */ }
      await new Promise((r) => setTimeout(r, 800));
    }
  }
  window.__refreshLockDigits = refreshLockDigits;

  // 启动时拉一次策略：要口令就先锁住
  (async function bootPolicy() {
    const p = await loadPolicy(true);
    if (!p) {
      await new Promise((r) => setTimeout(r, 800));
      await loadPolicy(true);
    }
    if (policy && policy.screen && policy.screen.required && !policy.screen.solved) {
      renderDigits(policy.screen);
      showLock('先过这道口令');
    } else {
      hideLock();
    }
  })();

  EXTRA.afterSettingsOpen = function () { injectAdminEntry(); };

  window.EXTRA_OPEN_GATE = openGate;
  window.EXTRA_SHOWLOCK = showLock;
})();
