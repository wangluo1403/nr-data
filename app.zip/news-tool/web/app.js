/* 离线新闻阅览室 — 前端逻辑
   数据全从本地服务拿，断网也能用。 */

const $ = (id) => document.getElementById(id);

const el = {
  syncLine: $('sync-line'),
  netBadge: $('net-badge'), netText: $('net-text'),
  stateBadge: $('state-badge'), stateText: $('state-text'),
  btnFetch: $('btn-fetch'),
  barFill: $('bar-fill'), countdownText: $('countdown-text'),
  tabs: $('tabs'),
  search: $('search'), onlyNew: $('only-new'),
  snapSelect: $('snapshot-select'),
  metaLine: $('meta-line'), sourceLine: $('source-line'),
  grid: $('grid'), empty: $('empty'),
  footLeft: $('foot-left'),
  btnLog: $('btn-log'), logDialog: $('log-dialog'),
  logBody: $('log-body'), btnLogClose: $('btn-log-close'),
  reader: $('reader'), rdTitle: $('rd-title'), rdContent: $('rd-content'),
  rdCat: $('rd-cat'), rdSrcLine: $('rd-src-line'), rdOrigin: $('rd-origin'),
  btnReaderClose: $('btn-reader-close'),
  player: $('player'), plVideo: $('pl-video'), plTitle: $('pl-title'),
  plDesc: $('pl-desc'), plComments: $('pl-comments'),
  plSrcLine: $('pl-src-line'), plOrigin: $('pl-origin'),
  btnPlayerClose: $('btn-player-close'),
  btnSettings: $('btn-settings'), settings: $('settings'),
  setBody: $('set-body'), setPath: $('set-path'), setMsg: $('set-msg'),
  btnSettingsSave: $('btn-settings-save'), btnSettingsClose: $('btn-settings-close'),
  btnSettingsReset: $('btn-settings-reset'),
};

const VIDEO_TAB = '视频';
const SEARCH_TAB = '搜索';
const MIRROR_TAB = '镜像';

const state = {
  snap: null,          // 当前快照
  videos: null,        // 本地视频索引
  search: null,        // 必应搜索结果
  mirrors: null,       // 离线镜像索引
  view: [],            // 当前筛完的列表（卡片下标就指这里）
  cat: '全部',
  q: '',
  onlyNew: false,
  status: null,
  loadSeq: 0,
  schema: null,        // 设置面板的字段定义
  cfg: null,           // 当前设置值
};

/* ───────────── 工具 ───────────── */

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));

function pad(n) { return String(n).padStart(2, '0'); }

function fmtAbs(ts) {
  if (!ts) return '未知';
  const d = new Date(ts * 1000);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} `
       + `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function fmtRel(ts) {
  if (!ts) return '未知';
  const s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
  if (s < 60) return `${s} 秒前`;
  if (s < 3600) return `${Math.floor(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.floor(s / 3600)} 小时 ${Math.floor((s % 3600) / 60)} 分前`;
  return `${Math.floor(s / 86400)} 天前`;
}

function fmtDur(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  if (h > 0) return `${h} 小时 ${m} 分`;
  if (m > 0) return `${m} 分 ${s} 秒`;
  return `${s} 秒`;
}

// 视频时长用 12:34 这种
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  if (h > 0) return `${h}:${pad(m)}:${pad(s)}`;
  return `${m}:${pad(s)}`;
}

function fmtNum(n) {
  n = Number(n) || 0;
  if (n >= 100000000) return (n / 100000000).toFixed(1) + ' 亿';
  if (n >= 10000) return (n / 10000).toFixed(1) + ' 万';
  return String(n);
}

/* ───────────── 状态轮询（每秒） ───────────── */

async function pollStatus() {
  try {
    const r = await fetch('/api/status', { cache: 'no-store' });
    const st = await r.json();
    state.status = st;
    renderStatus(st);
  } catch (e) {
    el.netText.textContent = '服务断线';
    el.netBadge.className = 'badge offline';
    el.stateText.textContent = '找不到后端';
  }
}

function renderStatus(st) {
  // 同步时间（重点显示）
  if (st.last_fetch_ts) {
    el.syncLine.innerHTML =
      `同步时间：<b>${esc(st.last_fetch_at)}</b> ・ ${esc(fmtRel(st.last_fetch_ts))}`
      + ` ・ 共 ${st.total_items} 条`;
  } else {
    el.syncLine.textContent = '还没同步过，正在等网络…';
  }

  // 网络状态
  if (st.online === true) {
    el.netBadge.className = 'badge online';
    el.netText.textContent = '已联网';
  } else if (st.online === false) {
    el.netBadge.className = 'badge offline';
    el.netText.textContent = '没网';
  } else {
    el.netBadge.className = 'badge';
    el.netText.textContent = '检测中';
  }

  // 抓取状态 + 倒计时
  const stMap = {
    idle: '待命中', hunting: '正在盯网络', fetching: '抓取中', starting: '启动中',
  };
  el.stateText.textContent = stMap[st.state] || st.state;
  el.stateBadge.className = 'badge' + (st.fetching || st.state === 'hunting' ? ' busy' : '');

  let pct = 0, label = '';
  if (st.state === 'fetching') {
    pct = st.progress_total ? (st.progress_done / st.progress_total) * 100 : 0;
    label = st.task_label
      ? `正在做：${st.task_label} ・ 队列里还有 ${(st.queue && st.queue.pending) || 0} 条`
      : `正在抓取 ${st.progress_done}/${st.progress_total} 个源…`;
  } else if (st.blocked) {
    pct = 0;
    label = `被云端停用了：${st.blocked}`;
  } else if (st.state === 'hunting') {
    pct = 0;
    label = '没网，正在盯着（一有网立刻开工）';
  } else if (st.seconds_to_next_round > 0) {
    const total = st.dedupe_seconds || 1;
    pct = Math.min(100, ((total - st.seconds_to_next_round) / total) * 100);
    label = `刚抓过，${fmtDur(st.seconds_to_next_round)}后才会再抓一轮`;
  } else if ((st.queue && st.queue.pending)) {
    label = `有 ${st.queue.pending} 条任务排队，联网就开工`;
  } else {
    label = '空闲中，一联网就开工';
  }
  el.barFill.style.width = pct.toFixed(1) + '%';
  el.countdownText.textContent = label;

  el.btnFetch.disabled = st.fetching;
  el.footLeft.textContent =
    `后端运行 ${fmtDur((st.now || 0) - (st.started_ts || 0))}`
    + ` ・ 端口 ${st.port || '-'}`
    + (st.rate_bytes ? ` ・ 限速 ${(st.rate_bytes / 1048576).toFixed(1)} MB/s` : ' ・ 不限速')
    + (st.disk_free_mb != null ? ` ・ 磁盘剩 ${st.disk_free_mb} MB` : '')
    + (st.last_error ? ` ・ 上次出错：${st.last_error}` : '');
  if (window.EXTRA) EXTRA.afterStatus(st);
}

/* ───────────── 数据加载 ───────────── */

async function loadNews(snapId) {
  const seq = ++state.loadSeq;
  const url = snapId ? `/api/news?id=${encodeURIComponent(snapId)}` : '/api/news';
  try {
    const r = await fetch(url, { cache: 'no-store' });
    const data = await r.json();
    if (seq !== state.loadSeq) return;
    state.snap = data;
    if (!data.items) data.items = [];
    buildTabs(data);
    render();
    renderSourceLine(data);
  } catch (e) {
    el.metaLine.textContent = '读取数据失败：' + e.message;
  }
}

async function loadVideos() {
  try {
    const r = await fetch('/api/videos', { cache: 'no-store' });
    state.videos = await r.json();
  } catch (e) {
    state.videos = null;
  }
  if (!state.videos || !state.videos.items) {
    state.videos = { generated_at: '', total: 0, total_bytes: 0, items: [] };
  }
}

async function loadSearch() {
  try {
    const r = await fetch('/api/search', { cache: 'no-store' });
    state.search = await r.json();
  } catch (e) {
    state.search = null;
  }
  if (!state.search || !state.search.items) {
    state.search = { generated_at: '', total: 0, keywords: [], items: [] };
  }
}

async function loadMirrors() {
  try {
    const r = await fetch('/api/mirror', { cache: 'no-store' });
    state.mirrors = await r.json();
  } catch (e) {
    state.mirrors = null;
  }
  if (!state.mirrors || !state.mirrors.items) {
    state.mirrors = { generated_at: '', total: 0, items: [], job: {} };
  }
}

function fmtBytes(n) {
  n = Number(n) || 0;
  if (n >= 1048576) return (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB';
  if (n >= 1024) return Math.round(n / 1024) + ' KB';
  return n + ' B';
}

function buildTabs(snap) {
  const counts = {};
  for (const it of snap.items || []) {
    counts[it.category] = (counts[it.category] || 0) + 1;
  }
  const cats = ['全部', ...(snap.categories || Object.keys(counts))];
  el.tabs.innerHTML = '';
  for (const c of cats) {
    const n = c === '全部' ? (snap.items || []).length : (counts[c] || 0);
    if (n === 0) continue;
    const b = document.createElement('button');
    b.className = 'tab' + (c === state.cat ? ' active' : '');
    b.innerHTML = `${esc(c)}<span class="n">${n}</span>`;
    b.onclick = () => { state.cat = c; render(); buildTabs(snap); };
    el.tabs.appendChild(b);
  }

  // 视频单独挂一个标签，放最后
  const nv = ((state.videos && state.videos.items) || []).length;
  if (nv) {
    const vb = document.createElement('button');
    vb.className = 'tab tab-video' + (state.cat === VIDEO_TAB ? ' active' : '');
    vb.innerHTML = `${VIDEO_TAB}<span class="n">${nv}</span>`;
    vb.onclick = () => { state.cat = VIDEO_TAB; render(); buildTabs(snap); };
    el.tabs.appendChild(vb);
  }

  // 必应搜索结果：不混进新闻流，单独一个标签
  const ns = ((state.search && state.search.items) || []).length;
  if (ns) {
    const sb = document.createElement('button');
    sb.className = 'tab tab-search' + (state.cat === SEARCH_TAB ? ' active' : '');
    sb.innerHTML = `${SEARCH_TAB}<span class="n">${ns}</span>`;
    sb.onclick = () => { state.cat = SEARCH_TAB; render(); buildTabs(snap); };
    el.tabs.appendChild(sb);
  }

  // 离线网页镜像
  const nm = ((state.mirrors && state.mirrors.items) || []).length;
  if (nm) {
    const mb = document.createElement('button');
    mb.className = 'tab tab-mirror' + (state.cat === MIRROR_TAB ? ' active' : '');
    mb.innerHTML = `${MIRROR_TAB}<span class="n">${nm}</span>`;
    mb.onclick = () => { state.cat = MIRROR_TAB; render(); buildTabs(snap); };
    el.tabs.appendChild(mb);
  }

  // v0.3 的那些新标签（点歌台 / 追更 / B 站 / 收藏 / 归档）交给 extra.js 画
  if (window.EXTRA) EXTRA.appendTabs();
}

function render() {
  if (window.EXTRA && EXTRA.render(state.cat)) return;
  if (state.cat === VIDEO_TAB) { renderVideos(); return; }
  if (state.cat === SEARCH_TAB) { renderSearch(); return; }
  if (state.cat === MIRROR_TAB) { renderMirrors(); return; }
  const snap = state.snap;
  if (!snap) return;
  let items = snap.items || [];

  if (state.cat !== '全部') items = items.filter((i) => i.category === state.cat);
  if (state.onlyNew) items = items.filter((i) => i.is_new);
  if (state.q) {
    const q = state.q.toLowerCase();
    items = items.filter((i) =>
      (i.title || '').toLowerCase().includes(q) ||
      (i.summary || '').toLowerCase().includes(q) ||
      (i.source || '').toLowerCase().includes(q));
  }

  el.metaLine.textContent =
    `本次同步 ${snap.generated_at || '-'} ・ 显示 ${items.length} / 共 ${snap.total || 0} 条`;

  el.grid.classList.remove('video-grid');
  el.grid.innerHTML = items.map(cardHtml).join('');
  el.empty.hidden = items.length > 0;
  state.view = items;

  // 图挂了就换成占位块
  el.grid.querySelectorAll('img.thumb').forEach((img) => {
    img.addEventListener('error', () => {
      const ph = document.createElement('div');
      ph.className = 'thumb-ph';
      ph.textContent = '🐋';
      img.replaceWith(ph);
    }, { once: true });
  });
}

function cardHtml(it, i) {
  const img = it.image
    ? `<img class="thumb" src="/${esc(it.image)}" alt="" loading="lazy">`
    : `<div class="thumb-ph">🐋</div>`;
  const summary = it.summary ? `<p class="summary">${esc(it.summary)}</p>` : '';
  const when = it.published || (it.published_ts ? fmtAbs(it.published_ts) : '');
  // 正文块数，让用户知道点进去有东西
  const nPara = (it.content || []).filter((b) => b.t !== 'img').length;
  const hint = nPara >= 2
    ? `<span class="read-hint">正文 ${nPara} 段</span>`
    : (it.summary ? '<span class="read-hint dim">仅摘要</span>' : '');
  return `
  <article class="card${it.is_new ? ' is-new' : ''}" data-i="${i}" tabindex="0" role="button"
           aria-label="阅读：${esc(it.title)}">
    ${it.is_new ? '<span class="flag-new">NEW</span>' : ''}
    ${img}
    <div class="card-body">
      <h2>${esc(it.title)}</h2>
      ${summary}
      <div class="card-foot">
        <span class="cat-chip cat-${esc(it.category)}">${esc(it.category)}</span>
        <span>${esc(it.source)}${when ? ' ・ ' + esc(when) : ''}</span>
        ${hint}
      </div>
    </div>
  </article>`;
}

/* ───────────── 本地短视频 ───────────── */

function videoCardHtml(v, i) {
  const img = v.pic
    ? `<img class="thumb" src="/${esc(v.pic)}" alt="" loading="lazy">`
    : `<div class="thumb-ph">🎬</div>`;
  const nCmt = (v.comments || []).length;
  return `
  <article class="card vcard" data-i="${i}" tabindex="0" role="button"
           aria-label="播放：${esc(v.title)}">
    <span class="dur-badge">${esc(fmtClock(v.duration))}</span>
    ${img}
    <span class="play-badge">▶</span>
    <div class="card-body">
      <h2>${esc(v.title)}</h2>
      <div class="card-foot">
        <span class="cat-chip cat-视频">视频</span>
        <span>${esc(v.up || '未知 UP')}${v.view ? ' ・ ' + esc(fmtNum(v.view)) + ' 播放' : ''}</span>
        ${nCmt ? `<span class="read-hint">评论 ${nCmt}</span>` : ''}
      </div>
    </div>
  </article>`;
}

function renderVideos() {
  const all = (state.videos && state.videos.items) || [];
  let items = all;
  if (state.q) {
    const q = state.q.toLowerCase();
    items = items.filter((v) =>
      (v.title || '').toLowerCase().includes(q) ||
      (v.up || '').toLowerCase().includes(q) ||
      (v.desc || '').toLowerCase().includes(q));
  }

  const mb = all.reduce((a, v) => a + (v.size || 0), 0) / 1048576;
  el.metaLine.textContent = (state.videos && state.videos.generated_at)
    ? `视频同步 ${state.videos.generated_at} ・ 显示 ${items.length} / 共 ${all.length} 个`
      + ` ・ 占用 ${mb.toFixed(0)} MB`
    : '还没抓到视频';
  el.sourceLine.textContent = '数据来自 B 站热门榜，全部已存本地，断网也能刷';

  el.grid.classList.add('video-grid');
  el.grid.innerHTML = items.map(videoCardHtml).join('');
  el.empty.hidden = items.length > 0;
  state.view = items;

  el.grid.querySelectorAll('img.thumb').forEach((img) => {
    img.addEventListener('error', () => {
      const ph = document.createElement('div');
      ph.className = 'thumb-ph';
      ph.textContent = '🎬';
      img.replaceWith(ph);
    }, { once: true });
  });
}

/* ───────────── 必应搜索结果 ───────────── */

function renderSearch() {
  const all = (state.search && state.search.items) || [];
  let items = all;
  if (state.q) {
    const q = state.q.toLowerCase();
    items = items.filter((it) =>
      (it.title || '').toLowerCase().includes(q) ||
      (it.summary || '').toLowerCase().includes(q) ||
      (it.keyword || '').toLowerCase().includes(q) ||
      (it.host || '').toLowerCase().includes(q));
  }

  const kws = (state.search && state.search.keywords) || [];
  const job = (state.search && state.search.job) || {};
  let tail = '';
  if (job.state === 'running') tail = ' ・ 正在搜…';
  else if (job.state === 'error') tail = ` ・ 上次搜失败：${job.error || ''}`;

  el.metaLine.textContent = (state.search && state.search.generated_at)
    ? `搜索同步 ${state.search.generated_at} ・ 显示 ${items.length} / 共 ${all.length} 条`
      + (kws.length ? ` ・ 关键词：${kws.join('、')}` : '') + tail
    : (kws.length ? `关键词：${kws.join('、')} ・ 还没搜过${tail}`
                  : '还没设关键词，去「设置」里填几个，比如 DeepSeek、考研数学');
  el.sourceLine.textContent = '结果来自必应，正文已存本地，点开直接读';

  el.grid.classList.remove('video-grid');
  el.grid.innerHTML = searchToolsHtml(kws) + items.map(searchCardHtml).join('');
  el.empty.hidden = true;
  state.view = items;

  el.grid.querySelectorAll('img.thumb').forEach((img) => {
    img.addEventListener('error', () => {
      const ph = document.createElement('div');
      ph.className = 'thumb-ph';
      ph.textContent = '🔎';
      img.replaceWith(ph);
    }, { once: true });
  });
}

function searchToolsHtml(kws) {
  const running = ((state.search || {}).job || {}).state === 'running';
  const mode = (window.EXTRA && EXTRA.readMode()) || 'article';
  return `
  <div class="mtools">
    <span class="dim" style="flex:1;min-width:180px;align-self:center">
      ${kws.length ? '关键词：' + kws.map((k) => esc(k)).join('、') : '还没设关键词'}
    </span>
    <div class="mode-toggle" id="search-mode-toggle"
         title="搜索结果点开时怎么看：本地正文 / 整页镜像">
      <button class="mt-btn${mode === 'article' ? ' active' : ''}" data-mode="article">正文</button>
      <button class="mt-btn${mode === 'mirror' ? ' active' : ''}" data-mode="mirror">原网页</button>
    </div>
    <button class="btn" id="btn-search-go"${running || !kws.length ? ' disabled' : ''}>
      ${running ? '正在搜…' : '立刻搜索'}
    </button>
  </div>`;
}

async function searchGo() {
  el.metaLine.textContent = '正在搜…';
  try {
    const r = await fetch('/api/search', { method: 'POST' });
    const d = await r.json();
    if (!r.ok) el.metaLine.textContent = d.error || d.msg || '搜不了';
  } catch (e) {
    el.metaLine.textContent = '请求失败：' + e.message;
  }
  await loadSearch();
  render();
  setTimeout(refreshSearchJob, 1000);
}

async function refreshSearchJob() {
  await loadSearch();
  if (state.cat === SEARCH_TAB) render();
  const job = ((state.search || {}).job || {});
  if (job.state === 'running') setTimeout(refreshSearchJob, 1500);
  else buildTabs(state.snap || {});
}

function searchCardHtml(it, i) {
  const img = it.image
    ? `<img class="thumb" src="/${esc(it.image)}" alt="" loading="lazy">`
    : `<div class="thumb-ph">🔎</div>`;
  const summary = it.summary ? `<p class="summary">${esc(it.summary)}</p>` : '';
  const nPara = (it.content || []).filter((b) => b.t !== 'img').length;
  const hint = nPara >= 2
    ? `<span class="read-hint">正文 ${nPara} 段</span>`
    : '<span class="read-hint dim">仅摘要</span>';
  return `
  <article class="card scard" data-i="${i}" tabindex="0" role="button"
           aria-label="阅读：${esc(it.title)}">
    ${img}
    <div class="card-body">
      <h2>${esc(it.title)}</h2>
      ${summary}
      <div class="card-foot">
        <span class="cat-chip cat-搜索">${esc(it.keyword || '搜索')}</span>
        <span>${esc(it.host || '')}</span>
        ${hint}
      </div>
    </div>
  </article>`;
}

/* ───────────── 离线网页镜像 ───────────── */

function renderMirrors() {
  const all = (state.mirrors && state.mirrors.items) || [];
  let items = all;
  if (state.q) {
    const q = state.q.toLowerCase();
    items = items.filter((m) =>
      (m.title || '').toLowerCase().includes(q) ||
      (m.url || '').toLowerCase().includes(q) ||
      (m.host || '').toLowerCase().includes(q));
  }

  const bytes = all.reduce((a, m) => a + (m.bytes || 0), 0);
  const job = (state.mirrors && state.mirrors.job) || {};
  let tail = '';
  if (job.state === 'running') tail = ` ・ 正在扒：${job.url || ''}`;
  else if (job.state === 'error') tail = ` ・ 上次扒失败：${job.error || ''}`;

  el.metaLine.textContent = all.length
    ? `共 ${items.length} / ${all.length} 个页面 ・ 占用 ${fmtBytes(bytes)}${tail}`
    : '还没有扒过网页';
  el.sourceLine.textContent = '整个页面连样式、图片、字体都扒下来了，断网打开也长原样';

  el.grid.classList.remove('video-grid');
  el.grid.innerHTML = mirrorToolsHtml() + items.map(mirrorCardHtml).join('');
  el.empty.hidden = true;
  state.view = items;
}

function mirrorToolsHtml() {
  return `
  <div class="mtools">
    <input type="url" id="mirror-url" placeholder="贴一个网页地址，扒下来离线看…">
    <button class="btn" id="btn-mirror-go">扒这个页面</button>
  </div>`;
}

function mirrorCardHtml(m, i) {
  const img = m.image
    ? `<img class="thumb" src="/${esc(m.image)}" alt="" loading="lazy">`
    : `<div class="thumb-ph">📄</div>`;
  return `
  <article class="card mcard" data-i="${i}" tabindex="0" role="button"
           aria-label="打开：${esc(m.title)}">
    ${img}
    <div class="card-body">
      <h2>${esc(m.title)}</h2>
      <div class="card-foot">
        <span class="cat-chip cat-镜像">离线</span>
        <span class="mmeta">${esc(m.host || '')} ・ ${esc(m.created_at || '')}
          ・ ${m.assets || 0} 个资源 ・ ${fmtBytes(m.bytes)}</span>
        <button class="linkbtn mdel" data-del="${esc(m.id)}" title="删掉这个镜像">删除</button>
      </div>
    </div>
  </article>`;
}

function mirrorUrlOf(m) {
  return `/mirror/${encodeURIComponent(m.id)}/index.html`;
}

async function mirrorGo() {
  const box = document.getElementById('mirror-url');
  const url = (box && box.value || '').trim();
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) {
    el.metaLine.textContent = '地址要以 http:// 或 https:// 开头';
    return;
  }
  el.metaLine.textContent = '正在扒 ' + url + '…（大页面要等十几秒）';
  try {
    const r = await fetch('/api/mirror', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const d = await r.json();
    if (!r.ok) el.metaLine.textContent = d.msg || '扒不了';
    else if (box) box.value = '';
  } catch (e) {
    el.metaLine.textContent = '请求失败：' + e.message;
  }
  await loadMirrors();
  render();
  setTimeout(refreshMirrorJob, 1500);
}

async function refreshMirrorJob() {
  const job = (state.mirrors && state.mirrors.job) || {};
  if (job.state !== 'running') return;
  await loadMirrors();
  if (state.cat === MIRROR_TAB) render();
  if (((state.mirrors || {}).job || {}).state === 'running') {
    setTimeout(refreshMirrorJob, 2000);
  } else {
    buildTabs(state.snap || {});
  }
}

async function mirrorDelete(id) {
  if (!id) return;
  try {
    await fetch('/api/mirror?id=' + encodeURIComponent(id), { method: 'DELETE' });
  } catch (e) { /* 忽略 */ }
  await loadMirrors();
  if (state.cat === MIRROR_TAB) render();
  buildTabs(state.snap || {});
}

/* ───────────── 设置面板 ───────────── */

async function openSettings() {
  el.setMsg.textContent = '';
  if (!state.schema) {
    el.setBody.textContent = '载入中…';
    try {
      const r = await fetch('/api/config', { cache: 'no-store' });
      const d = await r.json();
      state.schema = d.schema || [];
      state.cfg = d.config || {};
      state.defaults = d.defaults || {};
      el.setPath.textContent = d.path || '';
    } catch (e) {
      el.setBody.textContent = '读设置失败：' + e.message;
      el.settings.showModal();
      return;
    }
  }
  el.setBody.innerHTML = state.schema
    .filter((g) => !g.admin)
    .map(setGroupHtml).join('');
  el.settings.showModal();
  if (window.EXTRA) EXTRA.afterSettingsOpen();
}

function setGroupHtml(g) {
  const rows = (g.items || []).map((it) => setRowHtml(it)).join('');
  const hint = g.hint ? `<p class="set-hint">${esc(g.hint)}</p>` : '';
  return `<section class="set-group">
    <h3>${esc(g.group || '')}</h3>${hint}<div class="set-rows">${rows}</div>
  </section>`;
}

function setRowHtml(it) {
  const v = state.cfg[it.key];
  const id = 'set-' + it.key;
  const label = `<label class="set-label" for="${id}">${esc(it.label)}`
    + (it.unit ? `<span class="dim"> ${esc(it.unit)}</span>` : '') + '</label>';
  let input;
  if (it.type === 'bool') {
    input = `<input type="checkbox" id="${id}" data-key="${esc(it.key)}" data-type="bool"`
      + (v ? ' checked' : '') + '>';
    return `<div class="set-row set-row-bool">${input}${label}
      <p class="set-hint">${esc(it.hint || '')}</p></div>`;
  }
  if (it.type === 'select') {
    const opts = (it.options || []).map((o) => {
      // 老写法是 [值, 文字] 数组，新写法可能是 {value,label}，两种都认
      const val = String(Array.isArray(o) ? o[0] : o.value);
      const lab = Array.isArray(o) ? o[1] : o.label;
      return `<option value="${esc(val)}"${String(v) === val ? ' selected' : ''}>${esc(lab)}</option>`;
    }).join('');
    input = `<select id="${id}" data-key="${esc(it.key)}" data-type="select">${opts}</select>`;
  } else if (it.type === 'text') {
    input = `<input type="text" id="${id}" data-key="${esc(it.key)}" data-type="text"
      value="${esc(v == null ? '' : v)}">`;
  } else if (it.type === 'intlist') {
    input = `<input type="text" id="${id}" data-key="${esc(it.key)}" data-type="intlist"
      placeholder="用逗号或空格分开" value="${esc((v || []).join(', '))}">`;
  } else if (it.type === 'sources') {
    return setSourcesHtml(it);
  } else {
    const attrs = [
      it.min != null ? `min="${it.min}"` : '',
      it.max != null ? `max="${it.max}"` : '',
      it.step != null ? `step="${it.step}"` : '',
    ].filter(Boolean).join(' ');
    input = `<input type="number" id="${id}" data-key="${esc(it.key)}" data-type="number"
      ${attrs} value="${esc(v)}">`;
  }
  return `<div class="set-row">${label}${input}
    <p class="set-hint">${esc(it.hint || '')}</p></div>`;
}

function setSourcesHtml(it) {
  const rows = (state.cfg.custom_sources || []).map((s, i) => `
    <div class="src-row">
      <input type="text" class="src-name" data-i="${i}" value="${esc(s.name || '')}" placeholder="名字">
      <input type="text" class="src-url" data-i="${i}" value="${esc(s.url || '')}" placeholder="RSS 或网页地址">
      <select class="src-cat" data-i="${i}">
        ${['科技', '科学', '国内', '国际', '财经', '游戏'].map((c) =>
          `<option value="${c}"${s.cat === c ? ' selected' : ''}>${c}</option>`).join('')}
      </select>
      <label class="chk"><input type="checkbox" class="src-en" data-i="${i}"${s.enabled !== false ? ' checked' : ''}> 启用</label>
      <button class="linkbtn src-del" data-i="${i}">删</button>
    </div>`).join('');
  return `<div class="set-row set-row-sources">
    ${label0(it)}
    ${rows}
    <button class="btn btn-ghost" id="btn-src-add">加一个源</button>
    <p class="set-hint">${esc(it.hint || '')}</p></div>`;
}

function label0(it) {
  return `<label class="set-label">${esc(it.label)}</label>`;
}

function collectCustomSources() {
  const out = [];
  const names = document.querySelectorAll('.src-name');
  const urls = document.querySelectorAll('.src-url');
  const cats = document.querySelectorAll('.src-cat');
  const ens = document.querySelectorAll('.src-en');
  for (let i = 0; i < urls.length; i++) {
    const url = (urls[i].value || '').trim();
    if (!url) continue;
    out.push({
      id: 'custom_' + (i + 1),
      name: (names[i] && names[i].value || '').trim() || ('自定义 ' + (i + 1)),
      url,
      cat: cats[i] ? cats[i].value : '科技',
      enabled: ens[i] ? ens[i].checked : true,
    });
  }
  return out;
}

function collectConfig() {
  const cfg = Object.assign({}, state.cfg);
  document.querySelectorAll('#set-body [data-key]').forEach((n) => {
    const k = n.dataset.key, t = n.dataset.type;
    if (t === 'bool') cfg[k] = n.checked;
    else if (t === 'number') cfg[k] = Number(n.value);
    else if (t === 'intlist') {
      // 只按逗号分 —— 关键词里带空格是常事（「DeepSeek 开源」是一个词，不是两个）
      cfg[k] = (n.value || '').split(/[,，]+/).map((s) => s.trim()).filter(Boolean);
    } else cfg[k] = n.value;
  });
  cfg.custom_sources = collectCustomSources();
  // 中文逗号统一成英文的
  Object.keys(cfg).forEach((k) => {
    if (typeof cfg[k] === 'string') cfg[k] = cfg[k].replace(/，/g, ',');
  });
  return cfg;
}

async function saveSettings() {
  const cfg = collectConfig();
  el.setMsg.textContent = '保存中…';
  try {
    const r = await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cfg),
    });
    const d = await r.json();
    if (!r.ok) {
      el.setMsg.textContent = d.msg || '保存失败';
      return;
    }
    state.cfg = d.config || cfg;
    el.setMsg.textContent = '已保存 ✓';
    await loadSearch();
    await loadMirrors();
    buildTabs(state.snap || {});
    setTimeout(() => { el.setMsg.textContent = ''; }, 2500);
  } catch (e) {
    el.setMsg.textContent = '保存失败：' + e.message;
  }
}

/* ───────────── 播放面板 ───────────── */

function openPlayer(v) {
  if (!v) return;
  el.plTitle.textContent = v.title || '（无标题）';
  el.plSrcLine.textContent = [
    v.up || '未知 UP',
    fmtClock(v.duration),
    v.view ? fmtNum(v.view) + ' 播放' : '',
    v.size ? (v.size / 1048576).toFixed(1) + ' MB' : '',
  ].filter(Boolean).join(' ・ ');

  el.plDesc.textContent = v.desc || '';
  el.plDesc.hidden = !v.desc;

  el.plOrigin.href = v.url || '#';
  el.plOrigin.hidden = !v.url;

  const cs = v.comments || [];
  el.plComments.innerHTML = cs.length
    ? '<h3 class="rd-h">热门评论</h3>' + cs.map((c) => `
        <div class="cmt">
          <div class="cmt-head"><b>${esc(c.user || '匿名')}</b>${
            c.like ? `<span class="dim">${fmtNum(c.like)} 赞</span>` : ''}</div>
          <p>${esc(c.text)}</p>
        </div>`).join('')
    : '<p class="dim pl-nocmt">这条没抓到评论。</p>';

  el.plVideo.src = '/' + v.file;
  el.player.showModal();
  if (window.EXTRA) EXTRA.setPlayerItem(v);
}

function closePlayer() {
  try { el.plVideo.pause(); } catch (e) { /* 忽略 */ }
  el.plVideo.removeAttribute('src');
  try { el.plVideo.load(); } catch (e) { /* 忽略 */ }
  if (window.EXTRA) EXTRA.onPlayerClose();
  el.player.close();
}

function renderSourceLine(snap) {
  const stats = snap.source_stats || [];
  const ok = stats.filter((s) => s.ok);
  const bad = stats.filter((s) => !s.ok);
  let txt = `有效源 ${ok.length}/${stats.length}`;
  if (bad.length) txt += ` ・ 挂了：${bad.map((s) => s.name).join('、')}`;
  txt += ` ・ 抓取耗时 ${snap.duration_sec ?? '-'} 秒`;
  el.sourceLine.textContent = txt;
}

/* ───────────── 本地阅读面板 ───────────── */

function blockHtml(b) {
  if (b.t === 'img') {
    return b.v
      ? `<figure class="rd-fig"><img src="/${esc(b.v)}" alt="" loading="lazy"></figure>`
      : '';
  }
  if (b.t === 'h') return `<h3 class="rd-h">${esc(b.v)}</h3>`;
  return `<p>${esc(b.v)}</p>`;
}

function openReader(it) {
  if (!it) return;
  if (window.EXTRA && EXTRA.wantsMirror(it)) { EXTRA.openMirror(it); return; }
  el.rdTitle.textContent = it.title || '（无标题）';
  el.rdCat.textContent = it.category || '';
  el.rdCat.className = 'cat-chip cat-' + (it.category || '');
  const when = it.published || (it.published_ts ? fmtAbs(it.published_ts) : '');
  el.rdSrcLine.textContent = [it.source, when].filter(Boolean).join(' ・ ');

  if (it.url) {
    el.rdOrigin.href = it.url;
    el.rdOrigin.hidden = false;
  } else {
    el.rdOrigin.hidden = true;
  }

  const body = (it.content || []).map(blockHtml).join('');
  if (body.trim()) {
    el.rdContent.innerHTML = body;
  } else {
    const s = it.summary
      ? `<p>${esc(it.summary)}</p>`
      : '<p class="dim">这篇源站只给了这么点。</p>';
    el.rdContent.innerHTML = s
      + '<p class="rd-note dim">（本地没存正文，想看全文得联网点右上角「原文」）</p>';
  }

  el.reader.showModal();
  el.rdContent.parentElement.scrollTop = 0;
  if (window.EXTRA) EXTRA.setReaderItem(it);
}

/* ───────────── 历史快照 ───────────── */

async function loadSnapshotList() {
  try {
    const r = await fetch('/api/snapshots', { cache: 'no-store' });
    const d = await r.json();
    const rows = d.snapshots || [];
    const cur = el.snapSelect.value;
    el.snapSelect.innerHTML = '<option value="">最新</option>' +
      rows.map((s) => `<option value="${esc(s.id)}">${esc(s.generated_at)}（${s.total} 条）</option>`).join('');
    el.snapSelect.value = cur;
  } catch (e) { /* 忽略 */ }
}

/* ───────────── 事件 ───────────── */

el.search.addEventListener('input', () => {
  state.q = el.search.value.trim();
  render();
});

el.onlyNew.addEventListener('change', () => {
  state.onlyNew = el.onlyNew.checked;
  render();
});

el.snapSelect.addEventListener('change', () => {
  loadNews(el.snapSelect.value);
});

el.btnFetch.addEventListener('click', async () => {
  el.btnFetch.disabled = true;
  try {
    const r = await fetch('/api/fetch', { method: 'POST' });
    const d = await r.json();
    el.countdownText.textContent = d.msg || '已排队';
  } catch (e) {
    el.countdownText.textContent = '请求失败：' + e.message;
  }
  setTimeout(pollStatus, 800);
});

el.btnLog.addEventListener('click', async () => {
  el.logBody.textContent = '载入中…';
  el.logDialog.showModal();
  try {
    const r = await fetch('/api/log?n=200', { cache: 'no-store' });
    el.logBody.textContent = await r.text();
    el.logBody.scrollTop = el.logBody.scrollHeight;
  } catch (e) {
    el.logBody.textContent = '读日志失败：' + e.message;
  }
});
el.btnLogClose.addEventListener('click', () => el.logDialog.close());

// 点卡片 → 新闻开本地阅读面板，视频开播放面板，镜像开扒下来的本地页面（都不跳原网页）
function openCard(card) {
  if (!card) return;
  const item = state.view[Number(card.dataset.i)];
  if (card.classList.contains('vcard')) openPlayer(item);
  else if (card.classList.contains('mcard')) window.open(mirrorUrlOf(item), '_blank');
  else openReader(item);
}

el.grid.addEventListener('click', (e) => {
  const del = e.target.closest('.mdel');
  if (del) { e.stopPropagation(); mirrorDelete(del.dataset.del); return; }
  const go = e.target.closest('#btn-mirror-go');
  if (go) { mirrorGo(); return; }
  const sgo = e.target.closest('#btn-search-go');
  if (sgo) { searchGo(); return; }
  openCard(e.target.closest('.card'));
});

// 自定义源的增删：设置面板不在 #grid 里，得单独挂
function rebuildSources() {
  const g = (state.schema || []).find((x) => (x.items || []).some((y) => y.type === 'sources'));
  const box = g && g.items.find((y) => y.type === 'sources');
  const row = document.querySelector('.set-row-sources');
  if (box && row) row.outerHTML = setSourcesHtml(box);
}

el.setBody.addEventListener('click', (e) => {
  if (e.target.closest('#btn-src-add')) {
    state.cfg.custom_sources = collectCustomSources();
    state.cfg.custom_sources.push({ id: '', name: '', url: '', cat: '科技', enabled: true });
    rebuildSources();
    return;
  }
  const del = e.target.closest('.src-del');
  if (del) {
    const i = Number(del.dataset.i);
    state.cfg.custom_sources = collectCustomSources();
    state.cfg.custom_sources.splice(i, 1);
    rebuildSources();
  }
});
el.grid.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const card = e.target.closest('.card');
  if (!card) return;
  e.preventDefault();
  openCard(card);
});
el.btnReaderClose.addEventListener('click', () => {
  if (window.EXTRA) EXTRA.onReaderClose();
  el.reader.close();
});
// 按 Esc 关的时候也得算「看完」
el.reader.addEventListener('close', () => {
  if (window.EXTRA) EXTRA.onReaderClose();
});
el.btnPlayerClose.addEventListener('click', closePlayer);
el.player.addEventListener('close', () => {
  try { el.plVideo.pause(); } catch (e) { /* 忽略 */ }
  if (window.EXTRA) EXTRA.onPlayerClose();
});

el.btnSettings.addEventListener('click', openSettings);
el.btnSettingsClose.addEventListener('click', () => el.settings.close());
el.btnSettingsSave.addEventListener('click', saveSettings);
el.btnSettingsReset.addEventListener('click', async () => {
  if (!state.cfg) return;
  state.cfg = Object.assign({}, state.defaults || {});
  await openSettingsRebuild();
});
async function openSettingsRebuild() {
  el.setBody.innerHTML = state.schema
    .filter((g) => !g.admin)
    .map(setGroupHtml).join('');
}

/* ───────────── 启动 ───────────── */

(async function boot() {
  if (window.EXTRA) { try { await EXTRA.boot(); } catch (e) { /* 忽略 */ } }
  await pollStatus();
  await loadVideos();
  await loadSearch();
  await loadMirrors();
  await loadNews();
  await loadSnapshotList();
  setInterval(pollStatus, 1000);       // 状态每秒刷
  setInterval(() => {
    // 后端抓完新的会自动更新 latest，这里定期跟一下
    if (state.status && state.status.snapshot_id !== (state.snap && state.snap.id)
        && !el.snapSelect.value) {
      loadNews();
      loadSnapshotList();
    }
  }, 10000);
  setInterval(async () => {
    // 视频、搜索结果也是一轮一轮抓的，跟着刷一下
    await loadVideos();
    await loadSearch();
    if (state.cat === VIDEO_TAB || state.cat === SEARCH_TAB) render();
    else buildTabs(state.snap || {});
  }, 60000);
  setInterval(async () => {
    // 镜像有后台任务在跑，勤看着点
    const job = (state.mirrors && state.mirrors.job) || {};
    if (job.state !== 'running' && state.cat !== MIRROR_TAB) return;
    await loadMirrors();
    if (state.cat === MIRROR_TAB) render();
  }, 3000);
  setInterval(() => {
    if (state.status && state.status.last_fetch_ts) renderStatus(state.status);
  }, 1000);
})();
