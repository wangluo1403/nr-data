// 对唱 / 间奏三个点 —— 逻辑来自 MeiloX（NEORUAA/MeiloX），翻译成 JS
// DuetDetector.kt  → detectDuet / applyDuet
// PlayerLyricsView.kt → interludeState（间奏判定 + 开头三个点）
(function (global) {
  'use strict';

  var ROLE_PREFIX_RE = /^\[\d+:\d+(?:\.\d+)?\]\s*(?:【([^】]+)】|(\S{1,8})[：:])\s*/;
  var STANDALONE_RE = /^\[(\d+):(\d+(?:\.\d+)?)\]\s*([A-Za-z0-9]+)[:：]\s*$/;
  var TS_RE = /^\[(\d+):(\d+(?:\.\d+)?)\]/;
  var MARKER_ONLY_RE = /^[A-Za-z0-9]+[:：]\s*$/;
  var CREDIT_SEP_RE = /[/／&＆+、]/;
  var WORD_CHAR_RE = /[A-Za-z0-9]/;

  var CREDIT_LABELS = {};
  ('词 曲 词曲 作词 填词 作曲 编曲 演唱 原唱 翻唱 制作 制作人 监制 录音 录制 混音 母带 ' +
   '和声 和声编写 吉他 贝斯 钢琴 鼓 弦乐 绘图 题字 出品 发行 版权 ' +
   'lyric lyrics lyricist words writtenby songwriter music composer composition ' +
   'arranger arrangement arrangedby vocal vocals singer sungby producer producedby ' +
   'recording recordedby mix mixing mixedby mastering masteredby')
    .split(/\s+/).forEach(function (w) { if (w) CREDIT_LABELS[w] = 1; });

  function singerRole(label) {
    var role = String(label || '').trim().toLowerCase();
    if (!role) return '';
    var parts = role.split(CREDIT_SEP_RE).filter(function (x) { return x !== ''; });
    var allCredit = parts.length > 0;
    for (var i = 0; i < parts.length; i++) {
      if (!CREDIT_LABELS[parts[i].replace(/\s+/g, '')]) { allCredit = false; break; }
    }
    return allCredit ? '' : role;
  }

  function extractTimestampMs(line) {
    var m = TS_RE.exec(String(line || '').trim());
    if (!m) return null;
    return parseInt(m[1], 10) * 60000 + Math.round(parseFloat(m[2]) * 1000);
  }

  function prefixRole(line) {
    var m = ROLE_PREFIX_RE.exec(String(line || '').trim());
    if (!m) return null;
    var label = (m[1] || '').trim() || (m[2] || '').trim();
    return singerRole(label) || null;
  }

  // 整行只有角色的写法：[00:12.00] A:
  function hasStandaloneRoles(rows) {
    var roles = {};
    var n = 0;
    for (var i = 0; i < rows.length; i++) {
      var m = STANDALONE_RE.exec(rows[i].trim());
      if (!m) continue;
      var role = singerRole(m[3]);
      if (!role) continue;
      var ts = parseInt(m[1], 10) * 60000 + Math.round(parseFloat(m[2]) * 1000);
      if (i + 1 < rows.length) {
        var next = extractTimestampMs(rows[i + 1]);
        if (next != null && next - ts <= 1000) {
          if (!roles[role]) { roles[role] = 1; n++; }
        }
      }
    }
    return n >= 2;
  }

  function hasRolePrefixes(rows) {
    var roles = {};
    var n = 0;
    for (var i = 0; i < rows.length; i++) {
      var r = prefixRole(rows[i]);
      if (r && !roles[r]) { roles[r] = 1; n++; }
    }
    return n >= 2;
  }

  function detectStandaloneSegments(rows) {
    var segments = [];
    var curRole = '', curStart = -1;
    for (var i = 0; i < rows.length; i++) {
      var m = STANDALONE_RE.exec(rows[i].trim());
      if (!m) continue;
      var role = singerRole(m[3]);
      if (!role) continue;
      var ts = parseInt(m[1], 10) * 60000 + Math.round(parseFloat(m[2]) * 1000);
      var next = i + 1 < rows.length ? extractTimestampMs(rows[i + 1]) : null;
      var nextIsLyric = next != null && next - ts >= 1 && next - ts <= 1000;
      if (nextIsLyric && role.length >= 1 && role.length <= 15 && WORD_CHAR_RE.test(role)) {
        if (curRole && curStart >= 0) segments.push({ role: curRole, startLine: curStart });
        curRole = role;
        curStart = i;
      }
    }
    if (curRole && curStart >= 0) segments.push({ role: curRole, startLine: curStart });
    return segments.length >= 2 ? segments : null;
  }

  function detectPrefixSegments(rows) {
    var segments = [];
    var curRole = null, curStart = -1;
    for (var i = 0; i < rows.length; i++) {
      var role = prefixRole(rows[i]);
      if (!role) continue;
      if (curRole != null && curRole !== role && curStart >= 0) {
        segments.push({ role: curRole, startLine: curStart });
      }
      if (curRole == null || curRole !== role) curStart = i;
      curRole = role;
    }
    if (curRole != null && curStart >= 0) segments.push({ role: curRole, startLine: curStart });
    return segments.length >= 2 ? segments : null;
  }

  function detectDuet(rawLrc) {
    var rows = String(rawLrc || '').split(/\r?\n/);
    var segs = null;
    if (hasStandaloneRoles(rows)) segs = detectStandaloneSegments(rows);
    if (!segs && hasRolePrefixes(rows)) segs = detectPrefixSegments(rows);
    if (!segs) return null;
    var out = [];
    for (var i = 0; i < segs.length; i++) {
      var ms = extractTimestampMs(rows[segs[i].startLine] || '');
      if (ms == null) return null;
      out.push({ role: segs[i].role, startMs: ms });
    }
    return out.length >= 2 ? out : null;
  }

  // 第一个唱歌的靠左，第二个靠右，之后按角色固定
  function applyDuet(lines, segs) {
    if (!segs || !segs.length) return lines;
    var align = {};
    var last = 'r';
    for (var i = 0; i < segs.length; i++) {
      var name = segs[i].role;
      if (!align[name]) {
        last = (last === 'l') ? 'r' : 'l';
        align[name] = last;
      }
    }
    for (var j = 0; j < lines.length; j++) {
      var side = '';
      var tMs = Math.round(lines[j].t * 1000);
      for (var k = segs.length - 1; k >= 0; k--) {
        if (tMs >= segs[k].startMs) { side = align[segs[k].role] || ''; break; }
      }
      lines[j].side = side;
    }
    return lines;
  }

  // 间奏：上一句唱完后空了 5 秒以上，这段时间显示三个点
  // MeiloX 用卡拉OK的真实结束时间，LRC 只有开始时间，所以按字数估一下这句唱了多久
  function lineEnd(line) {
    var text = String(line.text || '');
    var guess = Math.max(1.2, text.length * 0.38);
    return line.t + guess;
  }

  function interludeState(lines, duration, time) {
    var out = { interlude: false, intro: false, from: 0, to: 0 };
    if (!lines || !lines.length) return out;
    for (var i = 0; i < lines.length; i++) {
      var prev = lines[i - 1];
      if (!prev) continue;
      var prevEnd = lineEnd(prev);
      var start = lines[i].t;
      if (start - prevEnd > 5 && time >= prevEnd && time <= start) {
        out.interlude = true;
        out.from = prevEnd;
        out.to = start;
        return out;
      }
    }
    // 开头到第一句之前
    var first = lines[0].t;
    if (first >= 5 && time >= 0 && time < first) {
      out.intro = true;
      out.from = 0;
      out.to = first;
    }
    return out;
  }

  global.MEILOX = {
    detectDuet: detectDuet,
    applyDuet: applyDuet,
    interludeState: interludeState,
    singerRole: singerRole,
    extractTimestampMs: extractTimestampMs,
    hasStandaloneRoles: hasStandaloneRoles,
    hasRolePrefixes: hasRolePrefixes,
    MARKER_ONLY_RE: MARKER_ONLY_RE,
    CREDIT_LABELS: CREDIT_LABELS
  };
})(window);
