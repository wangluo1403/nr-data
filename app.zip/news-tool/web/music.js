/* ============================================================
   music.js — 点歌台（离线音乐播放器）
   ------------------------------------------------------------
   对外只暴露 window.MusicUI：
     MusicUI.mount(container)  把界面画进空的 container
     MusicUI.unmount()         停止播放、清定时器、拆监听

   纯原生 JS，无模块、无网络依赖；数据来自 /api/music。
   ============================================================ */
(function () {
  'use strict';

  if (window.MusicUI && typeof window.MusicUI.mount === 'function') return;

  var API_URL = '/api/music';
  var REFRESH_MS = 60000;

  var API_PLAYLIST = '/api/playlist';
  var API_NM_USER = '/api/netease/user';
  var API_NM_PLAYLISTS = '/api/netease/playlists';
  var API_NM_PLSEARCH = '/api/netease/plsearch';
  var API_NM_RECENT = '/api/netease/recent';
  var API_NM_TRACKS = '/api/netease/playlist/tracks';
  var API_MUSIC_DL = '/api/music/download';
  var API_MUSIC_RELRC = '/api/music/relrc';
  var API_WISH = '/api/wish';
  var POLL_FAST_MS = 1500;
  var POLL_SLOW_MS = 5000;
  var WISH_FAST_MS = 2000;
  var WISH_SLOW_MS = 10000;
  var SEARCH_DEBOUNCE_MS = 400;

  var LS_VOL = 'mu.volume';
  var LS_REPEAT = 'mu.repeat';
  var LS_FAVS = 'mu.favs';
  var LS_POS = 'mu.pos';
  var LS_VIEW = 'mu.view';
  var LS_NPLAYOUT = 'mu.npLayout';

  var VIEWS = [
    { key: 'discover', label: '发现音乐', icon: 'compass' },
    { key: 'all', label: '全部歌曲', icon: 'list' },
    { key: 'recent', label: '最近下载', icon: 'download' },
    { key: 'fav', label: '我的收藏', icon: 'heart' },
    { key: 'plaza', label: '歌单广场', icon: 'globe' }
  ];

  var REPEAT_LABEL = {
    list: '列表循环',
    one: '单曲循环',
    shuffle: '随机播放'
  };

  /* ------------------------------------------------------------
     图标：全部内联 SVG，断网也能显示
     ------------------------------------------------------------ */
  var ICONS = {
    note: '<path d="M9 17.5V6.3l9-1.8v10.4"/><circle cx="6.4" cy="18" r="2.6"/><circle cx="15.4" cy="15.4" r="2.6"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.6 8.4l-2.1 5.1-5.1 2.1 2.1-5.1z"/>',
    list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.2" cy="6" r="1.1" fill="currentColor" stroke="none"/><circle cx="4.2" cy="12" r="1.1" fill="currentColor" stroke="none"/><circle cx="4.2" cy="18" r="1.1" fill="currentColor" stroke="none"/>',
    download: '<path d="M12 3.5v10M8 10l4 4 4-4M4.5 17.5v2h15v-2"/>',
    heart: '<path d="M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.7a4.1 4.1 0 0 1 7.5 2.9C19.5 15.6 12 20 12 20z"/>',
    heartFill: '<path d="M12 20s-7.5-4.4-7.5-9.4A4.1 4.1 0 0 1 12 7.7a4.1 4.1 0 0 1 7.5 2.9C19.5 15.6 12 20 12 20z" fill="currentColor" stroke="currentColor"/>',
    play: '<path d="M8 5.5v13l11-6.5z" fill="currentColor" stroke="none"/>',
    pause: '<path d="M8 5.5h3v13H8zM13 5.5h3v13h-3z" fill="currentColor" stroke="none"/>',
    prev: '<path d="M18.5 6v12L9.5 12z" fill="currentColor" stroke="none"/><path d="M6 5.5v13"/>',
    next: '<path d="M5.5 6v12l9-6z" fill="currentColor" stroke="none"/><path d="M18 5.5v13"/>',
    repeat: '<path d="M17 3.5l3 3-3 3"/><path d="M20 6.5H7a3.5 3.5 0 0 0-3.5 3.5v1"/><path d="M7 20.5l-3-3 3-3"/><path d="M4 17.5h13a3.5 3.5 0 0 0 3.5-3.5v-1"/>',
    repeatOne: '<path d="M17 3.5l3 3-3 3"/><path d="M20 6.5H7a3.5 3.5 0 0 0-3.5 3.5v1"/><path d="M7 20.5l-3-3 3-3"/><path d="M4 17.5h13a3.5 3.5 0 0 0 3.5-3.5v-1"/><path d="M11.4 10.2l1.4-.9v5.4"/>',
    shuffle: '<path d="M3.5 6.5h3.2c1.4 0 2.6.7 3.4 2l3 5.4c.8 1.4 2 2.1 3.4 2.1h3.8"/><path d="M17.6 3.5l3 3-3 3"/><path d="M3.5 17.5h3.2c1.4 0 2.6-.7 3.4-2l3-5.4c.8-1.4 2-2.1 3.4-2.1h3.8"/><path d="M17.6 13.5l3 3-3 3"/>',
    volume: '<path d="M4 9.5h3l5-3.5v12l-5-3.5H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.6 7.6 0 0 1 0 11"/>',
    mute: '<path d="M4 9.5h3l5-3.5v12l-5-3.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.4 15.4L20 20"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4.5V9h-4.5"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3.2 9h17.6M3.2 15h17.6"/><ellipse cx="12" cy="12" rx="4.2" ry="9"/>',
    disc: '<circle cx="12" cy="12" r="8.6"/><circle cx="12" cy="12" r="2.3"/><path d="M12 3.4a8.6 8.6 0 0 1 6.1 2.6"/>',
    check: '<path d="M5 12.6l4.4 4.4L19 7.2"/>',
    alert: '<path d="M12 4.6l8.4 14.8H3.6z"/><path d="M12 10v3.4"/><circle cx="12" cy="16.6" r=".85" fill="currentColor" stroke="none"/>',
    fsCollapse: '<path d="M9 4.5v5H4M15 19.5v-5h5M4.5 15h5v5M19.5 9h-5V4"/>',
    fsExpand: '<path d="M4.5 9h5V4M19.5 15h-5v5M9 19.5v-5H4M15 4.5v5h5"/>',
    chevronDown: '<path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z" fill="currentColor" stroke="none"/>',
    chevronLeft: '<path d="M15 5l-7 7 7 7"/>',
    sliders: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2.2"/><circle cx="10" cy="17" r="2.2"/>',
    quote: '<path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z" fill="currentColor" stroke="none"/>',
    npPrev: '<path d="M21.5 5v14L12 12zM13 5v14l-9.5-7z" fill="currentColor" stroke="none"/>',
    npNext: '<path d="M2.5 5v14L12 12zM11 5v14l9.5-7z" fill="currentColor" stroke="none"/>',
    npPlay: '<path d="M6 4.5v15L19 12z" fill="currentColor" stroke="none"/>',
    npPause: '<path d="M6.5 4.5h4v15h-4zM13.5 4.5h4v15h-4z" fill="currentColor" stroke="none"/>',
    volLow: '<path d="M3 9v6h4l5 5V4L7 9H3z" fill="currentColor" stroke="none"/>',
    volHigh: '<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 7.97v8.05A4.47 4.47 0 0 0 16.5 12zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" fill="currentColor" stroke="none"/>'
  };

  function svg(name, extraClass) {
    var body = ICONS[name] || '';
    return '<svg class="mu-ico' + (extraClass ? ' ' + extraClass : '') +
      '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  /* ------------------------------------------------------------
     小工具
     ------------------------------------------------------------ */
  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function pad2(n) {
    return (n < 10 ? '0' : '') + n;
  }

  function fmtTime(sec) {
    var s = Number(sec);
    if (!isFinite(s) || s < 0) return '00:00';
    s = Math.floor(s);
    var m = Math.floor(s / 60);
    var r = s % 60;
    return pad2(m) + ':' + pad2(r);
  }

  function fmtSize(bytes) {
    var n = Number(bytes);
    if (!isFinite(n) || n <= 0) return '0 MB';
    var mb = n / 1048576;
    if (mb >= 1024) return (mb / 1024).toFixed(2) + ' GB';
    if (mb >= 100) return Math.round(mb) + ' MB';
    return mb.toFixed(1) + ' MB';
  }

  function normalizePath(p) {
    return String(p == null ? '' : p).replace(/^\/+/, '');
  }

  function pathURL(p) {
    var clean = normalizePath(p);
    if (!clean) return '';
    return '/' + clean.split('/').filter(function (x) { return x !== ''; })
      .map(encodeURIComponent).join('/');
  }

  function readLS(key, fallback) {
    try {
      var raw = window.localStorage.getItem(key);
      if (raw == null) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  }

  function writeLS(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (e) { /* 隐私模式 / 配额满了，忽略 */ }
  }

  function loadVolume() {
    var v = Number(readLS(LS_VOL, 0.8));
    if (!isFinite(v)) v = 0.8;
    return Math.min(1, Math.max(0, v));
  }

  function loadRepeat() {
    var r = readLS(LS_REPEAT, 'list');
    return REPEAT_LABEL[r] ? r : 'list';
  }

  function loadFavs() {
    var arr = readLS(LS_FAVS, []);
    if (!Array.isArray(arr)) return [];
    return arr.filter(function (x) { return typeof x === 'string'; });
  }

  function loadPos() {
    var p = readLS(LS_POS, null);
    if (!p || typeof p !== 'object' || !p.id) return null;
    var t = Number(p.t);
    return { id: String(p.id), t: isFinite(t) && t > 0 ? t : 0 };
  }

  function loadView() {
    var v = readLS(LS_VIEW, 'discover');
    for (var i = 0; i < VIEWS.length; i++) {
      if (VIEWS[i].key === v) return v;
    }
    return 'discover';
  }

  function loadNpLayout() {
    var v = readLS(LS_NPLAYOUT, 'cover');
    if (v === 'lyrics' || v === 'split' || v === 'cover') return v;
    return 'cover';
  }

  function chartName(item) {
    return (item && item.chart) ? String(item.chart) : '本地曲库';
  }

  function artistOf(item) {
    return (item && item.artist) ? String(item.artist) : '未知歌手';
  }

  function durationOf(item) {
    var d = Number(item && item.duration_s);
    return isFinite(d) && d > 0 ? d : 0;
  }

  function coverMarkup(item, cls) {
    var title = item && item.title ? String(item.title).trim() : '';
    var initial = '';
    if (title) {
      var cp = title.codePointAt(0);
      initial = String.fromCodePoint(cp).toUpperCase();
    }
    var ph = '<span class="mu-cov-ph">' + svg('note') + '<i>' + esc(initial || '?') + '</i></span>';
    var url = item && item.cover ? pathURL(item.cover) : '';
    var img = url ? '<img class="mu-cov-img" src="' + esc(url) + '" alt="" loading="lazy" draggable="false">' : '';
    return '<span class="mu-cov' + (cls ? ' ' + cls : '') + '">' + ph + img + '</span>';
  }

  function eqMarkup() {
    return '<span class="mu-eq"><i></i><i></i><i></i></span>';
  }

  // 网络图片（网易云头像 / 歌单封面）——本地曲库的 cover 走 pathURL，这里不能走
  function remoteCover(url, label, cls) {
    var raw = String(url == null ? '' : url);
    var title = String(label == null ? '' : label).trim();
    var initial = '';
    if (title) initial = String.fromCodePoint(title.codePointAt(0)).toUpperCase();
    var ph = '<span class="mu-cov-ph">' + svg('note') + '<i>' + esc(initial || '?') + '</i></span>';
    var img = /^https?:\/\//i.test(raw)
      ? '<img class="mu-cov-img" src="' + esc(raw) + '" alt="" loading="lazy" draggable="false" referrerpolicy="no-referrer">'
      : '';
    return '<span class="mu-cov' + (cls ? ' ' + cls : '') + '">' + ph + img + '</span>';
  }

  function fmtPlayCount(n) {
    var v = Number(n);
    if (!isFinite(v) || v <= 0) return '0 次播放';
    if (v >= 100000000) return (v / 100000000).toFixed(1) + ' 亿次播放';
    if (v >= 10000) return (v / 10000).toFixed(1) + ' 万次播放';
    return Math.round(v) + ' 次播放';
  }

  function emptyMarkup(title, hint, retry) {
    return '<div class="mu-empty">' +
      '<div class="mu-empty-ico">' + svg('note') + '</div>' +
      '<p class="mu-empty-title">' + esc(title) + '</p>' +
      '<p class="mu-empty-hint">' + esc(hint) + '</p>' +
      (retry ? '<button type="button" class="mu-btn" data-act="reload">' + svg('refresh') + '重新读取</button>' : '') +
      '</div>';
  }

  function loadingMarkup(text) {
    return '<div class="mu-loading"><span class="mu-spinner"></span>' + esc(text) + '</div>';
  }

  /* ------------------------------------------------------------
     模块状态
     ------------------------------------------------------------ */
  var mounted = false;
  var host = null;
  var root = null;
  var refs = {};
  var audio = null;
  var st = null;
  var refreshTimer = null;
  var toastTimer = null;
  var keyHandler = null;
  var resizeHandler = null;
  var hideHandler = null;
  var resizeObserver = null;
  var seeking = false;
  var lastPosSave = 0;

  // 我的歌单 / 歌单广场 / 离线点歌
  var pollTimer = null;
  var wishTimer = null;
  var libReloadTimer = null;
  var debounceTimer = null;
  var visHandler = null;
  var mineRefs = {};
  var wishRefs = {};
  var plSeq = 0;
  var nmUserSeq = 0;
  var nmPlSeq = 0;
  var nmPlSearchSeq = 0;
  var wishSeq = 0;
  var recentSeq = 0;

  // 全屏 Now Playing
  var lyrOpen = false;
  var npLayout = 'cover';
  var lyrData = { synced: false, lines: [] };
  var npActive = -1;
  var npManual = false;
  var npManualTimer = null;
  var npSettleTimer = null;
  var npCloseTimer = null;
  var npAnimId = 0;
  var npFrameH = [];
  var npMeasuredW = -1;
  var npDragRatio = null;
  var npVolDrag = false;
  var npColorSeq = 0;
  var npBg = 'rgb(30, 30, 32)';
  // 逐字高亮
  var npKaraokeId = 0;
  var npLitLine = -1;
  var npLitCount = -1;

  function createState() {
    var savedPos = loadPos();
    return {
      items: [],
      byId: {},
      loading: true,
      error: '',
      view: loadView(),
      query: '',
      favs: {},
      newIds: {},
      known: {},
      generated: '',
      totalBytes: 0,
      currentId: null,
      current: null,
      queue: [],
      visibleIds: [],
      repeat: loadRepeat(),
      volume: loadVolume(),
      muted: false,
      savedPos: savedPos,
      restoreTo: null,
      pendingPlay: null,
      bad: {},
      firstLoadDone: false,
      plItems: [],
      plByPid: {},
      plError: '',
      plLoaded: false,
      // 点开的歌单曲目缓存：pid -> {items, loading, loaded, error, offline, cached_at, total, queued}
      plTracks: {},
      tracksPid: '',
      tracksPoll: 0,
      plaza: {
        q: '',
        searched: '',
        users: [],
        usersLoading: false,
        usersError: '',
        usersOffline: false,
        usersCachedAt: '',
        searchError: '',
        plSearch: [],
        plSearchLoading: false,
        plSearchError: '',
        plSearchErrMsg: '',
        plSearchOffline: false,
        plSearchCachedAt: '',
        selectedUid: '',
        pls: [],
        plsLoading: false,
        plsError: '',
        plsOffline: false,
        plsCachedAt: '',
        adding: {},
        queued: {},
        recent: null,
        recentLoading: false,
        recentTried: false
      },
      wish: {
        items: [],
        loading: false,
        error: '',
        online: true,
        adding: false,
        loaded: false
      }
    };
  }

  function isFav(id) {
    return !!st.favs[id];
  }

  function persistFavs() {
    writeLS(LS_FAVS, Object.keys(st.favs));
  }

  /* ------------------------------------------------------------
     骨架
     ------------------------------------------------------------ */
  function shellHTML() {
    return '' +
      '<aside class="mu-side">' +
        '<div class="mu-brand">' +
          '<span class="mu-brand-mark">' + svg('note') + '</span>' +
          '<span class="mu-brand-txt"><b>点歌台</b><small>离线音乐</small></span>' +
        '</div>' +
        '<nav class="mu-nav" id="mu-nav"></nav>' +
        '<div class="mu-mine" id="mu-mine">' +
          '<div class="mu-mine-head">' +
            '<span>我的歌单</span>' +
            '<button type="button" class="mu-mine-add" data-act="go-plaza" title="去歌单广场找歌单">' + svg('plus') + '</button>' +
          '</div>' +
          '<div class="mu-mine-list" id="mu-mine-list"></div>' +
        '</div>' +
        '<div class="mu-side-foot">' +
          '<div class="mu-side-stat" id="mu-side-stat">正在读取本地曲库…</div>' +
          '<div class="mu-side-time" id="mu-side-time"></div>' +
        '</div>' +
      '</aside>' +

      '<section class="mu-stage">' +
        '<header class="mu-head">' +
          '<div class="mu-search">' + svg('search') +
            '<input id="mu-search" type="search" placeholder="搜索歌名 / 歌手 / 专辑" autocomplete="off" spellcheck="false" aria-label="搜索歌曲">' +
            '<button type="button" class="mu-search-clear" id="mu-search-clear" title="清空搜索" aria-label="清空搜索" hidden>' + svg('close') + '</button>' +
          '</div>' +
          '<div class="mu-head-right">' +
            '<button type="button" class="mu-fs-toggle" id="mu-fs-toggle" title="收起全屏">' +
              '<span class="mu-fs-ico" id="mu-fs-ico"></span><span id="mu-fs-label">收起全屏</span>' +
            '</button>' +
            '<span class="mu-updated" id="mu-updated"></span>' +
            '<button type="button" class="mu-icon-btn" id="mu-refresh" title="重新读取歌单">' + svg('refresh') + '</button>' +
          '</div>' +
        '</header>' +
        '<div class="mu-content" id="mu-content" tabindex="-1"></div>' +
      '</section>' +

      '<div class="mu-player" id="mu-player">' +
        '<div class="mu-pl-left">' +
          '<div class="mu-disc" id="mu-disc" role="button" tabindex="0" title="看全屏歌词" aria-label="看全屏歌词"><div class="mu-disc-inner" id="mu-disc-inner"></div><span class="mu-disc-pin"></span></div>' +
          '<div class="mu-meta">' +
            '<div class="mu-meta-title" id="mu-now-title">还没有选歌</div>' +
            '<div class="mu-meta-sub" id="mu-now-sub">点一首歌开始听</div>' +
          '</div>' +
          '<button type="button" class="mu-icon-btn mu-heart-btn" id="mu-now-fav" title="收藏">' + svg('heart') + '</button>' +
        '</div>' +
        '<div class="mu-pl-center">' +
          '<div class="mu-ctrls">' +
            '<button type="button" class="mu-icon-btn mu-skip-btn" id="mu-prev" title="上一首">' + svg('npPrev') + '</button>' +
            '<button type="button" class="mu-play-btn" id="mu-play" title="播放 / 暂停">' + svg('npPlay') + '</button>' +
            '<button type="button" class="mu-icon-btn mu-skip-btn" id="mu-next" title="下一首">' + svg('npNext') + '</button>' +
          '</div>' +
          '<div class="mu-progress">' +
            '<span class="mu-time" id="mu-cur">00:00</span>' +
            '<input class="mu-range mu-range-seek" id="mu-seek" type="range" min="0" max="100" step="0.1" value="0" aria-label="播放进度">' +
            '<span class="mu-time" id="mu-dur">00:00</span>' +
          '</div>' +
        '</div>' +
        '<div class="mu-pl-right">' +
          '<button type="button" class="mu-icon-btn" id="mu-mode" title="列表循环">' + svg('repeat') + '</button>' +
          '<button type="button" class="mu-icon-btn" id="mu-vol" title="静音">' + svg('volume') + '</button>' +
          '<input class="mu-range mu-range-vol" id="mu-volume" type="range" min="0" max="100" step="1" value="80" aria-label="音量">' +
        '</div>' +
      '</div>' +

      '<div class="mu-lyr" id="mu-lyr" hidden aria-hidden="true">' +
        '<div class="mu-np-bg" id="mu-lyr-bg"></div>' +
        '<img class="mu-np-blur" id="mu-lyr-blur" alt="" aria-hidden="true">' +
        '<div class="mu-np-scrim"></div>' +

        '<header class="mu-np-top">' +
          '<button type="button" class="mu-np-round" id="mu-lyr-close" title="收起">' + svg('chevronDown') + '</button>' +
          '<div class="mu-np-top-right">' +
            '<button type="button" class="mu-np-round mu-np-heart" id="mu-lyr-fav" title="收藏">' + svg('heart') + '</button>' +
            '<button type="button" class="mu-np-round mu-np-setup" id="mu-np-setup" title="播放页布局" aria-haspopup="true" aria-expanded="false">' + svg('sliders') + '</button>' +
            '<button type="button" class="mu-np-round mu-np-lyricbtn" id="mu-lyr-toggle" title="歌词" aria-pressed="false">' + svg('quote') + '</button>' +
          '</div>' +
          '<div class="mu-np-menu" id="mu-np-menu" hidden role="menu" aria-label="播放页布局">' +
            '<div class="mu-np-menu-title">播放页布局</div>' +
            '<button type="button" class="mu-np-menu-item" data-layout="cover" role="menuitemradio" aria-checked="false">' +
              svg('check', 'mu-np-check') + '<span>封面</span>' +
            '</button>' +
            '<button type="button" class="mu-np-menu-item" data-layout="lyrics" role="menuitemradio" aria-checked="false">' +
              svg('check', 'mu-np-check') + '<span>歌词</span>' +
            '</button>' +
            '<button type="button" class="mu-np-menu-item" data-layout="split" role="menuitemradio" aria-checked="false">' +
              svg('check', 'mu-np-check') + '<span>分栏（左封面右歌词）</span>' +
            '</button>' +
          '</div>' +
        '</header>' +

        '<div class="mu-np-coverview" id="mu-np-coverview">' +
          '<div class="mu-np-stack">' +
            '<div class="mu-np-cover" id="mu-lyr-cover"></div>' +
            '<div class="mu-np-title" id="mu-lyr-title"></div>' +
            '<div class="mu-np-sub" id="mu-lyr-sub"></div>' +
            '<div class="mu-np-scrub" id="mu-np-scrub">' +
              '<div class="mu-np-track"><div class="mu-np-track-fill" id="mu-np-fill"></div></div>' +
            '</div>' +
            '<div class="mu-np-times">' +
              '<span id="mu-lyr-cur">0:00</span><span id="mu-lyr-remain">-0:00</span>' +
            '</div>' +
            '<div class="mu-np-btns">' +
              '<button type="button" class="mu-np-btn" id="mu-lyr-prev" title="上一首">' + svg('npPrev') + '</button>' +
              '<button type="button" class="mu-np-btn mu-np-play" id="mu-lyr-play" title="播放">' + svg('npPlay') + '</button>' +
              '<button type="button" class="mu-np-btn" id="mu-lyr-next" title="下一首">' + svg('npNext') + '</button>' +
            '</div>' +
            '<div class="mu-np-vol" id="mu-np-vol">' +
              '<span class="mu-np-vol-ico">' + svg('volLow') + '</span>' +
              '<div class="mu-np-vol-track" id="mu-np-voltrack">' +
                '<div class="mu-np-track"><div class="mu-np-track-fill" id="mu-np-volfill"></div></div>' +
              '</div>' +
              '<span class="mu-np-vol-ico">' + svg('volHigh') + '</span>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="mu-np-lyricview" id="mu-np-lyricview" hidden>' +
          '<div class="mu-np-scroll" id="mu-lyr-scroll">' +
            '<div class="mu-np-lines" id="mu-lyr-lines"></div>' +
            '<div class="mu-np-measure" id="mu-np-measure" aria-hidden="true"></div>' +
          '</div>' +
          '<button type="button" class="mu-np-resume" id="mu-np-resume" hidden>回到当前行</button>' +
          '<div class="mu-np-lyricbar">' +
            '<span class="mu-np-bt" id="mu-lyr-cur2">0:00</span>' +
            '<div class="mu-np-scrub" id="mu-np-scrub2">' +
              '<div class="mu-np-thin-track"><div class="mu-np-thin-fill" id="mu-np-fill2"></div></div>' +
            '</div>' +
            '<button type="button" class="mu-np-miniplay" id="mu-lyr-play2" title="播放 / 暂停">' + svg('play', 'fill') + '</button>' +
            '<span class="mu-np-bt" id="mu-lyr-dur2">0:00</span>' +
          '</div>' +
        '</div>' +
      '</div>' +

      '<div class="mu-toast" id="mu-toast" role="status" aria-live="polite"></div>';
  }

  function cacheRefs() {
    refs.nav = root.querySelector('#mu-nav');
    refs.mine = root.querySelector('#mu-mine');
    refs.mineList = root.querySelector('#mu-mine-list');
    refs.fsBtn = root.querySelector('#mu-fs-toggle');
    refs.fsIco = root.querySelector('#mu-fs-ico');
    refs.fsLabel = root.querySelector('#mu-fs-label');
    refs.sideStat = root.querySelector('#mu-side-stat');
    refs.sideTime = root.querySelector('#mu-side-time');
    refs.search = root.querySelector('#mu-search');
    refs.searchClear = root.querySelector('#mu-search-clear');
    refs.refreshBtn = root.querySelector('#mu-refresh');
    refs.updated = root.querySelector('#mu-updated');
    refs.content = root.querySelector('#mu-content');
    refs.player = root.querySelector('#mu-player');
    refs.discInner = root.querySelector('#mu-disc-inner');
    refs.nowTitle = root.querySelector('#mu-now-title');
    refs.nowSub = root.querySelector('#mu-now-sub');
    refs.nowFav = root.querySelector('#mu-now-fav');
    refs.playBtn = root.querySelector('#mu-play');
    refs.prevBtn = root.querySelector('#mu-prev');
    refs.nextBtn = root.querySelector('#mu-next');
    refs.seek = root.querySelector('#mu-seek');
    refs.cur = root.querySelector('#mu-cur');
    refs.dur = root.querySelector('#mu-dur');
    refs.modeBtn = root.querySelector('#mu-mode');
    refs.volBtn = root.querySelector('#mu-vol');
    refs.volRange = root.querySelector('#mu-volume');
    refs.toast = root.querySelector('#mu-toast');
    refs.disc = root.querySelector('#mu-disc');
    refs.lyrRoot = root.querySelector('#mu-lyr');
    refs.lyrBg = root.querySelector('#mu-lyr-bg');
    refs.lyrBlur = root.querySelector('#mu-lyr-blur');
    refs.lyrClose = root.querySelector('#mu-lyr-close');
    refs.lyrCover = root.querySelector('#mu-lyr-cover');
    refs.lyrTitle = root.querySelector('#mu-lyr-title');
    refs.lyrSub = root.querySelector('#mu-lyr-sub');
    refs.lyrScroll = root.querySelector('#mu-lyr-scroll');
    refs.lyrLines = root.querySelector('#mu-lyr-lines');
    refs.lyrCur = root.querySelector('#mu-lyr-cur');
    refs.lyrRemain = root.querySelector('#mu-lyr-remain');
    refs.lyrCur2 = root.querySelector('#mu-lyr-cur2');
    refs.lyrDur2 = root.querySelector('#mu-lyr-dur2');
    refs.npCoverView = root.querySelector('#mu-np-coverview');
    refs.npLyricView = root.querySelector('#mu-np-lyricview');
    // 间奏那三个点：单独一个层，不塞进歌词列表
    refs.lyrDots = root.querySelector('#mu-np-dots');
    if (!refs.lyrDots) {
      refs.lyrDots = document.createElement('div');
      refs.lyrDots.id = 'mu-np-dots';
      refs.lyrDots.className = 'mu-np-dots';
      refs.lyrDots.hidden = true;
      refs.lyrDots.innerHTML = '<span></span><span></span><span></span>';
      (root.querySelector('#mu-np-lyricview') || root).appendChild(refs.lyrDots);
    }
    refs.npToggle = root.querySelector('#mu-lyr-toggle');
    refs.npScrub = root.querySelector('#mu-np-scrub');
    refs.npScrub2 = root.querySelector('#mu-np-scrub2');
    refs.npFill = root.querySelector('#mu-np-fill');
    refs.npFill2 = root.querySelector('#mu-np-fill2');
    refs.npVol = root.querySelector('#mu-np-voltrack');
    refs.npVolFill = root.querySelector('#mu-np-volfill');
    refs.npPrev = root.querySelector('#mu-lyr-prev');
    refs.npPlay = root.querySelector('#mu-lyr-play');
    refs.npPlay2 = root.querySelector('#mu-lyr-play2');
    refs.npNext = root.querySelector('#mu-lyr-next');
    refs.npFav = root.querySelector('#mu-lyr-fav');
    refs.npMeasure = root.querySelector('#mu-np-measure');
    refs.npResume = root.querySelector('#mu-np-resume');
    refs.npSetup = root.querySelector('#mu-np-setup');
    refs.npMenu = root.querySelector('#mu-np-menu');
  }

  /* ------------------------------------------------------------
     挂载 / 卸载
     ------------------------------------------------------------ */
  function mount(container) {
    if (!container || !container.appendChild) return;
    if (mounted) unmount();

    mounted = true;
    host = container;
    st = createState();

    container.classList.add('mu-host');
    container.innerHTML = '';
    root = document.createElement('div');
    root.className = 'mu-app';
    root.innerHTML = shellHTML();
    container.appendChild(root);

    cacheRefs();
    document.body.classList.add('mu-fs');
    document.body.classList.remove('mu-fs-off');
    renderFsButton();
    fitHeight();

    audio = new Audio();
    audio.preload = 'metadata';
    audio.volume = st.volume;
    audio.setAttribute('aria-hidden', 'true');
    root.appendChild(audio);

    st.items = [];
    st.favs = {};
    var favIds = loadFavs();
    for (var i = 0; i < favIds.length; i++) st.favs[favIds[i]] = true;

    bindUi();
    bindAudio();

    refs.volRange.value = String(Math.round(st.volume * 100));
    renderNav();
    renderStats();
    renderContent();
    renderNow();
    renderMode();
    renderVolume();
    renderProgress();
    renderUpdated('正在读取本地曲库…');
    loadData(true);
    loadPlaylists();
    loadWishes();
    schedulePoll();
    scheduleWishPoll();

    refreshTimer = window.setInterval(function () { loadData(false); }, REFRESH_MS);

    keyHandler = function (e) { onKeyDown(e); };
    document.addEventListener('keydown', keyHandler, false);

    visHandler = function () { onVisibility(); };
    document.addEventListener('visibilitychange', visHandler, false);

    resizeHandler = function () {
      fitHeight();
      if (lyrOpen) layoutLyrics(false);
    };
    window.addEventListener('resize', resizeHandler);

    hideHandler = function () { savePosition(true); };
    window.addEventListener('pagehide', hideHandler);

    if (typeof window.ResizeObserver === 'function') {
      resizeObserver = new ResizeObserver(function () { fitHeight(); });
      try { resizeObserver.observe(host); } catch (e) { resizeObserver = null; }
    }
  }

  function unmount() {
    if (!mounted) return;

    savePosition(true);
    mounted = false;
    npKaraokeStop();

    if (refreshTimer) { window.clearInterval(refreshTimer); refreshTimer = null; }
    if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }
    stopPoll();
    stopWishPoll();
    if (libReloadTimer) { window.clearTimeout(libReloadTimer); libReloadTimer = null; }
    if (debounceTimer) { window.clearTimeout(debounceTimer); debounceTimer = null; }

    document.body.classList.remove('mu-fs');
    document.body.classList.remove('mu-fs-off');

    if (keyHandler) { document.removeEventListener('keydown', keyHandler, false); keyHandler = null; }
    if (visHandler) { document.removeEventListener('visibilitychange', visHandler, false); visHandler = null; }
    if (resizeHandler) { window.removeEventListener('resize', resizeHandler); resizeHandler = null; }
    if (hideHandler) { window.removeEventListener('pagehide', hideHandler); hideHandler = null; }
    if (resizeObserver) { try { resizeObserver.disconnect(); } catch (e) {} resizeObserver = null; }

    if (audio) {
      try {
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
      } catch (e) { /* 忽略 */ }
      if (audio.parentNode) audio.parentNode.removeChild(audio);
      audio = null;
    }

    if (root && root.parentNode) root.parentNode.removeChild(root);
    if (host) host.classList.remove('mu-host');

    root = null;
    refs = {};
    host = null;
    st = null;
    seeking = false;
    lastPosSave = 0;
    mineRefs = {};
    wishRefs = {};
    plSeq = 0;
    nmUserSeq = 0;
    nmPlSeq = 0;
    nmPlSearchSeq = 0;
    wishSeq = 0;
    recentSeq = 0;
    lyrOpen = false;
    npLayout = 'cover';
    lyrData = { synced: false, lines: [] };
    npActive = -1;
    npManual = false;
    if (npManualTimer) { window.clearTimeout(npManualTimer); npManualTimer = null; }
    if (npSettleTimer) { window.clearTimeout(npSettleTimer); npSettleTimer = null; }
    if (npCloseTimer) { window.clearTimeout(npCloseTimer); npCloseTimer = null; }
    npCancelAnim();
    npFrameH = [];
    npMeasuredW = -1;
    npDragRatio = null;
    npVolDrag = false;
    npColorSeq = 0;
    npBg = 'rgb(30, 30, 32)';
  }

  function fitHeight() {
    if (!root || !host) return;
    if (host.offsetParent === null && host.getClientRects().length === 0) return;
    var h = host.clientHeight;
    if (h > 200) {
      root.style.height = '100%';
      return;
    }
    var rect = host.getBoundingClientRect();
    var avail = window.innerHeight - rect.top - 14;
    root.style.height = Math.max(480, avail) + 'px';
  }

  /* ------------------------------------------------------------
     数据
     ------------------------------------------------------------ */
  function loadData(first) {
    if (!mounted) return;
    if (first && !st.items.length) {
      renderUpdated('正在读取本地曲库…');
    } else {
      renderUpdated('正在刷新…');
    }

    fetch(API_URL + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (res) {
        if (!res.ok) {
          var err = new Error('HTTP ' + res.status);
          err.status = res.status;
          throw err;
        }
        return res.json();
      })
      .then(function (data) {
        if (!mounted) return;
        applyData(data || {});
        st.loading = false;
        st.error = '';
        renderNav();
        renderStats();
        renderContent();
        syncNowFav();
        if (st.pendingPlay) {
          var pid = st.pendingPlay;
          st.pendingPlay = null;
          if (st.byId[pid]) {
            st.queue = st.visibleIds.slice();
            if (st.queue.indexOf(pid) < 0) st.queue.push(pid);
            playId(pid, 'force');
          }
        }
        renderUpdated();
      })
      .catch(function (err) {
        if (!mounted) return;
        st.loading = false;
        var msg;
        if (err && err.status === 404) {
          msg = '本地服务还没有开放点歌台接口（/api/music 返回 404）。';
        } else if (err && err.status) {
          msg = '读取歌单失败（HTTP ' + err.status + '），稍后点右上角刷新试试。';
        } else if (window.navigator && window.navigator.onLine === false) {
          msg = '网络还没通，歌单拉不下来。等老师开热点、后台同步好再来。';
        } else {
          msg = '连不上本地服务，确认 newsd 起来了再刷新。';
        }

        if (first || !st.items.length) {
          st.error = msg;
          renderContent();
          renderNav();
          renderStats();
          renderUpdated('读取失败');
        } else {
          renderUpdated('刷新失败，先听已经下好的');
          toast('刷新失败：' + msg);
        }
      });
  }

  function applyData(data) {
    var raw = Array.isArray(data.items) ? data.items : [];
    var prevKnown = st.known;
    var nextKnown = {};
    var newIds = {};
    var items = [];
    var byId = {};

    for (var i = 0; i < raw.length; i++) {
      var it = raw[i];
      if (!it || typeof it !== 'object' || !it.file) continue;
      var id = it.id ? String(it.id) : ('fmt-' + i + '-' + String(it.file));
      var norm = {
        id: id,
        title: it.title ? String(it.title) : '未命名曲目',
        artist: it.artist ? String(it.artist) : '',
        album: it.album ? String(it.album) : '',
        file: String(it.file),
        cover: it.cover ? String(it.cover) : '',
        size: Number(it.size) || 0,
        duration_s: Number(it.duration_s) || 0,
        chart: it.chart ? String(it.chart) : '',
        added_at: it.added_at ? String(it.added_at) : '',
        lrc: it.lrc ? String(it.lrc) : '',
        song_id: it.song_id ? String(it.song_id) : '',
        // 网易云另一路接口给的是分离的翻译歌词，后端要是带了就直接用
        tlrc: it.tlrc ? String(it.tlrc) : (it.tlyric ? String(it.tlyric) : '')
      };
      if (st.firstLoadDone && !prevKnown[id]) newIds[id] = true;
      nextKnown[id] = true;
      items.push(norm);
      byId[id] = norm;
    }

    // 接口里带的新字段，合并进来（不要覆盖播放中的对象引用）
    st.items = items;
    st.byId = byId;
    st.known = nextKnown;
    st.newIds = newIds;
    st.generated = data.generated_at ? String(data.generated_at) : '';
    var total = Number(data.total_bytes);
    if (!isFinite(total) || total < 0) {
      total = 0;
      for (var k = 0; k < items.length; k++) total += items[k].size;
    }
    st.totalBytes = total;

    if (!st.firstLoadDone) {
      st.firstLoadDone = true;
      restoreLastTrack();
    }
  }

  function restoreLastTrack() {
    var saved = st.savedPos;
    if (!saved) return;
    var it = st.byId[saved.id];
    if (!it) return;
    loadTrack(it);
    st.restoreTo = saved.t || 0;
  }

  /* ------------------------------------------------------------
     视图数据
     ------------------------------------------------------------ */
  function hasAddedAt() {
    for (var i = 0; i < st.items.length; i++) {
      if (st.items[i].added_at) return true;
    }
    return false;
  }

  function recentItems() {
    var arr = st.items.slice();
    if (hasAddedAt()) {
      arr.sort(function (a, b) {
        var av = a.added_at || '';
        var bv = b.added_at || '';
        if (av === bv) return 0;
        return av < bv ? 1 : -1;
      });
    } else {
      arr.reverse();
    }
    return arr;
  }

  function favItems() {
    return st.items.filter(function (it) { return isFav(it.id); });
  }

  function viewItems() {
    if (st.view === 'recent') return recentItems();
    if (st.view === 'fav') return favItems();
    return st.items.slice();
  }

  function filteredItems() {
    var list = viewItems();
    var q = st.query.trim().toLowerCase();
    if (!q) return list;
    return list.filter(function (it) {
      var hay = (it.title + ' ' + it.artist + ' ' + it.album + ' ' + it.chart).toLowerCase();
      return hay.indexOf(q) >= 0;
    });
  }

  function groupByChart(list) {
    var order = [];
    var map = {};
    for (var i = 0; i < list.length; i++) {
      var name = chartName(list[i]);
      if (!map[name]) {
        map[name] = [];
        order.push(name);
      }
      map[name].push(list[i]);
    }
    return order.map(function (name) { return { name: name, items: map[name] }; });
  }

  /* ------------------------------------------------------------
     渲染入口
     ------------------------------------------------------------ */
  function renderUpdated(text) {
    if (!refs.updated) return;
    if (text) {
      refs.updated.textContent = text;
      return;
    }
    refs.updated.textContent = st.generated ? ('上次扫描 ' + st.generated) : '本地曲库';
  }

  function renderNav() {
    if (!refs.nav) return;
    var favCount = st.items.filter(function (it) { return isFav(it.id); }).length;
    var html = VIEWS.map(function (v) {
      var n = '';
      if (v.key === 'all') n = st.items.length;
      else if (v.key === 'fav') n = favCount;
      else if (v.key === 'recent') n = recentItems().length;
      return '<button type="button" class="mu-nav-item' + (st.view === v.key ? ' active' : '') + '" data-view="' + v.key + '">' +
        svg(v.icon) + '<span>' + v.label + '</span>' +
        (n === '' ? '' : '<em class="mu-nav-n">' + n + '</em>') +
        '</button>';
    }).join('');
    refs.nav.innerHTML = html;
  }

  function renderStats() {
    if (!refs.sideStat) return;
    var n = st.items.length;
    refs.sideStat.textContent = '共 ' + n + ' 首 ・ 占用 ' + fmtSize(n ? st.totalBytes : 0);
    refs.sideTime.textContent = st.generated ? ('最近同步 ' + st.generated) : '本地缓存';
  }

  function renderContent() {
    if (!refs.content) return;

    // 打开某个收藏歌单的曲目页，和本地曲库/搜索无关
    if (st.view === 'tracks') {
      st.visibleIds = [];
      renderTracks();
      return;
    }

    // 歌单广场不依赖本地曲库，也不吃顶栏搜索词
    if (st.view === 'plaza') {
      st.visibleIds = [];
      renderPlaza();
      return;
    }

    if (st.loading && !st.items.length) {
      st.visibleIds = [];
      refs.content.innerHTML = loadingMarkup('正在读取本地曲库…');
      return;
    }

    if (st.error) {
      st.visibleIds = [];
      refs.content.innerHTML = emptyMarkup('歌单没读出来', st.error, true);
      return;
    }

    if (!st.items.length) {
      st.visibleIds = [];
      refs.content.innerHTML = emptyMarkup(
        '还没歌呢，等下次联网自动下几首',
        '把 mp3 / flac 丢进 data/music 文件夹也会被扫进来，封面会自动从标签里抽。',
        true
      );
      return;
    }

    var list = filteredItems();
    st.visibleIds = list.map(function (it) { return it.id; });

    if (st.query.trim() && !list.length) {
      refs.content.innerHTML = emptyMarkup(
        '没搜到「' + st.query.trim() + '」',
        '换个歌名、歌手或者专辑名试试，只搜本地已有的歌。',
        false
      );
      return;
    }

    if (st.view === 'discover') {
      refs.content.innerHTML = discoverHTML(list);
    } else if (st.view === 'fav') {
      refs.content.innerHTML = list.length ? tableHTML(list, 'fav') : emptyMarkup(
        '还没有收藏',
        '在歌曲右边点一下 ♥ ，喜欢的歌就收在这里了，收藏只存在这台电脑上。',
        false
      );
    } else if (st.view === 'recent') {
      refs.content.innerHTML = list.length ? tableHTML(list, 'recent') : emptyMarkup(
        '最近没有新歌',
        '后台联网时会陆续下一些，等下次同步完再来看看。',
        false
      );
    } else {
      refs.content.innerHTML = tableHTML(list, 'all');
    }
  }

  function discoverHTML(list) {
    if (!list.length) {
      return emptyMarkup('这里没有匹配的歌', '清掉搜索词，或者去「全部歌曲」里翻翻。', false);
    }

    var groups = groupByChart(list);
    var total = list.length;
    var hero = '<div class="mu-hero">' +
      '<div class="mu-hero-txt">' +
        '<span class="mu-hero-kicker">OFFLINE RADIO</span>' +
        '<h2>发现音乐</h2>' +
        '<p>本地曲库 ' + total + ' 首，点开就能听，不用联网。</p>' +
      '</div>' +
      '<div class="mu-hero-actions">' +
        '<button type="button" class="mu-btn" data-act="play-all">' + svg('play') + '播放全部</button>' +
      '</div>' +
    '</div>';

    var secs = groups.map(function (g) {
      var cards = g.items.map(cardHTML).join('');
      return '<section class="mu-sec">' +
        '<div class="mu-sec-head">' +
          '<h3>' + esc(g.name) + '</h3>' +
          '<span class="mu-sec-n">' + g.items.length + ' 首</span>' +
          '<button type="button" class="mu-sec-play" data-act="play-chart" data-chart="' + esc(g.name) + '">' +
            svg('play') + '播放全部</button>' +
        '</div>' +
        '<div class="mu-cards' + (g.items.length > 4 ? ' mu-cards-2' : '') + '">' + cards + '</div>' +
      '</section>';
    }).join('');

    return hero + secs;
  }

  function cardHTML(item) {
    var title = esc(item.title);
    return '<div class="mu-card" role="button" tabindex="0" data-act="play" data-id="' + esc(item.id) + '"' +
      ' title="' + esc(item.title + ' - ' + artistOf(item)) + '">' +
      '<div class="mu-card-cover">' + coverMarkup(item) +
        (st.newIds[item.id] ? '<span class="mu-card-new">NEW</span>' : '') +
        '<span class="mu-card-play">' + svg('play') + '</span>' +
      '</div>' +
      '<div class="mu-card-title">' + title + '</div>' +
      '<div class="mu-card-artist">' + esc(artistOf(item)) + '</div>' +
    '</div>';
  }

  function tableHTML(list, mode) {
    var head = '<div class="mu-listhead">' +
      '<h2>' + (mode === 'all' ? '全部歌曲' : mode === 'recent' ? '最近下载' : '我的收藏') + '</h2>' +
      '<span class="mu-count">' + list.length + ' 首' + (st.query.trim() ? '（已过滤）' : '') + '</span>' +
      '<button type="button" class="mu-btn" data-act="play-all">' + svg('play') + '播放全部</button>' +
    '</div>';

    var cols = '<div class="mu-row mu-row-head">' +
      '<div class="mu-cell mu-idx">#</div>' +
      '<div class="mu-cell">标题</div>' +
      '<div class="mu-cell mu-artist">歌手</div>' +
      '<div class="mu-cell mu-album">专辑</div>' +
      '<div class="mu-cell mu-dur">时长</div>' +
      '<div class="mu-cell mu-src">来源</div>' +
      '<div class="mu-cell mu-rowacts">操作</div>' +
    '</div>';

    var rows = list.map(function (it, idx) {
      var active = it.id === st.currentId;
      var fav = isFav(it.id);
      var dur = durationOf(it);
      return '<div class="mu-row' + (active ? ' is-playing' : '') + '" data-act="play" data-id="' + esc(it.id) + '"' +
        ' data-n="' + (idx + 1) + '" role="button" tabindex="0">' +
        '<div class="mu-cell mu-idx">' + (active ? eqMarkup() : String(idx + 1)) + '</div>' +
        '<div class="mu-cell mu-tcell">' + coverMarkup(it, 'mu-cov-sm') +
          '<div class="mu-tinfo">' +
            '<span class="mu-tname">' + esc(it.title) + (st.newIds[it.id] ? '<em class="mu-new">NEW</em>' : '') +
              (!it.lrc && it.song_id
                ? '<button type="button" class="mu-lyrchip" data-act="relrc" data-song-id="' + esc(it.song_id) + '" title="从网易云补这首的歌词">补词</button>'
                : '') +
            '</span>' +
            (it.album ? '<span class="mu-talb">' + esc(it.album) + '</span>' : '') +
          '</div>' +
        '</div>' +
        '<div class="mu-cell mu-artist">' + esc(artistOf(it)) + '</div>' +
        '<div class="mu-cell mu-album">' + esc(it.album || '—') + '</div>' +
        '<div class="mu-cell mu-dur"><span data-dur="' + esc(it.id) + '">' + (dur > 0 ? fmtTime(dur) : '--:--') + '</span></div>' +
        '<div class="mu-cell mu-src">' + (it.chart ? '<span class="mu-chip">' + esc(it.chart) + '</span>' : '<span class="mu-dim">本地</span>') + '</div>' +
        '<div class="mu-cell mu-rowacts">' +
          '<button type="button" class="mu-icon-btn mu-fav' + (fav ? ' is-on' : '') + '" data-act="fav" data-id="' + esc(it.id) + '" title="收藏">' +
            svg(fav ? 'heartFill' : 'heart') + '</button>' +
          '<button type="button" class="mu-icon-btn" data-act="add" data-id="' + esc(it.id) + '" title="加入播放列表">' + svg('plus') + '</button>' +
        '</div>' +
      '</div>';
    }).join('');

    return head + '<div class="mu-table">' + cols + rows + '</div>';
  }

  /* ------------------------------------------------------------
     播放器渲染
     ------------------------------------------------------------ */
  function renderNow() {
    if (!refs.nowTitle) return;
    var it = st.current;
    if (it) {
      refs.nowTitle.textContent = it.title;
      refs.nowTitle.title = it.title;
      var sub = artistOf(it);
      if (it.album) sub += ' · ' + it.album;
      refs.nowSub.textContent = sub;
      refs.nowSub.title = sub;
      refs.discInner.innerHTML = coverMarkup(it);
    } else {
      refs.nowTitle.textContent = '还没有选歌';
      refs.nowTitle.title = '';
      refs.nowSub.textContent = '点一首歌开始听';
      refs.nowSub.title = '';
      refs.discInner.innerHTML = '<span class="mu-cov"><span class="mu-cov-ph">' + svg('note') + '<i>♪</i></span></span>';
    }
    syncNowFav();
    if (lyrOpen) renderLyrics();
  }

  function syncNowFav() {
    if (!refs.nowFav) return;
    var on = !!(st.current && isFav(st.current.id));
    refs.nowFav.classList.toggle('is-on', on);
    refs.nowFav.innerHTML = svg(on ? 'heartFill' : 'heart');
    refs.nowFav.title = on ? '取消收藏' : '收藏';
    if (refs.npFav) {
      refs.npFav.classList.toggle('is-on', on);
      refs.npFav.innerHTML = svg(on ? 'heartFill' : 'heart');
      refs.npFav.title = on ? '取消收藏' : '收藏';
      refs.npFav.setAttribute('aria-label', on ? '取消收藏' : '收藏');
    }
  }

  function renderPlayState() {
    if (!refs.playBtn || !refs.player) return;
    var playing = !!(audio && !audio.paused && st.current);
    refs.playBtn.innerHTML = svg(playing ? 'npPause' : 'npPlay');
    refs.playBtn.title = playing ? '暂停' : '播放';
    refs.player.classList.toggle('is-playing', playing);
    if (refs.npPlay) {
      refs.npPlay.innerHTML = svg(playing ? 'npPause' : 'npPlay');
      refs.npPlay.title = playing ? '暂停' : '播放';
      refs.npPlay.setAttribute('aria-label', playing ? '暂停' : '播放');
    }
    if (refs.npPlay2) {
      refs.npPlay2.innerHTML = svg(playing ? 'npPause' : 'npPlay');
      refs.npPlay2.title = playing ? '暂停' : '播放';
      refs.npPlay2.setAttribute('aria-label', playing ? '暂停' : '播放');
    }
    if (refs.lyrCover) refs.lyrCover.classList.toggle('is-paused', !playing);
    // 暂停时把逐字渐变/呼吸冻在当前帧
    if (refs.lyrRoot) refs.lyrRoot.classList.toggle('is-paused', !playing);
  }

  function currentDuration() {
    if (audio && isFinite(audio.duration) && audio.duration > 0) return audio.duration;
    return st.current ? durationOf(st.current) : 0;
  }

  function renderProgress() {
    if (!refs.seek) return;
    var dur = currentDuration();
    var cur = 0;
    if (audio && isFinite(audio.currentTime)) cur = Math.max(0, audio.currentTime);
    if (dur > 0 && cur > dur) cur = dur;

    refs.seek.max = dur > 0 ? String(dur) : '100';
    refs.seek.disabled = !(dur > 0) && !st.current;
    if (!seeking) refs.seek.value = String(dur > 0 ? cur : 0);
    var pct = dur > 0 ? (cur / dur) * 100 : 0;
    refs.seek.style.setProperty('--mu-pct', pct.toFixed(2) + '%');
    refs.cur.textContent = fmtTime(cur);
    refs.dur.textContent = dur > 0 ? fmtTime(dur) : '--:--';
    if (lyrOpen) npPaintProgress();
  }

  function renderMode() {
    if (!refs.modeBtn) return;
    var name = st.repeat === 'one' ? 'repeatOne' : st.repeat === 'shuffle' ? 'shuffle' : 'repeat';
    refs.modeBtn.innerHTML = svg(name);
    refs.modeBtn.title = REPEAT_LABEL[st.repeat] || '列表循环';
    refs.modeBtn.classList.toggle('is-on', st.repeat !== 'list');
  }

  function renderVolume() {
    if (!refs.volRange) return;
    var v = st.muted ? 0 : st.volume;
    refs.volRange.value = String(Math.round(v * 100));
    refs.volRange.style.setProperty('--mu-pct', (v * 100).toFixed(1) + '%');
    if (refs.volBtn) {
      refs.volBtn.innerHTML = svg(v <= 0 ? 'mute' : 'volume');
      refs.volBtn.title = v <= 0 ? '取消静音' : '静音';
    }
    if (refs.npVolFill) refs.npVolFill.style.width = (v * 100).toFixed(1) + '%';
  }

  function syncPlayingRows() {
    if (!root || !st.currentId) return;
    var rows = root.querySelectorAll('.mu-row[data-id]');
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var on = row.getAttribute('data-id') === st.currentId;
      if (row.classList.contains('is-playing') !== on) {
        row.classList.toggle('is-playing', on);
        var idx = row.querySelector('.mu-idx');
        if (idx) {
          if (on) idx.innerHTML = eqMarkup();
          else idx.textContent = row.getAttribute('data-n') || '';
        }
      }
    }
  }

  function syncFavButtons(id) {
    if (!root) return;
    var on = isFav(id);
    var btns = root.querySelectorAll('[data-act="fav"][data-id]');
    for (var i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute('data-id') !== id) continue;
      btns[i].classList.toggle('is-on', on);
      btns[i].innerHTML = svg(on ? 'heartFill' : 'heart');
    }
    if (st.current && st.current.id === id) syncNowFav();
  }

  /* ------------------------------------------------------------
     播放逻辑
     ------------------------------------------------------------ */
  function bindAudio() {
    if (!audio) return;
    audio.addEventListener('timeupdate', function () {
      renderProgress();
      if (lyrOpen) npUpdateLyrics(false);
      savePosition(false);
    });
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('play', function () {
      renderPlayState();
      renderProgress();
      if (lyrOpen) npKaraokeStart();
    });
    audio.addEventListener('pause', function () {
      renderPlayState();
      if (lyrOpen) {
        npKaraokeStop();
        npPaintChars();
      }
      savePosition(true);
    });
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onAudioError);
  }

  function onLoadedMetadata() {
    if (!audio || !st) return;
    var dur = isFinite(audio.duration) ? audio.duration : 0;
    if (st.restoreTo != null) {
      var target = st.restoreTo;
      st.restoreTo = null;
      if (target > 0 && dur > 1) {
        try { audio.currentTime = Math.min(target, dur - 1); } catch (e) { /* 忽略 */ }
      }
    }
    if (st.current) {
      if (dur > 0) st.current.duration_s = dur;
      var cells = root.querySelectorAll('[data-dur]');
      for (var i = 0; i < cells.length; i++) {
        if (cells[i].getAttribute('data-dur') === st.current.id) {
          cells[i].textContent = fmtTime(dur || durationOf(st.current));
        }
      }
    }
    renderProgress();
  }

  function loadTrack(item) {
    if (!audio || !item) return;
    st.current = item;
    st.currentId = item.id;
    try {
      audio.pause();
      audio.src = pathURL(item.file);
      audio.load();
    } catch (e) {
      toast('这首歌加载失败，跳过');
    }
    renderNow();
    renderProgress();
    syncPlayingRows();
  }

  function playId(id, mode) {
    if (!st) return;
    var item = st.byId[id];
    if (!item) return;
    mode = mode || 'toggle';

    if (st.currentId === id && audio && audio.getAttribute('src')) {
      if (mode === 'toggle') {
        if (audio.paused) doPlay();
        else doPause();
      } else {
        try { audio.currentTime = 0; } catch (e) { /* 忽略 */ }
        doPlay();
      }
      return;
    }

    st.restoreTo = null;
    loadTrack(item);
    doPlay();
  }

  function doPlay() {
    if (!audio) return;
    if (!st.current) {
      var firstId = st.visibleIds.length ? st.visibleIds[0] : (st.items[0] && st.items[0].id);
      if (firstId) playId(firstId, 'force');
      return;
    }
    var p;
    try { p = audio.play(); } catch (e) { toast('播放失败，换一首试试'); return; }
    if (p && typeof p.catch === 'function') {
      p.catch(function (err) {
        if (!mounted) return;
        if (err && err.name === 'NotAllowedError') {
          toast('浏览器拦了自动播放，点一下播放键就好');
        }
        renderPlayState();
      });
    }
  }

  function doPause() {
    if (!audio) return;
    try { audio.pause(); } catch (e) { /* 忽略 */ }
    renderPlayState();
  }

  function togglePlay() {
    if (!audio) return;
    if (!st.current) {
      doPlay();
      return;
    }
    if (audio.paused) doPlay();
    else doPause();
  }

  function queueIds() {
    var list = st.queue.length ? st.queue : st.visibleIds;
    var out = [];
    for (var i = 0; i < list.length; i++) {
      if (st.byId[list[i]] && !st.bad[list[i]]) out.push(list[i]);
    }
    return out;
  }

  function nextTrack(auto) {
    var ids = queueIds();
    if (!ids.length) {
      allFailed();
      return;
    }
    if (st.repeat === 'shuffle' && ids.length > 1) {
      var pick = ids[Math.floor(Math.random() * ids.length)];
      if (pick === st.currentId) pick = ids[(ids.indexOf(pick) + 1) % ids.length];
      playId(pick, 'force');
      return;
    }
    var idx = ids.indexOf(st.currentId);
    var nextIdx = idx < 0 ? 0 : (idx + 1) % ids.length;
    if (ids.length === 1 && nextIdx === idx && !auto && st.currentId === ids[0]) {
      playId(ids[0], 'force');
      return;
    }
    playId(ids[nextIdx], 'force');
  }

  function prevTrack() {
    if (audio && isFinite(audio.currentTime) && audio.currentTime > 3) {
      try { audio.currentTime = 0; } catch (e) { /* 忽略 */ }
      return;
    }
    var ids = queueIds();
    if (!ids.length) return;
    var idx = ids.indexOf(st.currentId);
    if (idx < 0) idx = 0;
    var prevIdx = (idx - 1 + ids.length) % ids.length;
    playId(ids[prevIdx], 'force');
  }

  function onEnded() {
    if (!st) return;
    if (st.repeat === 'one') {
      try { audio.currentTime = 0; } catch (e) { /* 忽略 */ }
      doPlay();
      return;
    }
    nextTrack(true);
  }

  function allFailed() {
    renderPlayState();
    toast('列表里的歌都放不出来，检查一下文件还在不在。');
  }

  function onAudioError() {
    if (!mounted || !st || !st.current) return;
    var bad = st.current;
    var name = bad.title || '这首歌';
    st.bad[bad.id] = true;
    toast('《' + name + '》放不出来，可能文件被删了，跳过');
    var ids = queueIds();
    if (!ids.length) {
      renderPlayState();
      return;
    }
    var next = ids[0];
    if (ids.length > 1) {
      var idx = ids.indexOf(st.currentId);
      next = ids[(idx + 1 + ids.length) % ids.length];
    }
    if (next === st.currentId) {
      renderPlayState();
      return;
    }
    window.setTimeout(function () {
      if (mounted && st) playId(next, 'force');
    }, 350);
  }

  function seekBy(sec) {
    if (!audio || !st.current) return;
    var dur = currentDuration();
    if (!(dur > 0)) return;
    var t = (isFinite(audio.currentTime) ? audio.currentTime : 0) + sec;
    t = Math.min(dur - 0.05, Math.max(0, t));
    try { audio.currentTime = t; } catch (e) { /* 忽略 */ }
    renderProgress();
  }

  function savePosition(force) {
    if (!st || !audio || !st.currentId) return;
    var now = Date.now();
    if (!force && now - lastPosSave < 4000) return;
    lastPosSave = now;
    var t = isFinite(audio.currentTime) ? audio.currentTime : 0;
    writeLS(LS_POS, { id: st.currentId, t: Math.max(0, t) });
  }

  /* ------------------------------------------------------------
     交互
     ------------------------------------------------------------ */
  function bindUi() {
    root.addEventListener('click', onClick);
    refs.content.addEventListener('error', onImgError, true);
    refs.content.addEventListener('keydown', onContentKey);

    refs.search.addEventListener('input', onSearchInput);
    refs.searchClear.addEventListener('click', function () {
      refs.search.value = '';
      onSearchInput();
      refs.search.focus();
    });
    refs.refreshBtn.addEventListener('click', function () {
      if (st.loading) return;
      loadData(false);
    });

    refs.playBtn.addEventListener('click', togglePlay);
    refs.prevBtn.addEventListener('click', prevTrack);
    refs.nextBtn.addEventListener('click', nextTrack);
    refs.nowFav.addEventListener('click', function () {
      if (st.current) toggleFav(st.current.id);
      else toast('还没有在播的歌');
    });

    refs.seek.addEventListener('input', function () {
      seeking = true;
      var v = Number(refs.seek.value);
      var dur = currentDuration();
      if (dur > 0 && isFinite(v)) {
        try { audio.currentTime = v; } catch (e) { /* 忽略 */ }
        refs.cur.textContent = fmtTime(v);
        refs.seek.style.setProperty('--mu-pct', ((v / dur) * 100).toFixed(2) + '%');
      }
    });
    refs.seek.addEventListener('change', function () {
      seeking = false;
      renderProgress();
    });

    refs.modeBtn.addEventListener('click', function () {
      var order = ['list', 'one', 'shuffle'];
      var i = order.indexOf(st.repeat);
      st.repeat = order[(i + 1) % order.length];
      writeLS(LS_REPEAT, st.repeat);
      renderMode();
      toast('循环模式：' + REPEAT_LABEL[st.repeat]);
    });

    refs.volRange.addEventListener('input', function () {
      var v = Number(refs.volRange.value) / 100;
      if (!isFinite(v)) v = 0;
      st.volume = Math.min(1, Math.max(0, v));
      st.muted = st.volume <= 0;
      if (audio) {
        audio.volume = st.volume;
        audio.muted = false;
      }
      writeLS(LS_VOL, st.volume);
      renderVolume();
    });

    refs.volBtn.addEventListener('click', function () {
      st.muted = !st.muted;
      if (audio) audio.muted = st.muted;
      renderVolume();
    });

    // ── 触摸：滑一下看歌词 / 滑回去 ──────────────────────────────
    // 鼠标点封面也能切换，但手机上「点」容易被滑动手势吃掉，
    // 所以这里单独挂一套 touch 手势：上滑看歌词，下滑回唱片。
    function bindSwipe(el, handlers) {
      if (!el) return;
      var sy = 0, sx = 0, t0 = 0, moved = false, fired = false, suppress = false;
      el.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        sy = e.touches[0].clientY;
        sx = e.touches[0].clientX;
        t0 = Date.now();
        moved = false;
        fired = false;
      }, { passive: true });
      el.addEventListener('touchmove', function (e) {
        if (e.touches.length !== 1 || fired) return;
        var dy = e.touches[0].clientY - sy;
        var dx = e.touches[0].clientX - sx;
        if (Math.abs(dy) > 12 || Math.abs(dx) > 12) moved = true;
        // 竖着滑、够长、而且横向没怎么动，才算手势
        if (Math.abs(dy) < 48) return;
        if (Math.abs(dy) < Math.abs(dx) * 1.3) return;
        if (dy < 0 && handlers.up) { fired = true; handlers.up(); }
        else if (dy > 0 && handlers.down) { fired = true; handlers.down(); }
      }, { passive: true });
      el.addEventListener('touchend', function () {
        if (fired) { suppress = true; return; }
        if (!moved && Date.now() - t0 < 320 && handlers.tap) handlers.tap();
      }, { passive: true });
      // 滑完浏览器还会补一个 click，这里吃掉它，免得又切回去
      el.addEventListener('click', function (e) {
        if (!suppress) return;
        suppress = false;
        e.preventDefault();
        e.stopPropagation();
      }, true);
    }

    bindSwipe(refs.disc, {
      up: function () { if (!lyrOpen) openLyrics(); }
    });

    if (refs.npLyricView) {
      bindSwipe(refs.npLyricView, {
        down: function () {
          if (!lyrOpen) return;
          // 歌词滚到顶上再往下滑才退出，不然滑一下就没法看词了
          if (refs.lyrScroll && refs.lyrScroll.scrollTop > 8) return;
          closeLyrics();
        }
      });
    }

    if (refs.disc) {
      refs.disc.addEventListener('click', function () {
        if (lyrOpen) closeLyrics();
        else openLyrics();
      });
      refs.disc.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        e.preventDefault();
        e.stopPropagation();
        if (lyrOpen) closeLyrics();
        else openLyrics();
      });
    }

    if (refs.lyrClose) refs.lyrClose.addEventListener('click', closeLyrics);
    if (refs.npToggle) {
      refs.npToggle.addEventListener('click', function () { npToggleView(); });
    }
    if (refs.npSetup) {
      refs.npSetup.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleNpMenu();
      });
    }
    if (refs.npMenu) {
      var menuItems = refs.npMenu.querySelectorAll('[data-layout]');
      for (var mi = 0; mi < menuItems.length; mi++) {
        menuItems[mi].addEventListener('click', function (e) {
          e.stopPropagation();
          setNpLayout(this.getAttribute('data-layout'));
          toggleNpMenu(false);
        });
      }
    }

    if (refs.npPrev) refs.npPrev.addEventListener('click', prevTrack);
    if (refs.npPlay) refs.npPlay.addEventListener('click', togglePlay);
    if (refs.npPlay2) refs.npPlay2.addEventListener('click', togglePlay);
    if (refs.npNext) refs.npNext.addEventListener('click', nextTrack);

    if (refs.npFav) {
      refs.npFav.addEventListener('click', function () {
        if (st.current) toggleFav(st.current.id);
        else toast('还没有在播的歌');
      });
    }

    // 进度：pointer 事件只绑轨道本身（绑外层会把时间/按钮也变成热区）
    var scrubTracks = [refs.npScrub, refs.npScrub2];
    for (var si = 0; si < scrubTracks.length; si++) {
      var track = scrubTracks[si];
      if (!track) continue;
      track.addEventListener('pointerdown', npScrubDown);
      track.addEventListener('pointermove', npScrubMove);
      track.addEventListener('pointerup', npScrubUp);
      track.addEventListener('pointercancel', npScrubCancel);
    }

    if (refs.npVol) {
      refs.npVol.addEventListener('pointerdown', npVolDown);
      refs.npVol.addEventListener('pointermove', npVolMove);
      refs.npVol.addEventListener('pointerup', npVolUp);
      refs.npVol.addEventListener('pointercancel', npVolUp);
    }

    if (refs.lyrScroll) {
      refs.lyrScroll.addEventListener('wheel', npOnManualScroll, { passive: true });
      refs.lyrScroll.addEventListener('touchmove', npOnManualScroll, { passive: true });
      refs.lyrScroll.addEventListener('scroll', npQueueLyricBlur, { passive: true });
    }
    if (refs.lyrLines) refs.lyrLines.addEventListener('click', npOnLineClick);
    if (refs.npResume) refs.npResume.addEventListener('click', npResumeFollow);
  }

  function onClick(e) {
    if (!mounted || !root) return;

    // 点空白处关掉布局菜单（菜单项自己 stopPropagation）
    if (refs.npMenu && !refs.npMenu.hidden) {
      var inMenu = refs.npMenu.contains(e.target);
      var onSetup = refs.npSetup && refs.npSetup.contains(e.target);
      if (!inMenu && !onSetup) toggleNpMenu(false);
    }

    var nav = e.target.closest ? e.target.closest('.mu-nav-item') : null;
    if (nav && refs.nav && refs.nav.contains(nav)) {
      setView(nav.getAttribute('data-view'));
      return;
    }

    var fsEl = e.target.closest ? e.target.closest('#mu-fs-toggle') : null;
    if (fsEl) {
      toggleFullscreen();
      return;
    }

    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || !root.contains(el)) return;

    var act = el.getAttribute('data-act');
    var id = el.getAttribute('data-id');

    if (act === 'play') {
      if (!id) return;
      st.queue = st.visibleIds.slice();
      playId(id, 'toggle');
    } else if (act === 'play-all') {
      playAll(st.visibleIds);
    } else if (act === 'play-chart') {
      var chart = el.getAttribute('data-chart') || '';
      var ids = [];
      for (var i = 0; i < st.items.length; i++) {
        if (chartName(st.items[i]) === chart) ids.push(st.items[i].id);
      }
      playAll(ids);
    } else if (act === 'fav') {
      if (id) toggleFav(id);
    } else if (act === 'add') {
      if (id) addToQueue(id);
    } else if (act === 'reload') {
      st.loading = true;
      st.error = '';
      renderContent();
      renderUpdated('正在重新读取…');
      loadData(true);
    } else if (act === 'go-plaza') {
      setView('plaza');
    } else if (act === 'nm-user') {
      toggleUser(el.getAttribute('data-uid') || '');
    } else if (act === 'pl-add') {
      addPlaylist(el);
    } else if (act === 'pl-del') {
      removePlaylist(el.getAttribute('data-pid') || '');
    } else if (act === 'pl-open') {
      openTracks(el.getAttribute('data-pid') || '');
    } else if (act === 'pl-back') {
      setView('plaza');
    } else if (act === 'tracks-reload') {
      if (st.tracksPid) loadTracks(st.tracksPid, true);
    } else if (act === 'track-dl') {
      downloadTrack(el.getAttribute('data-id') || '');
    } else if (act === 'relrc') {
      relrc(el.getAttribute('data-song-id') || '');
    } else if (act === 'nm-recent') {
      applyRecent(el.getAttribute('data-q') || '');
    } else if (act === 'wish-del') {
      removeWish(el.getAttribute('data-id') || '');
    } else if (act === 'wish-from-q') {
      addWish(el.getAttribute('data-q') || '');
    }
  }

  function applyRecent(q) {
    if (!mounted || !st || !q) return;
    st.plaza.q = q;
    st.plaza.searched = '';
    if (refs.nmQ) {
      refs.nmQ.value = q;
      refs.nmQ.focus();
    }
    var trimmed = q.trim();
    if (trimmed.length >= 2) {
      runSearch();
      return;
    }
    st.plaza.users = [];
    st.plaza.usersError = '';
    st.plaza.usersLoading = false;
    renderPlazaResults();
  }

  function onContentKey(e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    var userEl = e.target.closest ? e.target.closest('[data-act="nm-user"]') : null;
    if (userEl) {
      e.preventDefault();
      e.stopPropagation();
      toggleUser(userEl.getAttribute('data-uid') || '');
      return;
    }
    var el = e.target.closest ? e.target.closest('[data-act="play"]') : null;
    if (!el) return;
    e.preventDefault();
    e.stopPropagation();
    st.queue = st.visibleIds.slice();
    playId(el.getAttribute('data-id'), 'toggle');
  }

  function onImgError(e) {
    var t = e.target;
    if (t && t.classList && t.classList.contains('mu-cov-img')) {
      t.classList.add('mu-imgfail');
    }
  }

  function onSearchInput() {
    st.query = refs.search.value || '';
    refs.searchClear.hidden = !st.query;
    renderContent();
  }

  function setView(view) {
    var matched = false;
    for (var i = 0; i < VIEWS.length; i++) {
      if (VIEWS[i].key === view) {
        st.view = view;
        matched = true;
        break;
      }
    }
    if (!matched) return;
    st.tracksPid = '';
    if (st.tracksPoll) {
      window.clearTimeout(st.tracksPoll);
      st.tracksPoll = 0;
    }
    writeLS(LS_VIEW, st.view);
    if (st.query) {
      st.query = '';
      refs.search.value = '';
      refs.searchClear.hidden = true;
    }
    renderNav();
    renderContent();
    if (refs.content) refs.content.scrollTop = 0;
    if (st.view === 'plaza') loadPlaylists();
    schedulePoll();
  }

  function playAll(ids) {
    var playable = [];
    for (var i = 0; i < ids.length; i++) {
      if (st.byId[ids[i]]) playable.push(ids[i]);
    }
    if (!playable.length) {
      toast('这里还没有能播的歌');
      return;
    }
    st.queue = playable.slice();
    playId(playable[0], 'force');
  }

  function addToQueue(id) {
    if (!st.byId[id]) return;
    for (var i = 0; i < st.queue.length; i++) {
      if (st.queue[i] === id) {
        toast('已经在播放列表里了');
        return;
      }
    }
    st.queue.push(id);
    toast('已加入播放列表（' + st.queue.length + ' 首）');
  }

  function toggleFav(id) {
    if (!id) return;
    if (st.favs[id]) {
      delete st.favs[id];
      toast('已取消收藏');
    } else {
      st.favs[id] = true;
      toast('已收藏');
    }
    persistFavs();
    syncFavButtons(id);
    renderNav();
    if (st.view === 'fav') renderContent();
  }

  function onKeyDown(e) {
    if (!mounted || !root) return;
    if (e.defaultPrevented || e.ctrlKey || e.metaKey || e.altKey) return;

    if (e.key === 'Escape' && lyrOpen) {
      e.preventDefault();
      if (refs.npMenu && !refs.npMenu.hidden) {
        toggleNpMenu(false);
        return;
      }
      closeLyrics();
      return;
    }

    var t = e.target;
    var tag = t && t.tagName ? String(t.tagName).toUpperCase() : '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' ||
        (t && t.isContentEditable)) return;

    if (root.offsetParent === null && root.getClientRects().length === 0) return;

    if (e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar') {
      if (e.repeat) return;
      // 焦点在按钮上时交给浏览器原生点击（播放键、导航都能正常工作）
      if (tag === 'BUTTON') return;
      e.preventDefault();
      togglePlay();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      seekBy(-5);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      seekBy(5);
    }
  }

  /* ------------------------------------------------------------
     我的歌单 / 歌单广场
     ------------------------------------------------------------ */
  var PL_RANK = { running: 0, pending: 1, paused: 2, error: 3, saved: 4, done: 5 };

  function plRank(state) {
    return PL_RANK[state] == null ? 5 : PL_RANK[state];
  }

  function fetchJSON(url, opt) {
    return fetch(url, opt || {}).then(function (res) {
      if (!res.ok) {
        var err = new Error('HTTP ' + res.status);
        err.status = res.status;
        throw err;
      }
      return res.json();
    });
  }

  function sortPlaylists() {
    return st.plItems.slice().sort(function (a, b) {
      var d = plRank(a.state) - plRank(b.state);
      if (d) return d;
      var av = a.added_at || '';
      var bv = b.added_at || '';
      if (av === bv) return 0;
      return av < bv ? 1 : -1;
    });
  }

  function anyRunning() {
    for (var i = 0; i < st.plItems.length; i++) {
      if (st.plItems[i].state === 'running') return true;
    }
    return false;
  }

  /* ------------------------------ 拉 / 写歌单数据 ------------------------------ */

  function loadPlaylists() {
    if (!mounted) return Promise.resolve();
    var seq = ++plSeq;
    return fetchJSON(API_PLAYLIST + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== plSeq) return;
        st.plError = '';
        applyPlaylists(data || {});
      })
      .catch(function () {
        if (!mounted || !st || seq !== plSeq) return;
        st.plError = st.plItems.length ? '' : '歌单服务没响应';
        if (!st.plItems.length) renderMine();
      });
  }

  function normalizePlaylist(raw) {
    var state = String(raw.state || 'pending');
    if (!PL_RANK.hasOwnProperty(state)) state = 'pending';
    return {
      pid: String(raw.pid == null ? '' : raw.pid),
      uid: String(raw.uid == null ? '' : raw.uid),
      name: raw.name ? String(raw.name) : '未命名歌单',
      cover: raw.cover ? String(raw.cover) : '',
      creator: raw.creator ? String(raw.creator) : '',
      state: state,
      total: Math.max(0, Number(raw.total) || 0),
      done: Math.max(0, Number(raw.done) || 0),
      ok: Math.max(0, Number(raw.ok) || 0),
      failed: Math.max(0, Number(raw.failed) || 0),
      skipped: Math.max(0, Number(raw.skipped) || 0),
      current: raw.current ? String(raw.current) : '',
      added_at: raw.added_at ? String(raw.added_at) : '',
      error: raw.error ? String(raw.error) : ''
    };
  }

  function applyPlaylists(data) {
    var raw = Array.isArray(data.items) ? data.items : [];
    var prev = st.plByPid;
    var items = [];
    var byPid = {};
    var finished = false;

    for (var i = 0; i < raw.length; i++) {
      if (!raw[i] || typeof raw[i] !== 'object') continue;
      var it = normalizePlaylist(raw[i]);
      if (!it.pid) continue;
      var old = prev[it.pid];
      if (old && old.state === 'running' && it.state === 'done') finished = true;
      items.push(it);
      byPid[it.pid] = it;
    }

    st.plItems = items;
    st.plByPid = byPid;
    st.plLoaded = true;
    renderMine();
    if (finished) scheduleLibraryReload();
    schedulePoll();
  }

  function scheduleLibraryReload() {
    if (libReloadTimer) window.clearTimeout(libReloadTimer);
    libReloadTimer = window.setTimeout(function () {
      libReloadTimer = null;
      if (!mounted) return;
      loadData(false);
    }, 1200);
  }

  /* ------------------------------ 轮询 ------------------------------ */

  function stopPoll() {
    if (pollTimer) {
      window.clearTimeout(pollTimer);
      pollTimer = null;
    }
  }

  function schedulePoll() {
    stopPoll();
    if (!mounted || !st) return;
    if (document.hidden) return;
    var fast = anyRunning() || st.view === 'plaza';
    pollTimer = window.setTimeout(function () {
      pollTimer = null;
      if (!mounted) return;
      loadPlaylists();
      schedulePoll();
    }, fast ? POLL_FAST_MS : POLL_SLOW_MS);
  }

  function onVisibility() {
    if (!mounted || !st) return;
    if (document.hidden) {
      stopPoll();
      stopWishPoll();
      return;
    }
    loadPlaylists();
    loadWishes();
    if (!st.plaza.recentTried) loadRecent();
    schedulePoll();
    scheduleWishPoll();
  }

  /* ------------------------------ 左栏「我的歌单」 ------------------------------ */

  function renderMine() {
    if (!refs.mineList || !st) return;
    var listEl = refs.mineList;
    var order = sortPlaylists();
    var hint = listEl.querySelector('.mu-mine-empty');

    if (!order.length) {
      for (var pid in mineRefs) {
        if (!mineRefs.hasOwnProperty(pid)) continue;
        var dead = mineRefs[pid];
        if (dead.row.parentNode) dead.row.parentNode.removeChild(dead.row);
      }
      mineRefs = {};
      var tip = st.plError ? '歌单服务没响应' : '还没收藏歌单';
      listEl.innerHTML = '<div class="mu-mine-empty">' + esc(tip) + '</div>' +
        '<button type="button" class="mu-mine-go" data-act="go-plaza">' + svg('globe') + '去歌单广场</button>';
      return;
    }

    if (hint) listEl.innerHTML = '';

    var seen = {};
    var prevRow = null;
    for (var i = 0; i < order.length; i++) {
      var it = order[i];
      seen[it.pid] = true;
      var rec = mineRefs[it.pid];
      if (!rec) rec = createMineRow(it);
      updateMineRow(rec, it);
      var ref = prevRow ? prevRow.nextSibling : listEl.firstChild;
      if (ref !== rec.row) listEl.insertBefore(rec.row, ref);
      prevRow = rec.row;
    }

    for (var key in mineRefs) {
      if (!mineRefs.hasOwnProperty(key) || seen[key]) continue;
      var gone = mineRefs[key];
      if (gone.row.parentNode) gone.row.parentNode.removeChild(gone.row);
      delete mineRefs[key];
    }
  }

  function createMineRow(it) {
    var row = document.createElement('div');
    row.className = 'mu-plitem';
    row.setAttribute('data-pid', it.pid);
    row.setAttribute('data-act', 'pl-open');
    row.setAttribute('role', 'button');
    row.setAttribute('tabindex', '0');
    row.innerHTML =
      '<div class="mu-plitem-top">' +
        '<span class="mu-plstate" aria-hidden="true">' +
          svg('disc', 'mu-ico-run') + svg('check', 'mu-ico-ok') +
        '</span>' +
        '<span class="mu-plname"></span>' +
        '<button type="button" class="mu-pl-del" data-act="pl-del" data-pid="' + esc(it.pid) + '" title="移出我的歌单">' +
          svg('close') + '</button>' +
      '</div>' +
      '<div class="mu-plbar"><span class="mu-plfill"></span></div>' +
      '<div class="mu-plmeta"><span class="mu-plnow"></span><span class="mu-plcount"></span></div>';

    var rec = {
      row: row,
      name: row.querySelector('.mu-plname'),
      now: row.querySelector('.mu-plnow'),
      count: row.querySelector('.mu-plcount'),
      fill: row.querySelector('.mu-plfill'),
      lastDone: -1,
      width: -1
    };

    row.addEventListener('animationend', function (e) {
      if (e.animationName === 'mu-pl-flash') row.classList.remove('is-flash');
    });

    mineRefs[it.pid] = rec;
    return rec;
  }

  function updateMineRow(rec, it) {
    var row = rec.row;
    var state = it.state;

    if (row.getAttribute('data-state') !== state) row.setAttribute('data-state', state);
    var saved = state === 'saved' || state === 'done';
    var stateText = state === 'running' ? '正在抓取' : state === 'pending' ? '排队中'
      : state === 'paused' ? '已暂停' : state === 'error' ? '出错了'
      : saved ? '已收藏' : '已完成';
    if (row.getAttribute('aria-label') !== it.name + '，' + stateText) {
      row.setAttribute('aria-label', it.name + '，' + stateText);
    }
    var isOpen = st.view === 'tracks' && st.tracksPid === it.pid;
    if (row.classList.contains('is-open') !== isOpen) row.classList.toggle('is-open', isOpen);

    if (rec.name.textContent !== it.name) {
      rec.name.textContent = it.name;
      rec.name.title = it.name;
    }

    var indet = state === 'running' && it.total <= 0;
    var pct;
    if (saved) pct = 100;
    else if (it.total > 0) pct = Math.min(100, Math.round((it.done / it.total) * 100));
    else pct = indet ? 100 : 0;

    if (row.getAttribute('data-indet') !== (indet ? '1' : '0')) {
      row.setAttribute('data-indet', indet ? '1' : '0');
    }
    if (rec.width !== pct) {
      rec.fill.style.width = pct + '%';
      rec.width = pct;
    }

    var trackRec = st.plTracks[it.pid];
    var totalShown = trackRec && trackRec.total > 0 ? trackRec.total : it.total;
    var countText;
    if (saved) countText = totalShown > 0 ? totalShown + ' 首' : '已收藏';
    else if (it.total > 0) countText = it.done + '/' + it.total;
    else countText = String(it.done);
    if (rec.count.textContent !== countText) rec.count.textContent = countText;

    var nowText;
    if (saved) nowText = '点开挑歌，单曲下载';
    else if (state === 'running') nowText = it.current || '正在准备…';
    else if (state === 'pending') nowText = '排队等开始';
    else if (state === 'paused') nowText = '已暂停';
    else if (state === 'error') nowText = it.error || '出错了';
    else nowText = '共 ' + it.total + ' 首' + (it.failed ? ' ・ 失败 ' + it.failed : '');
    if (rec.now.textContent !== nowText) {
      rec.now.textContent = nowText;
      rec.now.title = nowText;
    }

    if (rec.lastDone >= 0 && state === 'running' && it.done > rec.lastDone) {
      row.classList.remove('is-flash');
      void row.offsetWidth;
      row.classList.add('is-flash');
    }
    rec.lastDone = it.done;
  }

  function removePlaylist(pid) {
    if (!pid) return;
    fetchJSON(API_PLAYLIST + '?pid=' + encodeURIComponent(pid), { method: 'DELETE' })
      .then(function () {
        if (!mounted) return;
        delete st.plTracks[pid];
        if (st.tracksPid === pid) {
          st.tracksPid = '';
          st.view = 'plaza';
          renderNav();
          renderContent();
        }
        toast('已移出「我的歌单」');
        loadPlaylists();
      })
      .catch(function () {
        if (!mounted) return;
        toast('移除失败，服务没响应');
      });
  }

  /* ------------------------------ 收藏歌单的曲目页 ------------------------------ */

  function normTrack(raw) {
    var fee = Number(raw.fee) || 0;
    return {
      id: String(raw.id == null ? '' : raw.id),
      title: raw.name ? String(raw.name) : (raw.title ? String(raw.title) : '未知歌曲'),
      artist: raw.artist ? String(raw.artist) : '',
      album: raw.album ? String(raw.album) : '',
      duration_s: Number(raw.duration_s) || 0,
      cover_url: raw.cover_url ? String(raw.cover_url) : '',
      vip: raw.vip === true || fee === 1,
      downloaded: raw.downloaded === true
    };
  }

  function openTracks(pid) {
    if (!mounted || !st || !pid) return;
    st.tracksPid = pid;
    st.view = 'tracks';
    st.query = '';
    if (refs.search) refs.search.value = '';
    if (refs.searchClear) refs.searchClear.hidden = true;
    renderNav();
    renderContent();
    if (refs.content) refs.content.scrollTop = 0;
    loadTracks(pid);
    schedulePoll();
  }

  function trackFind(rec, id) {
    if (!rec || !rec.items) return null;
    for (var i = 0; i < rec.items.length; i++) {
      if (rec.items[i].id === id) return rec.items[i];
    }
    return null;
  }

  function loadTracks(pid, force) {
    if (!mounted || !st || !pid) return;
    var rec = st.plTracks[pid];
    if (!rec) {
      rec = {
        pid: pid, items: [], queued: {}, total: 0,
        loading: false, loaded: false, error: '', offline: false,
        cached_at: '', seq: 0, lastDownloaded: 0
      };
      st.plTracks[pid] = rec;
    }
    if (rec.loading || (rec.loaded && !force)) return;

    rec.loading = true;
    rec.error = '';
    var seq = ++rec.seq;
    if (st.view === 'tracks' && st.tracksPid === pid) renderTracks();

    fetchJSON(API_NM_TRACKS + '?pid=' + encodeURIComponent(pid) + '&t=' + Date.now(),
      { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || rec.seq !== seq) return;
        data = data || {};
        var raw = Array.isArray(data.items) ? data.items : [];
        rec.items = raw.map(normTrack).filter(function (x) { return x.id; });
        rec.total = Number(data.total) || rec.items.length;
        rec.offline = !!data.offline;
        rec.cached_at = data.cached_at ? String(data.cached_at) : '';
        rec.loading = false;
        rec.loaded = true;
        rec.error = '';

        // 排队中的歌可能已经下好了：清掉排队标记，顺手刷新本地曲库
        var gotNew = false;
        var dl = 0;
        for (var i = 0; i < rec.items.length; i++) {
          if (rec.items[i].downloaded) {
            dl++;
            if (rec.queued[rec.items[i].id]) {
              delete rec.queued[rec.items[i].id];
              gotNew = true;
            }
          }
        }
        var first = rec.lastDownloaded === 0;
        rec.lastDownloaded = dl;
        if (!first && gotNew) scheduleLibraryReload();

        if (st.view === 'tracks' && st.tracksPid === pid) {
          renderTracks();
          renderMine();
        }
        scheduleTracksPoll(pid);
      })
      .catch(function (err) {
        if (!mounted || !st || rec.seq !== seq) return;
        rec.loading = false;
        rec.error = (err && err.status === 404)
          ? '服务端还没开曲目接口（/api/netease/playlist/tracks）'
          : '曲目没拉到，服务没响应';
        if (st.view === 'tracks' && st.tracksPid === pid) renderTracks();
      });
  }

  function scheduleTracksPoll(pid) {
    if (!st) return;
    if (st.tracksPoll) {
      window.clearTimeout(st.tracksPoll);
      st.tracksPoll = 0;
    }
    var rec = st.plTracks[pid];
    if (!rec) return;
    var need = false;
    for (var id in rec.queued) {
      if (!rec.queued.hasOwnProperty(id) || !rec.queued[id]) continue;
      var tr = trackFind(rec, id);
      if (tr && !tr.downloaded) { need = true; break; }
      delete rec.queued[id];
    }
    if (!need) return;
    st.tracksPoll = window.setTimeout(function () {
      st.tracksPoll = 0;
      if (!mounted || !st) return;
      if (st.view !== 'tracks' || st.tracksPid !== pid) return;
      loadTracks(pid, true);
    }, 6000);
  }

  function downloadTrack(id) {
    if (!mounted || !st || !id) return;
    var pid = st.tracksPid;
    var rec = st.plTracks[pid];
    var tr = trackFind(rec, id);
    if (!rec || !tr || tr.vip || tr.downloaded || localHasTrack(tr) || rec.queued[id]) return;
    var pl = st.plByPid[pid] || {};
    rec.queued[id] = true;
    renderTracks();

    fetchJSON(API_MUSIC_DL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        song_id: tr.id,
        name: tr.title,
        artist: tr.artist,
        album: tr.album,
        duration_s: tr.duration_s,
        playlist_name: pl.name || '',
        playlist_pid: pid
      })
    })
      .then(function (res) {
        if (!mounted || !st) return;
        res = res || {};
        if (res.ok === false) {
          delete rec.queued[id];
          toast(res.msg || res.error || '排不进去，服务没响应');
          renderTracks();
          return;
        }
        toast(res.msg || '已排队，下好会出现在「全部歌曲」里');
        scheduleTracksPoll(pid);
      })
      .catch(function () {
        if (!mounted || !st) return;
        delete rec.queued[id];
        toast('下载请求没发出去，服务没响应');
        renderTracks();
      });
  }

  // 单曲补歌词：只对已经有 song_id 的本地歌有效（老文件多半没记）
  function relrc(songId) {
    if (!mounted || !st || !songId) return;
    toast('正在补歌词…');
    fetchJSON(API_MUSIC_RELRC, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ song_id: songId })
    })
      .then(function (res) {
        if (!mounted || !st) return;
        res = res || {};
        if (res.ok === false) {
          toast(res.error || res.msg || '没补上');
          return;
        }
        toast(res.msg || '歌词补好了');
        scheduleLibraryReload();
      })
      .catch(function (err) {
        if (!mounted || !st) return;
        if (err && err.status === 404) toast('服务端还没开补歌词接口');
        else toast('补歌词请求没发出去，服务没响应');
      });
  }

  // 老歌的 meta 里没有 song_id，接口按 id 判断会显示「未下载」。
  // 这里拿标题+歌手和本地曲库对一遍，避免页面上一排「未下载」其实文件都在。
  var localKeySig = '';
  var localKeyMap = {};

  function localKeyOf(s) {
    return String(s == null ? '' : s).toLowerCase()
      .replace(/[\s·・,，.。\\/|_\-—–()（）\[\]【】'"]/g, '');
  }

  function ensureLocalKeys() {
    var sig = (st.items.length + '|' + (st.generated || ''));
    if (sig === localKeySig) return localKeyMap;
    localKeySig = sig;
    localKeyMap = {};
    for (var i = 0; i < st.items.length; i++) {
      var it = st.items[i];
      localKeyMap[localKeyOf(it.title) + '|' + localKeyOf(it.artist)] = true;
    }
    return localKeyMap;
  }

  function localHasTrack(tr) {
    var keys = ensureLocalKeys();
    return !!keys[localKeyOf(tr.title) + '|' + localKeyOf(tr.artist)];
  }

  function tracksHeaderHTML(pl, rec) {
    var n = rec.items ? rec.items.length : 0;
    var dl = 0;
    var vip = 0;
    for (var i = 0; i < n; i++) {
      if (rec.items[i].downloaded || localHasTrack(rec.items[i])) dl++;
      if (rec.items[i].vip) vip++;
    }
    return '<div class="mu-trhead">' +
      '<button type="button" class="mu-trback" data-act="pl-back" title="返回歌单广场">' + svg('chevronLeft') + '</button>' +
      '<div class="mu-trmain">' +
        '<h2>' + esc(pl.name || '歌单') + '</h2>' +
        '<p>共 <b>' + (rec.total || n) + '</b> 首 ・ 已下载 <b>' + dl + '</b>' +
          (vip ? ' ・ <span class="mu-trvip">VIP ' + vip + ' 首</span>' : '') +
          ' ・ 收藏于 ' + esc(pl.added_at || '') + '</p>' +
      '</div>' +
      '<button type="button" class="mu-btn mu-btn-ghost mu-trrefresh" data-act="tracks-reload"' +
        (rec.loading ? ' disabled' : '') + '>' + svg('refresh') + '刷新</button>' +
    '</div>';
  }

  function trackRowHTML(tr, idx, rec) {
    var queued = !!(rec.queued && rec.queued[tr.id]);
    var isDl = !!(tr.downloaded || localHasTrack(tr));
    var state;
    var cls = '';
    if (isDl) { state = '已下载'; cls = ' is-dl'; }
    else if (queued) { state = '排队中'; cls = ' is-queued'; }
    else if (tr.vip) { state = 'VIP'; cls = ' is-vip'; }
    else { state = '未下载'; }

    var label = isDl ? '已下' : queued ? '排队中' : tr.vip ? 'VIP' : '下载';
    var disabled = (isDl || queued || tr.vip) ? ' disabled' : '';
    var action = '<button type="button" class="mu-tdl' + (isDl ? ' is-done' : '') + '"' +
      ' data-act="track-dl" data-id="' + esc(tr.id) + '"' + disabled + '>' +
      (isDl ? svg('check') : svg('download')) + label + '</button>';

    return '<div class="mu-trow' + cls + '" data-id="' + esc(tr.id) + '">' +
      '<div class="mu-tcell mu-tidx">' + (idx + 1) + '</div>' +
      '<div class="mu-tcell mu-ttitle">' +
        '<span class="mu-tcover">' + remoteCover(tr.cover_url, tr.title) + '</span>' +
        '<span class="mu-tname" title="' + esc(tr.title) + '">' + esc(tr.title) + '</span>' +
      '</div>' +
      '<div class="mu-tcell mu-tartist">' + esc(tr.artist || '未知歌手') + '</div>' +
      '<div class="mu-tcell mu-talbum">' + esc(tr.album || '—') + '</div>' +
      '<div class="mu-tcell mu-tdur">' + (tr.duration_s > 0 ? fmtTime(tr.duration_s) : '--:--') + '</div>' +
      '<div class="mu-tcell mu-tstate">' +
        (tr.vip && !isDl ? '<span class="mu-tchip is-vip">VIP</span>' : '') +
        (isDl ? '<span class="mu-tchip is-dl">已下载</span>' : '') +
        (queued ? '<span class="mu-tchip is-queued">排队中</span>' : '') +
        (!tr.vip && !isDl && !queued ? '<span class="mu-tchip">可下载</span>' : '') +
      '</div>' +
      '<div class="mu-tcell mu-tact">' + action + '</div>' +
    '</div>';
  }

  function renderTracks() {
    if (!refs.content || !st) return;
    var pid = st.tracksPid;
    var pl = st.plByPid[pid];
    var rec = pid ? st.plTracks[pid] : null;

    if (!pid || !pl) {
      if (!st.plLoaded) {
        refs.content.innerHTML = loadingMarkup('正在读取歌单…');
        return;
      }
      refs.content.innerHTML = emptyMarkup(
        '这个歌单不在了',
        '可能已经被移出「我的歌单」。去歌单广场重新收藏一个吧。',
        false
      ) + '<div class="mu-trgoback"><button type="button" class="mu-btn" data-act="pl-back">去歌单广场</button></div>';
      return;
    }

    if (!rec) {
      refs.content.innerHTML = loadingMarkup('正在拿歌单曲目…');
      loadTracks(pid);
      return;
    }

    var head = tracksHeaderHTML(pl, rec);
    if (rec.loading && !rec.loaded) {
      refs.content.innerHTML = head + loadingMarkup('正在拿歌单曲目…');
      return;
    }
    if (rec.error) {
      refs.content.innerHTML = head + emptyMarkup('曲目没拉到', rec.error, false) +
        '<div class="mu-trgoback"><button type="button" class="mu-btn" data-act="tracks-reload">重新读取</button></div>';
      return;
    }
    if (!rec.items.length) {
      refs.content.innerHTML = head + emptyMarkup(
        '这个歌单没有曲目',
        '可能是空歌单，或者接口没给到内容。',
        false
      );
      return;
    }

    var rows = rec.items.map(function (tr, i) { return trackRowHTML(tr, i, rec); }).join('');
    var offline = rec.offline
      ? '<div class="mu-tr-offline">断网中，这是上次缓存的曲目列表' +
        (rec.cached_at ? '（' + esc(rec.cached_at) + '）' : '') + '</div>'
      : '';
    var colHead = '<div class="mu-trow mu-trow-head">' +
      '<div class="mu-tcell mu-tidx">#</div>' +
      '<div class="mu-tcell">歌曲</div>' +
      '<div class="mu-tcell mu-tartist">歌手</div>' +
      '<div class="mu-tcell mu-talbum">专辑</div>' +
      '<div class="mu-tcell mu-tdur">时长</div>' +
      '<div class="mu-tcell mu-tstate">状态</div>' +
      '<div class="mu-tcell mu-tact">操作</div>' +
    '</div>';

    refs.content.innerHTML = head + offline +
      '<div class="mu-trtable">' + colHead + rows + '</div>' +
      '<div class="mu-trfoot">下载会一首一首排队，下好自动出现在「全部歌曲」，不会整单塞进队列。</div>';
  }

  /* ------------------------------ 歌单广场 ------------------------------ */

  function renderPlaza() {
    if (!refs.content || !st) return;
    ensurePlazaShell();
    if (!st.plaza.recentTried && !st.plaza.recentLoading) loadRecent();
    var q = (st.plaza.q || '').trim();
    if (q.length >= 2 && q !== st.plaza.searched) {
      runSearch();
      return;
    }
    renderPlazaResults();
    renderWish();
  }

  function ensurePlazaShell() {
    if (!refs.content) return;
    if (refs.content.querySelector('#mu-nm-q')) {
      cachePlazaRefs();
      return;
    }

    refs.content.innerHTML =
      '<div class="mu-plaza">' +
        '<div class="mu-plaza-hero">' +
          '<span class="mu-hero-kicker">NETEASE PLAYLIST</span>' +
          '<h2>歌单广场</h2>' +
          '<p>收藏歌单当找歌目录，点开挑歌，一首一首下；不会整单塞进下载队列。</p>' +
          '<div class="mu-nm-search" id="mu-nm-search">' + svg('search') +
            '<input id="mu-nm-q" type="search" placeholder="搜歌单名，或网易云用户名" autocomplete="off" spellcheck="false" aria-label="搜歌单名或网易云用户名">' +
            '<span class="mu-nm-spin" aria-hidden="true"></span>' +
          '</div>' +
        '</div>' +
        '<section class="mu-wish-box">' +
          '<div class="mu-wish-head">' +
            '<h3>离线点歌</h3>' +
            '<span class="mu-wish-hint" id="mu-wish-hint">断网也能先记个名字，联网后自动搜来下</span>' +
          '</div>' +
          '<div class="mu-wish-list" id="mu-wish-list"></div>' +
        '</section>' +
        '<div class="mu-nm-res" id="mu-nm-res"></div>' +
      '</div>';

    cachePlazaRefs();

    if (refs.nmQ) {
      refs.nmQ.value = st.plaza.q || '';
      refs.nmQ.addEventListener('input', onNmInput);
      refs.nmQ.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (debounceTimer) {
          window.clearTimeout(debounceTimer);
          debounceTimer = null;
        }
        runSearch();
      });
    }
  }

  function cachePlazaRefs() {
    if (!refs.content) return;
    refs.nmSearch = refs.content.querySelector('#mu-nm-search');
    refs.nmQ = refs.content.querySelector('#mu-nm-q');
    refs.nmRes = refs.content.querySelector('#mu-nm-res');
    refs.wishList = refs.content.querySelector('#mu-wish-list');
    refs.wishHint = refs.content.querySelector('#mu-wish-hint');
  }

  function onNmInput() {
    if (!refs.nmQ || !st) return;
    st.plaza.q = refs.nmQ.value;
    if (debounceTimer) {
      window.clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    var q = st.plaza.q.trim();
    if (q.length < 2) {
      resetSearchState();
      renderPlazaResults();
      return;
    }
    st.plaza.usersLoading = true;
    st.plaza.plSearchLoading = true;
    st.plaza.usersError = '';
    st.plaza.plSearchError = '';
    st.plaza.plSearchErrMsg = '';
    renderPlazaResults();
    debounceTimer = window.setTimeout(function () {
      debounceTimer = null;
      runSearch();
    }, SEARCH_DEBOUNCE_MS);
  }

  function resetSearchState() {
    var pz = st.plaza;
    pz.users = [];
    pz.usersError = '';
    pz.usersLoading = false;
    pz.usersOffline = false;
    pz.usersCachedAt = '';
    pz.plSearch = [];
    pz.plSearchLoading = false;
    pz.plSearchError = '';
    pz.plSearchErrMsg = '';
    pz.plSearchOffline = false;
    pz.plSearchCachedAt = '';
    pz.searched = '';
    pz.selectedUid = '';
    pz.pls = [];
    pz.plsError = '';
    pz.plsLoading = false;
  }

  function normalizeUsers(data) {
    var raw = Array.isArray(data.items) ? data.items : [];
    var out = [];
    for (var i = 0; i < raw.length; i++) {
      var u = raw[i];
      if (!u || typeof u !== 'object' || u.uid == null) continue;
      out.push({
        uid: String(u.uid),
        name: u.name ? String(u.name) : '未命名用户',
        avatar: u.avatar ? String(u.avatar) : '',
        signature: u.signature ? String(u.signature) : '',
        playlist_count: Math.max(0, Number(u.playlist_count) || 0)
      });
    }
    return out;
  }

  function normalizePls(data, uid) {
    var raw = Array.isArray(data.playlists) ? data.playlists : [];
    var out = [];
    for (var i = 0; i < raw.length; i++) {
      var p = raw[i];
      if (!p || typeof p !== 'object' || p.pid == null) continue;
      out.push({
        pid: String(p.pid),
        uid: p.uid != null ? String(p.uid) : String(uid || ''),
        name: p.name ? String(p.name) : '未命名歌单',
        track_count: Math.max(0, Number(p.track_count) || 0),
        cover_url: p.cover_url ? String(p.cover_url) : '',
        creator: p.creator ? String(p.creator) : '',
        play_count: Math.max(0, Number(p.play_count) || 0)
      });
    }
    return out;
  }

  function normalizePlSearch(data) {
    var raw = Array.isArray(data.items) ? data.items : [];
    var out = [];
    for (var i = 0; i < raw.length; i++) {
      var p = raw[i];
      if (!p || typeof p !== 'object' || p.pid == null) continue;
      out.push({
        pid: String(p.pid),
        uid: p.uid != null ? String(p.uid) : '',
        name: p.name ? String(p.name) : '未命名歌单',
        track_count: Math.max(0, Number(p.track_count) || 0),
        cover_url: p.cover_url ? String(p.cover_url) : '',
        creator: p.creator ? String(p.creator) : '',
        play_count: Math.max(0, Number(p.play_count) || 0)
      });
    }
    return out;
  }

  // 两个请求同时发，谁先回来谁先画；一个挂了不影响另一个
  function runSearch() {
    if (!mounted || !st) return;
    var q = (st.plaza.q || '').trim();
    if (q.length < 2) return;
    st.plaza.searched = q;
    searchUsers(q);
    searchPlaylists(q);
  }

  function searchUsers(q) {
    var seq = ++nmUserSeq;
    st.plaza.usersLoading = true;
    st.plaza.usersError = '';
    renderPlazaResults();

    fetchJSON(API_NM_USER + '?q=' + encodeURIComponent(q))
      .then(function (data) {
        if (!mounted || !st || seq !== nmUserSeq) return;
        data = data || {};
        st.plaza.usersLoading = false;
        st.plaza.users = normalizeUsers(data);
        st.plaza.usersOffline = !!data.offline;
        st.plaza.usersCachedAt = data.cached_at ? String(data.cached_at) : '';
        st.plaza.searchError = data.error ? String(data.error) : '';
        if (st.plaza.selectedUid) {
          var keep = false;
          for (var i = 0; i < st.plaza.users.length; i++) {
            if (st.plaza.users[i].uid === st.plaza.selectedUid) keep = true;
          }
          if (!keep) {
            st.plaza.selectedUid = '';
            st.plaza.pls = [];
            st.plaza.plsError = '';
          }
        }
        renderPlazaResults();
      })
      .catch(function () {
        if (!mounted || !st || seq !== nmUserSeq) return;
        st.plaza.usersLoading = false;
        st.plaza.users = [];
        st.plaza.usersError = '用户没搜到，服务没响应';
        st.plaza.usersOffline = false;
        st.plaza.usersCachedAt = '';
        st.plaza.searchError = '';
        renderPlazaResults();
      });
  }

  function searchPlaylists(q) {
    var seq = ++nmPlSearchSeq;
    st.plaza.plSearchLoading = true;
    st.plaza.plSearchError = '';
    st.plaza.plSearchErrMsg = '';
    renderPlazaResults();

    fetchJSON(API_NM_PLSEARCH + '?q=' + encodeURIComponent(q))
      .then(function (data) {
        if (!mounted || !st || seq !== nmPlSearchSeq) return;
        data = data || {};
        st.plaza.plSearchLoading = false;
        st.plaza.plSearch = normalizePlSearch(data);
        st.plaza.plSearchOffline = !!data.offline;
        st.plaza.plSearchCachedAt = data.cached_at ? String(data.cached_at) : '';
        st.plaza.plSearchErrMsg = data.error ? String(data.error) : '';
        renderPlazaResults();
        loadRecent();
      })
      .catch(function () {
        if (!mounted || !st || seq !== nmPlSearchSeq) return;
        st.plaza.plSearchLoading = false;
        st.plaza.plSearch = [];
        st.plaza.plSearchOffline = false;
        st.plaza.plSearchCachedAt = '';
        st.plaza.plSearchError = '歌单没搜到，服务没响应';
        renderPlazaResults();
      });
  }

  function shortTime(text) {
    var s = String(text == null ? '' : text);
    var m = /(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2})/.exec(s);
    if (m) return m[1].replace('T', ' ');
    return s;
  }

  function offlineBar(cachedAt) {
    var when = shortTime(cachedAt);
    var tail = when ? '这是 ' + when + ' 搜到的结果' : '这是上次联网时存下的结果';
    return '<div class="mu-nm-offline" role="status">' +
      '<span class="mu-nm-offline-dot" aria-hidden="true"></span>' +
      '断网中，' + esc(tail) + '，加歌单会先排队。' +
      '</div>';
  }

  function renderPlazaResults() {
    if (!refs.nmRes || !st) return;
    var pz = st.plaza;
    if (refs.nmQ && refs.nmQ.value !== pz.q) refs.nmQ.value = pz.q;

    var loading = !!pz.usersLoading || !!pz.plSearchLoading;
    if (refs.nmSearch) refs.nmSearch.classList.toggle('is-loading', loading);

    var q = (pz.q || '').trim();

    if (!q) {
      refs.nmRes.innerHTML = '<div class="mu-nm-tip">搜歌单名，或者搜网易云用户名。</div>' + recentHTML();
      return;
    }
    if (q.length < 2) {
      refs.nmRes.innerHTML = '<div class="mu-nm-tip">再多打一个字就能搜了。</div>' + recentHTML();
      return;
    }

    var html = '';
    var offline = pz.usersOffline || pz.plSearchOffline;
    if (offline) html += offlineBar(pz.usersCachedAt || pz.plSearchCachedAt);

    var empty = !pz.plSearch.length && !pz.users.length;

    if (loading && empty) {
      html += loadingMarkup('正在找歌单和用户…');
    } else {
      if (pz.plSearch.length) {
        html += '<section class="mu-nm-group">' +
          '<h4 class="mu-nm-group-h">歌单<em>' + pz.plSearch.length + '</em></h4>' +
          '<div class="mu-nm-pls">' + pz.plSearch.map(plCardHTML).join('') + '</div>' +
          '</section>';
      } else if (pz.plSearchError) {
        html += '<div class="mu-nm-tip is-err">' + esc(pz.plSearchError) + '</div>';
      } else if (!pz.plSearchLoading && pz.plSearchErrMsg) {
        html += '<div class="mu-nm-tip is-err">' + esc(pz.plSearchErrMsg) + '</div>';
      } else if (pz.plSearchLoading && pz.users.length) {
        html += '<div class="mu-nm-tip">歌单还在找…</div>';
      }

      if (pz.users.length) {
        html += '<section class="mu-nm-group">' +
          '<h4 class="mu-nm-group-h">用户<em>' + pz.users.length + '</em></h4>' +
          pz.users.map(userCardHTML).join('') +
          '</section>';
      } else if (pz.usersError) {
        html += '<div class="mu-nm-tip is-err">' + esc(pz.usersError) + '</div>';
      } else if (pz.usersLoading && pz.plSearch.length) {
        html += '<div class="mu-nm-tip">用户还在找…</div>';
      }
    }

    html += wishLineHTML(q);

    refs.nmRes.innerHTML = html;
  }

  function wishLineHTML(q) {
    var raw = String(q || '');
    var text = raw.replace(/\s+/g, ' ').trim();
    if (!text) return '';
    var shown = text.length > 28 ? text.slice(0, 28) + '…' : text;
    return '<div class="mu-nm-wishline">' +
      '<button type="button" class="mu-nm-wishbtn" data-act="wish-from-q" data-q="' + esc(raw) + '"' +
        (st.wish.adding ? ' disabled' : '') + '>' +
        '没有你要的？把「' + esc(shown) + '」记成离线点歌，联网自动下 →' +
      '</button>' +
    '</div>';
  }

  function recentHTML() {
    var pz = st.plaza;
    if (!pz.recent) return '';
    var chips = [];
    var seen = {};
    var kw = Array.isArray(pz.recent.keywords) ? pz.recent.keywords : [];
    var us = Array.isArray(pz.recent.users) ? pz.recent.users : [];
    var pls = Array.isArray(pz.recent.playlists) ? pz.recent.playlists : [];
    var i;

    for (i = 0; i < pls.length; i++) {
      var p = pls[i];
      if (!p || !p.q || seen[p.q]) continue;
      seen[p.q] = true;
      chips.push(recentChipHTML(String(p.q), Number(p.total) || 0));
    }
    for (i = 0; i < kw.length; i++) {
      var k = kw[i];
      if (!k || !k.q || seen[k.q]) continue;
      seen[k.q] = true;
      chips.push(recentChipHTML(String(k.q), Number(k.total) || 0));
    }
    for (i = 0; i < us.length; i++) {
      var u = us[i];
      var name = u && (u.name || u.q);
      if (!name || seen[name]) continue;
      seen[name] = true;
      chips.push(recentChipHTML(String(name), Number(u.total) || 0));
    }

    if (!chips.length) return '';
    return '<div class="mu-nm-recent">' +
      '<span class="mu-nm-recent-t">最近搜过</span>' +
      chips.join('') +
      '</div>';
  }

  function recentChipHTML(q, total) {
    return '<button type="button" class="mu-nm-chip" data-act="nm-recent" data-q="' + esc(q) + '">' +
      esc(q) + (total > 0 ? '<em>' + total + '</em>' : '') + '</button>';
  }

  function userCardHTML(u) {
    var open = !!st.plaza.selectedUid && st.plaza.selectedUid === u.uid;
    return '<div class="mu-nm-user' + (open ? ' is-open' : '') + '" data-act="nm-user" data-uid="' + esc(u.uid) + '"' +
        ' role="button" tabindex="0" aria-expanded="' + (open ? 'true' : 'false') + '">' +
        remoteCover(u.avatar, u.name, 'mu-nm-av') +
        '<div class="mu-nm-uinfo">' +
          '<span class="mu-nm-uname">' + esc(u.name) + '</span>' +
          '<span class="mu-nm-usig">' + esc(u.signature || '这个人很安静，没写签名') + '</span>' +
        '</div>' +
        '<span class="mu-nm-upls">' + u.playlist_count + ' 个歌单</span>' +
      '</div>' +
      (open ? '<div class="mu-nm-pls-wrap">' + playlistsHTML() + '</div>' : '');
  }

  function playlistsHTML() {
    var pz = st.plaza;
    if (pz.plsLoading) return loadingMarkup('正在拉这个人的歌单…');
    if (pz.plsError) return '<div class="mu-nm-tip is-err">' + esc(pz.plsError) + '</div>';
    if (!pz.pls.length) return '<div class="mu-nm-tip">这个人没有公开歌单。</div>';
    return (pz.plsOffline ? offlineBar(pz.plsCachedAt) : '') +
      '<div class="mu-nm-pls">' + pz.pls.map(plCardHTML).join('') + '</div>';
  }

  function plCardHTML(pl) {
    var busy = !!st.plaza.adding[pl.pid];
    var inLocal = !!st.plByPid[pl.pid];
    var queued = !inLocal && !!st.plaza.queued[pl.pid];
    var locked = inLocal || queued || busy;
    var label = busy ? '收藏中…' : inLocal ? '已收藏' : queued ? '已收藏' : '收藏歌单';
    var meta = pl.track_count + ' 首 ・ ' + fmtPlayCount(pl.play_count);
    return '<div class="mu-plcard">' +
      '<div class="mu-plcard-cover">' + remoteCover(pl.cover_url, pl.name) + '</div>' +
      '<div class="mu-plcard-body">' +
        '<div class="mu-plcard-name" title="' + esc(pl.name) + '">' + esc(pl.name) + '</div>' +
        (pl.creator ? '<div class="mu-plcard-by" title="' + esc(pl.creator) + '">' + esc(pl.creator) + '</div>' : '') +
        '<div class="mu-plcard-meta">' + esc(meta) + '</div>' +
        '<div class="mu-plcard-foot">' +
          '<button type="button" class="mu-pl-add' + (locked ? ' is-added' : '') + '" data-act="pl-add"' +
            ' data-uid="' + esc(pl.uid) + '" data-pid="' + esc(pl.pid) + '"' +
            ' data-name="' + esc(pl.name) + '" data-cover="' + esc(pl.cover_url) + '"' +
            (locked ? ' disabled' : '') + '>' +
            (busy ? '<span class="mu-nm-spin is-on"></span>' : svg(inLocal ? 'check' : 'plus')) + label +
          '</button>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function toggleUser(uid) {
    if (!mounted || !st || !uid) return;
    var pz = st.plaza;
    if (pz.selectedUid === uid) {
      pz.selectedUid = '';
      pz.pls = [];
      pz.plsError = '';
      pz.plsLoading = false;
      renderPlazaResults();
      return;
    }
    pz.selectedUid = uid;
    pz.pls = [];
    pz.plsError = '';
    pz.plsLoading = true;
    renderPlazaResults();

    var seq = ++nmPlSeq;
    fetchJSON(API_NM_PLAYLISTS + '?uid=' + encodeURIComponent(uid))
      .then(function (data) {
        if (!mounted || !st || seq !== nmPlSeq || st.plaza.selectedUid !== uid) return;
        data = data || {};
        st.plaza.plsLoading = false;
        st.plaza.pls = normalizePls(data, uid);
        st.plaza.plsOffline = !!data.offline;
        st.plaza.plsCachedAt = data.cached_at ? String(data.cached_at) : '';
        st.plaza.plsError = '';
        renderPlazaResults();
      })
      .catch(function () {
        if (!mounted || !st || seq !== nmPlSeq || st.plaza.selectedUid !== uid) return;
        st.plaza.plsLoading = false;
        st.plaza.pls = [];
        st.plaza.plsOffline = false;
        st.plaza.plsCachedAt = '';
        st.plaza.plsError = '歌单没拉到，服务没响应';
        renderPlazaResults();
      });
  }

  function addPlaylist(el) {
    if (!mounted || !st || !el) return;
    var pid = el.getAttribute('data-pid') || '';
    if (!pid || st.plaza.adding[pid]) return;
    var body = {
      uid: el.getAttribute('data-uid') || st.plaza.selectedUid || '',
      pid: pid,
      name: el.getAttribute('data-name') || '',
      cover: el.getAttribute('data-cover') || ''
    };
    st.plaza.adding[pid] = true;
    renderPlazaResults();

    fetchJSON(API_PLAYLIST + '/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
      .then(function (res) {
        if (!mounted || !st) return;
        res = res || {};
        delete st.plaza.adding[pid];
        if (res.ok === false) {
          toast(res.msg || '收藏不进去，服务没响应');
          renderPlazaResults();
          return;
        }
        toast(res.msg || (res.exist ? '这个歌单已经收藏过了' : '已收藏，点开挑歌，一首一首下'));
        renderPlazaResults();
        loadPlaylists().then(function () {
          if (mounted && st) openTracks(pid);
        });
      })
      .catch(function () {
        if (!mounted || !st) return;
        delete st.plaza.adding[pid];
        toast('加不进去，服务没响应');
        renderPlazaResults();
      });
  }

  /* ------------------------------ 最近搜过 ------------------------------ */

  function loadRecent() {
    if (!mounted || !st || st.plaza.recentLoading) return;
    var seq = ++recentSeq;
    st.plaza.recentLoading = true;
    fetchJSON(API_NM_RECENT)
      .then(function (data) {
        if (!mounted || !st || seq !== recentSeq) return;
        data = data || {};
        st.plaza.recentLoading = false;
        st.plaza.recentTried = true;
        st.plaza.recent = {
          keywords: Array.isArray(data.keywords) ? data.keywords : [],
          users: Array.isArray(data.users) ? data.users : [],
          playlists: Array.isArray(data.playlists) ? data.playlists : [],
          online: data.online !== false
        };
        renderPlazaResults();
      })
      .catch(function () {
        if (!mounted || !st || seq !== recentSeq) return;
        st.plaza.recentLoading = false;
        st.plaza.recentTried = true;
        renderPlazaResults();
      });
  }

  /* ------------------------------ 离线点歌 ------------------------------ */

  function wishActive() {
    for (var i = 0; i < st.wish.items.length; i++) {
      var s = st.wish.items[i].state;
      if (s === 'pending' || s === 'searching' || s === 'downloading') return true;
    }
    return false;
  }

  function stopWishPoll() {
    if (wishTimer) {
      window.clearTimeout(wishTimer);
      wishTimer = null;
    }
  }

  function scheduleWishPoll() {
    stopWishPoll();
    if (!mounted || !st || document.hidden) return;
    wishTimer = window.setTimeout(function () {
      wishTimer = null;
      if (!mounted) return;
      loadWishes();
      scheduleWishPoll();
    }, wishActive() ? WISH_FAST_MS : WISH_SLOW_MS);
  }

  function loadWishes() {
    if (!mounted) return Promise.resolve();
    var seq = ++wishSeq;
    return fetchJSON(API_WISH + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (data) {
        if (!mounted || !st || seq !== wishSeq) return;
        applyWishes(data || {});
      })
      .catch(function () {
        if (!mounted || !st || seq !== wishSeq) return;
        st.wish.error = '点歌服务没响应';
        if (!st.wish.items.length) renderWish();
      });
  }

  function normalizeWish(raw) {
    var state = String(raw.state || 'pending');
    if (state !== 'pending' && state !== 'searching' && state !== 'downloading' &&
        state !== 'done' && state !== 'error') state = 'pending';
    return {
      id: String(raw.id == null ? '' : raw.id),
      text: raw.text ? String(raw.text) : '未命名',
      state: state,
      song: raw.song ? String(raw.song) : '',
      file: raw.file ? String(raw.file) : '',
      error: raw.error ? String(raw.error) : '',
      created_at: raw.created_at ? String(raw.created_at) : ''
    };
  }

  function applyWishes(data) {
    var raw = Array.isArray(data.items) ? data.items : [];
    var items = [];
    for (var i = 0; i < raw.length; i++) {
      if (!raw[i] || typeof raw[i] !== 'object') continue;
      var w = normalizeWish(raw[i]);
      if (!w.id) continue;
      items.push(w);
    }
    st.wish.items = items;
    st.wish.online = data.online !== false;
    st.wish.loaded = true;
    st.wish.error = '';
    renderWish();
    scheduleWishPoll();
  }

  function wishStateText(it) {
    if (it.state === 'searching') return '正在搜…';
    if (it.state === 'downloading') return '正在下：' + (it.song || '…');
    if (it.state === 'done') return it.song ? '已完成：' + it.song : '已完成';
    if (it.state === 'error') return it.error || '没下成';
    return '排队中';
  }

  function renderWish() {
    if (!refs.wishList || !st) return;
    var listEl = refs.wishList;
    var items = st.wish.items;

    if (refs.wishHint) {
      var hint = st.wish.online
        ? '断网也能先记个名字，联网后自动搜来下'
        : '现在没网，先记下，联网后自动搜来下';
      if (refs.wishHint.textContent !== hint) refs.wishHint.textContent = hint;
    }
    var hintEl = listEl.querySelector('.mu-wish-empty');
    if (!items.length) {
      for (var pid in wishRefs) {
        if (!wishRefs.hasOwnProperty(pid)) continue;
        if (wishRefs[pid].row.parentNode) wishRefs[pid].row.parentNode.removeChild(wishRefs[pid].row);
      }
      wishRefs = {};
      var tip = st.wish.error ? '点歌服务没响应，稍后再试' : '还没点过歌，断网也能先记名字';
      if (!hintEl) {
        listEl.innerHTML = '<div class="mu-wish-empty">' + esc(tip) + '</div>';
      } else if (hintEl.textContent !== tip) {
        hintEl.textContent = tip;
      }
      return;
    }
    if (hintEl && hintEl.parentNode) hintEl.parentNode.removeChild(hintEl);

    var seen = {};
    var prevRow = null;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      seen[it.id] = true;
      var rec = wishRefs[it.id];
      if (!rec) rec = createWishRow(it);
      updateWishRow(rec, it);
      var ref = prevRow ? prevRow.nextSibling : listEl.firstChild;
      if (ref !== rec.row) listEl.insertBefore(rec.row, ref);
      prevRow = rec.row;
    }

    for (var key in wishRefs) {
      if (!wishRefs.hasOwnProperty(key) || seen[key]) continue;
      var gone = wishRefs[key];
      if (gone.row.parentNode) gone.row.parentNode.removeChild(gone.row);
      delete wishRefs[key];
    }
  }

  function createWishRow(it) {
    var row = document.createElement('div');
    row.className = 'mu-wish';
    row.setAttribute('data-id', it.id);
    row.innerHTML =
      '<span class="mu-plstate" aria-hidden="true">' +
        svg('disc', 'mu-ico-run') + svg('check', 'mu-ico-ok') +
      '</span>' +
      '<span class="mu-wish-info">' +
        '<span class="mu-wish-text"></span>' +
        '<span class="mu-wish-sub"></span>' +
      '</span>' +
      '<button type="button" class="mu-wish-del" data-act="wish-del" data-id="' + esc(it.id) + '" title="删掉这条">' +
        svg('close') + '</button>';

    var rec = {
      row: row,
      text: row.querySelector('.mu-wish-text'),
      sub: row.querySelector('.mu-wish-sub')
    };
    wishRefs[it.id] = rec;
    return rec;
  }

  function updateWishRow(rec, it) {
    if (rec.row.getAttribute('data-state') !== it.state) rec.row.setAttribute('data-state', it.state);
    if (rec.text.textContent !== it.text) {
      rec.text.textContent = it.text;
      rec.text.title = it.text;
    }
    var sub = wishStateText(it);
    if (rec.sub.textContent !== sub) {
      rec.sub.textContent = sub;
      rec.sub.title = sub;
    }
  }

  function addWish(text) {
    if (!mounted || !st || st.wish.adding) return;
    text = String(text == null ? '' : text).trim();
    if (!text) {
      toast('先写个歌名或者歌手名');
      return;
    }
    st.wish.adding = true;
    renderWish();
    renderPlazaResults();

    fetchJSON(API_WISH, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    })
      .then(function (res) {
        if (!mounted || !st) return;
        res = res || {};
        st.wish.adding = false;
        if (res.ok === false) {
          toast(res.msg || '记不下，服务没响应');
          renderWish();
          renderPlazaResults();
          return;
        }
        if (res.exist) toast('「' + text + '」早就在队列里了');
        else if (res.online === false) toast(res.msg || '先记下了，联网后自动搜来下');
        else toast(res.msg || '记下了，排队去搜');

        st.plaza.q = '';
        st.plaza.searched = '';
        resetSearchState();
        if (refs.nmQ) {
          refs.nmQ.value = '';
          refs.nmQ.focus();
        }
        renderPlazaResults();
        renderWish();
        loadWishes();
        scheduleWishPoll();
      })
      .catch(function () {
        if (!mounted || !st) return;
        st.wish.adding = false;
        toast('记不下，服务没响应');
        renderWish();
        renderPlazaResults();
      });
  }

  function removeWish(id) {
    if (!id) return;
    fetchJSON(API_WISH + '?id=' + encodeURIComponent(id), { method: 'DELETE' })
      .then(function () {
        if (!mounted) return;
        loadWishes();
        scheduleWishPoll();
      })
      .catch(function () {
        if (!mounted) return;
        toast('删不掉，服务没响应');
      });
  }

  /* ------------------------------ 全屏 Now Playing ------------------------------
     布局参考 Lyra (MIT, github.com/sucooer/lyra) —— NowPlaying.vue / LyricsView.vue / scrubber.ts */

  var NP_ANCHOR_WIDE = 0.4;
  var NP_ANCHOR_NARROW = 0.3;
  var NP_SCROLL_MS = 700;

  function npFmt(sec) {
    var s = Number(sec);
    if (!s || !isFinite(s) || s < 0) return '0:00';
    var m = Math.floor(s / 60);
    var r = Math.floor(s % 60);
    return m + ':' + pad2(r);
  }

  // 32×32 平均色，深色场景压到 0.55，得到 Apple Music 那种暗底
  function npColorOf(rgb) {
    var dim = 0.55;
    return 'rgb(' + Math.round(rgb[0] * dim) + ',' + Math.round(rgb[1] * dim) + ',' + Math.round(rgb[2] * dim) + ')';
  }

  function lrcTime(min, sec, frac) {
    var f = frac || '0';
    var fracMs = f.length === 3 ? parseInt(f, 10) : parseInt((f + '00').slice(0, 3), 10);
    return parseInt(min, 10) * 60 + parseInt(sec, 10) + fracMs / 1000;
  }

  // 这行是什么文字：日文假名 / 韩文 / 纯汉字 / 纯拉丁。混排返回 ''，不去猜翻译
  function scriptClass(text) {
    var s = String(text || '');
    var han = 0, kana = 0, hangul = 0, latin = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c >= 0x3040 && c <= 0x30ff) kana++;
      else if ((c >= 0xac00 && c <= 0xd7af) || (c >= 0x1100 && c <= 0x11ff)) hangul++;
      else if ((c >= 0x3400 && c <= 0x9fff) || (c >= 0xf900 && c <= 0xfaff)) han++;
      else if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) ||
               (c >= 0x00c0 && c <= 0x024f)) latin++;
    }
    if (kana > 0) return 'kana';
    if (hangul > 0) return 'hangul';
    if (han > 0 && latin === 0) return 'han';
    if (latin > 0 && han === 0) return 'latin';
    return '';
  }

  // 逐字标签：`<mm:ss.xx>字`
  function parseWordTags(text) {
    var re = /<(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?>/g;
    var out = [];
    var last = 0;
    var m;
    var pending = null;
    var has = false;
    while ((m = re.exec(text)) !== null) {
      has = true;
      var seg = text.slice(last, m.index);
      if (pending) pending.text += seg;
      else if (seg) out.push({ t: null, text: seg });
      pending = { t: lrcTime(m[1], m[2], m[3]), text: '' };
      out.push(pending);
      last = re.lastIndex;
    }
    if (!has) return null;
    var tail = text.slice(last);
    if (pending) pending.text += tail;
    else if (tail) out.push({ t: null, text: tail });
    var got = out.filter(function (w) { return w.text; });
    return got.length ? got : null;
  }

  // YRC / KRC：`[1234,567](1234,300,0)字(1534,200,0)字`
  function parseYrcLine(line) {
    var head = /^\[(\d{1,6}),(\d{1,6})\](.*)$/.exec(line);
    if (!head) return null;
    var body = head[3];
    var re = /\((\d{1,6}),(\d{1,6}),\d+\)([^(]*)/g;
    var words = [];
    var m;
    while ((m = re.exec(body)) !== null) {
      var txt = m[3];
      if (txt) words.push({ t: parseInt(m[1], 10) / 1000, text: txt });
    }
    if (!words.length) return null;
    return {
      t: parseInt(head[1], 10) / 1000,
      words: words,
      text: words.map(function (w) { return w.text; }).join('')
    };
  }

  function lrcRaw(text) {
    var raw = String(text == null ? '' : text);
    var out = [];
    var plain = [];
    var offsetSec = 0;
    var timeTag = /\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g;
    var metaTag = /^\[(ti|ar|al|by|offset|re|ve):/i;
    var rows = raw.split(/\r?\n/);

    for (var i = 0; i < rows.length; i++) {
      var line = rows[i].trim();
      if (!line) continue;

      var om = /^\[offset:\s*([+-]?\d+)\s*\]/i.exec(line);
      if (om) {
        offsetSec = parseInt(om[1], 10) / 1000;
        continue;
      }
      if (metaTag.test(line)) continue;

      var yrc = parseYrcLine(line);
      if (yrc) {
        for (var y = 0; y < yrc.words.length; y++) yrc.words[y].t += offsetSec;
        yrc.t += offsetSec;
        out.push(yrc);
        continue;
      }

      timeTag.lastIndex = 0;
      var stamps = [];
      var m;
      while ((m = timeTag.exec(line)) !== null) {
        stamps.push(lrcTime(m[1], m[2], m[3]));
      }

      var body = line.replace(timeTag, '').trim();
      if (!stamps.length) {
        if (body) plain.push(body);
        continue;
      }

      var words = parseWordTags(body);
      var shown = words ? words.map(function (w) { return w.text; }).join('') : body;

      for (var s = 0; s < stamps.length; s++) {
        var rec = { t: stamps[s] + offsetSec, text: shown };
        if (words) {
          rec.words = words.map(function (w) {
            return {
              t: (w.t == null ? stamps[s] : w.t) + offsetSec,
              text: w.text
            };
          });
        }
        out.push(rec);
      }
    }

    if (!out.length) {
      return { synced: false, lines: plain.map(function (x) { return { t: -1, text: x }; }) };
    }
    out.sort(function (a, b) { return a.t - b.t; });
    out = cleanLyricLines(out, false);
    return { synced: true, lines: out };
  }

function pairTranslations(lines) {
    for (var i = 0; i < lines.length - 1; i++) {
      var cur = lines[i];
      var next = lines[i + 1];
      if (!cur || !next || cur.isTrans || next.isTrans) continue;
      if (!cur.text || !next.text) continue;
      var a = scriptClass(cur.text);
      var b = scriptClass(next.text);
      if (!a || !b || a === b) continue;
      // 网易云给的翻译基本都是从外文翻成中文：只认「外文 → 中文」，
      // 免得把中文歌里单独一句英文歌词当成翻译吃掉
      if (b !== 'han') continue;
      if (a === 'han') continue;

      var gap = next.t - cur.t;
      if (gap < -0.05 || gap > 5.5) continue;

      // 贴得很近，或者后面很快又回到原语言（原/译/原 的三明治结构）
      var after = lines[i + 2];
      var sandwich = !!(after && scriptClass(after.text) === a &&
        (after.t - next.t) <= 3.5 && gap <= 5.5);
      if (gap <= 2.0 || sandwich) {
        next.isTrans = true;
        if (!cur.tr) cur.tr = next.text;
      }
    }
    var out = [];
    for (var k = 0; k < lines.length; k++) {
      if (!lines[k].isTrans) out.push(lines[k]);
    }
    return out;
  }

  // 后端要是单独给了翻译 lrc（字段 tlrc / tlyric），按时间就近贴到原行下面
  function mergeTransLines(lines, transLines) {
    if (!transLines || !transLines.length) return 0;
    var used = 0;
    for (var i = 0; i < transLines.length; i++) {
      var tr = transLines[i];
      if (!tr.text) continue;
      var best = -1;
      var bestGap = 3.0;
      for (var j = 0; j < lines.length; j++) {
        var gap = Math.abs(lines[j].t - tr.t);
        if (gap <= bestGap) { bestGap = gap; best = j; }
      }
      if (best >= 0 && !lines[best].tr) {
        lines[best].tr = tr.text;
        used++;
      }
    }
    return used;
  }

  
  var ROLE_PREFIX_RE = /^\[\d+:\d+(?:\.\d+)?\]\s*(?:【([^】]+)】|(\S{1,8})[：:])\s*/;
  var STANDALONE_RE = /^\[(\d+):(\d+(?:\.\d+)?)\]\s*([A-Za-z0-9]+)[:：]\s*$/;
  var TS_RE = /^\[(\d+):(\d+(?:\.\d+)?)\]/;
  var MARKER_ONLY_RE = /^[A-Za-z0-9]+[:：]\s*$/;
  var CREDIT_SEP_RE = /[\/／&＆+、]/;
  var CREDIT_LABELS = {};
  ('词 曲 词曲 作词 填词 作曲 编曲 演唱 原唱 翻唱 制作 制作人 监制 录音 录制 混音 母带 ' +
   '和声 和声编写 吉他 贝斯 钢琴 鼓 弦乐 绘图 题字 出品 发行 版权 ' +
   'lyric lyrics lyricist words writtenby songwriter music composer composition ' +
   'arranger arrangement arrangedby vocal vocals singer sungby producer producedby ' +
   'recording recordedby mix mixing mixedby mastering masteredby')
    .split(/\s+/).forEach(function (w) { if (w) CREDIT_LABELS[w] = 1; });

  function singerRole(label) {
    var role = String(label || '').trim().toLowerCase();
    if (!role) return '';
    var parts = role.split(CREDIT_SEP_RE).filter(function (x) { return x !== ''; });
    var allCredit = parts.length > 0;
    for (var i = 0; i < parts.length; i++) {
      if (!CREDIT_LABELS[parts[i].replace(/\s+/g, '')]) { allCredit = false; break; }
    }
    return allCredit ? '' : role;
  }

  function lineMs(line) {
    var m = TS_RE.exec(String(line || '').trim());
    if (!m) return null;
    return parseInt(m[1], 10) * 60000 + Math.round(parseFloat(m[2]) * 1000);
  }

  function prefixRoleOf(line) {
    var m = ROLE_PREFIX_RE.exec(String(line || '').trim());
    if (!m) return null;
    var label = (m[1] || '').trim() || (m[2] || '').trim();
    return singerRole(label) || null;
  }

  function detectDuet(rawLrc) {
    var rows = String(rawLrc || '').split(/\r?\n/);
    var segs = [];
    var i;

    var curRole = '', curStart = -1;
    var standalone = [];
    for (i = 0; i < rows.length; i++) {
      var m = STANDALONE_RE.exec(rows[i].trim());
      if (!m) continue;
      var role = singerRole(m[3]);
      if (!role) continue;
      var t = parseInt(m[1], 10) * 60000 + Math.round(parseFloat(m[2]) * 1000);
      var nxt = i + 1 < rows.length ? lineMs(rows[i + 1].trim()) : null;
      if (nxt != null && nxt - t >= 1 && nxt - t <= 1000 && role.length <= 15) {
        if (curRole && curStart >= 0) standalone.push({ role: curRole, lineIdx: curStart });
        curRole = role;
        curStart = i;
      }
    }
    if (curRole && curStart >= 0) standalone.push({ role: curRole, lineIdx: curStart });
    if (standalone.length >= 2) {
      standalone.forEach(function (seg) {
        var ms = lineMs(rows[seg.lineIdx]);
        if (ms != null) segs.push({ role: seg.role, startMs: ms });
      });
      if (segs.length >= 2) return segs;
      segs = [];
    }

    var cur = null, start = -1;
    var seg2 = [];
    for (i = 0; i < rows.length; i++) {
      var r = prefixRoleOf(rows[i]);
      if (!r) continue;
      if (cur !== null && cur !== r && start >= 0) seg2.push({ role: cur, lineIdx: start });
      if (cur === null || cur !== r) start = i;
      cur = r;
    }
    if (cur !== null && start >= 0) seg2.push({ role: cur, lineIdx: start });
    seg2.forEach(function (seg) {
      var ms = lineMs(rows[seg.lineIdx]);
      if (ms != null) segs.push({ role: seg.role, startMs: ms });
    });
    return segs.length >= 2 ? segs : null;
  }

  function parseLrc(text, transText) {
    var parsed = lrcRaw(text);
    if (parsed.synced) {
      parsed.lines = pairTranslations(parsed.lines);
      if (transText) {
        var t = lrcRaw(transText);
        if (t.synced) mergeTransLines(parsed.lines, t.lines);
      }
      var segs = detectDuet(text);
      if (segs) parsed.lines = alignDuet(parsed.lines, segs);
    }
    return parsed;
  }

  // 按卡拉OK那套：第一个唱歌的靠左，第二个靠右，之后轮流
  function alignDuet(lines, segs) {
    segs.sort(function (a, b) { return a.startMs - b.startMs; });
    var sides = {};
    var next = 'l';
    for (var i = 0; i < segs.length; i++) {
      if (!sides[segs[i].role]) {
        sides[segs[i].role] = next;
        next = next === 'l' ? 'r' : 'l';
      }
    }
    var out = [];
    for (var j = 0; j < lines.length; j++) {
      var ln = lines[j];
      var side = '';
      for (var k = segs.length - 1; k >= 0; k--) {
        if (Math.round(ln.t * 1000) >= segs[k].startMs) { side = sides[segs[k].role] || ''; break; }
      }
      ln.side = side;
      out.push(ln);
    }
    return out;
  }

  // 去掉制作名单和只写着角色的空行
  var CREDIT_RE = /^(作词|作曲|编曲|制作人|监制|混音|母带|录音|吉他|贝斯|鼓|和声|出品|发行|统筹|企划|词|曲|编|Producer|Mixing|Mastering|Composer|Lyricist)\s*[:：]/i;
  var BODY_ROLE_RE = /^(?:【([^】]+)】|([^\s:：【】]{1,8})[：:])\s*/;

  function cleanLyricLines(lines, duetOn) {
    var out = [];
    var seq = [];
    var i;
    for (i = 0; i < lines.length; i++) {
      var text = String(lines[i].text || '').trim();
      if (!text) continue;
      if (CREDIT_RE.test(text)) continue;
      if (MARKER_ONLY_RE.test(text)) continue;
      var m = BODY_ROLE_RE.exec(text);
      if (m) {
        var label = (m[1] || '').trim() || (m[2] || '').trim();
        if (singerRole(label)) text = text.slice(m[0].length).trim();
      }
      if (!text) continue;
      lines[i].text = text;
      out.push(lines[i]);
      seq.push(i);
    }
    return out;
  }

  // 长间奏插三个点；纯音乐只有一行字就不插
  // 间奏段：上一句结束到下一句开始之间空太久，那段时间在画面中间显示三个点
  function interludeWindows(lines, duration) {
    var w = [];
    if (!lines || lines.length <= 1) return w;
    var inst = lines.length <= 2 && lines.every(function (l) {
      return /纯音乐|请欣赏|instrumental/i.test(String(l.text || ''));
    });
    if (inst) return w;
    // 开头：0 到第一句
    if (lines[0].t >= 5) w.push({ from: 0, to: lines[0].t, intro: true });
    for (var i = 0; i < lines.length - 1; i++) {
      var a = lines[i].t, b = lines[i + 1].t;
      if (b - a >= 7) w.push({ from: a + 4, to: b });
    }
    if (duration > 0) {
      var last = lines[lines.length - 1].t;
      if (duration - last >= 7) w.push({ from: last + 4, to: duration });
    }
    return w;
  }

  // 把一行切成高亮单元：汉字/假名逐字，英文按单词，标点跟着前一个字
  function tokenizeLine(text) {
    var s = String(text || '');
    var tokens = [];
    var word = '';
    function flush() {
      if (word) { tokens.push(word); word = ''; }
    }
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i);
      var c = s.charCodeAt(i);
      var isCjk = (c >= 0x3040 && c <= 0x30ff) || (c >= 0xac00 && c <= 0xd7af) ||
        (c >= 0x3400 && c <= 0x9fff) || (c >= 0xf900 && c <= 0xfaff) ||
        (c >= 0x20000 && c <= 0x2ffff);
      var isWord = (c >= 65 && c <= 90) || (c >= 97 && c <= 122) ||
        (c >= 48 && c <= 57) || c === 39 || c === 8217 ||
        (c >= 0x00c0 && c <= 0x024f);
      if (isCjk) {
        flush();
        tokens.push(ch);
      } else if (isWord) {
        word += ch;
      } else if (ch === ' ') {
        flush();
        // 空格单独成一个高亮单元：塞进 inline-block 里会被当行尾空格吞掉
        tokens.push(' ');
      } else {
        flush();
        if (tokens.length) tokens[tokens.length - 1] += ch;
        else tokens.push(ch);
      }
    }
    flush();
    return tokens.filter(function (x) { return x !== ''; });
  }

  // 每行每个字的起亮时间：有逐字标签用真时间，没有就按这行到下一行之间的时长均分
  function buildLyricTokens(parsed) {
    var lines = parsed.lines;
    var total = currentDuration();
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (!line || line.t < 0) continue;
      var end;
      if (lines[i + 1]) end = lines[i + 1].t;
      else if (total > 0) end = Math.max(line.t + 1.2, total - 0.15);
      else end = line.t + Math.max(2.5, String(line.text || '').length * 0.22);
      if (!(end > line.t)) end = line.t + 0.8;

      var units = [];
      if (line.words && line.words.length) {
        for (var w = 0; w < line.words.length; w++) {
          var word = line.words[w];
          var wEnd = line.words[w + 1] ? line.words[w + 1].t : end;
          if (!(wEnd > word.t)) wEnd = word.t + 0.4;
          var pieces = tokenizeLine(word.text);
          if (!pieces.length) continue;
          var step = (wEnd - word.t) / pieces.length;
          for (var p = 0; p < pieces.length; p++) {
            units.push({
              text: pieces[p],
              t: word.t + p * step,
              end: word.t + (p + 1) * step
            });
          }
        }
      }
      if (!units.length) {
        var toks = tokenizeLine(line.text || '♪');
        if (!toks.length) toks = ['♪'];
        // 一句歌词不该拖到间奏结束才亮完，按字数估一个合理时长封顶
        var lineLen = String(line.text || '').length;
        var cap = line.t + Math.min(8, Math.max(2.0, 1.0 + lineLen * 0.2));
        var paintEnd = Math.min(end, cap);
        var dur = Math.max(0.6, paintEnd - line.t);
        for (var k = 0; k < toks.length; k++) {
          units.push({
            text: toks[k],
            t: line.t + dur * (k / toks.length),
            end: line.t + dur * ((k + 1) / toks.length)
          });
        }
      }
      line.tokens = units;
      line._lit = -1;
      line._p = 0;
    }
    return parsed;
  }

  function findLyrLine(lines, t) {
    if (!lines.length) return -1;
    var lo = 0;
    var hi = lines.length - 1;
    var ans = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (lines[mid].t <= t) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return ans;
  }

  function extractCoverColor(url, cb) {
    if (!url || typeof window.Image !== 'function') {
      cb(null);
      return;
    }
    var img = new Image();
    img.crossOrigin = 'anonymous';
    var done = false;
    function fail() {
      if (done) return;
      done = true;
      cb(null);
    }
    img.onload = function () {
      if (done) return;
      try {
        var size = 32;
        var cv = document.createElement('canvas');
        cv.width = size;
        cv.height = size;
        var ctx = cv.getContext('2d');
        if (!ctx) { fail(); return; }
        ctx.drawImage(img, 0, 0, size, size);
        var data = ctx.getImageData(0, 0, size, size).data;
        var r = 0, g = 0, b = 0;
        var n = data.length / 4;
        for (var i = 0; i < data.length; i += 4) {
          r += data[i];
          g += data[i + 1];
          b += data[i + 2];
        }
        done = true;
        cb([Math.round(r / n), Math.round(g / n), Math.round(b / n)]);
      } catch (e) {
        fail();
      }
    };
    img.onerror = fail;
    img.src = url;
  }

  function npAnchor() {
    return window.innerWidth >= 1024 ? NP_ANCHOR_WIDE : NP_ANCHOR_NARROW;
  }

  function openLyrics() {
    if (!mounted || !refs.lyrRoot) return;
    if (npCloseTimer) {
      window.clearTimeout(npCloseTimer);
      npCloseTimer = null;
    }
    lyrOpen = true;
    npLayout = loadNpLayout();
    refs.lyrRoot.hidden = false;
    refs.lyrRoot.setAttribute('aria-hidden', 'false');
    void refs.lyrRoot.offsetWidth;
    refs.lyrRoot.classList.add('is-open');
    renderLyrics();
    applyNpView();
    renderPlayState();
    renderVolume();
    syncNowFav();
    npPaintProgress();
    window.requestAnimationFrame(function () {
      if (!lyrOpen) return;
      layoutLyrics(false);
      npKaraokeStart();
    });
  }

  function closeLyrics() {
    if (!lyrOpen) return;
    lyrOpen = false;
    npKaraokeStop();
    npManual = false;
    if (npManualTimer) {
      window.clearTimeout(npManualTimer);
      npManualTimer = null;
    }
    if (npSettleTimer) {
      window.clearTimeout(npSettleTimer);
      npSettleTimer = null;
    }
    npCancelAnim();
    if (refs.lyrRoot) {
      refs.lyrRoot.classList.remove('is-open');
      refs.lyrRoot.classList.remove('is-split');
      refs.lyrRoot.classList.remove('is-enter');
      // 等写回动画跑完再真正藏起来
      if (npCloseTimer) window.clearTimeout(npCloseTimer);
      npCloseTimer = window.setTimeout(function () {
        npCloseTimer = null;
        if (!lyrOpen && refs.lyrRoot) {
          refs.lyrRoot.hidden = true;
          refs.lyrRoot.setAttribute('aria-hidden', 'true');
        }
      }, 320);
    }
    if (refs.disc && refs.disc.focus) {
      try { refs.disc.focus(); } catch (e) { /* 忽略 */ }
    }
  }

  function npToggleView(show) {
    if (!lyrOpen) return;
    var next;
    if (typeof show === 'boolean') next = show ? 'lyrics' : 'cover';
    else next = npLayout === 'lyrics' ? 'cover' : 'lyrics';
    setNpLayout(next);
  }

  function setNpLayout(layout) {
    if (!lyrOpen) return;
    if (layout !== 'cover' && layout !== 'lyrics' && layout !== 'split') layout = 'cover';
    npLayout = layout;
    writeLS(LS_NPLAYOUT, npLayout);
    npManual = false;
    applyNpView();
    if (npLayout === 'cover') {
      npCancelAnim();
      npKaraokeStop();
      return;
    }
    npKaraokeStart();
    layoutLyrics(false);
    if (npSettleTimer) window.clearTimeout(npSettleTimer);
    // 布局切换后高度才定型，补一次定位
    npSettleTimer = window.setTimeout(function () {
      npSettleTimer = null;
      if (!lyrOpen || npLayout === 'cover') return;
      layoutLyrics(false);
    }, 380);
  }

  function applyNpView() {
    var showCover = npLayout !== 'lyrics';
    var showLyric = npLayout !== 'cover';
    if (refs.lyrRoot) refs.lyrRoot.classList.toggle('is-split', npLayout === 'split');
    if (refs.npCoverView) refs.npCoverView.hidden = !showCover;
    if (refs.npLyricView) refs.npLyricView.hidden = !showLyric;

    // 切换布局时给刚露出来的那一栏一点入场动作
    var enter = showLyric ? refs.npLyricView : refs.npCoverView;
    if (lyrOpen && enter) {
      enter.classList.remove('is-enter');
      void enter.offsetWidth;
      enter.classList.add('is-enter');
    }
    if (refs.npCoverView && showCover) {
      var cover = refs.npCoverView.querySelector('.mu-np-cover');
      if (cover) {
        cover.classList.remove('is-swing');
        void cover.offsetWidth;
        cover.classList.add('is-swing');
      }
    }

    if (refs.npToggle) {
      refs.npToggle.classList.toggle('is-on', npLayout === 'lyrics');
      refs.npToggle.title = npLayout === 'lyrics' ? '回到封面' : '歌词';
      refs.npToggle.setAttribute('aria-pressed', npLayout === 'lyrics' ? 'true' : 'false');
    }
    renderNpMenu();
  }

  function renderNpMenu() {
    if (!refs.npMenu) return;
    var items = refs.npMenu.querySelectorAll('[data-layout]');
    for (var i = 0; i < items.length; i++) {
      var on = items[i].getAttribute('data-layout') === npLayout;
      items[i].classList.toggle('is-on', on);
      items[i].setAttribute('aria-checked', on ? 'true' : 'false');
    }
  }

  function toggleNpMenu(force) {
    if (!refs.npMenu || !refs.npSetup) return;
    var open = typeof force === 'boolean' ? force : refs.npMenu.hidden;
    refs.npMenu.hidden = !open;
    refs.npSetup.setAttribute('aria-expanded', open ? 'true' : 'false');
    refs.npSetup.classList.toggle('is-on', open);
  }

  function renderLyrics() {
    if (!refs.lyrRoot || !st) return;
    var it = st.current;
    var linesEl = refs.lyrLines;

    if (!it) {
      refs.lyrTitle.textContent = '还没有选歌';
      refs.lyrTitle.title = '';
      refs.lyrSub.innerHTML = '<span>点一首歌开始听</span>';
      refs.lyrCover.innerHTML = '<span class="mu-np-cover-ph">♪</span>';
      refs.lyrRoot.style.setProperty('--np-bg', 'rgb(30, 30, 32)');
      if (refs.lyrBlur) refs.lyrBlur.style.display = 'none';
      linesEl.innerHTML = '<div class="mu-np-empty">暂无歌词</div>';
      refs.lyrRoot.classList.add('is-plain');
      refs.lyrRoot.classList.add('is-nolyr');
      lyrData = { synced: false, lines: [] };
      npActive = -1;
      return;
    }

    refs.lyrRoot.classList.remove('is-nolyr');
    refs.lyrTitle.textContent = it.title;
    refs.lyrTitle.title = it.title;
    refs.lyrSub.innerHTML = '<span>' + esc(artistOf(it)) + '</span>' +
      (it.album ? '<span class="mu-np-dash">—</span><span>' + esc(it.album) + '</span>' : '');
    refs.lyrSub.title = artistOf(it) + (it.album ? ' — ' + it.album : '');
    refs.lyrCover.innerHTML = coverMarkup(it);

    var coverURL = it.cover ? pathURL(it.cover) : '';
    refs.lyrRoot.style.setProperty('--np-bg', npBg || 'rgb(30, 30, 32)');
    if (refs.lyrBlur) {
      if (coverURL) {
        refs.lyrBlur.src = coverURL;
        refs.lyrBlur.style.display = '';
      } else {
        refs.lyrBlur.removeAttribute('src');
        refs.lyrBlur.style.display = 'none';
      }
    }

    var seq = ++npColorSeq;
    extractCoverColor(coverURL, function (rgb) {
      if (!mounted || !lyrOpen || !st || seq !== npColorSeq) return;
      if (!st.current || st.current.id !== it.id) return;
      npBg = rgb ? npColorOf(rgb) : 'rgb(30, 30, 32)';
      refs.lyrRoot.style.setProperty('--np-bg', npBg);
    });

    var parsed = parseLrc(it.lrc, it.tlrc);
    lyrData = parsed;
    npActive = -1;
    npLitLine = -1;
    npLitCount = -1;

    if (!parsed.lines.length) {
      linesEl.innerHTML = '<div class="mu-np-empty">暂无歌词' +
        '<span>联网时下歌会自动带上，也可以手动放一个同名 .lrc 到 data/music 里。</span>' +
        '</div>';
      refs.lyrRoot.classList.add('is-plain');
      return;
    }

    if (!parsed.synced) {
      var plainText = parsed.lines.map(function (l) { return l.text; }).join('\n');
      linesEl.innerHTML = '<pre class="mu-np-plain">' + esc(plainText) + '</pre>';
      refs.lyrRoot.classList.add('is-plain');
      return;
    }

    refs.lyrRoot.classList.remove('is-plain');
    lyrDots = interludeWindows(parsed.lines, currentDuration());
    buildLyricTokens(parsed);
    linesEl.innerHTML = parsed.lines.map(npLineHTML).join('');
    npMeasuredW = -1;
    npFrameH = [];
    if (lyrOpen && npLayout !== 'cover') {
      layoutLyrics(false);
      npUpdateLyrics(true);
      npKaraokeStart();
    }
  }

  // 一行歌词：逐字 span（带亮色副本用 data-ch）+ 下面挂翻译
  function npLineHTML(line, i) {
    var tokens = line.tokens;
    var inner;
    if (tokens && tokens.length) {
      inner = tokens.map(function (tk) {
        if (/^\s+$/.test(tk.text)) {
          return '<span class="mu-np-ch mu-np-gap"> </span>';
        }
        return '<span class="mu-np-ch" data-ch="' + esc(tk.text) + '">' + esc(tk.text) + '</span>';
      }).join('');
    } else {
      inner = '<span class="mu-np-ch" data-ch="' + esc(line.text || '♪') + '">' + esc(line.text || '♪') + '</span>';
    }
    var tr = line.tr
      ? '<span class="mu-np-tr">' + esc(line.tr) + '</span>'
      : '';
    var sideCls = line.side === 'l' ? ' mu-np-duet-l'
      : (line.side === 'r' ? ' mu-np-duet-r' : '');
    return '<p class="mu-np-line' + sideCls + '" data-i="' + i + '">' +
      '<span class="mu-np-orig">' + inner + '</span>' + tr + '</p>';
  }

  function layoutLyrics(animate) {
    if (!lyrOpen || !refs.lyrScroll) return;
    npSyncLyricSize();
    if (animate === false) npScrollToActive(false);
    else npScrollToActive(true);
    npApplyLyricBlur();
  }

  function npSyncLyricSize() {
    var el = refs.lyrScroll;
    if (!el) return;
    var h = el.clientHeight;
    if (!h) return;
    if (!lyrData.synced) {
      el.style.paddingTop = '28px';
      el.style.paddingBottom = '40px';
      return;
    }
    var padTop = Math.round(h * npAnchor());
    el.style.paddingTop = padTop + 'px';
    el.style.paddingBottom = Math.max(0, h - padTop) + 'px';
    if (el.clientWidth !== npMeasuredW) npMeasureFrames();
  }

  function npMeasureFrames() {
    var el = refs.lyrScroll;
    var probe = refs.npMeasure;
    var linesEl = refs.lyrLines;
    if (!el || !probe || !linesEl) return;
    npMeasuredW = el.clientWidth;
    probe.innerHTML = '';
    npFrameH = [];
    if (!lyrData.synced || !lyrData.lines.length) return;
    var w = linesEl.clientWidth;
    if (!w) return;
    probe.style.width = w + 'px';
    var cells = [];
    for (var i = 0; i < lyrData.lines.length; i++) {
      var d = document.createElement('div');
      d.className = 'mu-np-measure-line';
      var ln = lyrData.lines[i];
      d.innerHTML = esc(ln.text || '♪') +
        (ln.tr ? '<span class="mu-np-measure-tr">' + esc(ln.tr) + '</span>' : '');
      probe.appendChild(d);
      cells.push(d);
    }
    for (var k = 0; k < cells.length; k++) {
      npFrameH.push(Math.ceil(cells[k].getBoundingClientRect().height));
    }
    probe.innerHTML = '';
    var nodes = linesEl.querySelectorAll('.mu-np-line');
    for (var n = 0; n < nodes.length; n++) {
      if (npFrameH[n]) nodes[n].style.minHeight = npFrameH[n] + 'px';
    }
    npApplyLyricBlur();
  }

  // 按「离锚点（当前行停的位置）的像素距离」算模糊：
  // 这样手动上下滚动时，滚到中间的那几行会自动变清楚，而不是死跟着当前播放行。
  var npBlurRaf = 0;
  function npQueueLyricBlur() {
    if (npBlurRaf) return;
    npBlurRaf = window.requestAnimationFrame(function () {
      npBlurRaf = 0;
      npApplyLyricBlur();
    });
  }

  function npApplyLyricBlur() {
    if (!lyrOpen || !refs.lyrScroll || !lyrData.synced) return;
    var el = refs.lyrScroll;
    var h = el.clientHeight;
    if (!h) return;
    var anchorY = el.scrollTop + h * npAnchor();
    var nodes = el.querySelectorAll('.mu-np-line');
    var vals = [];
    for (var i = 0; i < nodes.length; i++) {
      var mid = nodes[i].offsetTop + nodes[i].offsetHeight / 2;
      var d = Math.abs(mid - anchorY);
      var b = Math.min(4, Math.max(0, (d - 75) / 55));
      vals.push(b < 0.12 ? '' : 'blur(' + b.toFixed(2) + 'px)');
    }
    for (var k = 0; k < nodes.length; k++) {
      if (nodes[k].style.filter !== vals[k]) nodes[k].style.filter = vals[k];
    }
  }

  function npCancelAnim() {
    if (npAnimId) {
      window.cancelAnimationFrame(npAnimId);
      npAnimId = 0;
    }
  }

  function npAnimateScroll(target) {
    var el = refs.lyrScroll;
    if (!el) return;
    npCancelAnim();
    var start = el.scrollTop;
    var delta = target - start;
    if (Math.abs(delta) < 1) return;
    var t0 = 0;
    var ease = function (x) { return 1 - Math.pow(1 - x, 5); };
    function step(now) {
      if (!t0) t0 = now;
      var p = Math.min(1, (now - t0) / NP_SCROLL_MS);
      el.scrollTop = start + delta * ease(p);
      if (p < 1) npAnimId = window.requestAnimationFrame(step);
      else npAnimId = 0;
    }
    npAnimId = window.requestAnimationFrame(step);
  }

  function npScrollToActive(smooth) {
    var el = refs.lyrScroll;
    if (!el || !lyrData.synced || npActive < 0) return;
    var line = el.querySelector('.mu-np-line[data-i="' + npActive + '"]');
    if (!line) return;
    var target = Math.max(0, line.offsetTop - el.clientHeight * npAnchor() + line.offsetHeight / 2);
    if (smooth === false) {
      npCancelAnim();
      el.scrollTop = target;
      return;
    }
    npAnimateScroll(target);
  }

  function npMarkActive() {
    var el = refs.lyrScroll;
    if (!el) return;
    var nodes = el.querySelectorAll('.mu-np-line');
    for (var i = 0; i < nodes.length; i++) {
      var on = i === npActive;
      var past = npActive >= 0 && i < npActive;
      if (nodes[i].classList.contains('is-on') !== on) nodes[i].classList.toggle('is-on', on);
      if (nodes[i].classList.contains('is-past') !== past) nodes[i].classList.toggle('is-past', past);
      if (on) nodes[i].setAttribute('aria-current', 'true');
      else nodes[i].removeAttribute('aria-current');
    }
  }

  // 间奏期间中间飘三个点（不进歌词列表）
  var lyrDots = [];
  var npDotsOn = null;
  function npMarkInterlude(t) {
    var hit = null;
    for (var i = 0; i < lyrDots.length; i++) {
      if (t >= lyrDots[i].from && t < lyrDots[i].to) { hit = lyrDots[i]; break; }
    }
    var on = !!hit;
    if (on === npDotsOn) {
      if (hit && refs.lyrDots) {
        var p = Math.max(0, Math.min(1, (t - hit.from) / Math.max(0.1, hit.to - hit.from)));
        refs.lyrDots.style.setProperty('--np-dots-progress', p.toFixed(3));
      }
      return;
    }
    npDotsOn = on;
    if (refs.lyrDots) refs.lyrDots.hidden = !on;
  }

  // 还没唱到第一句时，中间显示三个点，不显示歌名
  var npWaiting = null;
  function npMarkWaiting(t) {
    if (!lyrData.lines || !lyrData.lines.length) return;
    var first = lyrData.lines[0].t;
    var wait = (first > 0.5) && (t < first - 0.15);
    if (wait === npWaiting) return;
    npWaiting = wait;
    if (refs.lyrTitle) {
      refs.lyrTitle.textContent = wait ? '•••' : (st && st.current ? st.current.title : '');
    }
    if (refs.lyrCover) {
      var cur = st && st.current;
      if (wait) {
        refs.lyrCover.innerHTML = '<span class="mu-np-cover-ph mu-np-dots">•••</span>';
      } else if (cur) {
        refs.lyrCover.innerHTML = coverMarkup(cur);
      }
    }
    if (refs.lyrRoot) refs.lyrRoot.classList.toggle('is-waiting', !!wait);
  }

  function npUpdateLyrics(force) {
    if (!lyrOpen || !st) return;
    npPaintProgress();
    if (!audio || !lyrData.synced || !lyrData.lines.length) return;

    var t = isFinite(audio.currentTime) ? audio.currentTime : 0;
    npMarkWaiting(t);
    npMarkInterlude(t);
    var idx = findLyrLine(lyrData.lines, t);
    if (idx !== npActive) {
      // 旧行不清 --mu-p：留着那点浮起的高度，唱过的行不会“掉回去”
      npActive = idx;
      npLitLine = -1;
      npLitCount = -1;
      npMarkActive();
      if (!npManual) npScrollToActive(true);
    } else if (force) {
      npClearLit(npActive);
      npLitLine = -1;
      npLitCount = -1;
    }
    npPaintChars();
    npApplyLyricBlur();
  }

  // 清掉某一行的逐字进度（换行、拖动时用），字会退回没亮、没浮起的状态
  function npClearLit(lineIndex) {
    if (lineIndex == null || lineIndex < 0 || !refs.lyrScroll) return;
    var el = refs.lyrScroll.querySelector('.mu-np-line[data-i="' + lineIndex + '"]');
    if (!el) return;
    var spans = el.querySelectorAll('.mu-np-ch');
    for (var i = 0; i < spans.length; i++) {
      spans[i].style.setProperty('--mu-p', '0');
      spans[i].classList.remove('is-done');
    }
    var line = lyrData && lyrData.lines ? lyrData.lines[lineIndex] : null;
    if (line) {
      line._lit = -1;
      line._p = 0;
      if (line.tokens) {
        for (var k = 0; k < line.tokens.length; k++) line.tokens[k]._p = 0;
      }
    }
  }

  // 按播放时间推进当前行每个字的渐变进度 --mu-p：
  // 0 = 还没唱到，1 = 已经完全亮起并浮到最高
  function npPaintChars() {
    if (!lyrOpen || !refs.lyrScroll || !audio) return;
    if (!lyrData.synced || npActive < 0) return;
    var line = lyrData.lines[npActive];
    if (!line || !line.tokens || !line.tokens.length) return;

    var el = refs.lyrScroll.querySelector('.mu-np-line[data-i="' + npActive + '"]');
    if (!el) return;
    var spans = el.querySelectorAll('.mu-np-ch');
    var t = isFinite(audio.currentTime) ? audio.currentTime : 0;

    for (var k = 0; k < line.tokens.length && k < spans.length; k++) {
      var tk = line.tokens[k];
      var p;
      if (t < tk.t) {
        p = 0;
      } else {
        var end = tk.end != null ? tk.end : (line.tokens[k + 1] ? line.tokens[k + 1].t : tk.t + 0.4);
        var d = end - tk.t;
        p = d > 0.01 ? Math.min(1, (t - tk.t) / d) : 1;
      }
      if (t > tk.t + 0.001) p = Math.max(p, 0.0001);
      if (tk._p == null) tk._p = -1;
      if (Math.abs(p - tk._p) > 0.002 || (p === 0 && tk._p !== 0)) {
        tk._p = p;
        spans[k].style.setProperty('--mu-p', p.toFixed(4));
      }
      var done = p >= 0.999;
      if (done !== spans[k].classList.contains('is-done')) {
        spans[k].classList.toggle('is-done', done);
      }
    }
    var done = 0;
    for (var j = 0; j < line.tokens.length; j++) {
      if (line.tokens[j].t <= t) done++;
      else break;
    }
    line._lit = done;
  }

  function npKaraokeStart() {
    if (npKaraokeId || !lyrOpen || !lyrData.synced) return;
    if (npLayout === 'cover') return;
    npKaraokeId = window.requestAnimationFrame(npKaraokeStep);
  }

  function npKaraokeStop() {
    if (npKaraokeId) {
      window.cancelAnimationFrame(npKaraokeId);
      npKaraokeId = 0;
    }
  }

  function npKaraokeStep() {
    npKaraokeId = 0;
    if (!mounted || !lyrOpen) return;
    npUpdateLyrics(false);
    if (lyrOpen && audio && !audio.paused) {
      npKaraokeId = window.requestAnimationFrame(npKaraokeStep);
    }
  }

  function npPaintProgress() {
    if (!refs.lyrRoot) return;
    var dur = currentDuration();
    var cur = (audio && isFinite(audio.currentTime)) ? Math.max(0, audio.currentTime) : 0;
    if (dur > 0 && cur > dur) cur = dur;
    var ratio = npDragRatio !== null ? npDragRatio : (dur > 0 ? cur / dur : 0);
    var shown = npDragRatio !== null ? ratio * dur : cur;
    var pct = (ratio * 100).toFixed(2) + '%';

    if (refs.npFill) refs.npFill.style.width = pct;
    if (refs.npFill2) refs.npFill2.style.width = pct;
    if (refs.lyrCur) refs.lyrCur.textContent = npFmt(shown);
    if (refs.lyrRemain) refs.lyrRemain.textContent = '-' + npFmt(Math.max(0, dur - shown));
    if (refs.lyrCur2) refs.lyrCur2.textContent = npFmt(shown);
    if (refs.lyrDur2) refs.lyrDur2.textContent = dur > 0 ? npFmt(dur) : '0:00';
  }

  function npPaintVolume() {
    if (!st) return;
    var v = st.muted ? 0 : st.volume;
    if (refs.npVolFill) refs.npVolFill.style.width = (v * 100).toFixed(1) + '%';
  }

  function npSeekRatio(ratio) {
    var dur = currentDuration();
    if (!(dur > 0)) return;
    var t = Math.max(0, Math.min(dur, ratio * dur));
    if (audio) {
      try { audio.currentTime = t; } catch (e) { /* 忽略 */ }
    }
    npPaintProgress();
    npUpdateLyrics(true);
  }

  function npRatioFrom(e) {
    var r = e.currentTarget.getBoundingClientRect();
    if (!r.width) return 0;
    return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
  }

  function npScrubDown(e) {
    if (e.button != null && e.button !== 0) return;
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ }
    npDragRatio = npRatioFrom(e);
    if (e.currentTarget.classList) e.currentTarget.classList.add('is-dragging');
    npPaintProgress();
  }

  function npScrubMove(e) {
    if (npDragRatio === null) return;
    npDragRatio = npRatioFrom(e);
    npPaintProgress();
  }

  function npScrubUp(e) {
    if (npDragRatio === null) return;
    var ratio = npRatioFrom(e);
    npDragRatio = null;
    if (e.currentTarget.classList) e.currentTarget.classList.remove('is-dragging');
    npSeekRatio(ratio);
  }

  function npScrubCancel(e) {
    if (npDragRatio === null) return;
    npDragRatio = null;
    if (e && e.currentTarget && e.currentTarget.classList) {
      e.currentTarget.classList.remove('is-dragging');
    }
    npPaintProgress();
  }

  function npVolDown(e) {
    if (e.button != null && e.button !== 0) return;
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ }
    npVolDrag = true;
    npApplyVol(npRatioFrom(e));
  }

  function npVolMove(e) {
    if (!npVolDrag) return;
    npApplyVol(npRatioFrom(e));
  }

  function npVolUp() {
    npVolDrag = false;
  }

  function npApplyVol(ratio) {
    if (!st || !audio) return;
    st.volume = Math.max(0, Math.min(1, ratio));
    st.muted = st.volume <= 0;
    audio.volume = st.volume;
    audio.muted = false;
    writeLS(LS_VOL, st.volume);
    renderVolume();
  }

  function npOnManualScroll() {
    if (!lyrData.synced) return;
    npManual = true;
    npCancelAnim();
    if (refs.npResume) refs.npResume.hidden = false;
    if (npManualTimer) window.clearTimeout(npManualTimer);
    npManualTimer = window.setTimeout(function () {
      npManualTimer = null;
      if (!lyrOpen) return;
      npManual = false;
      npScrollToActive(true);
    }, 2500);
  }

  function npResumeFollow() {
    npManual = false;
    if (npManualTimer) {
      window.clearTimeout(npManualTimer);
      npManualTimer = null;
    }
    if (refs.npResume) refs.npResume.hidden = true;
    npScrollToActive(true);
  }

  function npOnLineClick(e) {
    if (!lyrData.synced) return;
    var el = e.target.closest ? e.target.closest('.mu-np-line') : null;
    if (!el || !refs.lyrScroll || !refs.lyrScroll.contains(el)) return;
    var i = Number(el.getAttribute('data-i'));
    var line = lyrData.lines[i];
    if (!line || !isFinite(line.t)) return;
    if (audio) {
      try { audio.currentTime = line.t; } catch (err) { /* 忽略 */ }
    }
    npManual = false;
    if (npManualTimer) {
      window.clearTimeout(npManualTimer);
      npManualTimer = null;
    }
    if (refs.npResume) refs.npResume.hidden = true;
    npActive = i;
    npMarkActive();
    npScrollToActive(true);
    npPaintProgress();
  }



  /* ------------------------------ 全屏 ------------------------------ */

  function renderFsButton() {
    if (!refs.fsBtn) return;
    var off = document.body.classList.contains('mu-fs-off');
    if (refs.fsIco) refs.fsIco.innerHTML = svg(off ? 'fsExpand' : 'fsCollapse');
    if (refs.fsLabel) refs.fsLabel.textContent = off ? '铺满窗口' : '收起全屏';
    refs.fsBtn.title = off ? '铺满整个浏览器窗口' : '还原成嵌在页面里';
    refs.fsBtn.setAttribute('aria-pressed', off ? 'false' : 'true');
  }

  function toggleFullscreen() {
    if (!mounted) return;
    var off = document.body.classList.toggle('mu-fs-off');
    renderFsButton();
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(function () { if (mounted) fitHeight(); });
    } else {
      fitHeight();
    }
    toast(off ? '已经还原成嵌在页面里' : '已经铺满整个窗口');
  }

  /* ------------------------------------------------------------
     提示
     ------------------------------------------------------------ */
  function toast(msg) {
    if (!refs.toast || !mounted) return;
    refs.toast.textContent = msg;
    refs.toast.classList.add('is-show');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      if (refs.toast) refs.toast.classList.remove('is-show');
    }, 3200);
  }

  /* ------------------------------------------------------------
     对外接口
     ------------------------------------------------------------ */
  // 供主页面（搜索结果、推荐位）跳过来点名播放：MusicUI.playById(id)
  function playById(id) {
    if (!mounted || !st) return false;
    id = String(id == null ? '' : id);
    if (!id) return false;
    if (!st.byId[id]) {
      st.pendingPlay = id;
      return false;
    }
    st.pendingPlay = null;
    st.queue = st.visibleIds.slice();
    if (st.queue.indexOf(id) < 0) st.queue.push(id);
    playId(id, 'force');
    return true;
  }

  window.MusicUI = {
    mount: mount,
    unmount: unmount,
    playById: playById
  };
})();
