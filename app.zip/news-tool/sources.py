# -*- coding: utf-8 -*-
"""
sources.py — 新闻源清单

全部是「国内可直连」且**内容确实在更新**的 RSS，不需要科学上网。
（2026-09 实测过：人民网、新华网、新浪、环球时报、参考消息这些老的 RSS
  地址早就停更了，内容还停在一两年前，所以没放进来。）

想加源就往 SOURCES 里加一条，字段说明：

    id       唯一标识（英文，存文件名用，别重复）
    name     显示名
    cat      分类，见 CATEGORIES
    url      RSS 地址
    limit    这个源最多取几条（不给就用 DEFAULT_LIMIT）
    timeout  可选，单源超时秒数，慢的源可以调大
    retries  可选，失败重试几次（默认 1；老是超时的源设 0，免得拖慢整轮）
    max_age_days  可选，这个源的内容最多算几天前的（默认看 newsd.py 里的
                  MAX_AGE_DAYS）。更新很慢的源（比如科学类）放宽点，
                  不然抓回来会被整条扔掉。
    web      可选，写 True 表示这是个网页列表页而不是 RSS。
                  政府站基本不提供 RSS，只能当网页扒，就会走这条。

改完不用重启服务 —— 每次抓取都会重新读这个文件。
"""

CATEGORIES = ["科技", "科学", "国内", "教育", "国际", "财经", "游戏"]

# 分类的展示顺序 = CATEGORIES 的顺序，第一个是默认页
DEFAULT_LIMIT = 10

SOURCES = [
    # ═══════════ 科技（主力区，源最多，一定要有） ═══════════
    {"id": "ithome",     "name": "IT之家",     "cat": "科技", "url": "https://www.ithome.com/rss/",           "limit": 12},
    {"id": "cnbeta",     "name": "cnBeta",     "cat": "科技", "url": "https://www.cnbeta.com.tw/backend.php",  "limit": 12},
    {"id": "sspai",      "name": "少数派",     "cat": "科技", "url": "https://sspai.com/feed",                "limit": 10},
    {"id": "ifanr",      "name": "爱范儿",     "cat": "科技", "url": "https://www.ifanr.com/feed",            "limit": 10},
    {"id": "tmtpost",    "name": "钛媒体",     "cat": "科技", "url": "https://www.tmtpost.com/rss.xml",       "limit": 10},
    {"id": "geekpark",   "name": "极客公园",   "cat": "科技", "url": "https://www.geekpark.net/rss",          "limit": 10},
    {"id": "solidot",    "name": "Solidot",    "cat": "科技", "url": "https://www.solidot.org/index.rss",     "limit": 10},
    {"id": "oschina",    "name": "开源中国",   "cat": "科技", "url": "https://www.oschina.net/news/rss",      "limit": 10},
    {"id": "infoq",      "name": "InfoQ中文",  "cat": "科技", "url": "https://www.infoq.cn/feed",             "limit": 8},
    {"id": "leiphone",   "name": "雷锋网",     "cat": "科技", "url": "https://www.leiphone.com/feed",         "limit": 8},
    {"id": "zol",        "name": "中关村在线", "cat": "科技", "url": "https://rss.zol.com.cn/news.xml",       "limit": 8},

    # ═══════════ 科学 ═══════════
    # 这俩更新慢，一个月才发几篇，max_age_days 放宽到 60 天，
    # 否则按默认的 14 天一切，整个科学区就空了。
    # 知识分子服务器 SSL 握手时不时超时，超时短一点、不重试，免得拖慢整轮抓取
    {"id": "zhishifenzi", "name": "知识分子", "cat": "科学", "url": "https://www.zhishifenzi.com/rss",
     "limit": 10, "timeout": 10, "retries": 0, "max_age_days": 60},
    {"id": "kexue",       "name": "科学空间", "cat": "科学", "url": "https://www.kexue.fm/feed",
     "limit": 10, "max_age_days": 60},
    # 前面俩偶尔双双抽风，科学区会整片空掉，加一个科学网兜底
    {"id": "sciencenet",  "name": "科学网", "cat": "科学", "url": "https://www.sciencenet.cn/xml/rss.aspx",
     "limit": 10, "timeout": 12},

    # ═══════════ 国内（中新网各频道，实测更新最勤） ═══════════
    {"id": "cnnews_roll",  "name": "中新网滚动", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/scroll-news.xml", "limit": 10},
    {"id": "cnnews_top",   "name": "中新网要闻", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/importnews.xml",  "limit": 10},
    {"id": "cnnews_china", "name": "中新网国内", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/china.xml",       "limit": 8},
    {"id": "cnnews_soc",   "name": "中新网社会", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/society.xml",    "limit": 8},
    {"id": "cnnews_edu",   "name": "中新网教育", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/edu.xml",        "limit": 6},
    {"id": "cnnews_health","name": "中新网健康", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/health.xml",     "limit": 6},
    {"id": "cnnews_sport", "name": "中新网体育", "cat": "国内", "url": "https://www.chinanews.com.cn/rss/sports.xml",     "limit": 6},

    # ═══════════ 教育（政府站没有 RSS，标 "web": True 当列表页扒） ═══════════
    # 教育部「媒体聚焦」频道，更新很勤，实测每天一两条
    {"id": "moe_news",  "name": "教育部",       "cat": "教育",
     "url": "http://www.moe.gov.cn/jyb_xwfb/s5147/", "web": True, "limit": 10, "timeout": 20},
    # 成都市教育考试院，招生考试信息都在这儿（研考/高考/成考报名通知）
    {"id": "cdzk",      "name": "成都市教育考试院", "cat": "教育",
     "url": "https://www.cdzk.cn/", "web": True, "limit": 10, "timeout": 20},
    # 四川省教育厅，省级政策
    {"id": "sc_edu",    "name": "四川省教育厅",  "cat": "教育",
     "url": "http://edu.sc.gov.cn/", "web": True, "limit": 8, "timeout": 20},

    # ═══════════ 国际 ═══════════
    {"id": "cnnews_world", "name": "中新网国际", "cat": "国际", "url": "https://www.chinanews.com.cn/rss/world.xml", "limit": 10},

    # ═══════════ 财经 ═══════════
    {"id": "wallstreetcn", "name": "华尔街见闻", "cat": "财经", "url": "https://dedicated.wallstreetcn.com/rss.xml", "limit": 10},
    {"id": "jiemian",      "name": "界面新闻",   "cat": "财经", "url": "https://a.jiemian.com/index.php?m=article&a=rss", "limit": 10},
    {"id": "cnnews_fin",   "name": "中新网财经", "cat": "财经", "url": "https://www.chinanews.com.cn/rss/finance.xml", "limit": 8},
    {"id": "xueqiu",       "name": "雪球",       "cat": "财经", "url": "https://xueqiu.com/hots/topic/rss", "limit": 6},

    # ═══════════ 游戏 ═══════════
    {"id": "yystv",  "name": "游研社", "cat": "游戏", "url": "https://www.yystv.cn/rss/feed", "limit": 10},
    {"id": "gcores", "name": "机核",   "cat": "游戏", "url": "https://www.gcores.com/rss",    "limit": 10},
]
