# -*- coding: utf-8 -*-
"""
anime_site.py — 从小站抓番剧（OmoFun 那条链路）

为什么要这个：
  老板说追番别在 B 站下，去小站抓。试了一圈，能通的只有 OmoFun（omofun.in），
  它是标准 MacCMS 站，三段就能拿到真正的 m3u8：

    1. 搜   GET /vod/search.html?wd=<关键词>
            ⚠ 必须带 Referer: https://omofun.in/ ，不带有时候返回空壳
    2. 详情 GET /vod/detail/<id>.html  → 里面是 /vod/play/<id>/ep<N>.html 的列表
    3. 取源 GET /_dyn_plays/<id>/ep<N>  → JSON，video_plays[].play_data 就是 m3u8

  别的站试过但没通：樱花/风车/mxdm 一票 TLS 直接断，ikanbot 播放页 403，
  AGE动漫是 Vue 单页应用、接口逆不出来。所以这里只做 OmoFun，别假装支持一堆。

m3u8 是 HLS：要下就下整张播放列表 + 所有 ts 分片，拼成一个 .ts 文件。
浏览器不能直接播 .ts，得配 hls.js（前端那边的事，这里只负责把文件搞下来）。

⚠ 实测下来这条路**不适合当主功能**，原因写在这儿免得以后踩：
  1. 搜索页时好时坏 —— 同一个 URL，隔一秒重发，有时给 52KB 完整结果，
     有时只给 9.4KB 空壳（没有一条 /vod/detail/）。像风控，也像边缘节点不一致。
  2. 分片下得很慢 —— 一集 424 片，实测 96 秒只下了 20 片，
     整集要半小时往上；学校的 15 分钟联网窗口根本装不下。
  3. 下回来是 .ts，浏览器原生播不了，得再引一个 hls.js（几百 KB）。
  
  所以这个模块留着当"手动工具"用：知道番剧 id 和集数时可以直接拿播放源；
  要真接进「追更」的自动下载，得先解决上面三条，否则体验比 B 站片源还差。
"""

from __future__ import annotations

import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://omofun.in"
REFERER = BASE + "/"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

_OPENER = urllib.request.build_opener(
    urllib.request.ProxyHandler({}),
    urllib.request.HTTPSHandler(context=_CTX),
)


def _get(url: str, referer: str = REFERER, timeout: int = 15) -> bytes:
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/json,*/*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Referer": referer,
    })
    with _OPENER.open(req, timeout=timeout) as r:
        return r.read()


def _text(url: str, referer: str = REFERER, timeout: int = 15) -> str:
    return _get(url, referer, timeout).decode("utf-8", "replace")


def search(keyword: str, limit: int = 20, timeout: int = 15, log=print) -> list[dict]:
    """按名字搜番剧。返回 [{"aid","title","note","url"}]，失败返回 []。"""
    kw = (keyword or "").strip()
    if not kw:
        return []
    url = "%s/vod/search.html?wd=%s" % (BASE, urllib.parse.quote(kw))
    # 这个站时不时回一个只有壳、没有结果的页面（九千多字节那种），
    # 多试两次就好了 —— 实测同一个 URL 隔一秒重发就能拿到完整结果。
    html = ""
    for attempt in range(3):
        try:
            html = _text(url, REFERER, timeout)
        except Exception:  # noqa: BLE001
            html = ""
        if "/vod/detail/" in html:
            break
        time.sleep(1.2)
    if "/vod/detail/" not in html:
        log("[anime_site] 搜「%s」没拿到结果（站点风控？）" % kw)
        return []

    out, seen = [], set()
    # 卡片结构是嵌套 div，<a> 和 </a> 之间可能隔好几百字符，所以别指望一次正则配完。
    # 做法：先按锚点切片，再在「这个锚点到下一个锚点之间」找标题和集数备注。
    marks = list(re.finditer(r'href="(/vod/detail/(\d+)\.html)"([^>]*)>', html))
    for i, m in enumerate(marks):
        path, aid = m.group(1), m.group(2)
        if aid in seen:
            continue
        start = m.end()
        end = marks[i + 1].start() if i + 1 < len(marks) else min(len(html), start + 1200)
        block = html[start:end]
        note_m = re.search(r'module-item-note[^>]*>([^<]{1,30})<', block)
        title = ""
        tm = re.search(r'title="([^"]{1,80})"', m.group(3) or "")
        if tm:
            title = tm.group(1)
        if not title:
            tm = re.search(r'<img[^>]*alt="([^"]{1,80})"', block)
            if tm:
                title = tm.group(1)
        if not title:
            tm = re.search(r'class="module-card-item-title"[^>]*>\s*<a[^>]*>([^<]{1,80})<', block)
            if tm:
                title = tm.group(1)
        if not title:
            continue
        seen.add(aid)
        out.append({
            "aid": aid,
            "title": title.strip(),
            "note": (note_m.group(1).strip() if note_m else ""),
            "url": BASE + path,
        })
        if len(out) >= limit:
            break
    log("[anime_site] 搜「%s」：%d 条" % (kw, len(out)))
    return out


def episodes(aid: str, timeout: int = 15, log=print) -> list[dict]:
    """一部番的集数列表：[{"ep":"ep1","label":"第1话","url":...}]（按集号排序）。"""
    aid = str(aid or "").strip()
    if not aid.isdigit():
        return []
    try:
        html = _text("%s/vod/detail/%s.html" % (BASE, aid), REFERER, timeout)
    except Exception as e:  # noqa: BLE001
        log("[anime_site] 取 %s 详情失败：%s" % (aid, type(e).__name__))
        return []

    out, seen = [], set()
    for m in re.finditer(
            r'href="(/vod/play/%s/(ep\d+)\.html)"[^>]*>([^<]{0,20})<' % aid, html):
        ep = m.group(2)
        if ep in seen:
            continue
        seen.add(ep)
        out.append({
            "ep": ep,
            "label": m.group(3).strip() or ep,
            "url": BASE + m.group(1),
        })

    def key(x):
        n = re.sub(r"\D", "", x["ep"])
        return int(n) if n else 0

    out.sort(key=key)
    log("[anime_site] %s 共 %d 集" % (aid, len(out)))
    return out


def resolve(aid: str, ep: str, timeout: int = 15, log=print) -> list[dict]:
    """拿这一集的播放源：[{"url": m3u8, "site": "mdzy"}]，可能有多条线路。"""
    aid = str(aid or "").strip()
    ep = str(ep or "").strip()
    if not aid.isdigit() or not ep:
        return []
    api = "%s/_dyn_plays/%s/%s" % (BASE, aid, ep)
    play_page = "%s/vod/play/%s/%s.html" % (BASE, aid, ep)
    try:
        raw = _get(api, play_page, timeout)
        data = json.loads(raw.decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        log("[anime_site] 取 %s/%s 播放源失败：%s" % (aid, ep, type(e).__name__))
        return []

    out = []
    for item in data.get("video_plays") or []:
        if not isinstance(item, dict):
            continue
        url = (item.get("play_data") or "").strip()
        if not url.startswith("http"):
            continue
        if ".m3u8" not in url:
            continue        # 只有 m3u8 能下，别的格式先不管
        out.append({"url": url, "site": item.get("src_site") or ""})
    log("[anime_site] %s %s：%d 条线路" % (aid, ep, len(out)))
    return out


def fetch_m3u8(url: str, referer: str = REFERER, timeout: int = 20) -> str:
    """拿播放列表原文。"""
    return _text(url, referer, timeout)


def segments(playlist: str, base_url: str) -> list[str]:
    """把 m3u8 里的分片地址解析成绝对地址（支持 #EXT-X-STREAM-INF 主列表先跳过）。"""
    out = []
    for line in (playlist or "").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        out.append(urllib.parse.urljoin(base_url, s))
    return out


def download_episode(url: str, dest_dir: str, aid: str = "", ep: str = "",
                     max_bytes: int = 600 * 1024 * 1024,
                     log=print) -> dict:
    """把一集（m3u8 + 所有分片）拼成一个 .ts 存下来。

    返回 {"ok","file","bytes","parts","error"}。
    没做转码 —— 浏览器播 .ts 要配合 hls.js，这里只保证文件是完整的。
    """
    res = {"ok": False, "file": "", "bytes": 0, "parts": 0, "error": ""}
    try:
        text = fetch_m3u8(url)
    except Exception as e:  # noqa: BLE001
        res["error"] = "播放列表拿不到：%s" % type(e).__name__
        return res

    # 主列表（多码率）：取其一带宽最高的
    if "#EXT-X-STREAM-INF" in text:
        variants = [urllib.parse.urljoin(url, l.strip())
                    for l in text.splitlines()
                    if l.strip() and not l.strip().startswith("#")]
        if not variants:
            res["error"] = "主列表里没有子列表"
            return res
        url = variants[-1]
        try:
            text = fetch_m3u8(url)
        except Exception as e:  # noqa: BLE001
            res["error"] = "子播放列表拿不到：%s" % type(e).__name__
            return res

    segs = segments(text, url)
    if not segs:
        res["error"] = "播放列表里没有分片"
        return res

    os.makedirs(dest_dir, exist_ok=True)
    name = "anime_%s_%s.ts" % (aid or "x", ep or time.strftime("%H%M%S"))
    path = os.path.join(dest_dir, name)
    got = 0
    try:
        with open(path, "wb") as f:
            for i, seg in enumerate(segs, 1):
                blob = _get(seg, url, 30)
                f.write(blob)
                got += len(blob)
                if got > max_bytes:
                    res["error"] = "超过体积上限，先存到这里"
                    break
                if i % 20 == 0:
                    log("[anime_site] %s 已下 %d/%d 片" % (name, i, len(segs)))
    except Exception as e:  # noqa: BLE001
        res["error"] = res["error"] or ("下载中断：%s" % type(e).__name__)
        try:
            os.remove(path)
        except OSError:
            pass
        return res

    res.update(ok=got > 0, file=path, bytes=got, parts=len(segs))
    return res


if __name__ == "__main__":
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    print("=== 搜 ===")
    hits = search("凡人修仙传")
    for h in hits[:3]:
        print("  ", h["aid"], h["title"], "|", h["note"])
    if hits:
        aid = hits[0]["aid"]
        print("=== 集数 ===")
        eps = episodes(aid)
        print("  共", len(eps), "集；前 3:", [(e["ep"], e["label"]) for e in eps[:3]])
        if eps:
            print("=== 播放源 ===")
            src = resolve(aid, eps[0]["ep"])
            for s in src[:3]:
                print("  ", s["site"], s["url"][:90])

def _seg_dir(dest_dir: str, key: str) -> str:
    return os.path.join(dest_dir, ".parts_" + re.sub(r"[^0-9A-Za-z_\-]", "_", key))


def download_episode_resume(url: str, dest_dir: str, key: str,
                            max_segments: int = 0, timeout: int = 25,
                            on_progress=None, log=print) -> dict:
    """分段下载，可中断、可续传。

    为什么这么写：学校的热点只开十几分钟，一集 400 多个分片根本下不完。
    所以下到的每一片都单独落盘，下次联网从缺的那一片接着下，
    跟种子断点续传一个道理。

    目录结构：
        dest/.parts_<key>/manifest.json    分片地址清单 + 说明
        dest/.parts_<key>/seg_00001.ts     一片一个文件
    全下完之后拼成 dest/<key>.ts（原来是啥名就啥名）。

    返回 {"ok","file","bytes","parts","total","done","error","finished"}
    finished=False 表示还没下完（被 max_segments 掐断或者中途断网）。
    """
    res = {"ok": False, "file": "", "bytes": 0, "parts": 0, "total": 0,
           "done": 0, "error": "", "finished": False}
    home = _seg_dir(dest_dir, key)
    mpath = os.path.join(home, "manifest.json")
    segs = []
    try:
        text = fetch_m3u8(url)
        if "#EXT-X-STREAM-INF" in text:
            variants = [urllib.parse.urljoin(url, l.strip())
                        for l in text.splitlines()
                        if l.strip() and not l.strip().startswith("#")]
            if variants:
                url = variants[-1]
                text = fetch_m3u8(url)
        segs = segments(text, url)
    except Exception as e:  # noqa: BLE001
        # 播放列表拉不到：如果之前下过，就照旧清单接着下（离线续传）
        old = None
        try:
            with open(mpath, "r", encoding="utf-8") as f:
                old = json.load(f)
        except (OSError, ValueError):
            old = None
        if not old or not old.get("segments"):
            res["error"] = "播放列表拿不到：%s" % type(e).__name__
            return res
        segs = old["segments"]
        url = old.get("url") or url
        log("[anime_site] 播放列表拉不到，用上次的清单接着下")

    if not segs:
        res["error"] = "播放列表里没有分片"
        return res

    os.makedirs(home, exist_ok=True)
    try:
        with open(mpath, "w", encoding="utf-8") as f:
            json.dump({"url": url, "segments": segs, "saved": time.strftime(
                "%Y-%m-%d %H:%M:%S")}, f, ensure_ascii=False, indent=1)
    except OSError as e:
        res["error"] = "清单写不进去：%s" % e
        return res

    done = 0
    fetched_new = 0
    for i, seg in enumerate(segs, 1):
        name = "seg_%05d.ts" % i
        path = os.path.join(home, name)
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            done += 1
            continue
        if max_segments and fetched_new >= max_segments:
            res["error"] = "到了本轮上限，剩下的下次接着下"
            break
        try:
            blob = _get(seg, url, timeout)
        except Exception as e:  # noqa: BLE001
            res["error"] = "第 %d 片下不动（%s），下次再试" % (i, type(e).__name__)
            break
        try:
            with open(path, "wb") as f:
                f.write(blob)
        except OSError as e:
            res["error"] = "写盘失败：%s" % e
            break
        done += 1
        fetched_new += 1
        if on_progress:
            try:
                on_progress({"done": done, "total": len(segs),
                             "fetched": fetched_new})
            except Exception:  # noqa: BLE001
                pass

    res.update(parts=fetched_new, total=len(segs), done=done)
    if done >= len(segs):
        # 全了，拼成一个文件；拼完把分片目录删掉省地方
        out = os.path.join(dest_dir, re.sub(r"[^0-9A-Za-z_\-]", "_", key) + ".ts")
        tmp = out + ".part"
        try:
            with open(tmp, "wb") as w:
                for i in range(1, len(segs) + 1):
                    p = os.path.join(home, "seg_%05d.ts" % i)
                    if not os.path.isfile(p):
                        raise OSError("缺分片 %d" % i)
                    with open(p, "rb") as r:
                        while True:
                            chunk = r.read(1 << 20)
                            if not chunk:
                                break
                            w.write(chunk)
            os.replace(tmp, out)
            res.update(ok=True, finished=True, file=out,
                       bytes=os.path.getsize(out))
            try:
                import shutil as _sh
                _sh.rmtree(home, ignore_errors=True)
            except Exception:  # noqa: BLE001
                pass
            log("[anime_site] %s 拼好了：%.1f MB"
                % (os.path.basename(out), res["bytes"] / 1048576.0))
        except Exception as e:  # noqa: BLE001
            res["error"] = "拼接失败：%s" % type(e).__name__
            try:
                os.remove(tmp)
            except OSError:
                pass
    else:
        res["error"] = res["error"] or "还没下完"
    return res
