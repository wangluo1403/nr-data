# -*- coding: utf-8 -*-
"""
library.py — 收藏夹、归档、阅读记录

规则（用户定的，别自己改）：

  - 一个东西**打开过又关掉**，就算"看完"，进归档，从主列表里挪走
  - **收藏过的东西永远不归档**，就算关掉了也留在收藏列表
  - 归档里的东西要能搜、能重新下载（联网的时候再抓一遍）
  - 记录存 data/library.json，跟快照分开 —— 快照会被 _prune() 删掉，
    但用户的收藏和"我看过什么"不该跟着消失

每条记录长这样：

    "news:8f3a...": {
        "key":   "news:8f3a...",     # "<kind>:<原 id>"
        "kind":  "news",             # news / video / music / search / anime / mirror
        "rid":   "8f3a...",          # 原来那个 id
        "title": "...",
        "sub":   "来源 ・ 时间",      # 列表上第二行
        "cat":   "科技",
        "url":   "https://...",      # 重新下载要用
        "image": "images/xxx.jpg",
        "ts":    1759...             # 内容自己的时间
        "fav":   false,
        "read":  false,
        "archived": false,
        "opened_ts": 0,
        "finished_ts": 0,
        "added_ts": 1759...
    }

只有"碰过"的东西才会进这张表 —— 没点开过、没收藏过的，不占地方。
主列表还是从快照 / videos.json / music.json 那些索引里读。
"""

from __future__ import annotations

import json
import os
import threading
import time

KINDS = ("news", "video", "music", "search", "anime", "mirror", "bili")

# 归档留多久（天）。收藏的不管多久都留着。
ARCHIVE_DAYS = 60


def _now() -> float:
    return time.time()


def _fmt(ts: float) -> str:
    if not ts:
        return ""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


class Library:
    def __init__(self, path: str, log=print):
        self.path = path
        self.log = log
        self._lock = threading.RLock()
        self._recs: dict[str, dict] = {}
        self.load()

    # ---------- 读写 ----------

    def load(self) -> None:
        with self._lock:
            data = None
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = None
            recs = (data or {}).get("records") if isinstance(data, dict) else None
            if not isinstance(recs, dict):
                recs = {}
            clean = {}
            for k, v in recs.items():
                if not isinstance(v, dict) or not isinstance(k, str):
                    continue
                if ":" not in k:
                    continue
                kind, rid = k.split(":", 1)
                clean[k] = {
                    "key": k, "kind": kind, "rid": rid,
                    "title": str(v.get("title") or ""),
                    "sub": str(v.get("sub") or ""),
                    "cat": str(v.get("cat") or ""),
                    "url": str(v.get("url") or ""),
                    "image": str(v.get("image") or ""),
                    "ts": float(v.get("ts") or 0),
                    "fav": bool(v.get("fav")),
                    "read": bool(v.get("read")),
                    "archived": bool(v.get("archived")),
                    "opened_ts": float(v.get("opened_ts") or 0),
                    "finished_ts": float(v.get("finished_ts") or 0),
                    "added_ts": float(v.get("added_ts") or _now()),
                    "size": int(v.get("size") or 0),
                }
            self._recs = clean

    def save(self) -> None:
        with self._lock:
            body = json.dumps({
                "saved_at": _fmt(_now()),
                "records": self._recs,
            }, ensure_ascii=False, indent=1)
        tmp = self.path + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(body)
            os.replace(tmp, self.path)
        except OSError as e:
            self.log("收藏夹写不进去：%s" % e)

    # ---------- 记录 ----------

    @staticmethod
    def make_key(kind: str, rid: str) -> str:
        return "%s:%s" % (kind, (rid or "").strip())

    def upsert(self, kind: str, rid: str, meta: dict | None = None) -> dict:
        """记下"有这么个东西"（收藏或点开时调）。已有的字段不会被空值覆盖。"""
        key = self.make_key(kind, rid)
        with self._lock:
            rec = self._recs.get(key)
            if rec is None:
                rec = {
                    "key": key, "kind": kind, "rid": rid,
                    "title": "", "sub": "", "cat": "", "url": "", "image": "",
                    "ts": 0.0, "fav": False, "read": False, "archived": False,
                    "opened_ts": 0.0, "finished_ts": 0.0, "added_ts": _now(),
                    "size": 0,
                }
                self._recs[key] = rec
            for k, v in (meta or {}).items():
                if k in ("key", "kind", "rid"):
                    continue
                if k in rec and (v is not None) and (v != "" or not rec.get(k)):
                    rec[k] = v
            out = dict(rec)
        self.save()
        return out

    def get(self, key: str) -> dict | None:
        with self._lock:
            rec = self._recs.get(key)
            return dict(rec) if rec else None

    def set_fav(self, key: str, on: bool) -> dict | None:
        """收藏 / 取消收藏。收藏等于"钉住"：不会被归档挪走。"""
        with self._lock:
            rec = self._recs.get(key)
            if rec is None:
                return None
            rec["fav"] = bool(on)
            if on:
                rec["archived"] = False
                rec["archived_ts"] = 0
            out = dict(rec)
        self.save()
        return out

    def mark_opened(self, kind: str, rid: str, meta: dict | None = None) -> dict:
        """点开时记一笔。"""
        rec = self.upsert(kind, rid, meta)
        with self._lock:
            r = self._recs.get(rec["key"])
            if r:
                r["opened_ts"] = _now()
        self.save()
        return rec

    def mark_finished(self, key: str) -> dict | None:
        """关掉阅读/播放面板 = 看完。收藏的不归档，没收藏的进归档。"""
        with self._lock:
            rec = self._recs.get(key)
            if rec is None:
                return None
            rec["read"] = True
            rec["finished_ts"] = _now()
            if not rec["fav"]:
                rec["archived"] = True
                rec["archived_ts"] = _now()
            out = dict(rec)
        self.save()
        return out

    def set_archived(self, key: str, on: bool) -> dict | None:
        with self._lock:
            rec = self._recs.get(key)
            if rec is None:
                return None
            rec["archived"] = bool(on) and not rec["fav"]
            rec["archived_ts"] = _now() if rec["archived"] else 0
            out = dict(rec)
        self.save()
        return out

    def forget(self, key: str) -> bool:
        with self._lock:
            if key not in self._recs:
                return False
            del self._recs[key]
        self.save()
        return True

    # ---------- 查询 ----------

    def listing(self, kind: str = "", q: str = "", archived=None,
                fav=None, limit: int = 500) -> list[dict]:
        """筛记录。
        archived=None 表示不管归没归档；True/False 是明确要求。
        """
        ql = (q or "").strip().lower()
        out = []
        with self._lock:
            for rec in self._recs.values():
                if kind and rec["kind"] != kind:
                    continue
                if archived is not None and bool(rec["archived"]) != bool(archived):
                    continue
                if fav is not None and bool(rec["fav"]) != bool(fav):
                    continue
                if ql:
                    hay = " ".join([rec["title"], rec["sub"], rec["cat"], rec["url"]]).lower()
                    if ql not in hay:
                        continue
                out.append(dict(rec))
        out.sort(key=lambda r: (r.get("finished_ts") or r.get("opened_ts")
                                or r.get("added_ts") or 0), reverse=True)
        return out[:limit]

    def counts(self) -> dict:
        with self._lock:
            favs = sum(1 for r in self._recs.values() if r["fav"])
            arch = sum(1 for r in self._recs.values() if r["archived"] and not r["fav"])
            read = sum(1 for r in self._recs.values() if r["read"])
            return {"total": len(self._recs), "favs": favs,
                    "archived": arch, "read": read}

    def status(self) -> dict:
        c = self.counts()
        c["archive_days"] = ARCHIVE_DAYS
        return c

    # ---------- 维护 ----------

    def prune(self, days: int = ARCHIVE_DAYS) -> int:
        """老归档清掉。收藏的和还没归档的一律不动。"""
        cut = _now() - max(0, days) * 86400
        with self._lock:
            dropped = [k for k, r in self._recs.items()
                       if r["archived"] and not r["fav"]
                       and (r.get("finished_ts") or 0) < cut]
            for k in dropped:
                del self._recs[k]
        if dropped:
            self.save()
        return len(dropped)


if __name__ == "__main__":
    import tempfile
    d = tempfile.mkdtemp()
    lib = Library(os.path.join(d, "library.json"))
    lib.mark_opened("news", "a1", {"title": "标题一", "url": "http://x"})
    lib.set_fav("news:a1", True)
    lib.mark_finished("news:a1")
    rec = lib.get("news:a1")
    assert rec["fav"] and not rec["archived"], rec      # 收藏的不归档
    lib.mark_opened("news", "a2", {"title": "标题二"})
    lib.mark_finished("news:a2")
    assert lib.get("news:a2")["archived"], "没收藏的应该归档"
    assert len(lib.listing(archived=True)) == 1
    assert len(lib.listing(fav=True)) == 1
    lib2 = Library(os.path.join(d, "library.json"))
    assert lib2.counts()["favs"] == 1, lib2.counts()
    print("library.py 自测通过", lib2.counts())
